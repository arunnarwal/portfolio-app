/***
<View>
	<Description>Returns charge details for account - used in TH docs</Description>
</View>
***/

CREATE PROCEDURE [Charges].[spGetAccountChargeTiersDetails]
(
	@AccountId INT,
	@TranType VARCHAR(50)
)
AS
--test
--DECLARE @AccountId INT
--DECLARE @TranType SMALLINT
--SET @AccountId  = 664
--SET @TranType = ''

SELECT 
	seca.Id As AccountId, 
	seca.ClaccountId As ClaccountId,
	pd.ProductType As ProductType, 
	pwst.ProductWrapperSubType As ProductSubType,
	c.ChargeId,
	ct.ChargeTypeName As ChargeTypeName,
	ct.TranType As TranType,
	tct.Rate As Rate,
	tb.LowerLimit As LowerLimit,
	tb.UpperLimit As UpperLimit
FROM dbo.SEClientAccount seca
	INNER JOIN Discovery.dbo.ProductDetails pd on pd.ClAccountId = seca.ClAccountId
	INNER JOIN [Platform].ChargeConfig.ProductWrapperSubTypes pwst on pwst.ProductWrapperSubTypeId = pd.ProductSubTypeId
	INNER JOIN [Platform].ChargeConfig.ProductWrapperTypes pwt ON pd.ProductType = pwt.ProductType
	inner join [Platform].Charges.Charges c on c.ProductWrapperSubTypeId = pd.ProductSubTypeId  AND c.ProductWrapperTypeId = pwt.ProductWrapperTypeId
	INNER JOIN [Platform].Charges.TieredCharges tc ON tc.TieredChargeId = c.ChargeId
	INNER JOIN [Platform].ChargeConfig.ChargeTypes ct ON c.ChargeTypeId = ct.ChargeTypeId 
	INNER JOIN [Platform].ChargeConfig.ChargeTimetables ctt ON ctt.ChargeTimetableId = ct.ChargeTimetableId 
	INNER JOIN [Platform].Charges.TieredChargeTiers tct ON tct.TieredChargeId = tc.TieredChargeId
	INNER JOIN [Platform].Charges.TierBoundaries tb ON tb.TierBoundaryId = tct.TierBoundaryId
WHERE seca.Id = @AccountId AND ct.TranType = @TranType