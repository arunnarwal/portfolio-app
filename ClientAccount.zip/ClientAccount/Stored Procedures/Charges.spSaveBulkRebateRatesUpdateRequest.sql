/***
<StoredProcedure>
    <Description>Saves a bulk request to save or update rebate rates</Description>
    <Service>Charges</Service>
    <Feature>Charges</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE Charges.spSaveBulkRebateRatesUpdateRequest (
	@EntityType VARCHAR(20),
	@EntityName VARCHAR(20),
	@OriginalFileName VARCHAR(1024),
	@DocumentsStoreId INT,	
	@UserId INT, 
	@BulkRebateRateUpdateRequestId INT OUTPUT)
AS
BEGIN

	BEGIN TRY		

		INSERT INTO dbo.BulkRebateRateUpdateRequests (
			EntityType,
			EntityName,
			OriginalFileName,
			DocumentStoreId,
			Status,
			UserRequested,
			DateRequested)
		VALUES (
			@EntityType,
			@EntityName,
			@OriginalFileName,
			@DocumentsStoreId,
			'Pending',
			@UserId,
			GETDATE()
		)

		SET @BulkRebateRateUpdateRequestId = SCOPE_IDENTITY()				

	END TRY
	BEGIN CATCH
		PRINT 'Saving bulk rebate rate request failed';
		THROW;
	END CATCH
END
GO

