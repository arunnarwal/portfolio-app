/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>A2BDA2A88F96378A72383C1DFCFE2E38</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[spAMCRebateInvoicesForReport](
               @DateFrom    DATETIME,
               @DateTo      DATETIME,
               @ClAccountId VarChar(20)  = NULL)
WITH EXECUTE AS caller
AS

  /*declare @DateFrom datetime, @DateTo datetime, @ClAccountID varchar(20) 
  select @DateFrom = '1 Jun 2012', @DateTo = '1 Jul 2012', @ClAccountID = 'UKW1091'*/

  SELECT fad.instrumentcode,
         Sum(fad.totalamount)                    AS totalamount,
         Abs(Sum(fad.totalamount))               AS amount,
         Coalesce(ao.claccountid,fm.claccountid) AS claccountid,
         i.managerid,
         i.displayname                           AS fundname,
         Dateadd(m,-1,fad.chargedate)            AS fromdate,
         Dateadd(d,-1,fad.chargedate)            AS todate,
         co.wrapprovider
  FROM     clientaccount..feeaccrualdetail2 AS fad
           INNER JOIN res_db..instruments AS i
             ON fad.instrumentcode = i.security
           INNER JOIN res_db..managedfunds AS mf
             ON i.security = mf.instrumentcode
           LEFT OUTER JOIN res_db..fundmanager AS fm
             ON i.managerid = fm.managerid
           LEFT OUTER JOIN res_db..fundmanageraccountoverrides AS ao
             ON ao.instrumentcode = i.security
           INNER JOIN clientaccount..clientdetails AS cd
             ON fad.claccountid = cd.claccountid
           INNER JOIN discovery.dbo.clientaccount AS ca
             ON fad.claccountid = ca.claccountid
           INNER JOIN clientaccount..company AS co
             ON co.company = cd.company
  WHERE    fad.TYPE = 'MFR'
           AND fad.category = 'AMC'
           AND fad.asat >= @DateFrom
           AND fad.asat < @DateTo
           AND ca.subaccounttype IN ('PEP','ISA','SIPP','ONSHORE BOND',
                                     'OFFSHORE BOND','PERSONAL PORTFOLIO','RETAIL BOND','RETAIL SIPP',
                                     'Platform Fund','JISA')
           AND Coalesce(ao.claccountid,fm.claccountid) = Isnull(@ClAccountID,Coalesce(ao.claccountid,fm.claccountid))
  GROUP BY fad.instrumentcode,
           Coalesce(ao.claccountid,fm.claccountid),
           fad.chargedate,
           i.managerid,
           i.displayname,
           co.wrapprovider
  HAVING   Round(Sum(fad.totalamount),2) <> 0
  ORDER BY Coalesce(ao.claccountid,fm.claccountid),
           fad.instrumentcode

GO
