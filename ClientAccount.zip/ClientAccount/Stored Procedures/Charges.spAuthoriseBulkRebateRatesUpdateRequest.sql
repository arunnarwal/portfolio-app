/***
<StoredProcedure>
    <Description>Authorises a bulk request to save or update rebate rates. Writes valid records to final table and failed ones to failed table</Description>
    <Service>Charges</Service>
    <Feature>Charges</Feature>
	<Parameters>
		<Parameter Name="@BulkRequestId">
			<Description>Id of bulk rebate rates update request</Description>
		</Parameter>
		<Parameter Name="@UserId">
			<Description>Authorised by</Description>
		</Parameter>		
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE Charges.spAuthoriseBulkRebateRatesUpdateRequest (
	@BulkRequestId INT, 
	@UserId INT)
AS
BEGIN
	BEGIN TRY
	BEGIN TRANSACTION
		DECLARE @Today DATE = GETDATE()
		DECLARE @Tomorrow DATE = DateAdd(day, 1, GETDATE())
		
		DECLARE @RebateRateRequestId INT
		DECLARE @InstrumentID INT
		DECLARE @BundledRate NUMERIC(9,6)
		DECLARE @UnBundledRate NUMERIC(9,6)
		DECLARE @TrailRate NUMERIC(9,6)
		DECLARE @CompanyId INT
		DECLARE @RowIndex INT = 1
		DECLARE @RowCount INT

		IF NOT EXISTS (SELECT 1 FROM dbo.BulkRebateRateUpdateRequests WHERE BulkRebateRateUpdateRequestID = @BulkRequestId AND [Status] = 'Pending')
		BEGIN
			RAISERROR('Request does not exist', 16, 1)
		END
		
		DECLARE @EntityType VARCHAR(20)
		DECLARE @EntityName VARCHAR(20)
		DECLARE @EntityId INT
		
		SELECT @EntityType = EntityType, @EntityName = EntityName FROM dbo.BulkRebateRateUpdateRequests WHERE BulkRebateRateUpdateRequestID = @BulkRequestId
		
		IF (@EntityType = 'SystemProvider' and @EntityName = 'FNZ') --only supported type for day 1
		BEGIN
			SELECT @EntityID = ID FROM dbo.SystemProvider WHERE SystemProvider = @EntityName
			
			SELECT 
				RRUR.RebateRateUpdateRequestId, 
				RRUR.BulkRebateRateUpdateRequestId, 
				INS.Id AS InstrumentId, 
				RRUR.BundledRate, 
				RRUR.UnbundledRate, 
				RRUR.TrailRate,
				ROW_NUMBER() OVER(ORDER BY RRUR.RebateRateUpdateRequestId) AS RowIndex
			INTO #RatesToProcess
			FROM dbo.RebateRateUpdateRequests RRUR
			INNER JOIN Res_db.dbo.Instruments INS ON RRUR.InstrumentIsIn = INS.ISINCode
			WHERE RRUR.BulkRebateRateUpdateRequestId = @BulkRequestId
			AND NOT EXISTS(
				SELECT 1 FROM dbo.RebateBySystemProvider RBS WHERE RBS.ProviderID = @EntityId AND RBS.InstrumentsID = INS.ID AND RBS.FromDate > @Tomorrow
			)

			CREATE NONCLUSTERED INDEX IDX_RowIndex ON #RatesToProcess(RowIndex)

			SELECT @RowCount = MAX(RowIndex) FROM #RatesToProcess
			
			WHILE (@RowIndex <= @RowCount)
			BEGIN
				SELECT 
					@RebateRateRequestId = RebateRateUpdateRequestId, 
					@InstrumentId = InstrumentId,
					@BundledRate = BundledRate,
					@UnbundledRate = UnbundledRate,
					@TrailRate = TrailRate
				FROM #RatesToProcess 
				WHERE RowIndex = @RowIndex	
				
				IF EXISTS(SELECT 1 FROM dbo.RebateBySystemProvider 
					WHERE ProviderID = @EntityId AND InstrumentsID = @InstrumentId  AND FromDate = @Tomorrow) 
				BEGIN
					UPDATE dbo.RebateBySystemProvider
					SET BundledRate = @BundledRate, 
						UnBundledRate = @UnBundledRate, 
						TrailRate = @TrailRate,
						RebateRequestId = @RebateRateRequestId,
						BulkRebateRequestId = @BulkRequestId 
					WHERE InstrumentsId = @InstrumentId 
					AND ProviderID = @EntityId
					AND FromDate = @Tomorrow
				END
				ELSE
				BEGIN
					UPDATE dbo.RebateBySystemProvider
					SET ToDate = @Today
					WHERE ProviderID = @EntityId 
					AND InstrumentsID = @InstrumentID 
					AND (ToDate IS NULL OR ToDate >= @Today)

					INSERT INTO dbo.RebateBySystemProvider
					(ProviderID, InstrumentsID, Rate, UnbundledRate, BundledRate, TrailRate, FromDate, ToDate, RebateRequestId, BulkRebateRequestId) 
					VALUES(@EntityId, @InstrumentID, 0, @UnBundledRate, @BundledRate, @TrailRate, @Tomorrow, NULL, @RebateRateRequestId, @BulkRequestId)
				END	

				SET @RowIndex = @RowIndex + 1
			END
	
			INSERT INTO dbo.FailedRebateRateUpdateRequests (RebateRateUpdateRequestId, FailReason)
			SELECT 
				RRUR.RebateRateUpdateRequestId,
				CASE 
					WHEN INS.Id IS NULL THEN 'InvalidInstrument'
					WHEN RBS.Id IS NOT NULL THEN 'FutureRateExists'
				END AS FailReason
			FROM dbo.RebateRateUpdateRequests RRUR
			LEFT JOIN Res_db.dbo.Instruments INS 
				ON RRUR.InstrumentIsin = INS.ISINCode
			LEFT JOIN dbo.RebateBySystemProvider RBS 
				ON RBS.ProviderId = @EntityId AND RBS.InstrumentsId = INS.Id AND RBS.FromDate > @Tomorrow
			WHERE RRUR.BulkRebateRateUpdateRequestId = @BulkRequestId
			AND (RBS.ID IS NOT NULL OR INS.Id IS NULL)

			UPDATE dbo.BulkRebateRateUpdateRequests
			SET [Status] = 'Authorised',
				UserAuthorised = @UserId, 
				DateAuthorised = GETDATE() 
			WHERE [BulkRebateRateUpdateRequestID] = @BulkRequestId
			
			DROP TABLE #RatesToProcess
		END

		IF @EntityType = 'Company'
		BEGIN
			SELECT 
				RRUR.RebateRateUpdateRequestId, 
				RRUR.BulkRebateRateUpdateRequestId, 
				INS.Id AS InstrumentId,
				COM.ID AS CompanyId,
				RRUR.UnBundledRate,
				ROW_NUMBER() OVER(ORDER BY RRUR.RebateRateUpdateRequestId) AS RowIndex
			INTO #EnhancedRatesToProcess
			FROM dbo.RebateRateUpdateRequests RRUR
			INNER JOIN Res_db.dbo.Instruments INS ON INS.ISINCode = RRUR.InstrumentIsIn
			INNER JOIN dbo.Company COM ON COM.Company = RRUR.Company
			WHERE RRUR.BulkRebateRateUpdateRequestId = @BulkRequestId
			AND NOT EXISTS(
				SELECT 1 FROM dbo.RebateByCompany RBC 
				WHERE RBC.CompanyID = COM.ID AND RBC.InstrumentsID = INS.ID AND RBC.FromDate > @Tomorrow
			)

			CREATE NONCLUSTERED INDEX IDX_RowIndex ON #EnhancedRatesToProcess(RowIndex)

			SELECT @RowCount = MAX(RowIndex) FROM #EnhancedRatesToProcess

			WHILE(@RowIndex <= @RowCount)
			BEGIN
				SELECT 
					@RebateRateRequestId = RebateRateUpdateRequestId,
					@InstrumentID = InstrumentId,
					@CompanyId = CompanyId,
					@UnBundledRate = UnBundledRate
				FROM #EnhancedRatesToProcess 
				WHERE RowIndex = @RowIndex

				IF EXISTS(SELECT 1 FROM dbo.RebateByCompany RBC 
					WHERE RBC.InstrumentsID = @InstrumentID AND RBC.CompanyID = @CompanyId AND RBC.FromDate = @Tomorrow)
				BEGIN
					UPDATE dbo.RebateByCompany
					SET UnBundledRate = @UnBundledRate,
					RebateRequestId = @RebateRateRequestId
					WHERE InstrumentsID = @InstrumentID
					AND CompanyID = @CompanyId
					AND FromDate = @Tomorrow
				END
				ELSE
				BEGIN
					UPDATE dbo.RebateByCompany
					SET ToDate = @Today
					WHERE InstrumentsID = @InstrumentID
					AND CompanyID = @CompanyId
					AND (ToDate IS NULL OR ToDate >= @Today)

					INSERT INTO dbo.RebateByCompany(CompanyID, InstrumentsID, Rate, UnbundledRate, BundledRate, TrailRate, FromDate, ToDate, RebateRequestId, BulkRebateRequestId) 
					VALUES(@CompanyId, @InstrumentID, 0, @UnBundledRate, 0, 0, @Tomorrow, NULL, @RebateRateRequestId, @BulkRequestId)
				END	

				SET @RowIndex = @RowIndex + 1
			END

			INSERT INTO dbo.FailedRebateRateUpdateRequests (RebateRateUpdateRequestId, FailReason)
			SELECT 
				RRUR.RebateRateUpdateRequestId,
				CASE
					WHEN INS.ID IS NULL THEN 'InvalidInstrument'
					WHEN RBC.ID IS NOT NULL THEN 'FutureRateExists'
				END AS FailReason
			FROM dbo.RebateRateUpdateRequests RRUR
			LEFT JOIN Res_db.dbo.Instruments INS ON RRUR.InstrumentIsIn = INS.ISINCode
			LEFT JOIN dbo.Company COM ON COM.Company = RRUR.Company
			LEFT JOIN dbo.RebateByCompany RBC ON RBC.InstrumentsID = INS.ID AND RBC.CompanyID = COM.ID AND RBC.FromDate > @Tomorrow
			WHERE RRUR.BulkRebateRateUpdateRequestId = @BulkRequestId
			AND (RBC.ID IS NOT NULL OR INS.ID IS NULL)

			UPDATE dbo.BulkRebateRateUpdateRequests
			SET [Status] = 'Authorised', 
				UserAuthorised = @UserId, 
				DateAuthorised = GETDATE() 
			WHERE [BulkRebateRateUpdateRequestID] = @BulkRequestId

			DROP TABLE #EnhancedRatesToProcess
		END
	
	COMMIT TRANSACTION
	END TRY

	BEGIN CATCH
		PRINT 'Authorising bulk rebate rate request failed';
		ROLLBACK TRANSACTION
		THROW;
	END CATCH
END
GO