/***
<StoredProcedure>
	<Description>Gets the onging adviser charge tier rates for the specified day</Description>
	<Parameters>
		<Parameter Name="@AsAt">
			<Description>the day data required for</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE ChargeProcessing.spGetOngoingAdviserChargeTieredRates @AsAt DATE AS

	SELECT
		cfs.Id AS FbrcId,
		tb.LowerLimit,
		tb.UpperLimit,
		tst.Rate
	FROM dbo.ClientFBRCSettings cfs
	INNER JOIN Charges.TierStructureTiers tst ON tst.TierStructureId = cfs.TierStructureId
	INNER JOIN Res_DB.Charges.TierBoundaries tb on tb.TierBoundaryId = tst.TierBoundaryId
	INNER JOIN 
		(SELECT ClAccountId,MAX(AsAt) AS AsAt, MAX(Id) AS Id
		FROM dbo.ClientFBRCSettings
		WHERE AsAt <= @AsAt
		GROUP BY ClAccountId) LatestDate
		ON LatestDate.ClAccountId = cfs.ClAccountId
		AND LatestDate.AsAt = cfs.AsAt
		AND LatestDate.Id = cfs.Id
	WHERE cfs.Active = 1
	
