/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>E86D7C62DB43E84D2733B6633BE77AD3</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[spClientChangesAndPaymentOutByWrapProvider](@FromDate As DateTime, @ToDate As DateTime, @WrapProvider As Varchar(20))
AS


/*Declare @FromDate As dateTime;
Declare @ToDate As DateTime;
Declare @WrapProvider AS Varchar(20);
Set @FromDate = '2014-01-06';
Set @ToDate = '2014-03-20';
Set @WrapProvider = 'AXA';*/


Declare @FromDateMinus30Days As DateTime;
Set @FromDateMinus30Days = DATEADD(day, -30, @FromDate);

With ClientChanges(InvestorType, ClaccountId, AdviserName, CompanyName, AdviserPostCode, Company, EditedBy, EditedAt, FieldName, OriginalValue, NewValue, HolderNumber, Residential) As (

	Select
		SE.InvestorType,
		CCL.ClaccountId,
		ADV.Name,
		CO.CompanyName,
		ADV.PostCode,
		CO.Company,
		CLT.FullName,
		CCL.DateModified,
		CCL.FieldName,
		CCL.OriginalValue,
		CCL.NewValue, 
		AD.HolderNumber,
		Case
			When AD.PostalAddress = 'Yes' Then 0
			Else 1
		End From
	ClientAccount..ClientChangeLog CCL
	Inner Join Discovery..Address AD
		On CCL.Identifier = AD.ID
	Inner Join ClientAccount..SEClientAccount SE
		On CCL.ClaccountID = SE.ClaccountId and SE.InvestorType In ('INDIVIDUAL', 'JOINT_INDIVIDUAL')
	Inner Join ClientAccount..Advisor ADV
		On SE.PrimaryAdviser = ADV.AdvCode
		Inner Join ClientAccount..Company CO
			On ADV.Company = CO.Company and CO.WrapProvider = @WrapProvider
	Inner Join ClientDB3..tblClients CLT
			On CCL.ModifiedBy = CLT.ClientID
	Where CCL.DateModified Between @FromDateMinus30Days and @ToDate And CCL.TableName = 'Address' and CCL.FieldName In ('Address1', 'Address2', 'Address3', 'Address4', 'Address5') and CCL.IdentifierField = 'ID' and CCL.ChangeStatus = 'Processed'

	Union

	Select
		SE.InvestorType,
		CCL.ClaccountId,
		ADV.Name,
		CO.CompanyName,
		ADV.PostCode,
		CO.Company,
		CLT.FullName,
		CCL.DateModified,
		CCL.FieldName,
		CCL.OriginalValue,
		CCL.NewValue, 
		1,
		1 From
	ClientAccount..ClientChangeLog CCL
	Inner Join ClientAccount..SEClientAccount SE
		On CCL.ClaccountID = SE.ClaccountId and SE.InvestorType In ('INDIVIDUAL', 'JOINT_INDIVIDUAL')
	Inner Join ClientAccount..Advisor ADV
		On SE.PrimaryAdviser = ADV.AdvCode
		Inner Join ClientAccount..Company CO
			On ADV.Company = CO.Company and CO.WrapProvider = @WrapProvider
	Inner Join ClientDB3..tblClients CLT
			On CCL.ModifiedBy = CLT.ClientID
	Where CCL.DateModified Between @FromDateMinus30Days and @ToDate And CCL.TableName = 'ClientAccount' and CCL.FieldName in ('ProtectionEmail', 'ProtectionPhone', 'ProtectionMail', 'ProtectionSMS', 'ProtectionFax', 'ProtectionMobile') and CCL.ChangeStatus = 'Processed'

	Union

	Select 
		SE.InvestorType,
		CCL.ClaccountId,
		ADV.Name,
		CO.CompanyName,
		ADV.PostCode,
		CO.Company,
		CLT.FullName,
		CCL.DateModified,
		CCL.FieldName,
		CCL.OriginalValue,
		CCL.NewValue, 
		1,
		1 From
	ClientAccount..ClientChangeLog CCL
	Inner Join ClientAccount..SEClientAccount SE
		On CCL.ClaccountID = SE.ClaccountId and SE.InvestorType In ('INDIVIDUAL', 'JOINT_INDIVIDUAL')
		Inner Join ClientAccount..Advisor ADV
			On SE.PrimaryAdviser = ADV.AdvCode
			Inner Join ClientAccount..Company CO
				On ADV.Company = CO.Company and CO.WrapProvider = @WrapProvider
	Inner Join ClientDB3..tblClients CLT
			On CCL.ModifiedBy = CLT.ClientID
	Where CCL.DateModified Between @FromDateMinus30Days and @ToDate And CCL.TableName = 'Account Details' and CCL.FieldName = 'AccountName' and CCL.ChangeStatus = 'Processed'

	Union

	Select 
		SE.InvestorType,
		CCL.ClaccountId,
		ADV.Name,
		CO.CompanyName,
		ADV.PostCode,
		CO.Company,
		CLT.FullName,
		CCL.DateModified,
		CCL.FieldName,
		CCL.OriginalValue,
		CCL.NewValue,
		CAST(CCL.Identifier As Int), 
		1 From
	ClientAccount..ClientChangeLog CCL
	Inner Join ClientAccount..SEClientAccount SE
		On CCL.ClaccountID = SE.ClaccountId and SE.InvestorType In ('INDIVIDUAL', 'JOINT_INDIVIDUAL')
		Inner Join ClientAccount..Advisor ADV
			On SE.PrimaryAdviser = ADV.AdvCode
			Inner Join ClientAccount..Company CO
				On ADV.Company = CO.Company and CO.WrapProvider = @WrapProvider
	Inner Join ClientDB3..tblClients CLT
			On CCL.ModifiedBy = CLT.ClientID
	Where CCL.DateModified Between @FromDateMinus30Days and @ToDate And CCL.TableName = 'Account Holders' and CCL.FieldName in ('Title', 'Given', 'Surname', 'MaritalStatus', 'Gender', 'DateOfBirth', 'HomePhone', 'WorkPhone', 'MobilePhone', 'Fax', 'EmailAddress', 'PreferredPhoneNo', 'ClientAccess', 'DocumentsHardCopyRequired') and identifierField = 'HolderNumber' and CCL.ChangeStatus = 'Processed'

	Union

	Select
		SE.InvestorType,
		SE.ClaccountID,
		ADV.Name,
		CO.CompanyName,
		ADV.PostCode,
		CO.Company,
		CLT.FullName,
		CD.CreatedOn,
		CDP.Process + 'Declaration',
		Null,
		'1',
		1,
		1 From
	ClientAccount..ClientDeclaration CD
	Inner Join ClientAccount..SEClientAccount SE
		On CD.SEClientAccountId = SE.ID and SE.InvestorType In ('INDIVIDUAL', 'JOINT_INDIVIDUAL')
		Inner Join ClientAccount..Advisor ADV
			On SE.PrimaryAdviser = ADV.AdvCode
			Inner Join ClientAccount..Company CO
				On ADV.Company = CO.Company and CO.WrapProvider = @WrapProvider	
	Inner Join ClientAccount..ClientDeclarationProcess CDP
		On CD.ClientDeclarationProcessId = CDP.ClientDeclarationProcessId and CDP.Process In ('ContactDetails', 'ClientDetails')
	Inner Join ClientDB3..tblClients CLT
		On CD.CreatedClientId = CLT.ClientID
	Where CD.CreatedOn Between @FromDateMinus30Days and @ToDate

)


Select 
	CC.ClaccountId,
	AH.Given,
	AH.Surname, 
	CC.AdviserName, 
	CC.CompanyName,
	CC.AdviserPostCode, 
	CC.Company,
	CE.ID,
	CE.DateCreated,
	CLT.FullName,
	CE.Amount,
	CE.InstructionType,
	CE.Status, 
	CC.EditedAt, 
	CC.EditedBy,
	Case
		When InvestorType = 'INDIVIDUAL' Then 'Sole'
		When InvestorType = 'JOINT_INDIVIDUAL' Then 'Joint'
	End As InvestorType,
	Case
		When CC.FieldName = 'ClientDetailsDeclaration' Then CC.EditedAt
	End As DeclarationAgreed,
	Case
		When CC.FieldName = 'Address1' And CC.Residential = 1 Then CC.OriginalValue
	End As OriginalResidential1,
	Case
		When CC.FieldName = 'Address1' And CC.Residential = 1 Then CC.NewValue
	End As NewResidential1,
	Case
		When CC.FieldName = 'Address2' And CC.Residential = 1 Then CC.OriginalValue
	End As OriginalResidential2,
	Case
		When CC.FieldName = 'Address2' And CC.Residential = 1 Then CC.NewValue
	End As NewResidential2,
	Case
		When CC.FieldName = 'Address3' And CC.Residential = 1 Then CC.OriginalValue
	End As OriginalResidential3,
	Case
		When CC.FieldName = 'Address3' And CC.Residential = 1 Then CC.NewValue
	End As NewResidential3,
	Case
		When CC.FieldName = 'Address4' And CC.Residential = 1 Then CC.OriginalValue
	End As OriginalResidential4,
	Case
		When CC.FieldName = 'Address4' And CC.Residential = 1 Then CC.NewValue
	End As NewResidential4,
	Case
		When CC.FieldName = 'Address5' And CC.Residential = 1 Then CC.OriginalValue
	End As OriginalResidentialPostCode,
	Case
		When CC.FieldName = 'Address5' And CC.Residential = 1 Then CC.NewValue
	End As NewResidentialPostcode,
	Case
		When CC.FieldName = 'Address1' And CC.Residential = 0 Then CC.OriginalValue
	End As OriginalPostal1,
	Case
		When CC.FieldName = 'Address1' And CC.Residential = 0 Then CC.NewValue
	End As NewPostal1,
	Case
		When CC.FieldName = 'Address2' And CC.Residential = 0 Then CC.OriginalValue
	End As OriginalPostal2,
	Case
		When CC.FieldName = 'Address2' And CC.Residential = 0 Then CC.NewValue
	End As NewPostal2,
	Case
		When CC.FieldName = 'Address3' And CC.Residential = 0 Then CC.OriginalValue
	End As OriginalPostal3,
	Case
		When CC.FieldName = 'Address3' And CC.Residential = 0 Then CC.NewValue
	End As NewPostal3,
	Case
		When CC.FieldName = 'Address4' And CC.Residential = 0 Then CC.OriginalValue
	End As OriginalPostal4,
	Case
		When CC.FieldName = 'Address4' And CC.Residential = 0 Then CC.NewValue
	End As NewPostal4,
	Case
		When CC.FieldName = 'Address5' And CC.Residential = 0 Then CC.OriginalValue
	End As OriginalPostalPostCode,
	Case
		When CC.FieldName = 'Address5' And CC.Residential = 0 Then CC.NewValue
	End As NewPostalPostcode,
	Case
		When CC.FieldName = 'ContactDetailsDeclaration' Then CC.EditedAt
	End As AddressDeclaration,
	Case
		When CC.FieldName = 'AccountName' Then CC.OriginalValue
	End As OriginalAccountName,
	Case
		When CC.FieldName = 'AccountName' Then CC.NewValue
	End As NewAccountName,
	Case
		When CC.FieldName = 'Title' Then CC.OriginalValue
	End As OriginalTitle,
	Case
		When CC.FieldName = 'Title' Then CC.NewValue
	End As NewTitle,
	Case
		When CC.FieldName = 'Given' Then CC.OriginalValue
	End As OriginalFirstName,
	Case
		When CC.FieldName = 'Given' Then CC.NewValue
	End As NewFirstName,
	Case
		When CC.FieldName = 'Surname' Then CC.OriginalValue
	End As OriginalSurname,
	Case
		When CC.FieldName = 'Surname' Then CC.NewValue
	End As NewSurname,
	Case
		When CC.FieldName = 'MaritalStatus' Then CC.OriginalValue
	End As OriginalMaritalStatus,
	Case
		When CC.FieldName = 'MaritalStatus' Then CC.NewValue
	End As NewMaritalStatus,
	Case
		When CC.FieldName = 'Gender' Then CC.OriginalValue
	End As OriginalGender,
	Case
		When CC.FieldName = 'Gender' Then CC.NewValue
	End As NewGender,
	Case
		When CC.FieldName = 'DateOfBirth' Then CC.OriginalValue
	End As OriginalDOB,
	Case
		When CC.FieldName = 'DateOfBirth' Then CC.NewValue
	End As NewDOB,
	Case
		When CC.FieldName = 'HomePhone' Then CC.OriginalValue
	End As OriginalHomePhone,
	Case
		When CC.FieldName = 'HomePhone' Then CC.NewValue
	End As NewHomePhone,
	Case
		When CC.FieldName = 'WorkPhone' Then CC.OriginalValue
	End As OriginalWorkPhone,
	Case
		When CC.FieldName = 'WorkPhone' Then CC.NewValue
	End As NewWorkPhone,
	Case
		When CC.FieldName = 'MobilePhone' Then CC.OriginalValue
	End As OriginalMobile,
	Case
		When CC.FieldName = 'MobilePhone' Then CC.NewValue
	End As NewMobile,
	Case
		When CC.FieldName = 'Fax' Then CC.OriginalValue
	End As OriginalFax,
	Case
		When CC.FieldName = 'Fax' Then CC.NewValue
	End As NewFax,
	Case
		When CC.FieldName = 'EmailAddress' Then CC.OriginalValue
	End As OriginalEmail,
	Case
		When CC.FieldName = 'EmailAddress' Then CC.NewValue
	End As NewEmail,
	Case
		When CC.FieldName = 'PreferredPhoneNo' Then CC.OriginalValue
	End As OriginalPreferredPhone,
	Case
		When CC.FieldName = 'PreferredPhoneNo' Then CC.NewValue
	End As NewPreferredPhone,
	Case
		When CC.FieldName = 'ClientAccess' Then CASE WHEN CC.OriginalValue = '4238' THEN 'Yes' ELSE 'No' END 
	End As OriginalReadOnly,
	Case
		When CC.FieldName = 'ClientAccess' Then CASE WHEN CC.NewValue = '4238' THEN 'Yes' ELSE 'No' END  
	End As NewReadOnly,
	Case
		When CC.FieldName = 'DocumentsHardCopyRequired' And CC.OriginalValue = 'True' Then 'Yes'
		When CC.FieldName = 'DocumentsHardCopyRequired' And CC.OriginalValue = 'False' Then 'No'
	End As OriginalPaperOptOut,
	Case
		When CC.FieldName = 'DocumentsHardCopyRequired' And CC.NewValue = 'True' Then 'Yes'
		When CC.FieldName = 'DocumentsHardCopyRequired' And CC.NewValue = 'False' Then 'No'
	End As NewPaperOptOut,
	Case
		When CC.FieldName = 'ProtectionMail' And CC.OriginalValue = 'True' Then 'Yes'
		When CC.FieldName = 'ProtectionMail' And CC.OriginalValue = 'False' Then 'No'
	End As OriginalPCMMail,
	Case
		When CC.FieldName = 'ProtectionMail' And CC.NewValue = '1' Then 'Yes'
		When CC.FieldName = 'ProtectionMail' And CC.NewValue = '0' Then 'No'
	End As NewPCMMail,
	Case
		When CC.FieldName = 'ProtectionPhone' And CC.OriginalValue = '1' Then 'Yes'
		When CC.FieldName = 'ProtectionPhone' And CC.OriginalValue = '0' Then 'No'
	End As OriginalPCMPhone,
	Case
		When CC.FieldName = 'ProtectionPhone' And CC.NewValue = '1' Then 'Yes'
		When CC.FieldName = 'ProtectionPhone' And CC.NewValue = '0' Then 'No'
	End As NewPCMPhone,
	Case
		When CC.FieldName = 'ProtectionEmail' And CC.OriginalValue = '1' Then 'Yes'
		When CC.FieldName = 'ProtectionEmail' And CC.OriginalValue = '0' Then 'No'
	End As OriginalPCMEmail,
	Case
		When CC.FieldName = 'ProtectionEmail' And CC.NewValue = '1' Then 'Yes'
		When CC.FieldName = 'ProtectionEmail' And CC.NewValue = '0' Then 'No'
	End As NewPCMEmail,
	Case
		When CC.FieldName = 'ProtectionSMS' And CC.OriginalValue = '1' Then 'Yes'
		When CC.FieldName = 'ProtectionSMS' And CC.OriginalValue = '0' Then 'No'
	End As OriginalPCMSMS,
	Case
		When CC.FieldName = 'ProtectionSMS' And CC.NewValue = '1' Then 'Yes'
		When CC.FieldName = 'ProtectionSMS' And CC.NewValue = '0' Then 'No'
	End As NewPCMSMS,
	Case
		When CC.FieldName = 'ProtectionMobile' And CC.OriginalValue = '1' Then 'Yes'
		When CC.FieldName = 'ProtectionMobile' And CC.OriginalValue = '0' Then 'No'
	End As OriginalPCMMobile,
	Case
		When CC.FieldName = 'ProtectionMobile' And CC.NewValue = '1' Then 'Yes'
		When CC.FieldName = 'ProtectionMobile' And CC.NewValue = '0' Then 'No'
	End As NewPCMMobile,
	Case
		When CC.FieldName = 'ProtectionFax' And CC.OriginalValue = '1' Then 'Yes'
		When CC.FieldName = 'ProtectionFax' And CC.OriginalValue = '0' Then 'No'
	End As OriginalPCMFax,
	Case
		When CC.FieldName = 'ProtectionFax' And CC.NewValue = '1' Then 'Yes'
		When CC.FieldName = 'ProtectionFax' And CC.NewValue = '0' Then 'No'
	End As NewPCMFax
From ClientChanges CC
Inner Join ClientAccount..AccountHolders AH
	On CC.ClaccountId = AH.ClaccountId and CC.HolderNumber = AH.HolderNumber
	Inner Join ClientAccount..Consolidate CON
		On CC.ClaccountID = CON.ClaccountId
Inner Join (
			select CE.ClaccountId, CE.ID, CE.DateCreated, CE.Amount, CE.Status, CE.ClientID, CASE WHEN RW.ID is not null and InstructionType = 'One-Off' THEN 'Auto' ELSE CE.InstructionType END As InstructionType
			From Discovery..CashEntry CE 
				 left join Discovery..RegularWithdrawalPayments AS RW ON CE.ID = RW.CashEntry 
			Where CE.InstructionType In ('One-Off', 'Auto', 'Standing') and CE.Type = 'Withdrawal' and CE.DateCreated Between @FromDate and @ToDate
			UNION
			select ClaccountId, ID, DateCreated, Amount, Status, ClientID, 'Standing' As InstructionType			
			from Discovery..RegularWithdrawals RW2
			Where DateCreated Between @FromDate and @ToDate
			) As CE 
			  On CON.SubClaccountId = CE.ClaccountId
Inner Join ClientDB3..tblClients CLT
	On CE.ClientID = CLT.ClientID
Where DATEDIFF (day, CC.EditedAt, CE.DateCreated) between 0 and 30
Order By CC.CompanyName, CC.AdviserName, CC.EditedAt
GO