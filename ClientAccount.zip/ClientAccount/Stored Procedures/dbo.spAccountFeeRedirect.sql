/*
* Author: Tomas Preclik
* Created: 04/03/2016
* 
* <StoredProcedure>
*    <Description>Find accounts whithout fee redirect</Description>
*    <Service>CAFees</Service>
*	 <Parameters>
*	 	 <Parameter Name="@ClHeadAccount">
*			 <Description>Find data from date</Description>
*		 </Parameter>		
*	 </Parameters>
* </StoredProcedure>
**/

CREATE PROCEDURE [dbo].[spAccountFeeRedirect] (@ClHeadAccount AS VARCHAR(20)) AS

SELECT pdNonWrapCash.ClAccountid AS AccountGeneratingFee, 
	WC.ClAccountid AS AccountFeeToBePaidFrom
FROM Discovery.dbo.ProductDetails AS pdNonWrapCash
		LEFT JOIN dbo.fnHeadAccounts() As HA 
			ON HA.ClAccountID = pdNonWrapCash.ClAccountid
		LEFT JOIN dbo.FeeRedirect AS FR 
			ON FR.AccountGeneratingFee = pdNonWrapCash.ClAccountid
		JOIN 
			(SELECT HA.ClAccountID, 
					HA.HeadClAccountID 
				FROM Discovery.dbo.ProductDetails AS pdWrapCash 
					INNER JOIN dbo.FnHeadAccounts() AS HA
						ON pdWrapCash.ClAccountId = HA.ClAccountID
				WHERE pdWrapCash.ProductType = 'Wrap Cash'
				) WC
			ON WC.HeadClAccountID = HA.HeadClAccountID
WHERE pdNonWrapCash.ProductType In ('Personal Portfolio','Stocks/Shares')
	AND FR.AccountFeeToBePaidFrom Is NULL
	AND HA.HeadClAccountID = @ClHeadAccount

GO