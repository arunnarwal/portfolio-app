/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>B967D0FD905364E8F62F6F76A51944E0</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- =============================================
-- Author:		Will Barker
-- Create date: 1st September 2009
-- Description:	Retrieve all orders related to completed bulk trade wizards
-- =============================================
CREATE PROCEDURE [dbo].[spBulkTradeOrders]
(
	@ClientID int, 
	@DateFrom datetime, 
	@DateTo datetime, 
	@WrapProvider varchar(20),
	@Company VarChar(20) = NULL,
	@WizardSessionID int = null
) 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- uncomment to test
	
	/*declare @ClientID as int
	declare @DateFrom as datetime
	declare @DateTo as datetime
	declare @WrapProvider as VarChar(20)
	declare @Company as varchar(20)
	set @ClientID = 938959
	set @DateFrom = '2009-12-20'
	set @DateTo = GetDate()
	set @WrapProvider = 'SL'
	set @Company = 'HAS'*/
	

    ;with 
	bulktradeorders as
	(
		SELECT 
			SE.accountname as accountname,
			SE.claccountid as claccountid,
			PD.producttype as taxwrapper,
			OC.instrumentcode as fund,
			i.displayname as fundname,
			B.advicegiven as advicegiven,
			OC.status as orderstatus,
			OC.orderbuysell as orderbuysell,
			OC.switchid as orderswitchid,
			OC.datecreated as orderdatecreated,
			OC.batchid as orderbatchid,
			B.wizardsessionid as wizardsessionid,
			WWCS.company as wizardcompany,
			WW.ID as WizardID, 
			OC.PlacedValue,
			OC.OrderType, 
			OC.OrderPercentage
		FROM dbo.WorkflowWizard WW
			INNER JOIN dbo.WorkflowWizardClientSession WWCS ON WW.id = WWCS.wizardid
			INNER JOIN dbo.WorkflowWizardMappings WWM on WWM.WizardID = WW.ID and WWM.Name = @WrapProvider
			INNER JOIN Discovery.dbo.Batch B ON B.wizardsessionid = WWCS.id
			INNER JOIN Discovery.dbo.OrderCurrent OC ON B.batchid = OC.batchid
			INNER JOIN res_db..instruments i on OC.instrumentcode = i.security
			INNER JOIN dbo.SEClientAccount SE ON OC.claccountid = SE.claccountid
			INNER JOIN Discovery.dbo.ProductDetails PD ON OC.claccountid = PD.claccountid
		WHERE WWCS.status = 'COMPLETE'
		AND WW.id in (335, 434)
		AND WWCS.DateCompleted between @DateFrom and DateAdd(day, 1, @DateTo)
		AND WWCS.company = CASE when @company is null THEN WWCS.company ELSE @company END
		AND WWCS.ID = CASE when @WizardSessionID is null THEN WWCS.ID ELSE @WizardSessionID END
	)

	select 
		BTO.claccountid,
		BTO.accountname,
		BTO.taxwrapper,
		BTO.fund,
		BTO.fundname,
		BTO.advicegiven,
		BTO.orderstatus,
		BTO.orderbuysell,
		BTO.orderswitchid,
		BTO.orderdatecreated,
		BTO.orderbatchid,
		BTO.wizardsessionid,
		BTO.WizardID, 
		BTO.PlacedValue,
		BTO.OrderType, 
		BTO.OrderPercentage
	from bulktradeorders BTO 
		INNER HASH JOIN dbo.tvfn_BaseAllowedClient(@ClientID) ACA on ACA.ClaccountID = BTO.ClAccountID
	order by BTO.orderdatecreated desc

END
GO
