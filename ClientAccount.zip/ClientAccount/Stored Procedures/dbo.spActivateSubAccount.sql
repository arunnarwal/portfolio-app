/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>5FF1ED2B22F2033ED768A235D300B9CB</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[spActivateSubAccount](
               @UserId       INT,
			   @TransactionId INT,
               @SubClAccountId VARCHAR(15))
AS


  DECLARE  @ClAccountId  VARCHAR(10),
           @Today        DATETIME,
           @TimeStamp    DATETIME
  
  SET @TimeStamp = Getdate()
  
  SELECT @Today = Dateadd(dd,Datediff(dd,0,@TimeStamp) + 0,0)
  
  /*
  DECLARE @UserId INT,  
  @SubClAccountId VARCHAR(15) ,
@TransactionId INT

  
  SET @UserId = 424192 
  SET @SubClAccountId = 'AD2001360-002'
  SET @TransactionId = 1
*/
  /*
  SELECT * FROM discovery..productdetails AS PD
  INNER JOIN discovery..ClientAccount AS CA ON CA.ClaccountId = PD.ClaccountId AND PD.ProductType <> 'WRap cash' AND CA.Status = 'Submitted'
*/
  SET @ClAccountId = dbo.Fngetheadaccountid(@SubClAccountId)
 
IF EXISTS (	SELECT 1 FROM discovery..clientaccount
				WHERE  claccountid = @SubClAccountId AND Status <> 'Active')
BEGIN
      BEGIN TRAN ActivateSubAccount
      
      DECLARE  @OldValues     VARCHAR(300),
               @NewValues     VARCHAR(300),
               @id            INT,
			   @SetNewRate BIT     
      
		IF EXISTS (SELECT 1
                         FROM   discovery..productdetails 
                         WHERE ClAccountId = @SubClAccountId AND ProductType = 'Wrap Cash')
		BEGIN
			SET @SetNewRate = 0
		END
		ELSE
		BEGIN
			SET @SetNewRate = 1
          
			IF NOT EXISTS (SELECT 1
                         FROM   clientaccount.dbo.clientfbrcsettings
                         WHERE  claccountid = @SubClAccountId)
            BEGIN
              /*==================== FBRC settings =====================*/
              /*====================== clientaccount.dbo.clientfbrcsettings ===============================*/
              INSERT INTO clientaccount.dbo.clientfbrcsettings
                         (claccountid,
                          fbrcrate,
                          usefundfbrcrate,
                          asat,
                          dateadded,
                          useraddedby,
                          active,
                          activationdate,
                          callersource)
              VALUES     (@SubClAccountId,0,0,@Today,@Today,@userId,1,@Today,'RequestInterface')
              
              SELECT @id = Scope_identity(),
                     @OldValues = NULL
            END
          ELSE
            BEGIN
              SELECT   TOP 1 @OldValues = 'FBRCRate=' + Cast(COALESCE(fbrcrate, 'NULL') AS VARCHAR(10)) 
							+ '|UseFundFBRCRate=' + Cast(COALESCE(usefundfbrcrate, 'NULL') AS VARCHAR(10))
							+ '|ActivationDate=' + COALESCE(Cast(ActivationDate AS VARCHAR(25)), 'NULL'),
                             @id = id
              FROM     clientaccount.dbo.clientfbrcsettings
              WHERE    claccountid = @SubClAccountId
              ORDER BY id DESC
              
              UPDATE clientaccount.dbo.clientfbrcsettings
              SET    usefundfbrcrate = 0,
                     fbrcrate = 0,
					 ActivationDate = @Today
              WHERE  id = @id
            END
          
          INSERT INTO discovery..requestinterfacechangelog
                     (transactionid,
                      tablerowidentifier,
                      databasename,
                      tablename,
                      oldvalues,
                      newvalues)
          VALUES     (@TransactionId,@id,'ClientAccount','ClientFBRCSettings',@OldValues,'FBRCRate=0|UseFundFBRCRate=0|ActivationDate=' + CAST(@Today AS VARCHAR(20)))
         END 
          /*====================== discovery..clientaccount ===============================*/
			SET @id = NULL
          SELECT @OldValues = 'Status=' + status 
							+ CASE @SetNewRate 
								WHEN 1 THEN '|MonitoringRate=' + Cast(COALESCE(monitoringrate, 'NULL') AS VARCHAR(20))
								ELSE '' 
							  END,
                 @id = id
          FROM   discovery..clientaccount
          WHERE  claccountid = @SubClAccountId
                 AND status <> 'Active'
          
          IF NOT @id IS NULL
            BEGIN
              UPDATE discovery..clientaccount
              SET    status = 'Active',
                     monitoringrate = CASE @SetNewRate 
										WHEN 1 THEN 0
										ELSE monitoringrate 
									  END
              WHERE  claccountid = @SubClAccountId
					AND Status <> 'Active'
              
              INSERT INTO discovery..requestinterfacechangelog
                         (transactionid,
                          tablerowidentifier,
                          databasename,
                          tablename,
                          oldvalues,
                          newvalues)
              VALUES     (@TransactionId,@id,'Discovery','ClientAccount',@OldValues,'Status=Active|' 
								+ CASE @SetNewRate 
									WHEN 1 THEN '|MonitoringRate=0'
									ELSE '' 
								  END)
            END
          
          /*====================== clientaccount..clientdetails ===============================*/
			SET @id = NULL
          SELECT @id = id
          FROM   clientaccount..clientdetails
          WHERE  claccountid = @SubClAccountId
                 AND activationdate IS NULL
          
          IF NOT @id IS NULL
            BEGIN
              INSERT INTO discovery..requestinterfacechangelog
                         (transactionid,
                          tablerowidentifier,
                          databasename,
                          tablename,
                          oldvalues,
                          newvalues)
              VALUES     (@TransactionId,@id,'ClientAccount','ClientDetails','ActivationDate=NULL','ActivationDate=' + Cast(@TimeStamp AS VARCHAR(20)))
              
              UPDATE clientaccount..clientdetails
              SET    activationdate = @TimeStamp
              WHERE  claccountid = @SubClAccountId
                     AND activationdate IS NULL
            END
      
      
      COMMIT TRAN ActivateSubAccount;
END
/*
GO





GO
EXEC csfbmaster..Spupdatemetadb
  @DBName = 'ClientAccount' ,
  @TableName = 'spActivateSubAccount' ,
  @TableConstant = 'claspActivateSubAccount'
*/
GO
