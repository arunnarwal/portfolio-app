/***
<StoredProcedure>
    <Description>On arrival of Swift Transaction </Description>
    <Service>Disinvestments</Service>
    <Feature>DebtManagement</Feature>
	<Parameters>
        <Parameter Name="@CaseId">
            <Description>Linked workflow case ID</Description>
        </Parameter>
		<Parameter Name="@SwiftTransactionId">
            <Description>Mapped Swift Transaction Id</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [dbo].[spAddSwiftTransactionTransferWorkflowCaseMapping] (
                @CaseId INT,
                @SwiftTransactionId INT) AS
BEGIN

	IF EXISTS(SELECT 1 FROM [dbo].[SwiftTransactionTransferWorkflowCaseMapping] WHERE TransferWorkflowCaseId = @CaseId AND SwiftTransactionId = @SwiftTransactionId)
	BEGIN
		RETURN  -1
	END

	DECLARE @CurrentDate AS DATETIME2(3) = GETDATE()

	DECLARE @ToAddToAuditTable TABLE (
		TransferWorkflowCaseId INT NOT NULL,
		SwiftTransactionId INT NOT NULL,
		DateTimeAdded DATETIME2(3) NOT NULL
	)

	DELETE [dbo].[SwiftTransactionTransferWorkflowCaseMapping] 
	OUTPUT DELETED.TransferWorkflowCaseId, DELETED.SwiftTransactionId, DELETED.DateTimeAdded
	INTO @ToAddToAuditTable (TransferWorkflowCaseId, SwiftTransactionId, DateTimeAdded)
	WHERE TransferWorkflowCaseId = @CaseId OR SwiftTransactionId = @SwiftTransactionId

	INSERT INTO [dbo].[SwiftTransactionTransferWorkflowCaseMappingAudit] (TransferWorkflowCaseId, SwiftTransactionId, DateTimeAdded, DateTimeRemoved)
	SELECT TA.TransferWorkflowCaseId, TA.SwiftTransactionId, TA.DateTimeAdded, @CurrentDate
	FROM @ToAddToAuditTable TA

	INSERT INTO [dbo].[SwiftTransactionTransferWorkflowCaseMapping] (TransferWorkflowCaseId, SwiftTransactionId, DateTimeAdded)
	SELECT @CaseId, @SwiftTransactionId, @CurrentDate
END