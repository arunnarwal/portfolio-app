/***
<StoredProcedure>
	<Description>Adds the base account table entries for a new control account</Description>
	<Parameters>
		<Parameter Name="@Company">
			<Description>Company the account should be created under</Description>
		</Parameter>
		<Parameter Name="@ClAccountId">
			<Description>ClAccountId of the control account</Description>
		</Parameter>
		<Parameter Name="@AccountName">
			<Description>Name of the control account</Description>
		</Parameter>
		<Parameter Name="@GLADCashSweepType">
			<Description>GLADCashSweepType override</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE dbo.spAddBaseControlAccount @Company VARCHAR(20), 
											 @ClAccountId VARCHAR(20), 
											 @AccountName VARCHAR(200),
											 @GLADCashSweepType VARCHAR(50) = 'toCall', 
											 @AddGladSweepJnlPosting BIT = 1, 
											 @DivisionCode VARCHAR(6) = NULL,
											 @AdvCode VARCHAR(20) = 'UKW',
											 @InvestorType VARCHAR(20) = 'CONTROL' AS

	/*
	USE ClientAccount
	GO
	DECLARE @Company VARCHAR(20), @ClAccountId VARCHAR(20), @AccountName VARCHAR(200), @GLADCashSweepType VARCHAR(50) = 'toCall' 
	*/

	DECLARE @TransactionId AS INT
	INSERT INTO Discovery.dbo.TransactionId (UserId, MachineName, CallerSource) VALUES (8245, HOST_NAME(), 'spAddBaseControlAccount')
	SELECT @TransactionId = SCOPE_IDENTITY()

	INSERT INTO dbo.Consolidate
	(ClAccountid, SubClAccountid)
	SELECT @ClAccountId,@ClAccountId
	WHERE NOT EXISTS (SELECT 1 FROM dbo.Consolidate WHERE ClAccountId = @ClAccountId)

	INSERT INTO Discovery.dbo.ClientAccount
	(ClAccountId, [Status], SigType,AOFStatus,TransactionID,MonitoringRate,MonitoringMinimum,FIFStatus,PortfolioID,GSMinPerQtr,GSAgreedEquity,GSAgreedFI,GSDiscretion,GSContractNotesHeld,GSAnnualReports,GSExempt,GSClientTaxSummary,GSOtherTaxSummary,DefSettCurrency,RequestCSN,NZDefSettLocation,AUDefSettLocation,IntlDefSettLocation,ServiceLevel,GSInvoiceGST,DefCashSettMethod,DPSAccountType,SSSAuthorisation,ServiceLevel2,ProtectionEmail,ProtectionPhone,ProtectionMail,ProtectionSMS, ProtectionFax, ProtectionMobile, AdvisedAccount, TransferToWrap, CapitaSIPP, ElectraClient, DealingPlanClient, ContractualRelationship, ContractualRelationshipStartDate, ChargeExemptReason, MarketContactFax, MarketContactMail, MarketContactPhone, MarketContactEmail, MarketContactSMS)
	SELECT @ClAccountId,'Active','All','Processing',@TransactionId,0,0,'Processing',0,0,0,0,'No','None','No','No','No','No','GBP',0,'Custody','Custody','Custody','Transactions','Yes','Call','Account','NOT_REQUIRED','None',0,0,0,0, 0, 0, 1, 0, 0, 0, 0, 1, getdate(), 'None', 0, 0, 0, 0, 0
	WHERE NOT EXISTS (SELECT 1 FROM Discovery.dbo.ClientAccount WHERE ClAccountId = @ClAccountId)

	INSERT INTO dbo.SEClientAccount
	(ClAccountID,CPName,SearchKey,Class,SubClass,PrimaryAdviser,OwnerCode,AccountName,AccountType,AccountDesc,InvestorType,StartDate,BrokerageCode,WHTCode,MailoutIndicator,Status,DateCreated,LastUpdated,SyncSource,SyncStatus)
	SELECT @ClAccountId,@AccountName,@AccountName,'RETAIL_DIRECT','WELLINGTON',@AdvCode,'FIRST_NZ',@AccountName,'PRIVATE','PRIVATE Account','GLAD:'+@InvestorType,getdate(),'STANDARD','NZ_RES_39','NO','IN_USE',getdate(),getdate(),'NotSpecified','InActive'
	WHERE NOT EXISTS (SELECT 1 FROM dbo.SEClientAccount WHERE ClAccountId = @ClAccountId)

	INSERT INTO dbo.ClientDetails
	(CLAccountID,PrismStatus,NZCreditUtil,AUCreditUtil,DivTaxRate,IntTaxRate,CGTTaxRate,HoldingLocationDefault,IncomeTaxBasis,CostReportingStatus,CostReportingType,LocationClassification,ClientDisplayName,WHTDomicile,WHTFormReceived,StatementFrequency,AllowShorts,BaseCCY,CachePrismData,FeeSettlementMethod,FeeInvoicingFrequency,FeeScheduleID,DefIncSettCCY,DefIncSettMethod,InvestorType,COE,FeeInvoicingEnabled,Discretionary,DistributionMethod,CostBasis,FirstNZClientResponded,FirstNZKeepClientRecords,FirstNZClientContacted,Company,DlyCall,DlyContract,DlyDirectCredit,CAAdvice,MthlyCall,MthlyCustody,DRP,AssetWatch,DividendSource,FeeType,LastModified,CMTDemo,CacheHoldings,IsAccrualTaxReporting,CAPaymentOption,InceptionValue,CustodianByMarketIDOverrideASX,OverrideInceptionSettings,RestrictActivities,CRESTSettlementOption,GLADCashSweepType,FeeStructure, SuspendWithdrawals, ReferToCompliance, LostContact, VIP, POA, Director, SuspendAccount, RegistrationStatus, IsTaxExempt, IIPTaxRate, GLADAutoContraEnabled)
	SELECT @ClAccountId,'Disabled',100,100,33,0,33,'All','Gross','Disabled','Average','NZAUSGlobal',@AccountName,'New Zealand',0,'M',0,'GBP',0,'External','Q',1,'LOCAL','CMT',@InvestorType,'No',0,0,'Mail','Auto','No','Yes','No',@Company,'Print','Print','Print','Print','Print','Print',0,0,'IncomeSummary','None',getdate(),0,0,0,'Call','Market Value','',1,0,0,@GLADCashSweepType,'Bundled', 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 1
	WHERE NOT EXISTS (SELECT 1 FROM dbo.ClientDetails WHERE ClAccountId = @ClAccountId)
	
	INSERT INTO dbo.AccountGladProperties
	(AccountId, DivisionCode, InvestorType)
	SELECT se.Id, @DivisionCode, @InvestorType
	FROM dbo.SEClientAccount se
	WHERE NOT EXISTS (SELECT 1 FROM ClientAccount.dbo.AccountGladProperties agp WHERE se.Id = agp.AccountId)
		AND @DivisionCode IS NOT NULL
		AND se.ClAccountId = @ClAccountId
GO
