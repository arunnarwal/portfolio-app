/***
<StoredProcedure>
    <Description>This check whether advisers have External ID or not</Description>
    <Service>Unknown</Service>
    <Feature>Adviser Servicing - Adviser Leaver</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE [dbo].[spCheckAdvisersExternalID] (@AdvCode VARCHAR(20))
AS
/*
DECLARE @AdvCode VARCHAR(20)
SET @AdvCode = 'AVIVADEFCOMP0000006'
*/
SELECT CL.ExternalUserID FROM dbo.Advisor AD
INNER JOIN Clientdb3.dbo.TblClients CL ON AD.AdvCode = CL.AdvCode
WHERE AD.IsActive = 1 AND AD.AdvCode = @AdvCode AND CL.ExternalUserID IS NOT NULL AND CL.ExternalUserID <> ''