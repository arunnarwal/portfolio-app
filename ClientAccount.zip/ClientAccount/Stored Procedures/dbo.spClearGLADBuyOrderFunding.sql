/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>D348AB5DCA1761DA030C3C57A35883BC</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[spClearGLADBuyOrderFunding](@OrderId int, @TradeId int) AS

update clientaccount..gladMarketOrders
set TradeId = @TradeId, FundingClearDate = getdate()
where orderId = @OrderId and tradeId = 0;
GO
