/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>B9F2AA66B624DC2CC674F4F8BD65C818</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[spAMCRebateInvoices](@DateFrom datetime, @DateTo datetime,@ClAccountId VarChar(20)= NULL) AS

SELECT	MF.ClAccountID, 
		MF.ManagerID, 
		FAD.InstrumentCode, 
		MF.descript as FundName,
		DateAdd(m,-1,ChargeDate) as FromDate,
		DateAdd(d,-1,ChargeDate) as ToDate,
		sum(FAD.TotalAmount) as TotalAmount,
		abs(sum(FAD.TotalAmount)) as Amount, 
		CCD.SubAccountType, 
		CCD.WrapProvider

FROM	ClientAccount.dbo.FeeAccrualDetail FAD
			 inner join res_db.dbo.vwManagedFundsDetail MF on FAD.instrumentcode = MF.security
			 inner join ClientAccount.dbo.vwCombinedClientDetails CCD on FAD.ClAccountID = CCD.ClAccountID
	
WHERE	fad.type = 'MFR' 
		--and fad.category = 'AMC' removed for WL issue 111900 
		and fad.asat >= @DateFrom
		and fad.asat < @DateTo
		and CCD.subaccounttype in ('PEP','ISA','SIPP','ONSHORE BOND','OFFSHORE BOND','PERSONAL PORTFOLIO','RETAIL BOND','RETAIL SIPP','Platform Fund')
        AND MF.ClAccountID=ISNULL(@ClAccountID,MF.ClAccountID)


GROUP BY	MF.ClAccountID, ChargeDate, MF.ManagerID, FAD.InstrumentCode, MF.Descript, CCD.SubAccountType, CCD.WrapProvider

ORDER BY	MF.ClAccountID, FAD.InstrumentCode
GO
