CREATE PROCEDURE dbo.spCGTToolIncomeSummaryByHierarchy
	@HierarchyEntityId INTEGER
AS

/*
 USE ClientAccount

 DECLARE @HierarchyEntityId INTEGER

 SELECT @HierarchyEntityId = 5517
 
-- */

SELECT
	inc.LedgerDate
,	inc.QualifyingHolding
,	inc.CncyCode
,	COALESCE(inc.Equalisation, 0) AS Equalisation
,	inc.NetAmount
,	ca.ExDate
,	ca.EventId
,	epp.ExternalPropositionProductId
FROM dbo.IncomeSummary inc
INNER JOIN CorporateActions.dbo.CorporateAction ca
	ON inc.CorpActID = ca.Id
INNER JOIN Res_Db.dbo.Instruments i
	ON ca.InstrumentCode = i.Security
INNER JOIN dbo.vwAccountPlatformMembership apm
	ON inc.ClAccountId = apm.ClAccountId
INNER JOIN dbo.HierarchyEntities he
	ON inc.ClAccountId = he.EntityCOde
INNER JOIN dbo.ExternalProposition ep
	ON apm.PlatformId = ep.Id
INNER JOIN dbo.ExternalPropositionProductIds epp
	ON ep.ExternalPropositionEnvironmentId = epp.ExternalPropositionEnvironmentId
	   AND i.Id = epp.ProductId
WHERE inc.QualifyingHolding IS NOT NULL  
	AND inc.Reversal IS NULL  
	AND  I.[SecuritySubType] in ('ManagedFund','Exchange Traded Fund')
	AND he.HierarchyEntityId = @HierarchyEntityId
