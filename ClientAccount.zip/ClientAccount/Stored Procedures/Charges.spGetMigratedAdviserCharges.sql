/***
<StoredProcedure>
	<Description>Return adviser charges that were migrated onto the platform for specific advisers</Description>
	<Parameters>
		<Parameter Name="@AdviserIdsCsv">
			<Description>The lsit of adviser ids</Description>
		</Parameter>
		<Parameter Name="@FromDate">
			<Description>From date to search for</Description>
		</Parameter>
		<Parameter Name="@ToDate">
			<Description>To date to search for</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE Charges.spGetMigratedAdviserCharges (@AdviserIdsCsv VARCHAR(MAX), @FromDate DATE, @ToDate DATE) AS

--SET STATISTICS IO ON
--SET STATISTICS TIME ON

--DECLARE @AdviserIdsCsv VARCHAR(MAX)
--DECLARE @FromDate DATE
--DECLARE @ToDate DATE

--SET @AdviserIdsCsv = '50180' --'50832, 50356, 50767, 51655, 50401, 50799, 50742, 50960, 50751, 50536'
--SET @FromDate = '2018-10-01'
--SET @ToDate = '2019-10-31'


SELECT SE.ClAccountId ,
       SE.Id AS AccountId ,
       Adv.ID AS AdviserId ,
       Adv.BranchId AS BranchId ,
       C.Id AS CompanyId ,
       N.Id AS NetworkId ,
       C.WrapProvider
INTO   #Accounts
FROM   dbo.SEClientAccount SE
       INNER JOIN dbo.Advisor ADV ON se.PrimaryAdviser = ADV.AdvCode
       INNER JOIN dbo.Company C ON Adv.Company = C.Company
       LEFT JOIN dbo.Network N ON C.Network = N.Network
	   INNER JOIN CSFBMaster.dbo.[fn_convert_comma_to_table_int] (@AdviserIdsCsv) CSV on CSV.TabValue = ADV.ID

CREATE CLUSTERED INDEX CIDX_AccountId
    ON #Accounts ( AccountId );
	
-- Forcing it to use IDX_AccountIdLedgerDateCurrencyId
SELECT  CLT.TransactionId, CLT.LedgerDate
INTO    #Transactions
FROM    CashLedger.ExternalTransactions CLT
        INNER JOIN #Accounts acc ON acc.AccountId = CLT.AccountId
WHERE   CLT.LedgerDate BETWEEN @FromDate AND @ToDate

SELECT ACC.AdviserId ,
       ACC.BranchId ,
       ACC.CompanyId ,
       ACC.NetworkId ,
       CLT.LedgerDate AS AsAt ,
       HCF.FeeTranType ,
       CLT.Amount AS Amount

FROM   #Transactions Trans 
	   --joining again as adding too many columns in lookup above messes with execution plan...
	   INNER JOIN CashLedger.ExternalTransactions CLT ON Clt.TransactionId = Trans.TransactionId 
       INNER JOIN #Accounts ACC ON CLT.AccountID = ACC.AccountID
       INNER JOIN dbo.HistoricCashFeeTranTypes HCF ON CLT.TransactionId = HCF.CashLedgerId
       INNER JOIN dbo.FeeTranTypes FTT ON HCF.FeeTranType = FTT.TranType
                                          AND FTT.WrapProvider = ACC.WrapProvider
       INNER JOIN CashLedger.MovementTypes MT ON CLT.MovementTypeId = MT.MovementTypeId
       INNER JOIN CashLedger.ExternalLedgerSources ELS ON CLT.ExternalLedgerSourceId = ELS.ExternalLedgerSourceId
	   LEFT JOIN CashLedger.ChargeTransactions CT ON CT.TransactionId = CLT.TransactionId
WHERE  MT.MovementType = 'FEE'
       AND CT.ARLID IS NULL 
       AND ELS.ExternalLedgerSource = 'Migration'
       AND FTT.AdvisorCharge = 1

DROP TABLE #Accounts;
DROP TABLE #Transactions