/***
<StoredProcedure>
    <Description>Marks CorporateTieredAmcUnauthorised Schedules as authorised</Description>
	<Service>Charges</Service>
    <Feature>Tasks</Feature>
    <Parameters>
        <Parameter Name="@schemeId">
            <Description>The SchemeId</Description>
        </Parameter>
		<Parameter Name="@feeTranTypeId">
            <Description>The fee tran type id</Description>
        </Parameter>
		<Parameter Name="@clientId">
            <Description>The id of the client authorising the schedules</Description>
        </Parameter>
		<Parameter Name="@now">
            <Description>The time the schedules were authorised</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[AuthoriseUnauthorisedCorporateTieredAmcSchedule](@schemeId int, @feeTranTypeId int, @clientId int, @now DateTime) AS

	UPDATE ClientAccount.dbo.CorporateTieredAMCUnauthorised
	SET UserIdAuthorised = @clientId,
	DateAuthorised = @now
	WHERE SchemeId = @schemeId AND FeeTranTypeId = @feeTranTypeId
GO