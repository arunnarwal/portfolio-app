/***
<StoredProcedure>
    <Description>Gets tier structures that can be assigned</Description>
	<Parameters>
		<Parameter Name="@HierarchyLevelNameId">
			<Description>The type of the entity - Account or Advisor or branch or company or network</Description>
		</Parameter>
		<Parameter Name="@Entityid">
			<Description>The Id of the entity</Description>
		</Parameter>
	</Parameters>	
</StoredProcedure>
***/
CREATE PROCEDURE Charges.spGetTierStructuresByEntity (
	@HierarchyLevelNameId INT,
	@EntityId INT) AS

	--55918	177380
	 --DECLARE @HierarchyLevelNameId INT = 0 -- Account
	 --DECLARE @EntityId INT = 1539075
	 --DECLARE @EntityId INT = 177380

	 --DECLARE @HierarchyLevelNameid INT = 2 -- Advisor
	 --DECLARE @EntityId INT = 59183
	 --DECLARE @EntityId INT = 55918

	 --DECLARE @HierarchyLevelNameid INT = 5 -- branch id= 2709	company=PLDA03913
	 --DECLARE @EntityId INT = 2709
	 --DECLARE @EntityId INT = 2785 --2785	PLDA05459

	 --DECLARE @HierarchyLevelNameid INT = 3 -- company PLDA03913
	 --DECLARE @EntityId INT = 9527

	 --DECLARE @HierarchyLevelNameid INT = 4 -- network PLNW01501
	 --DECLARE @EntityId INT = 1533
	 --DECLARE @EntityId INT = 1533

	DECLARE @HierarchyLevelName VARCHAR(50)
	SELECT @HierarchyLevelName = HierarchyLevelName
	FROM Platform.HierarchyEntities.HierarchyLevelNames
	WHERE HierarchyLevelNameId = @HierarchyLevelNameId

	DECLARE @AccountId INT
	DECLARE @AdviserIds TABLE(AdviserId INT)
	DECLARE @BranchIds  TABLE(BranchId INT)
	DECLARE @CompanyIds TABLE(CompanyId INT)
	DECLARE @NetworkId INT

	DECLARE @AdviserId INT,@BranchId INT,@CompanyId INT

	--one adviser,one branch,one company,one network
	IF (@HierarchyLevelName = 'SubAccount')
	BEGIN
		SELECT
			@AccountId = seca.Id,
			@AdviserId = adv.Id
		FROM dbo.SEClientAccount seca
		INNER JOIN dbo.Advisor adv ON adv.AdvCode = seca.PrimaryAdviser 
		WHERE seca.Id = @EntityId

		SELECT
		@BranchId = adv.BranchId,
		@CompanyId = co.Id,
		@NetworkId = net.Id
		FROM dbo.Advisor adv
		INNER JOIN dbo.Company co ON co.Company = adv.Company
		INNER JOIN dbo.Network net ON net.Network = co.Network
		WHERE adv.Id = @AdviserId

		INSERT INTO @AdviserIds(AdviserId) VALUES(@AdviserId)
		INSERT INTO @BranchIds(BranchId) VALUES(@BranchId)
		INSERT INTO @CompanyIds(CompanyId) VALUES(@CompanyId)
	END
	--one adviser,one branch,one company,one network
	IF (@HierarchyLevelName = 'Advisor')
	BEGIN
		SELECT
		@BranchId = adv.BranchId,
		@CompanyId = co.Id,
		@NetworkId = net.Id
		FROM dbo.Advisor adv
		INNER JOIN dbo.Company co ON co.Company = adv.Company
		INNER JOIN dbo.Network net ON net.Network = co.Network
		WHERE adv.Id = @EntityId

		INSERT INTO @AdviserIds(AdviserId) VALUES(@EntityId)
		INSERT INTO @BranchIds(BranchId) VALUES(@BranchId)
		INSERT INTO @CompanyIds(CompanyId) VALUES(@CompanyId)
	END
	--many adviser,one branch,one company,one network
	IF (@HierarchyLevelName = 'Branch')
	BEGIN
		INSERT INTO @BranchIds(BranchId) VALUES(@EntityId)

		INSERT INTO @AdviserIds
		SELECT ID
		FROM dbo.Advisor
		WHERE BranchID = @EntityId

		SELECT
		@CompanyId = co.Id,
		@NetworkId = net.Id
		FROM dbo.Branches br
		INNER JOIN dbo.Company co ON co.Company = br.Company
		INNER JOIN dbo.Network net ON net.Network = co.Network
		WHERE br.Id = @EntityId

		INSERT INTO @CompanyIds(CompanyId) VALUES(@CompanyId)
	END
	--many adviser,many branch,one company,one network
	IF (@HierarchyLevelName = 'Company')
	BEGIN
		INSERT INTO @CompanyIds(CompanyId) VALUES(@EntityId)

		INSERT INTO @AdviserIds
		SELECT adv.ID
		FROM dbo.Advisor adv
		INNER JOIN dbo.Company co ON co.Company = adv.Company
		WHERE co.Id = @EntityId

		INSERT INTO @BranchIds
		SELECT br.Id
		FROM dbo.Branches br
		INNER JOIN dbo.Company co ON co.Company = br.Company
		WHERE co.Id = @EntityId

		SELECT @NetworkId = net.Id
		FROM dbo.Company co
		INNER JOIN dbo.Network net ON net.Network = co.Network
		WHERE co.Id = @EntityId
	END
	--many adviser,many branch,many company,one network
	IF (@HierarchyLevelName = 'Network')
	BEGIN
		INSERT INTO @AdviserIds
		SELECT adv.ID
		FROM dbo.Advisor adv
		INNER JOIN dbo.Company co ON co.Company = adv.Company
		INNER JOIN dbo.Network net ON net.Network = co.Network
		WHERE net.Id = @EntityId

		INSERT INTO @BranchIds
		SELECT br.Id
		FROM dbo.Branches br
		INNER JOIN dbo.Company co ON co.Company = br.Company
		INNER JOIN dbo.Network net ON net.Network = co.Network
		WHERE net.Id = @EntityId

		INSERT INTO @CompanyIds
		SELECT co.Id
		FROM dbo.Company co
		INNER JOIN dbo.Network net ON net.Network = co.Network
		WHERE net.Id = @EntityId

		SELECT @NetworkId = @EntityId
	END

	;WITH TierStructures (TierStructureId)
	AS
	(
		SELECT
			tsp.TierStructureId
		FROM Charges.TierStructurePermissions tsp
		INNER JOIN Platform.HierarchyEntities.HierarchyLevelNames hln ON hln.HierarchyLevelNameId = tsp.HierarchyLevelNameId
		WHERE hln.HierarchyLevelName = 'SubAccount'
		AND tsp.EntityId = @AccountId

		UNION ALL

		SELECT
		tsp.TierStructureId
		FROM Charges.TierStructurePermissions tsp
		INNER JOIN Platform.HierarchyEntities.HierarchyLevelNames hln ON hln.HierarchyLevelNameId = tsp.HierarchyLevelNameId
		WHERE hln.HierarchyLevelName = 'Advisor'
		AND tsp.EntityId IN(SELECT AdviserId FROM @AdviserIds) 

		UNION ALL

		SELECT
		tsp.TierStructureId
		FROM Charges.TierStructurePermissions tsp
		INNER JOIN Platform.HierarchyEntities.HierarchyLevelNames hln ON hln.HierarchyLevelNameId = tsp.HierarchyLevelNameId
		WHERE hln.HierarchyLevelName = 'Branch'
		AND tsp.EntityId IN(SELECT BranchId FROM @BranchIds) 

		UNION ALL

		SELECT
		tsp.TierStructureId
		FROM Charges.TierStructurePermissions tsp
		INNER JOIN Platform.HierarchyEntities.HierarchyLevelNames hln ON hln.HierarchyLevelNameId = tsp.HierarchyLevelNameId
		WHERE hln.HierarchyLevelName = 'Company'
		AND tsp.EntityId IN(SELECT CompanyId FROM @CompanyIds)

		UNION ALL

		SELECT
		tsp.TierStructureId
		FROM Charges.TierStructurePermissions tsp
		INNER JOIN Platform.HierarchyEntities.HierarchyLevelNames hln ON hln.HierarchyLevelNameId = tsp.HierarchyLevelNameId
		WHERE hln.HierarchyLevelName = 'Network'
		AND tsp.EntityId = @NetworkId
	)

	SELECT TS.TierStructureId, TS.TierStructureName, TS.OwnerHierarchyLevelNameId, TS.OwnerEntityId FROM Charges.TierStructures TS
	WHERE EXISTS
	(
		SELECT 1 FROM TierStructures T
		WHERE T.TierStructureId=TS.TierStructureId
	)
