/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>A89196F75E84870BEFC3F77FDC3DB4B7</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[spAllowedAccountsForChangingFeeStructure](
               @UserId      INT,
               @ClAccountId VARCHAR(20)  = '')
AS
  /*
  
  DECLARE @UserId INT, 
  
  @ClAccountId VarChar(20)
  
  SET @ClAccountId = 'E' 
  
  SET @UserId = 424192 
  */
  
  SET @ClAccountId = dbo.Fngetheadaccountid(@ClAccountId)
  
  /*====================== TEMP TABLE =======================*/
  CREATE TABLE #candidates (
    claccountid VARCHAR(10))
  
  INSERT INTO #candidates
  EXEC Spgetallowedaccounts
    @UserId ,
    @ClAccountId
  
  CREATE INDEX ix_1 ON #candidates (
        claccountid)
  
  /*==========================================================*/
  
  SELECT DISTINCT c.claccountid                     AS headaccountid,
				  MAX(SECA.AccountName) AS AccountName,
                  Coalesce(COUNT(w.claccountid),0) AS numofpendingwizards
  FROM   #candidates AS C
		INNER JOIN dbo.clientdetails AS cd
           ON cd.claccountid = c.claccountid AND cd.feestructure = 'Bundled'         
		 INNER JOIN dbo.SEClientAccount AS SECA ON SECA.ClAccountId = c.claccountid
         LEFT JOIN dbo.workflowwizardclientsession AS w
           ON w.claccountid LIKE c.claccountid + '%' AND W.status IN ('InProgress','New')
  GROUP BY C.ClAccountId
  
  DROP TABLE #candidates

GO
