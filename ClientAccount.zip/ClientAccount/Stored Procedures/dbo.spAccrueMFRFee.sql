/***
<StoredProcedure>
    <Description>Accrue the MFR Rebate</Description>
	<Service>Charges</Service>
    <Feature>Tasks</Feature>
    <Parameters>
        <Parameter Name="@AsAt">
            <Description>The date of the fee run</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/

CREATE PROCEDURE [dbo].[spAccrueMFRFee] (@AsAt DATETIME)
AS

/*
DECLARE @AsAt SMALLDATETIME
SET @AsAt = '30 Jul 2013'
*/

BEGIN TRY
	BEGIN TRANSACTION T1

	IF OBJECT_ID(N'tempdb..#Accruals', N'U') IS NOT NULL
	BEGIN
		DROP TABLE #Accruals
	END

	DECLARE @firstNextMonth DATETIME
	SET @firstNextMonth = DATEADD(m, 1, DATEADD(d, 1 - DAY(@AsAt), @AsAt))

	DECLARE @vatRate AS DECIMAL(18, 4)

	SELECT TOP 1 @vatRate = Rate
	FROM Discovery.dbo.VATRate AS VatRate
	WHERE VatRate.Status = 'Current'

	DECLARE @TranType VARCHAR(10)

	SET @TranType = 'MFR'

	------------------------------------------------------------------------------------------------------------------
	-- Tax Rate Logic - at the moment just fetching from sys variable. Future todo: configuable by new table
	------------------------------------------------------------------------------------------------------------------
	DECLARE @taxRateStr VARCHAR(max)
	DECLARE @taxRate NUMERIC(10, 4)

	SET @taxRateStr = (
			SELECT SystemVariables.[Value]
			FROM SystemVariables.dbo.SystemVariables AS SystemVariables
			WHERE SystemVariables.Location = 'Global'
				AND SystemVariables.Application = 'AssetWatch'
				AND SystemVariables.[Variable] = 'UKMutualFund-SourceWTInterest'
			)
			
	SET @taxRate = cast(@taxRateStr AS NUMERIC(10, 4))

	CREATE TABLE #Accruals (
		ToBeAppliedFeesId INT
		,AsAt SMALLDATETIME
		,SecaId INT
		,InstrumentId INT
		,Valuation MONEY
		,Amount MONEY
		,Rate NUMERIC(7, 4)
		,VatRate NUMERIC(7, 4)
		,VatAmount MONEY
		,ChargeDate SMALLDATETIME
		,IsProcessed BIT
		,CompanyId INT
		,Units MONEY
		,TaxAmount MONEY
		,WrapAmount MONEY
		,CompanyAmount MONEY
		,ClientAmount MONEY
		,WrapProviderId INT
		,CurrencyId INT
		)

	INSERT INTO #Accruals (
		ToBeAppliedFeesId
		,AsAt
		,SecaID
		,InstrumentId
		,Valuation
		,Amount
		,Rate
		,ChargeDate
		,IsProcessed
		,VATRate
		,VATAmount
		,CompanyId
		,Units
		,TaxAmount
		,WrapAmount
		,CompanyAmount
		,ClientAmount
		,WrapProviderId
		,CurrencyId 
		)
	SELECT ToBeApplied.Id AS ToBeAppliedFeesId
		,Fum.AsAt
		,Fum.SECAId
		,Fum.InstrumentId
		,ROUND(COALESCE((Fum.NonCashAmount - Fum.BTAAmount), 0), 4) AS Valuation
		,CASE 
			WHEN ToBeApplied.ApplyVAT = 1
				THEN ROUND(COALESCE(((Fum.NonCashAmount - Fum.BTAAmount) * ToBeApplied.Rate / 100 / 365.25), 0), 4) + ROUND(COALESCE(((Fum.NonCashAmount - Fum.BTAAmount) * ToBeApplied.Rate / 100 / 365.25), 0) * @vatRate / 100, 4)
			ELSE ROUND(COALESCE(((Fum.NonCashAmount - Fum.BTAAmount) * ToBeApplied.Rate / 100 / 365.25), 0), 4)
			END AS Amount
		,COALESCE(ToBeApplied.Rate, 0) AS Rate
		,@firstNextMonth
		,0 AS IsProcessed
		,CASE 
			WHEN ToBeApplied.ApplyVAT = 1
				THEN @vatRate
			ELSE NULL
			END AS VATRate
		,CASE 
			WHEN ToBeApplied.ApplyVAT = 1
				THEN ROUND(COALESCE(((Fum.NonCashAmount - Fum.BTAAmount) * ToBeApplied.Rate / 100 / 365.25), 0) * @vatRate / 100, 4)
			ELSE NULL
			END AS VatAmount
		,Fum.CompanyId
		,Fum.Quantity
		,ROUND(ToBeApplied.Rate * (Fum.NonCashAmount - Fum.BTAAmount) * 1 /36525,4) * (@taxRate/100) * (FeeTranTypes.UseTax) as TaxAmount /*add in future*/
		,0 as WrapAmount /*add in future*/
		,0 as CompanyAmount /*add in future*/
		,0 as ClientAmount /*add in future*/
		,WrapProvider.Id as WrapProviderId
		,Fum.CurrencyId
	FROM Cache.dbo.Fee_FUM_ByInstrument AS Fum
	INNER JOIN dbo.SEClientAccount AS SecaId
		ON SecaId.Id = Fum.SECAId
	INNER JOIN Discovery.dbo.ClientAccount AS ClientAccount
		ON ClientAccount.ClAccountId = SecaId.ClAccountId
	INNER JOIN dbo.WrapProvider AS WrapProvider
		ON WrapProvider.Id = Fum.WrapProviderId
	INNER JOIN dbo.FeeTranTypes AS FeeTranTypes
		ON FeeTranTypes.TranType IN (@TranType)
			AND FeeTranTypes.WrapProvider = WrapProvider.WrapProvider
	INNER JOIN dbo.ToBeAppliedFees_ByInstV2 AS ToBeApplied
		ON ToBeApplied.AsAt = Fum.AsAt
			AND Fum.SECAId = ToBeApplied.SECAId
			AND ToBeApplied.Applied = 0
			AND FeeTranTypes.Id = ToBeApplied.FeeTranTypesId
			AND Fum.InstrumentId = ToBeApplied.InstrumentId
	INNER JOIN Res_DB.dbo.Instruments INS
		ON fum.InstrumentId = INS.Id
		INNER JOIN Res_DB.dbo.CurrencyFormat CFI
			ON INS.InstrumentCCY = CFI.ISOCode
	WHERE Fum.AsAt = @AsAt AND Fum.CurrencyId = CFI.Id

	INSERT INTO #Accruals (
		ToBeAppliedFeesId
		,AsAt
		,SecaID
		,InstrumentId
		,Valuation
		,Amount
		,Rate
		,ChargeDate
		,IsProcessed
		,VATRate
		,VATAmount
		,CompanyId
		,Units
		,TaxAmount
		,WrapAmount
		,CompanyAmount
		,ClientAmount
		,WrapProviderId
		,CurrencyId 
		)
	SELECT ToBeApplied.Id AS ToBeAppliedFeesId
		,Fum.AsAt
		,Fum.SECAId
		,Fum.InstrumentId
		,ROUND(COALESCE(((Fum.NonCashAmount * COALESCE(FX2.A,1)) - (Fum.BTAAmount * COALESCE(FX2.A,1))), 0), 4) AS Valuation
		,CASE 
			WHEN ToBeApplied.ApplyVAT = 1
				THEN ROUND(COALESCE((((Fum.NonCashAmount * COALESCE(FX2.A,1)) - (Fum.BTAAmount * COALESCE(FX2.A,1))) * ToBeApplied.Rate / 100 / 365.25), 0), 4) + ROUND(COALESCE((((Fum.NonCashAmount * COALESCE(FX2.A,1)) - (Fum.BTAAmount * COALESCE(FX2.A,1))) * ToBeApplied.Rate / 100 / 365.25), 0) * @vatRate / 100, 4)
			ELSE ROUND(COALESCE((((Fum.NonCashAmount * COALESCE(FX2.A,1)) - (Fum.BTAAmount * COALESCE(FX2.A,1))) * ToBeApplied.Rate / 100 / 365.25), 0), 4)
			END AS Amount
		,COALESCE(ToBeApplied.Rate, 0) AS Rate
		,@firstNextMonth
		,0 AS IsProcessed
		,CASE 
			WHEN ToBeApplied.ApplyVAT = 1
				THEN @vatRate
			ELSE NULL
			END AS VATRate
		,CASE 
			WHEN ToBeApplied.ApplyVAT = 1
				THEN ROUND(COALESCE((((Fum.NonCashAmount * COALESCE(FX2.A,1)) - (Fum.BTAAmount * COALESCE(FX2.A,1))) * ToBeApplied.Rate / 100 / 365.25), 0) * @vatRate / 100, 4)
			ELSE NULL
			END AS VatAmount
		,Fum.CompanyId
		,Fum.Quantity
		,ROUND(ToBeApplied.Rate * ((Fum.NonCashAmount * COALESCE(FX2.A,1)) - (Fum.BTAAmount * COALESCE(FX2.A,1))) * 1 /36525,4) * (@taxRate/100) * (FeeTranTypes.UseTax) as TaxAmount /*add in future*/
		,0 as WrapAmount /*add in future*/
		,0 as CompanyAmount /*add in future*/
		,0 as ClientAmount /*add in future*/
		,WrapProvider.Id as WrapProviderId
		,CF.Id
	FROM Cache.dbo.Fee_FUM_ByInstrument AS Fum
	INNER JOIN dbo.SEClientAccount AS SecaId
		ON SecaId.Id = Fum.SECAId
	INNER JOIN Discovery.dbo.ClientAccount AS ClientAccount
		ON ClientAccount.ClAccountId = SecaId.ClAccountId
	INNER JOIN dbo.WrapProvider AS WrapProvider
		ON WrapProvider.Id = Fum.WrapProviderId
	INNER JOIN dbo.FeeTranTypes AS FeeTranTypes
		ON FeeTranTypes.TranType IN (@TranType)
			AND FeeTranTypes.WrapProvider = WrapProvider.WrapProvider
	INNER JOIN dbo.ToBeAppliedFees_ByInstV2 AS ToBeApplied
		ON ToBeApplied.AsAt = Fum.AsAt
			AND Fum.SECAId = ToBeApplied.SECAId
			AND ToBeApplied.Applied = 0
			AND FeeTranTypes.Id = ToBeApplied.FeeTranTypesId
			AND Fum.InstrumentId = ToBeApplied.InstrumentId
	INNER JOIN Res_DB.dbo.Instruments INS
		ON fum.InstrumentId = INS.Id
		INNER JOIN Res_DB.dbo.CurrencyFormat CFI
			ON INS.InstrumentCCY = CFI.ISOCode
			LEFT JOIN Res_DB.dbo.Securities as FX2 
				ON Fx2.Security = CFI.ISOCode + 'USD' 
				AND Fx2.Date = @AsAt
	INNER JOIN Res_DB.dbo.CurrencyFormat CF
			ON Fum.CurrencyId = CF.Id AND CF.ISOCode = 'USD'
	WHERE Fum.AsAt = @AsAt AND Fum.CurrencyId <> CFI.ID

	INSERT INTO #Accruals (
		ToBeAppliedFeesId
		,AsAt
		,SecaID
		,InstrumentId
		,Valuation
		,Amount
		,Rate
		,ChargeDate
		,IsProcessed
		,VATRate
		,VATAmount
		,CompanyId
		,Units
		,TaxAmount
		,WrapAmount
		,CompanyAmount
		,ClientAmount
		,WrapProviderId
		,CurrencyId 
		)
	SELECT ToBeApplied.Id AS ToBeAppliedFeesId
		,Fum.AsAt
		,Fum.SECAId
		,Fum.InstrumentId
		,ROUND(COALESCE((Fum.NonCashAmount * COALESCE(FX2.A,1) / COALESCE(FX1.A,1)) - (Fum.BTAAmount * COALESCE(FX2.A,1) / COALESCE(FX1.A,1)), 0), 4) AS Valuation
		,CASE 
			WHEN ToBeApplied.ApplyVAT = 1
				THEN ROUND(COALESCE((((Fum.NonCashAmount * COALESCE(FX2.A,1) / COALESCE(FX1.A,1)) - (Fum.BTAAmount * COALESCE(FX2.A,1) / COALESCE(FX1.A,1))) * ToBeApplied.Rate / 100 / 365.25), 0), 4) + ROUND(COALESCE((((Fum.NonCashAmount * COALESCE(FX2.A,1) / COALESCE(FX1.A,1)) - (Fum.BTAAmount * COALESCE(FX2.A,1) / COALESCE(FX1.A,1))) * ToBeApplied.Rate / 100 / 365.25), 0) * @vatRate / 100, 4)
			ELSE ROUND(COALESCE((((Fum.NonCashAmount * COALESCE(FX2.A,1) / COALESCE(FX1.A,1)) - (Fum.BTAAmount * COALESCE(FX2.A,1) / COALESCE(FX1.A,1))) * ToBeApplied.Rate / 100 / 365.25), 0), 4)
			END AS Amount
		,COALESCE(ToBeApplied.Rate, 0) AS Rate
		,@firstNextMonth
		,0 AS IsProcessed
		,CASE 
			WHEN ToBeApplied.ApplyVAT = 1
				THEN @vatRate
			ELSE NULL
			END AS VATRate
		,CASE 
			WHEN ToBeApplied.ApplyVAT = 1
				THEN ROUND(COALESCE((((Fum.NonCashAmount * COALESCE(FX2.A,1) / COALESCE(FX1.A,1)) - (Fum.BTAAmount * COALESCE(FX2.A,1) / COALESCE(FX1.A,1))) * ToBeApplied.Rate / 100 / 365.25), 0) * @vatRate / 100, 4)
			ELSE NULL
			END AS VatAmount
		,Fum.CompanyId
		,Fum.Quantity
		,ROUND(ToBeApplied.Rate * ((Fum.NonCashAmount * COALESCE(FX2.A,1) / COALESCE(FX1.A,1)) - (Fum.BTAAmount * COALESCE(FX2.A,1) / COALESCE(FX1.A,1))) * 1 /36525,4) * (@taxRate/100) * (FeeTranTypes.UseTax) as TaxAmount /*add in future*/
		,0 as WrapAmount /*add in future*/
		,0 as CompanyAmount /*add in future*/
		,0 as ClientAmount /*add in future*/
		,WrapProvider.Id as WrapProviderId
		,CF.Id
	FROM Cache.dbo.Fee_FUM_ByInstrument AS Fum
	INNER JOIN dbo.SEClientAccount AS SecaId
		ON SecaId.Id = Fum.SECAId
	INNER JOIN Discovery.dbo.ClientAccount AS ClientAccount
		ON ClientAccount.ClAccountId = SecaId.ClAccountId
	INNER JOIN dbo.WrapProvider AS WrapProvider
		ON WrapProvider.Id = Fum.WrapProviderId
	INNER JOIN dbo.FeeTranTypes AS FeeTranTypes
		ON FeeTranTypes.TranType IN (@TranType)
			AND FeeTranTypes.WrapProvider = WrapProvider.WrapProvider
	INNER JOIN dbo.ToBeAppliedFees_ByInstV2 AS ToBeApplied
		ON ToBeApplied.AsAt = Fum.AsAt
			AND Fum.SECAId = ToBeApplied.SECAId
			AND ToBeApplied.Applied = 0
			AND FeeTranTypes.Id = ToBeApplied.FeeTranTypesId
			AND Fum.InstrumentId = ToBeApplied.InstrumentId
	INNER JOIN Res_DB.dbo.Instruments INS
		ON fum.InstrumentId = INS.Id
		INNER JOIN Res_DB.dbo.CurrencyFormat CFI
			ON INS.InstrumentCCY = CFI.ISOCode
			LEFT JOIN Res_DB.dbo.Securities as FX2 
				ON Fx2.Security = CFI.ISOCode + 'USD' 
				AND Fx2.Date = @AsAt
	INNER JOIN Res_DB.dbo.CurrencyFormat CF
			ON Fum.CurrencyId = CF.Id AND CF.ISOCode <> 'USD'
			LEFT JOIN Res_DB.dbo.Securities as FX1 
				ON Fx1.Security = CF.ISOCode + 'USD' 
				AND Fx1.Date = @AsAt
	WHERE Fum.AsAt = @AsAt AND Fum.CurrencyId <> CFI.ID

	INSERT INTO dbo.Fee_Accrual_MFR (
		AsAt
		,SecaID
		,InstrumentID
		,Valuation
		,TotalAmount
		,Rate
		,ChargeDate
		,IsProcessed
		,VatRate
		,VatAmount
		,CompanyId
		,Units
		,TaxAmount
		,WrapAmount
		,CompanyAmount
		,ClientAmount
		,WrapProviderId
		,CurrencyId 
		)
	SELECT #Accruals.AsAt
		,#Accruals.SECAId
		,#Accruals.InstrumentId
		,#Accruals.Valuation
		,- #Accruals.Amount AS Amount
		,#Accruals.Rate
		,#Accruals.ChargeDate
		,#Accruals.IsProcessed
		,#Accruals.VatRate
		,-#Accruals.VatAmount AS VatAmount
		,#Accruals.CompanyId
		,#Accruals.Units
		,-#Accruals.TaxAmount as TaxAmount
		,#Accruals.WrapAmount
		,#Accruals.CompanyAmount
		,#Accruals.ClientAmount
		,#Accruals.WrapProviderId
		,#Accruals.CurrencyId 
	FROM #Accruals
END TRY

BEGIN CATCH
	ROLLBACK TRANSACTION T1

	DECLARE @ErrorMessage NVARCHAR(4000);
	DECLARE @ErrorSeverity INT;
	DECLARE @ErrorState INT;

	IF OBJECT_ID(N'tempdb..#Accruals', N'U') IS NOT NULL
	BEGIN
		DROP TABLE #Accruals
	END

	SELECT @ErrorMessage = ERROR_MESSAGE()
		,@ErrorSeverity = ERROR_SEVERITY()
		,@ErrorState = ERROR_STATE();

	RAISERROR (
			@ErrorMessage
			,@ErrorSeverity
			,@ErrorState
			);
END CATCH;

IF @@TRANCOUNT > 0
BEGIN
	SELECT 'Success' AS Result

	UPDATE dbo.ToBeAppliedFees_ByInstV2
	SET Applied = 1
		,ProcessedDate = GETDATE()
	WHERE Id IN (
			SELECT ToBeAppliedFeesId
			FROM #Accruals
			)

	INSERT INTO dbo.AppliedFees_ByInstV2 (
		FeeTranTypesId
		,SECAId
		,InstrumentId
		,Rate
		,ProcessedDate
		,DateCreated
		,AsAt
		,ApplyVat
		)
	SELECT ToBeApplied.FeeTranTypesId
		,ToBeApplied.SECAId
		,ToBeApplied.InstrumentId
		,ToBeApplied.Rate
		,ToBeApplied.ProcessedDate
		,ToBeApplied.DateCreated
		,ToBeApplied.AsAt
		,ToBeApplied.ApplyVAT
	FROM dbo.ToBeAppliedFees_ByInstV2 ToBeApplied
	WHERE Id IN (
			SELECT #Accruals.ToBeAppliedFeesId
			FROM #Accruals
			)

	DELETE dbo.ToBeAppliedFees_ByInstV2
	WHERE Id IN (
			SELECT ToBeAppliedFeesId
			FROM #Accruals
			)

	IF OBJECT_ID(N'tempdb..#Accruals', N'U') IS NOT NULL
	BEGIN
		DROP TABLE #Accruals
	END

	COMMIT TRANSACTION T1
END
GO