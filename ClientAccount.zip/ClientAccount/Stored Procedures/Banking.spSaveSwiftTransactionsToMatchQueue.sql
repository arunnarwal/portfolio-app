/*** 
<StoredProcedure>
	<Description>Saves items to the automated receipt matching queue</Description>
	<Parameters>
		<Parameter Name="@Items">
			<Description>Xml document containing automated receipt matching queue items</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROC Banking.spSaveSwiftTransactionsToMatchQueue
	@Items VARCHAR(MAX)
AS
	DECLARE @ItemsXml XML = CAST(@Items AS XML)

	SELECT
		ROW_NUMBER() OVER(ORDER BY T.x.value('@TransactionId', 'INT')) Id,
		T.x.value('@TransactionId', 'INT') TransactionId,
		T.x.value('@LastAttempted', 'DATETIME') LastAttempted,
		T.x.value('@AttemptsRemaining', 'INT') AttemptsRemaining,
		T.x.value('@Complete', 'BIT') Complete
	INTO #Items
	FROM
		@ItemsXml.nodes('Items/Item') T(x)

	CREATE CLUSTERED INDEX IDX_Items ON #Items (Id)

	MERGE INTO Banking.SwiftTransactionsToMatchQueue T
	USING (SELECT TransactionId, LastAttempted, AttemptsRemaining, Complete FROM #Items) S
		ON T.TransactionId = S.TransactionId
	WHEN MATCHED AND S.Complete <> 1 AND S.AttemptsRemaining > 0 THEN
		UPDATE
		SET
			LastAttempted = S.LastAttempted,
			AttemptsRemaining = S.AttemptsRemaining
	WHEN MATCHED AND (S.Complete = 1 OR S.AttemptsRemaining = 0) THEN
		DELETE
	WHEN NOT MATCHED THEN
		INSERT (TransactionId, LastAttempted, AttemptsRemaining)
		VALUES (S.TransactionId, S.LAstAttempted, S.AttemptsRemaining);

	INSERT Banking.SwiftTransactionsToMatchQueueHistory (TransactionId, LastAttempted, AttemptsRemaining, Complete)
	SELECT TransactionId, LastAttempted, AttemptsRemaining, Complete
	FROM #Items
	WHERE Complete = 1 OR AttemptsRemaining = 0

	DROP TABLE #Items