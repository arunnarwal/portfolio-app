CREATE PROCEDURE dbo.spChangeCustomerInstructionForCustomerInBondLifeAssured
(
@CustomerInstructionId INT,
@CustomerId INT
)

AS

DECLARE @CustomerInstructionHierarchyLevelId SMALLINT,
@CustomerHierarchyLevelId SMALLINT

SELECT @CustomerInstructionHierarchyLevelId = HierarchyLevelNameId FROM Platform.HierarchyEntities.HierarchyLevelNames WHERE HierarchyLevelName = 'CustomerInstruction'

SELECT @CustomerHierarchyLevelId = HierarchyLevelNameId FROM Platform.HierarchyEntities.HierarchyLevelNames WHERE HierarchyLevelName = 'Customer'

UPDATE dbo.BondLifeAssured SET CustomerHierarchyTypeId = @CustomerHierarchyLevelId, CustomerId = @CustomerId WHERE CustomerId = @CustomerInstructionId AND CustomerHierarchyTypeId = @CustomerInstructionHierarchyLevelId

UPDATE Platform.Instructions.SubAccountInstructionBondLifeAssuredCustomers SET CustomerHierarchyTypeId = @CustomerHierarchyLevelId, CustomerId = @CustomerId WHERE CustomerId = @CustomerInstructionId AND CustomerHierarchyTypeId = @CustomerInstructionHierarchyLevelId