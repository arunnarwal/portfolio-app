/***
<StoredProcedure>
    <Description>Accrue the fee Product AMC Member</Description>
	<Service>Charges</Service>
    <Feature>Tasks</Feature>
    <Parameters>
        <Parameter Name="@AsAt">
            <Description>The date of the fee run</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/

CREATE PROCEDURE [dbo].[spAccruePAMCMFee] (@AsAt DATETIME)
AS

--DECLARE @AsAt SMALLDATETIME
--SET @AsAt = '11 April 2014'

BEGIN TRY
	BEGIN TRANSACTION T1

	IF OBJECT_ID(N'tempdb..#Accruals', N'U') IS NOT NULL
	BEGIN
		DROP TABLE #Accruals
	END

	DECLARE @TranType VARCHAR(10)
	SET @TranType = 'PAMCM'

	CREATE TABLE #Accruals (
		ToBeAppliedFeesID INT
		,AsAt SMALLDATETIME
		,SecaId INT
		,Valuation MONEY
		,Amount MONEY
		,Rate NUMERIC(7, 4)
		,ChargeDate SMALLDATETIME
		,IsProcessed BIT
		,CurrencyId INT
		)

	INSERT INTO #Accruals (
		ToBeAppliedFeesID
		,AsAt
		,SecaId
		,Valuation
		,Amount
		,Rate
		,ChargeDate
		,IsProcessed
		,CurrencyId
		)
	SELECT 
		ToBeApplied.Id AS ToBeAppliedFeesId
		,Fum.AsAt
		,Fum.SECAId
		,ROUND(COALESCE((Fum.CashAmount + Fum.NonCashAmount), 0), 4) AS Valuation
		,ROUND(COALESCE(((Fum.CashAmount + Fum.NonCashAmount) * ToBeApplied.Rate / 100 / 365.25), 0), 4) AS Amount
		,COALESCE(ToBeApplied.Rate, 0) AS Rate
		,FRQRanged.ToDate
		,0 AS IsProcessed
		,Fum.CurrencyId
	FROM Cache.dbo.Fee_FUM_ByAccount AS Fum
	INNER JOIN dbo.[SEClientAccount] AS Seca
		ON Seca.Id = Fum.SECAId
	INNER JOIN dbo.[WrapProvider] AS WrapProvider
		ON WrapProvider.Id = Fum.WrapProviderId
	INNER JOIN dbo.FeeTranTypes AS FeeTranTypes
		ON FeeTranTypes.TranType = @TranType
			AND FeeTranTypes.WrapProvider = WrapProvider.WrapProvider
	INNER JOIN dbo.ToBeAppliedFees_ByAccV2 AS ToBeApplied
		ON ToBeApplied.AsAt = Fum.AsAt
			AND Fum.SECAId = ToBeApplied.SECAId
			AND ToBeApplied.Applied = 0
			AND FeeTranTypes.Id = ToBeApplied.FeeTranTypesId
	CROSS APPLY dbo.fnGetDateRangesForFrequencies(@AsAt,DATEADD(dd, 0, DATEDIFF(dd, 0, Seca.DateCreated + 1))) FRQRanged
	WHERE FRQRanged.Frequency = 'M'
	AND Fum.AsAt = @AsAt 
	
	INSERT INTO dbo.Fee_Accrual_PAMCM (
		AsAt
		,SecaId
		,Valuation
		,Amount
		,Rate
		,ChargeDate
		,IsProcessed
		,CurrencyId
		)
	SELECT AsAt
		,#Accruals.SECAId
		,#Accruals.Valuation
		,#Accruals.Amount
		,#Accruals.Rate
		,DATEADD(dd, 0, DATEDIFF(dd, 0, #Accruals.ChargeDate))
		,#Accruals.IsProcessed
		,#Accruals.CurrencyId
	FROM #Accruals
END TRY

BEGIN CATCH
	ROLLBACK TRANSACTION T1

	DECLARE @ErrorMessage NVARCHAR(4000);
	DECLARE @ErrorSeverity INT;
	DECLARE @ErrorState INT;

	IF OBJECT_ID(N'tempdb..#Accruals', N'U') IS NOT NULL
	BEGIN
		DROP TABLE #Accruals
	END

	SELECT @ErrorMessage = ERROR_MESSAGE()
		,@ErrorSeverity = ERROR_SEVERITY()
		,@ErrorState = ERROR_STATE();

	RAISERROR (
			@ErrorMessage
			,@ErrorSeverity
			,@ErrorState
			);
END CATCH;

IF @@TRANCOUNT > 0
BEGIN 
	SELECT 'Success' AS Result

	UPDATE dbo.ToBeAppliedFees_ByAccV2 
	SET Applied = 1
		,ProcessedDate = GETDATE()
	WHERE Id IN (
			SELECT ToBeAppliedFeesId
			FROM #Accruals
			)

	INSERT INTO dbo.AppliedFees_ByAccV2 (
		[FeeTranTypesID]
		,[SecaId]
		,[Rate]
		,[ProcessedDate]
		,[DateCreated]
		,[AsAt]
		,[ApplyVAT]
		)
	SELECT ToBeApplied.[FeeTranTypesId]
		,ToBeApplied.[SECAId]
		,ToBeApplied.[Rate]
		,ToBeApplied.[ProcessedDate]
		,ToBeApplied.[DateCreated]
		,ToBeApplied.[AsAt]
		,ToBeApplied.[ApplyVAT]
	FROM dbo.ToBeAppliedFees_ByAccV2 ToBeApplied
	WHERE ToBeApplied.Id IN (
			SELECT Accruals.ToBeAppliedFeesId
			FROM #Accruals Accruals
			)

	DELETE dbo.ToBeAppliedFees_ByAccV2
	WHERE Id IN (
			SELECT ToBeAppliedFeesId
			FROM #Accruals Accruals
			)

	DROP TABLE #Accruals

	COMMIT TRANSACTION T1
END
GO