/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>413B90E86B9A68F90E98649247B8ABE4</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[spCgtGetAvailableHoldings]    
@clAccountId VARCHAR(100)
AS

BEGIN
SELECT SUM(Quantity) AS Quantity,
	   InstrumentCode
FROM scripTransactions 
WHERE clAccountId = @clAccountId  And TransStatus = 'Settled'
GROUP BY InstrumentCode
END
GO
