/***
<StoredProcedure>
    <Description>Permissions clients client fee FUM flags for MFR</Description>
	<Service>Charges</Service>
    <Feature>Tasks</Feature>
    <Parameters>
        <Parameter Name="@AsAt">
            <Description>The date of the fee run</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [dbo].[spApplyFeeFlags_ByInst_MFR] (@AsAt DATETIME)
AS
/*
declare @AsAt datetime 
set @AsAt = '10-Oct-2013'
*/
IF OBJECT_ID(N'tempdb.dbo.#FeeAccrual', N'U') IS NOT NULL
BEGIN
	DROP TABLE #FeeAccrual
END

DECLARE @TranType VARCHAR(10)
SET @TranType = 'MFR'

CREATE TABLE #FeeAccrual (
	SecaId INT
	,InstrumentID INT
	,AsAt SMALLDATETIME
	,FeeTranTypesID INT
	,Applies BIT
	,Status_NoteID INT
	,Rate NUMERIC(7, 4)
	,ApplyVAT BIT
	)

INSERT INTO #FeeAccrual
(SECAID,AsAt,InstrumentId,FeeTranTypesId,Applies,Status_NoteId,Rate,ApplyVat)
SELECT Fum.SECAId
	,@AsAt AS AsAt
	,Fum.InstrumentId
	,FeeTranTypes.Id AS FeeTranTypesId
	,CASE 
		WHEN (isnull(FeeTranTypes.IsAllowed, 0) = 1)
			AND (RebateClient.Rate > 0)
			AND (Fum.NonCashAmount - Fum.BtaAmount) > 0
			AND (isnull(ProductDetails.FullyWithdrawn, 0) = 0)
			THEN 1
		ELSE 0
		END AS Applies
	,CASE 
		WHEN isnull(FeeTranTypes.IsAllowed, 0) = 0
			THEN 1
		WHEN RebateClient.Rate IS NULL
			THEN 2
		WHEN isnull(RebateClient.Rate, 0) = 0
			THEN 3
		WHEN Fum.NonCashAmount - Fum.BtaAmount <= 0
			THEN 4
		WHEN (isnull(ProductDetails.FullyWithdrawn, 0) = 1)
			THEN 5
		ELSE 0
		END AS Status_NoteId
	,RebateClient.Rate
	,CASE WHEN ((ISNULL(VatProduct.VatEnabled, 0) = 1) AND (ISNULL(VatFee.VatEnabled, 0) = 1) )
			THEN 1
		ELSE 0
		END AS ApplyVat
FROM Cache.dbo.Fee_FUM_ByInstrument AS Fum
INNER JOIN dbo.WrapProvider AS WrapProvider
	ON Fum.WrapProviderID = WrapProvider.ID
INNER JOIN dbo.SEClientAccount AS SecaId
	ON Fum.SecaId = SecaId.Id
LEFT JOIN Discovery.dbo.ProductDetails AS ProductDetails
	ON ProductDetails.CLAccountID = SecaId.CLAccountID
INNER JOIN dbo.Advisor AS Advisor
	ON SecaId.PrimaryAdviser = Advisor.AdvCode
INNER JOIN dbo.FeeTranTypes AS FeeTranTypes
	ON FeeTranTypes.TranType = @TranType
		AND FeeTranTypes.WrapProvider = WrapProvider.WrapProvider
--LEFT JOIN [ClientAccount].dbo.[fnHeadAccounts]() as HA
--	ON HA.CLAccountID = SecaId.CLAccountId
LEFT JOIN dbo.vwVATProductTypeByCompany VatProduct
	ON VatProduct.ProductType = ProductDetails.ProductType 
		AND VatProduct.Company = Advisor.Company
LEFT JOIN dbo.vwVATFeeByCompany VatFee
	ON VatFee.FeeTranTypeId =  FeeTranTypes.Id 
		AND VatFee.Company = Advisor.Company		
LEFT JOIN dbo.[fn_GetRebateByClient](@AsAt) AS RebateClient
	ON RebateClient.WrapproviderID = Fum.WrapProviderId
	and RebateClient.CompanyID = Fum.CompanyId
	and RebateClient.SecaId = Fum.SecaId
	and RebateClient.InstrumentID = Fum.InstrumentId
LEFT JOIN dbo.AppliedFees_ByInstV2 AS Applied
	ON Applied.AsAt = @AsAt
		AND Applied.SecaId = Fum.SecaId
		AND Applied.FeeTranTypesId = FeeTranTypes.Id
		AND Applied.InstrumentId = Fum.InstrumentID
WHERE Fum.AsAt = @AsAt
	AND Applied.Id IS NULL /*ensures that only non-already-applied fees will be created*/
	AND NOT EXISTS (SELECT 1 FROM dbo.Fee_Fum_ExcludeAccountTypes EXAT 
						WHERE EXAT.WrapProviderID = WrapProvider.ID 
						AND EXAT.FeeTranTypeID = FeeTranTypes.ID 
						AND EXAT.AccountType = SecaId.InvestorType)

INSERT INTO dbo.ToBeAppliedFees_ByInstV2 (
	SecaId
	,[AsAt]
	,InstrumentID
	,FeeTranTypesID
	,Applied
	,Rate
	,ApplyVAT
	)
SELECT FeeAccruals.SecaId
	,FeeAccruals.[AsAt]
	,FeeAccruals.InstrumentId
	,FeeAccruals.FeeTranTypesId
	,0 As Applied /*Applied*/
	,FeeAccruals.Rate
	,FeeAccruals.ApplyVat
FROM #FeeAccrual as FeeAccruals
LEFT JOIN dbo.ToBeAppliedFees_ByInstV2 as ToApply
	ON FeeAccruals.SECAID = ToApply.SECAID AND FeeAccruals.AsAt = ToApply.AsAt AND FeeAccruals.InstrumentID = ToApply.InstrumentID AND FeeAccruals.FeeTranTypesID = ToApply.FeeTranTypesID
WHERE FeeAccruals.Applies = 1 AND ToApply.SECAID IS NULL

INSERT INTO dbo.NonAppliedFees_ByInstV2 (
	SECAId
	,InstrumentID
	,[AsAt]
	,FeeTranTypesID
	,Status_NoteID
	)
SELECT FeeAccruals.SecaId
	,FeeAccruals.InstrumentId
	,FeeAccruals.[AsAt]
	,FeeAccruals.FeeTranTypesId
	,FeeAccruals.Status_NoteId
FROM #FeeAccrual AS FeeAccruals
LEFT JOIN dbo.NonAppliedFees_ByInstV2 as NonApplied
	ON FeeAccruals.SecaId = NonApplied.SecaId AND FeeAccruals.AsAt = NonApplied.AsAt AND FeeAccruals.InstrumentID = NonApplied.InstrumentID AND FeeAccruals.FeeTranTypesID = NonApplied.FeeTranTypesID
WHERE FeeAccruals.Applies = 0 AND FeeAccruals.SecaId IS NULL

IF OBJECT_ID(N'tempdb.dbo.#FeeAccrual', N'U') IS NOT NULL
BEGIN
	DROP TABLE #FeeAccrual
END
GO


