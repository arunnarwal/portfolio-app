/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>575C56AFB63E4980460606871E69B4EB</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE[dbo].[spClientHoldingsEligibleForMP](@CLAccountID VarChar(20), @PortfolioID Integer)  AS

/*
DECLARE @CLAccountID as VarChar(20)
DECLARE @PortfolioID as Integer
SET @CLAccountID = 'EL2002361'
SET @PortfolioID = 1050
*/

SELECT st.CLAccountID, st.InstrumentCode, i.descript [Description], SUM(Quantity) Quantity, o Price, (SUM(Quantity) * o)  [Value]
FROM ClientAccount..ScripTransactions st
	INNER JOIN ClientAccount..Consolidate c on c.SubCLAccountID = st.CLAccountID
	INNER JOIN Discovery..ProductDetails pd on pd.CLAccountID = st.CLAccountID
	INNER JOIN Discovery..ClientAccount ca on ca.CLAccountID = st.CLAccountID
	INNER JOIN ClientAccount..SEClientAccount se on se.CLAccountID = st.CLAccountID
	INNER JOIN (SELECT [Security] InstrumentCode, Max(date) date FROM Res_DB..Securities GROUP BY [Security]) dates on dates.InstrumentCode = st.InstrumentCode
	INNER JOIN Res_DB..Securities s on s.Security = dates.InstrumentCode AND s.date = dates.date
	INNER JOIN Res_DB..Instruments i on i.Security = st.InstrumentCode
WHERE c.CLAccountID = @CLAccountID AND st.Location = 'Custody' AND TransStatus = 'Settled' AND InvestorType <> 'Consolidated' AND DPSAccountType = 'Sub-Account' AND pd.ProductType <> 'Fund Account'
AND EXISTS (SELECT 1 FROM  Discovery..vwMPAssetClassBreakdown WHERE PortfolioID = @PortfolioID AND InstrumentCode = st.InstrumentCode)
GROUP BY st.CLAccountID, st.InstrumentCode, o, descript
HAVING SUM(Quantity)  > 0
GO
