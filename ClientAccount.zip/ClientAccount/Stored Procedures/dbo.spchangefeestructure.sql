/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>96E6487FF1E4967336AF801E99DF0FF8</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[spchangefeestructure](
                @UserId      INT,
                @ClAccountId VARCHAR(20))
AS
  /*   
    
  DECLARE @UserId INT,   
    
  @ClAccountId VarChar(20)   
    
  SET @ClAccountId = 'EL10'   
    
  SET @UserId = 433247   
    
  */
  DECLARE  @Today DATETIME
  
  SET @Today = Getdate()
  
  SET @ClAccountId = dbo.Fngetheadaccountid(@ClAccountId)
  
  BEGIN TRANSACTION changefeestructure
  
  DECLARE  @id            INT,
           @oldValues     VARCHAR(500),
           @newValues     VARCHAR(500),
           @TransactionId INT
  
  INSERT INTO discovery..requestinterfacetransactions
             (actionname,
              claccountid,
              requestedby,
              requestdate)
  VALUES     ('ChangeFeeStructure',@ClAccountId,@userId,@Today)
  
  SELECT @TransactionId = Scope_identity()
  
  WHILE EXISTS (SELECT 1
                FROM   dbo.workflowwizardclientsession
                WHERE  status IN ('InProgress','New')
                       AND claccountid LIKE @ClAccountId + '%')
    BEGIN
      SELECT @id = id,
             @oldValues = 'Status=' + status + '|LastUpdated=' + CASE 
                                                                   WHEN lastupdated IS NULL THEN 'NULL'
                                                                   ELSE Cast(lastupdated AS VARCHAR(30))
                                                                 END
      FROM   dbo.workflowwizardclientsession
      WHERE  status IN ('InProgress','New')
             AND claccountid LIKE @ClAccountId + '%'
      
      UPDATE dbo.workflowwizardclientsession
      SET    status = 'DELETED',
             lastupdated = @Today,
             datedeleted = @Today,
             userdeleted = @UserId
      WHERE  id = @id
      
      INSERT INTO discovery..requestinterfacechangelog
                 (transactionid,
                  tablerowidentifier,
                  databasename,
                  tablename,
                  oldvalues,
                  newvalues)
      VALUES     (@TransactionId,@id,'ClientAccount','WorkflowWizardClientSession',@oldValues,'Status=DELETED|LastUpdated=' + Cast(@Today AS VARCHAR(30)))
    END
  
  WHILE EXISTS (SELECT 1
                FROM   dbo.clientdetails
                WHERE  claccountid LIKE @ClAccountId + '%'
                       AND feestructure = 'Bundled')
    BEGIN
      SET @id = NULL
      
      SELECT @id = id
      FROM   dbo.clientdetails
      WHERE  claccountid LIKE @ClAccountId + '%'
             AND feestructure = 'Bundled'
      
      IF NOT @id IS NULL
        BEGIN
          UPDATE dbo.clientdetails
          SET    feestructure = 'UnBundled'
          WHERE  id = @id
          
          INSERT INTO discovery..requestinterfacechangelog
                     (transactionid,
                      tablerowidentifier,
                      databasename,
                      tablename,
                      oldvalues,
                      newvalues)
          VALUES     (@TransactionId,@id,'ClientAccount','ClientDetails','FeeStructure=Bundled','FeeStructure=UnBundled')
        END
    END
  
  COMMIT TRANSACTION changefeestructure

GO
