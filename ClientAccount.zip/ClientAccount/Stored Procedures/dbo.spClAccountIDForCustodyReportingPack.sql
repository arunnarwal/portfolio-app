/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>6B973C1FD066052F7D771756E32E2683</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[spClAccountIDForCustodyReportingPack] (@FromDate datetime, @ToDate datetime)AS

SELECT Distinct ClAccountID
FROM 

	(SELECT Distinct ClAccountID
	FROM IncomeSummary
	WHERE Location='Custody' AND LedgerDate >= @FromDate AND LedgerDate <= @ToDate 
		AND Reversal IS NULL AND IsRebate <> 1
	
	UNION
	
	SELECT Distinct ClAccountID
	FROM InterestIncome
	WHERE Location='Custody' AND PayDate >= @FromDate AND PayDate <= @ToDate 
		AND Reversal IS NULL AND IsRebate <> 1
		
	UNION
	
	SELECT Distinct ClAccountID
	FROM ScripTransactions
	WHERE Location = 'Custody' AND TransStatus = 'Settled' AND AsAt <= @ToDate
	GROUP BY ClAccountID, InstrumentCode
	HAVING SUM(Quantity) <> 0) DerivedTBL
GO
