/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>B03CCD551962FDDB1D98BCBFFEC4084E</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[GetTotalAUM_FP]
	(@UserID as int, 
	 @AsAt as datetime, 
	 @CLAccountID as varChar(20) = '',
	 @Company as varChar(20) = '')
AS  
SET NOCOUNT ON  
  
/* 
DECLARE @ClAccountID varchar(20)  
SET @ClAccountID =''  
DECLARE @Company varchar(20)  
SET @Company =''  
DECLARE @UserID int  
SET @UserID =403959 
DECLARE @AsAt datetime  
SET @AsAt = '8 Jan 2010'
*/


DECLARE @IncludeExternal int   
set @IncludeExternal =1 

declare @requiredaccounts table (claccountid varchar(20) PRIMARY KEY CLUSTERED,topclaccountid varchar(20) not null)  

insert into @requiredaccounts  
select distinct
	c.subclaccountid claccountid,
	c.claccountid TopClAccountID
from 
ClientAccount..consolidate c 
INNER JOIN ClientAccount..vwAllowedClientAccountsQuickLookup ACA on ACA.ClAccountID = c.ClAccountID      
AND  ACA.ClientID = @UserID   
AND ACA.Status not in ('Demo','Deleted','Inactive')
where ( @claccountid = '' Or  @claccountid = 'All' Or  c.claccountid = @claccountid)
and (@company = '' Or  @company= 'All' Or  ACA.company = @company)
and ACA.subaccounttype = 'TIP'

 SELECT 
ClAccountID, 
InstrumentCode, 
Quantity, 
DisplayName, 
CCYCode, 
Company, 
Location, 
AssetType, 
AssetClassDescription, 
CitiCode, 
SecurityType, 
AccountName,
FundCode,
SEDOL,
Price,
@AsAt As PriceAsAt,
FXRate,
SettledValue,
round(SettledValue * FXRate, 2) As LocalSettledValue,
Cost

 FROM  
  
  (select holdings.claccountid, holdings.instrumentcode, quantity, sec_type InstrumentType, DisplayName, INS.InstrumentCCY CCYCode, clientdetails.baseccy BaseCCYCode, maturity_date MaturityDate, coupon_rate CouponRate, issuer_name IssuerName, 
isnull(bbgname,displayname) DisplayNameMixedCase, isnull(forecastdiv,0) ForecastDiv, isnull(forecastimp,0) ForecastImp, isnull(pricingbasis,'Price') PricingBasis, securitysubtype InstrumentSubType, isnull(ParValue,0) ParValue, ClientDetails.Company, 
ClientClassMethod2, holdings.Location, isnull(AssetType,'Unclassified') AssetType, isnull(clientdetails.NZCreditUtil,0) NZCreditUtil, isnull(clientdetails.AUCreditUtil,0) AUCreditUtil, isnull(clientdetails.IntTaxRate,0) IntTaxRate, 
isnull(clientdetails.DivTaxRate,0) DivTaxRate,vwCompanyAssetClasses.description as AssetClassDescription,   
   CASE   
    WHEN Mixed = 1 THEN 1  
    WHEN Split = 1 THEN 1  
    ELSE 0  
   END as Mixed,  
   CASE   
    WHEN Mixed = 1 THEN 'Mixed'  
    WHEN Split = 1 THEN 'Mixed'  
    ELSE isnull(vwCompanyAssetClasses.classcode,'Unclassified')  
   END as AssetSubType,  
   CASE   
    WHEN Split = 1 THEN 90  
    ELSE isnull(vwCompanyAssetClasses.sortorder,999)   
   END as SortOrder  
   ,MF.CitiCode,  
   ins.SecurityType,
	Cost,
	holdings.Group1,
	holdings.Group2,
	SECA.accountName,
	MF.FundCode,
	INS.SEDOL,
	SEC.o As Price,
	1 As FXRate,
	round(quantity * SEC.o, 2) As SettledValue

  from  

   (select RA.TopClAccountID as ClAccountID, InstrumentCode, sum(Quantity) Quantity, ST.Location, Sum(transactionvalue) as Cost, sum(ST.Group1) as Group1, sum(ST.Group2) as Group2
   from  vwScripTransactionsSettLocation ST  
     inner join @requiredaccounts RA   
      on RA.ClAccountID = ST.ClAccountID  
     inner join discovery.dbo.productdetails PD   
      on PD.ClAccountID = ST.ClAccountID  
     inner join discovery.dbo.clientaccount CA   
      on CA.ClAccountID = PD.ClAccountID  
   where  ST.AsAt < @AsAt + 1 and   
     ST.TransStatus <> 'Cancelled' and   
     (Cutover = 0 or Cutover is null) and  
     (@IncludeExternal = 1 or (@IncludeExternal = 0 and PD.Location <> 'EXTERNAL')) and  
     CA.Status not in ('InActive', 'inactive')  
   group by RA.TopClAccountID, InstrumentCode, ST.Location  
   having sum(Quantity) <> 0  and ST.Location = 'Registry'
   ) holdings  
   
  inner  join clientdetails WITH (NOLOCK) on clientdetails.claccountid = holdings.claccountid   
  inner  join Discovery.dbo.ClientAccount CA WITH (NOLOCK) on CA.claccountid = holdings.claccountid  
  inner  join clientaccount..SEClientAccount SECA  on CA.claccountid = SECA.claccountid  
  inner join res_db..instruments INS WITH (NOLOCK) on INS.security = holdings.instrumentcode   
  inner  join company WITH (NOLOCK) on company.company = clientdetails.company  
    
  left  join amaclass WITH (NOLOCK) on amaclass.company = company.clientclassmethod2 and amaclass.instrumentcode = holdings.instrumentcode   
  left join vwCompanyAssetClasses WITH (NOLOCK)   
  on amaclass.classcode = vwCompanyAssetClasses.classcode and clientdetails.company = vwCompanyAssetClasses.company   
  
  left  join res_db..bonds WITH (NOLOCK) on res_db..bonds.bond_code = INS.security   
  left  join res_db..bond_issuers WITH (NOLOCK) on res_db..bond_issuers.issuer_code = res_db..bonds.issuer_code   
  left  join res_db..equityinfo WITH (NOLOCK) on res_db..equityinfo.security = INS.security   
  left join res_db.dbo.managedfunds MF on MF.instrumentcode = INS.security
  left join res_db..securities as SEC on SEC.security = INS.security  and date = @AsAt 
  ) holdingsdata
GO
