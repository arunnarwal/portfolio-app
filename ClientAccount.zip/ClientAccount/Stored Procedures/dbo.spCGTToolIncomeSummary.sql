/***
<StoredProcedure>
    <Description>CGT Tool Income Summary</Description>
    <Parameters>
        <Parameter Name="@ClAccountIds">
            <Description>ClAccount Id</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE dbo.spCGTToolIncomeSummary
    @ClAccountIds VARCHAR(MAX)
AS

-- DECLARE @ClAccountIds VARCHAR(MAX)
-- SELECT @ClAccountIds = 'HB1000054-003,HB1003514-001'

SELECT
    ListValue AS ClAccountId
INTO
    #ClAccountIds
FROM
    Platform.Utils.fnCSVTable(@ClAccountIds)

SELECT
    CON.ClAccountID
,   let.LegalEntityTypeId
,   INC.Id
,   INC.LedgerDate
,   CA.ExDate
,   ISNULL(INC.InstrumentCode, CA.InstrumentCode) AS Instrumentcode
,   INC.QualifyingHolding
,   COALESCE(INC.Equalisation, 0) AS Equalisation
,   CASE WHEN INC.FinalProcessType NOT IN ('AccFund', 'ERI') AND INC.Equalisation > 0 THEN 0
         ELSE INC.NetAmount
    END AS NetAmount
,   INC.CorpActID
,   INC.Group1Group2
FROM dbo.IncomeSummary AS INC
	INNER JOIN dbo.Consolidate AS CON ON CON.SubClAccountID = INC.ClAccountID
	INNER JOIN Discovery.dbo.ProductDetails AS PD ON PD.ClAccountID = CON.SubClAccountID
	INNER JOIN CorporateActions.dbo.CorporateAction AS CA ON CA.Id = INC.CorpActID
	INNER JOIN Res_db.dbo.Instruments AS I ON CA.InstrumentCode = I.[Security]
	INNER JOIN Platform.ProductWrappers.ProductWrapperTypes pwt on pwt.ProductType=PD.ProductType
	LEFT JOIN dbo.VwCombinedClientDetails vwc on CON.ClAccountID=vwc.ClAccountID
	INNER JOIN dbo.VwWrapProviderWithJurisdiction vww on vww.WrapProvider=vwc.WrapProvider
	LEFT JOIN One.Tax.LegalEntityType let on (case when vwc.InvestorType='individ' then 'individual' else vwc.InvestorType end)=let.LegalEntityType and let.IsSubType = 0
	LEFT JOIN One.Tax.CGTProductWrapperException cgt on cgt.JurisdictionID=vww.JurisdictionID and (let.LegalEntityTypeId=cgt.LegalEntityType or cgt.LegalEntityType is null) and (vwc.LegalEntitySubType=cgt.LegalEntitySubType or cgt.LegalEntitySubType is null) and (vwc.LegalEntitySubSubType=cgt.LegalEntitySubSubType or cgt.LegalEntitySubSubType is null) and (pwt.ProductWrapperTypeId=cgt.ProductWrapperType or cgt.ProductWrapperType is null) and (pd.ProductSubTypeId=cgt.ProductWrapperSubType or cgt.ProductWrapperSubType is null)
WHERE
    CON.[ClAccountID] IN (SELECT ClAccountId FROM #ClAccountIds)
	AND  INC.[QualifyingHolding] IS NOT NULL
	AND  INC.[Reversal] IS NULL
	AND  I.[SecuritySubType] in ('ManagedFund','Exchange Traded Fund')
	AND ( cgt.JurisdictionID is null And cgt.LegalEntityType is null and cgt.LegalEntitySubType is null and cgt.LegalEntitySubSubType is null and cgt.ProductWrapperType is null and cgt.ProductWrapperSubType is null)
	AND (INC.FinalProcessType IN ('AccFund', 'ERI') OR INC.Equalisation > 0)
	AND vwc.IsCgtExempt <> 1
GO
