/***
<StoredProcedure>
    <Description>Returns SWIFT matching stats.</Description>
    <Parameters>
        <Parameter Name="@startDate">
            <Description>The start date (inclusive).</Description>
        </Parameter>
        <Parameter Name="@endDate">
            <Description>The end date (inclusive).</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE Banking.spGetSwiftMatchingStats
(
    @startDate DATE,
    @endDate DATE
)
AS
WITH ReconciledTransactions AS
(
	SELECT SBAC.GladBankAccountId, RR.*
	FROM Banking.SwiftBankAccountConfig SBAC
	JOIN dbo.Reconciliations R ON R.RecID = SBAC.RecID
	JOIN Banking.SwiftTransactions ST ON ST.GladBankAccountId = SBAC.GladBankAccountId
	JOIN dbo.ReconciledResults RR
		ON RR.TableConstant = R.TableConstant1
		AND RR.IDFieldValue = ST.SwiftTransactionId
	JOIN dbo.ReconciliationBatch RB ON RB.BatchID = RR.BatchID
), MatchedTransactions AS
(
	SELECT SBAC.GladBankAccountId
	, COUNT(CRM.AutoMatchScore) AS AutoMatchCount
	, COUNT(CASE WHEN CRM.AutoMatchScore IS NULL AND CRM.MatchBatchId IS NOT NULL THEN 1 END) AS ManualMatchCount
	FROM Banking.SwiftBankAccountConfig SBAC
	LEFT JOIN ReconciledTransactions RT ON RT.GladBankAccountId = SBAC.GladBankAccountId
	AND RT.DateUnMatched IS NULL
	AND CAST(RT.DateAdded AS DATE) >= @startDate
	AND CAST(RT.DateAdded AS DATE) <= @endDate
	LEFT JOIN dbo.CounterpartyReceiptMatches CRM ON CRM.MatchBatchId = RT.BatchID
	GROUP BY SBAC.GladBankAccountId
), UnmatchedTransactions AS
(
	SELECT SBAC.GladBankAccountId, COUNT(RT.DateUnMatched) AS UnmatchCount
	FROM Banking.SwiftBankAccountConfig SBAC
	LEFT JOIN ReconciledTransactions RT ON RT.GladBankAccountId = SBAC.GladBankAccountId
	AND CAST(RT.DateUnMatched AS DATE) >= @startDate
	AND CAST(RT.DateUnMatched AS DATE) <= @endDate
	GROUP BY SBAC.GladBankAccountId
), ReturnedTransactions AS
(
	SELECT SBAC.GladBankAccountId, COUNT(AP.DateCompleted) AS ReturnedCount
	FROM Banking.SwiftBankAccountConfig SBAC
	LEFT JOIN Banking.SwiftTransactions ST ON ST.GladBankAccountId = SBAC.GladBankAccountId
	LEFT JOIN dbo.AdhocPayments AP
		ON AP.ReturnedSwiftTransactionId = ST.SwiftTransactionId
		AND CAST(AP.DateCompleted AS DATE) >= @startDate AND CAST(AP.DateCompleted AS DATE) <= @endDate
	LEFT JOIN dbo.AdhocPaymentType APT ON APT.Id = AP.TypeId AND APT.Type = 'Return'
	GROUP BY SBAC.GladBankAccountId
)
SELECT MT.GladBankAccountId, MT.AutoMatchCount, MT.ManualMatchCount, UT.UnmatchCount, RT.ReturnedCount
FROM MatchedTransactions MT
JOIN UnmatchedTransactions UT ON UT.GladBankAccountId = MT.GladBankAccountId
JOIN ReturnedTransactions RT ON RT.GladBankAccountId = UT.GladBankAccountId
