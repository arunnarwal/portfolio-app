/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>AB36D69E244F7AE1831042840A1B94F2</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[spBackOfficeProviderCompanyAdviser](@WrapProviderId int, @BackOfficeProviderId int) AS 
 
/*
Declare @WrapProviderId int
Declare @BackOfficeProviderId int
Set @WrapProviderId = 7
Set @BackOfficeProviderId = 8
*/

Select
	Q1.firmName,
	Q1.firmCode,
	Q1.firmFSANo,
	Q1.adviserName,
	Q1.adviserCode,
	Q1.adviserFSANo,
	Q1.adviserBranch,
	Q1.elevateUserId,
	Q1.unbundled,
	Q1.bundled

From (

	Select
		CO.CompanyName As firmName,
		CO.Company As firmCode,
		CO.FSAAuthorisationNumber As firmFSANo,
		NULL As adviserName,
		NULL as adviserCode,
		NULL As adviserFSANo,
		Null As adviserBranch,
		Null As elevateUserId,
		Null As unbundled,
		Null As bundled
	From ClientAccount..SystemProvider SP
	Inner Join ClientAccount..WrapProvider WP
		On SP.SystemProvider = WP.SystemProvider And @WrapProviderId = WP.ID 
		Inner Join Clientaccount..Company CO
			On WP.WrapProvider = CO.WrapProvider And CO.FSAAuthorisationStatus = 'Authorised' And Not CO.FSAAuthorisationNumber Is Null
			Left Outer Join ClientAccount..Advisor ADV
				On CO.Company = ADV.Company and ADV.IsActive = 1 And Not ADV.FSAAuthorisationNumber Is Null
		Inner Join ClientAccount..BackOfficeProviderCompanySettings BCS
			On CO.ID = BCS.CompanyId And BCS.TwoWayIntegration = 1
			Inner Join ClientAccount..BackOfficeProvider BOP
				On BCS.BackOfficeProviderId = BOP.BackOfficeProviderId And @BackOfficeProviderId = BOP.BackOfficeProviderId
	Where ADV.ID Is Null 

	Union

	Select
		CO.CompanyName As firmName,
		CO.Company As firmCode,
		CO.FSAAuthorisationNumber As firmFSANo,
		ADV.Name As adviserName,
		ADV.AdvCode as adviserCode,
		ADV.FSAAuthorisationNumber As adviserFSANo,
		COALESCE(B.Branch, 'None') As adviserBranch,
		TC.ClientID As elevateUserId,
		COALESCE(p6.Unbundled,p5.Unbundled,p4.Unbundled,p3.Unbundled,p2.Unbundled,p1.Unbundled) As unbundled,
		COALESCE(p6.Bundled,p5.Bundled,p4.Bundled,p3.Bundled,p2.Bundled,p1.Bundled) As bundled
	From ClientAccount..SystemProvider SP
	Inner Join ClientAccount..WrapProvider WP
		On SP.SystemProvider = WP.SystemProvider And @WrapProviderId = WP.ID 
		Inner Join Clientaccount..Company CO
			On WP.WrapProvider = CO.WrapProvider And CO.FSAAuthorisationStatus = 'Authorised' And Not CO.FSAAuthorisationNumber Is Null
			Inner Join ClientAccount..Advisor ADV
				On CO.Company = ADV.Company and ADV.IsActive = 1 And Not ADV.FSAAuthorisationNumber Is Null
				Left Outer Join ClientDB3..tblClients TC
					On ADV.AdvCode = TC.AdvCode And TC.IsAdvisor = 1
				Left Outer Join ClientAccount..Branches B
					On ADV.BranchID = B.ID
					Left Outer Join ClientAccount..FeeStructures AS p5
						On p5.OwnerType = 'Branch' And p5.OwnerName = B.ID
				Left Outer Join	ClientAccount.dbo.FeeStructures AS p6
					On p6.OwnerType = 'Advisor' And p6.OwnerName = adv.AdvCode
			Left Outer Join ClientAccount..Network AS NET 
				On WP.WrapProvider = NET.WrapProvider And CO.Network = NET.Network
				Left Outer Join	ClientAccount..FeeStructures AS p3 
					On p3.OwnerType = 'Network' And p3.OwnerName = NET.Network
			Left Outer Join	ClientAccount..FeeStructures AS p4
				On p4.OwnerType = 'Company' And p4.OwnerName = CO.Company 
		Inner Join ClientAccount..BackOfficeProviderCompanySettings BCS
			On CO.ID = BCS.CompanyId And BCS.TwoWayIntegration = 1
			Inner Join ClientAccount..BackOfficeProvider BOP
				On BCS.BackOfficeProviderId = BOP.BackOfficeProviderId And @BackOfficeProviderId = BOP.BackOfficeProviderId
		Left Outer Join ClientAccount..FeeStructures AS p2 
			On p2.OwnerType = 'WP' And p2.OwnerName = WP.WrapProvider
	Left Outer Join	ClientAccount..FeeStructures As p1 
		On p1.OwnerType = 'System' And p1.OwnerName = SP.SystemProvider
	where tc.ostenabled=1 or tc.ostenabled is null --rule out locked accounts
) As Q1
Order By Q1.firmName, Q1.adviserName
