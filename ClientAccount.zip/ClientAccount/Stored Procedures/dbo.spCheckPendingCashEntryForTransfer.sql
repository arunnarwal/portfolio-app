/***
<StoredProcedure>
    <Description>Returns 1 if there is a pending authorisation cash entry for a tranfer</Description>
	<Parameters>
		<Parameter Name="@requestId">ID of Scrip Transfer Request</Parameter>
    </Parameters>
</StoredProcedure>
***/

CREATE PROCEDURE dbo.spCheckPendingCashEntryForTransfer

@requestId INT

AS

BEGIN

SELECT
CASE WHEN EXISTS ( SELECT 1
FROM
dbo.Reconciliations R
INNER JOIN dbo.vwReconciledResultsPending RRP on R.RecId = RRP.RecId AND RRP.TableConstant = R.TableConstant2
INNER JOIN Discovery.dbo.CashEntry CE on CE.Id = RRP.IdFieldValue
INNER JOIN Discovery.dbo.ScripTransferRequest STR ON (COALESCE(STR.BatchID,0) > 0 AND STR.BatchID = CE.BatchID)
WHERE R.Type = 'Cash Expectation' AND STR.RequestId = @requestId) THEN 1 ELSE 0 END AS CashEntryPending

END
GO