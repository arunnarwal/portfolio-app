/***
<StoredProcedure>
    <Description>Returns GLAD bank account balances using swift transactions.</Description>
    <Parameters>
        <Parameter Name="@startDate">
            <Description>The start date (inclusive).</Description>
        </Parameter>
        <Parameter Name="@endDate">
            <Description>The end date (inclusive).</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE Banking.spGetGladBankAccountBalances
(
    @startDate DATE,
    @endDate DATE
)
AS
WITH MT940 AS
(
    -- Find opening balance from the latest MT940 <= start date.
	SELECT ST.GladBankAccountId
        , SSM.OpeningBalance
        , ROW_NUMBER() OVER (PARTITION BY ST.GladBankAccountId ORDER BY ST.TransactionDate DESC) AS RowNumber
	FROM Banking.SwiftStatementMessages SSM
	JOIN Banking.SwiftStatementTransactions SST ON SST.SwiftStatementMessageId = SSM.SwiftStatementMessageId
	JOIN Banking.SwiftTransactionSources STS ON STS.SwiftStatementTransactionId = SST.SwiftStatementTransactionId
	JOIN Banking.SwiftTransactions ST ON ST.SwiftTransactionId = STS.SwiftTransactionId
	WHERE ST.TransactionDate <= @startDate
	-- Ensure that we get the correct opening balance in case statement is spread across multiple messages.
	AND SSM.OpeningBalanceFirstOrFinal = 1
), MT942 AS
(
	SELECT ST.GladBankAccountId AS GladBankAccountId
        ,COUNT(1) AS TransactionCount
        ,SUM(CASE ST.DebitCreditMark WHEN 'C' THEN ST.Amount WHEN 'DB' THEN -ST.Amount ELSE 0 END) AS InterimBalance
    FROM Banking.SwiftTransactions ST
    WHERE ST.TransactionDate >= @startDate AND ST.TransactionDate <= @endDate
    GROUP BY ST.GladBankAccountId
)
SELECT SBAC.GladBankAccountId
    , GBA.AccountName
    , GBA.CCYCode
    , COALESCE(GBA.IBAN, GBA.SortCode + '-' + GBA.AccountNumber) AccountDetails
    , MT940.OpeningBalance
    , MT940.OpeningBalance + COALESCE(MT942.InterimBalance, 0) AS ClosingBalance
    , MT942.TransactionCount
FROM dbo.GladBankAccounts GBA
JOIN Banking.SwiftBankAccountConfig SBAC ON SBAC.GladBankAccountId = GBA.ID
LEFT JOIN MT940 ON MT940.GladBankAccountId = SBAC.GladBankAccountId AND MT940.RowNumber = 1
LEFT JOIN MT942 ON MT942.GladBankAccountId = SBAC.GladBankAccountId
