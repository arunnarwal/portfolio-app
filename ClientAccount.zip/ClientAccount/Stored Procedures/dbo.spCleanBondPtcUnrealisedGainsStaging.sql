/***
<StoredProcedure>
    <Description>Clean table before unrealised gain/ ptc report is generated</Description>
    <Service>Transaction</Service>
	<Parameters>
		<Parameter Name="@AsAt">
			<Description>delete records asat</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [dbo].[spCleanBondPtcUnrealisedGainsStaging](
	@AsAt AS DATETIME
	) AS
BEGIN
DELETE FROM dbo.BondPtcUnrealisedGainsStaging WHERE AsAtDate = @AsAt

DELETE FROM dbo.BondPtcUnrealisedGainsStaging WHERE AsAtDate <= DATEADD(month, -12, @AsAt)
END