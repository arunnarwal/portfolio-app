/***
<StoredProcedure>
    <Description>Clean table BondUnrealisedPtcStaging after report is generated</Description>
    <Service>Transaction</Service>
</StoredProcedure>
***/
CREATE PROCEDURE [dbo].[spCleanBondUnrealisedPtcStaging] AS
BEGIN
DELETE FROM dbo.BondUnrealisedPtcStaging WHERE 1=1

END