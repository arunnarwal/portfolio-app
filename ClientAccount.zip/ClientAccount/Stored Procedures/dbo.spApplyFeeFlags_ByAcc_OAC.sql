/***
<StoredProcedure>
    <Description>Permissions clients client fee FUM flags for OAC Rate</Description>
	<Service>Charges</Service>
    <Feature>Tasks</Feature>
    <Parameters>
        <Parameter Name="@AsAt">
            <Description>The date of the fee run</Description>
        </Parameter>
        <Parameter Name="@TranType">
            <Description>The tran type, OACPercent / OACAmount</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/

CREATE PROCEDURE [dbo].[spApplyFeeFlags_ByAcc_OAC](@AsAt DATETIME, @TranType VARCHAR(10))
AS

--DECLARE @AsAt DATETIME 
--DECLARE @TranType VARCHAR(10)
--set @AsAt = '30 May 2014'
--SET @TranType = 'OACPercent' / 'OACAmount'

IF OBJECT_ID(N'tempdb..#FeeAccrual', N'U') IS NOT NULL
BEGIN
	DROP TABLE #FeeAccrual
END

DECLARE @PercentTranType VARCHAR(10)
DECLARE @AmountTranType VARCHAR(10)

set @PercentTranType = 'OACPercent'
set @AmountTranType = 'OACAmount'

SELECT Fum.SECAId
	,@AsAt AS AsAt
	,FeeTranTypes.ID AS FeeTranTypesID
	,CASE 
		WHEN (ISNULL(FeeTranTypes.IsAllowed, 0) = 1)
			AND ( @TranType = @PercentTranType AND (ISNULL(LatestFBRC.FbrcRate, 0) > 0) ) OR ( @TranType = @AmountTranType AND (ISNULL(LatestFBRC.FbrcAmount, 0) > 0) )
			AND (Fum.CashAmount + Fum.NonCashAmount) > 0
			AND (ISNULL(ProductDetails.FullyWithdrawn, 0) = 0)
			THEN 1
		ELSE 0
		END AS Applies
	,CASE  
		WHEN ISNULL(FeeTranTypes.IsAllowed, 0) = 0
			THEN 1
		WHEN @TranType = @PercentTranType AND LatestFBRC.FbrcRate IS NULL
			THEN 2
		WHEN @TranType = @AmountTranType AND LatestFBRC.FbrcAmount IS NULL
			THEN 2
		WHEN @TranType = @PercentTranType  AND ISNULL(LatestFBRC.FbrcRate, 0) = 0
			THEN 3
		WHEN @TranType = @AmountTranType  AND ISNULL(LatestFBRC.FbrcAmount, 0) = 0
			THEN 3
		WHEN (Fum.CashAmount + Fum.NonCashAmount) <= 0
			THEN 4
		WHEN (ISNULL(ProductDetails.FullyWithdrawn, 0) = 1)
			THEN 5
		ELSE 0
	END AS Status_NoteID
	, CASE 
		WHEN @TranType = @PercentTranType 
			THEN LatestFBRC.FbrcRate 
		WHEN @TranType = @AmountTranType 
			THEN LatestFBRC.FbrcAmount 
	END AS RATE
	,0 As ApplyVAT
INTO #FeeAccrual
FROM Cache.dbo.Fee_FUM_ByAccount AS Fum
INNER JOIN dbo.WrapProvider AS WrapProvider
	ON Fum.WrapProviderID = WrapProvider.ID
INNER JOIN dbo.SEClientAccount AS SecaId
	ON Fum.SECAID = SecaId.ID
INNER JOIN Discovery.dbo.ProductDetails AS ProductDetails
	ON ProductDetails.CLAccountID = SecaId.CLAccountID
INNER JOIN dbo.FeeTranTypes AS FeeTranTypes
	ON FeeTranTypes.TranType = @TranType
		AND FeeTranTypes.WrapProvider = WrapProvider.WrapProvider
LEFT OUTER JOIN dbo.vwLatestClientFBRCSettingsForFum LatestFBRC -- Fix Me: This does not support rerun
	ON LatestFBRC.ClAccountId = SecaId.ClAccountId
LEFT JOIN dbo.AppliedFees_ByAccV2 AS Applied
	ON Applied.AsAt = @AsAt
		AND Applied.SecaId = Fum.SecaId
		AND Applied.FeeTranTypesID = FeeTranTypes.ID
WHERE Fum.AsAt = @AsAt
	AND Applied.Id IS NULL
	AND NOT EXISTS (SELECT 1 FROM dbo.Fee_Fum_ExcludeAccountTypes EXAT 
				WHERE EXAT.WrapProviderID = Fum.WrapProviderID 
				AND EXAT.FeeTranTypeID = FeeTranTypes.ID 
				AND EXAT.AccountType = SecaId.InvestorType)

INSERT INTO dbo.ToBeAppliedFees_ByAccV2 (
	SECAId
	,[AsAt]
	,FeeTranTypesID
	,Applied
	,Rate
	,ApplyVAT
	)
SELECT 
	#FeeAccrual.SECAId
	,#FeeAccrual.[AsAt]
	,#FeeAccrual.FeeTranTypesID
	,0 
	,#FeeAccrual.Rate
	,#FeeAccrual.ApplyVAT
FROM #FeeAccrual
LEFT OUTER JOIN dbo.ToBeAppliedFees_ByAccV2 AS ToBeApplied
	ON #FeeAccrual.SECAID = ToBeApplied.SECAID 
		AND #FeeAccrual.AsAt = ToBeApplied.AsAt 
		AND #FeeAccrual.FeeTranTypesID = ToBeApplied.FeeTranTypesID
WHERE #FeeAccrual.Applies = 1 
		AND ToBeApplied.SecaId IS NULL

INSERT INTO dbo.NonAppliedFees_ByAccV2 (
	SECAId
	,AsAt
	,FeeTranTypesID
	,Status_NoteID
	)
SELECT 
	#FeeAccrual.SecaId
	,#FeeAccrual.AsAt
	,#FeeAccrual.FeeTranTypesId
	,#FeeAccrual.Status_NoteId
FROM #FeeAccrual 
LEFT JOIN dbo.NonAppliedFees_ByAccV2 as NonApplied
	ON #FeeAccrual.SecaId = NonApplied.SecaId 
		AND #FeeAccrual.AsAt = NonApplied.AsAt 
		AND #FeeAccrual.FeeTranTypesId = NonApplied.FeeTranTypesId
WHERE #FeeAccrual.Applies = 0 AND NonApplied.SecaId IS NULL

IF OBJECT_ID(N'tempdb..#FeeAccrual', N'U') IS NOT NULL
BEGIN
	DROP TABLE #FeeAccrual
END
GO