/***
<StoredProcedure>
    <Description>Get instrument holdings by subaccount id</Description>
	<Parameters>
		<Parameter Name="@ClAccountId">
			<Description>Sub Account ID</Description>
		</Parameter>		
	</Parameters>
</StoredProcedure>

--***/
CREATE PROCEDURE [dbo].[spAccountInstrumentHoldings] (@ClAccountId VARCHAR(20))
AS

/*
declare @ClAccountId as varchar(20)
set @ClAccountId = 'AC2029188-002'

DROP TABLE IF EXISTS #ScripLedgerTransaction
*/

CREATE TABLE #ScripLedgerTransaction
(
    InstrumentId INT NOT NULL,
    TotalQuantity decimal(23, 8) NOT NULL
);

INSERT INTO #ScripLedgerTransaction (InstrumentId, TotalQuantity)

SELECT		CT.InstrumentId, SUM(CT.Quantity)
FROM		ScripLedger.CustodyTransactions CT 
INNER JOIN	dbo.SEClientAccount SCA ON CT.AccountId = SCA.Id
WHERE		SCA.ClAccountId =  @ClAccountId
GROUP BY	CT.InstrumentId

UNION ALL

SELECT		NCT.InstrumentId, SUM(NCT.Quantity)
FROM		ScripLedger.NonCustodyTransactions NCT 
INNER JOIN	dbo.SEClientAccount SCA ON NCT.AccountId = SCA.Id
WHERE		SCA.ClAccountId =  @ClAccountId
GROUP BY	NCT.InstrumentId

CREATE NONCLUSTERED INDEX IDX_InstrumentId ON #ScripLedgerTransaction(InstrumentId)

;WITH SumQuantity AS (
	SELECT  SUM(ST.TotalQuantity) AS TotalQuantity,
			ST.InstrumentId 
	FROM    #ScripLedgerTransaction ST
	GROUP BY ST.InstrumentId 
	HAVING SUM(ST.TotalQuantity) > 0
)

SELECT  SQ.TotalQuantity,
		I.[Security] AS InstrumentCode,
		I.SecurityType,
		I.SecuritySubType,
		I.AssetWatchStatus,
		I.ISINCode
FROM    SumQuantity SQ 	
INNER JOIN Res_Db.dbo.Instruments I ON SQ.InstrumentId = I.Id

GO