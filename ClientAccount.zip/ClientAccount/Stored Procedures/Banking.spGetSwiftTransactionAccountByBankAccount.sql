/***
<StoredProcedure>
	<Description>Returns client account ids relating to swift transactions</Description>
	<Parameters>
		<Parameter Name="@SwiftTransactionIdList">
			<Description>List of swift transaction ids</Description>
		</Parameter>
	</Parameters>
	<Columns>
		<Parameter Name="SwiftTransactionId">
			<Description>Swift transaction id</Description>
		</Parameter>
		<Parameter Name="ClAccountId">
			<Description>Client account id</Description>
		</Parameter>
	</Columns>
</StoredProcedure>
***/
CREATE PROC Banking.spGetSwiftTransactionAccountByBankAccount
	@SwiftTransactionIdList VARCHAR(MAX)
AS
BEGIN
	SELECT DISTINCT
		t.TabValue SwiftTransactionId
	INTO #SwiftTransactionIds
	FROM
		CSFBMaster.dbo.fn_convert_comma_to_table_int(@SwiftTransactionIdList) t
		
	CREATE UNIQUE CLUSTERED INDEX IDX_SwiftTransactionIds ON #SwiftTransactionIds(SwiftTransactionId)

	SELECT DISTINCT 
		STI.SwiftTransactionId,
		ICBA.ClAccountId
	FROM
		#SwiftTransactionIds STI
		INNER JOIN Banking.vwSwiftTransactions ST
			ON STI.SwiftTransactionId = ST.SwiftTransactionId
		INNER JOIN Discovery.dbo.IncomingCounterpartyBankAccounts  ICBA
			ON 
				(ST.SourceCustomerAccountNumber = ICBA.AccountNumber AND ST.OrderingInstitutionIdentifier = ICBA.NCC)
				OR (ST.SourceCustomerAccountNumber = ICBA.Iban AND ST.OrderingInstitutionIdentifier = ICBA.Bic)
				OR (ST.SourceCustomerAccountNumber = ICBA.Iban AND ST.OrderingInstitutionIdentifier = ICBA.NCC)

END