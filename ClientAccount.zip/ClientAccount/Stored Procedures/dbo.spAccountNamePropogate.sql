/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>5830F96783FB5F743E44D4B503B008BF</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[spAccountNamePropogate](@ClAccountId VarChar(20),@AccountName varchar(100)) as

update SEClientAccount
set AccountName = @AccountName
where claccountid like @ClAccountID + '%';
select 1 as ReturnValue;
GO
