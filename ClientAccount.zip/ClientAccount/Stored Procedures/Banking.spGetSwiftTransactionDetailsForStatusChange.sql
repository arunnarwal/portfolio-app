/***
<StoredProcedure>
    <Description>Returns SWIFT transaction details required for processing status changes.</Description>
    <Parameters>
        <Parameter Name="@SwiftTransactionId">
            <Description>Unique SWIFT transaction Id.</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE Banking.spGetSwiftTransactionDetailsForStatusChange
(
    @SwiftTransactionId INT
)
AS
    DECLARE @LastJournalBatchId INT

    SELECT TOP 1 @LastJournalBatchId = JournalBatchId
    FROM         Banking.SwiftTransactionAccounting
    WHERE        SwiftTransactionId = @SwiftTransactionId
    ORDER BY     JournalBatchId DESC

    SELECT
        ST.SwiftTransactionId AS TransactionId,
        STS.SwiftTransactionStatusId AS StatusId,
        SBAC.WrapProvider,
        ST.Currency,
        ST.Amount,
        @LastJournalBatchId AS LastJournalBatchId,
        CA.UnallocatedControlAccount,
        CA.UnidentifiedControlAccount,
        SBAC.ReverseJournalAlias,
        ST.Narrative,
		SBAC.JournalAlias,
		GBA.GlDivisionCode
    FROM
        Banking.SwiftTransactions ST
        INNER JOIN Banking.vwSwiftBankAccountConfig SBAC ON ST.GladBankAccountId = SBAC.GladBankAccountId
        INNER JOIN Banking.SwiftTransactionStatus STS ON ST.StatusId = STS.SwiftTransactionStatusId
		INNER JOIN dbo.GladBankAccounts GBA ON GBA.ID = SBAC.GladBankAccountId
        LEFT JOIN Banking.SwiftBankAccountControlAccounts CA ON ST.GladBankAccountId = CA.GladBankAccountId
    WHERE
        ST.SwiftTransactionId = @SwiftTransactionId