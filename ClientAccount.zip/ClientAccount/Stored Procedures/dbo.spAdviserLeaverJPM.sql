/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>CB50956BE5DD22612594EB32B922C7B8</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[spAdviserLeaverJPM] (@AdviserCode varchar(20)) AS
DECLARE @ErrorMessage varchar(max)
DECLARE @NewAdviserCode varchar(20)
SET NOCOUNT ON
BEGIN TRANSACTION
BEGIN TRY
--Get latest jpmwrap advcode and increment it by 1
SELECT TOP 1 @NewAdviserCode = advcode FROM Advisor WHERE company = 'JPMLeft' and advcode like 'JPMLeft%' order by advcode desc
If (@NewAdviserCode is null)
	set @NewAdviserCode = 'JPMLeft0000000'
SET @NewAdviserCode = 'JPMLeft' + RIGHT('0000000' + CONVERT(VARCHAR,(RIGHT(@NewAdviserCode, LEN(@NewAdviserCode) - LEN('JPMLeft')) + 1)), 7)
END TRY
BEGIN CATCH
SET @ErrorMessage = error_message()
GOTO HANDLE_ERROR
END CATCH
BEGIN TRY
--Update Advcode and company in Advisor
UPDATE Advisor
SET Advcode = @NewAdviserCode,
company = 'JPMLeft' 
WHERE Advcode = @AdviserCode
END TRY
BEGIN CATCH
SET @ErrorMessage = error_message()
GOTO HANDLE_ERROR
END CATCH
BEGIN TRY
--Update Advcode and company in tblclients
UPDATE clientdb3..tblclients
SET Advcode = @NewAdviserCode,
company = 'JPMLeft',
ostsignaturelocked = 1 -- disable access
WHERE Advcode = @AdviserCode
END TRY
BEGIN CATCH
SET @ErrorMessage = error_message()
GOTO HANDLE_ERROR
END CATCH
COMMIT TRANSACTION
SELECT null as ErrorMessage
HANDLE_ERROR:
ROLLBACK TRANSACTION
SELECT @ErrorMessage as ErrorMessage

-- EXEC CSFBMaster..spUpdateMetaDB 'spAdviserLeaverJPM', 'clapAdviserLeaverJPM', 'ClientAccount';
GO
