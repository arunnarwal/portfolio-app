/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>B66FC318A2435A9BE0838E3C31593E2B</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[spallowedaccountstotoggletermsandconditions](
               @UserId      INT,
               @ClAccountId VARCHAR(20)  = '')
AS
  /*
  
  DECLARE @UserId INT,
  
  @ClAccountId VarChar(20)
  
  SET @ClAccountId = 'EL1102900' 
  
  SET @UserId = 433247
  
  */
  SET @ClAccountId = dbo.Fngetheadaccountid(@ClAccountId)
  
  --====================== TEMP TABLE =======================--
  CREATE TABLE #candidates (
    claccountid VARCHAR(10))
  
  INSERT INTO #candidates
  EXEC Spgetallowedaccounts
    @UserId ,
    @ClAccountId
  
  CREATE INDEX ix_1 ON #candidates (
        claccountid)
  
  --==========================================================--
  SELECT DISTINCT c.claccountid               AS headaccountid,
                  se.accountname,
                  a.name                      AS advisername,
                  a.advcode,
                  cd.termsandconditionsagreed
  FROM   #candidates AS c
         INNER JOIN dbo.clientdetails AS cd
           ON cd.claccountid = c.claccountid
         INNER JOIN dbo.seclientaccount AS se
           ON c.claccountid = se.claccountid
         INNER JOIN dbo.advisor AS a
           ON a.advcode = se.primaryadviser/**/
  
  DROP TABLE #candidates




GO
