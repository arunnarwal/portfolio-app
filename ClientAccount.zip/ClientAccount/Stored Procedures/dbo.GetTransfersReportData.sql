/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>D79A5BD8A885CBA2E8A595F74ED81406</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[GetTransfersReportData]
	(@UserID as int, 
	 @fromDate as datetime,
	 @toDate as datetime)
AS  
SET NOCOUNT ON  

/*
declare @fromDate as datetime 
set @fromDate = '1 Dec 2009'
declare @toDate as datetime 
set @toDate = '1 Feb 2010'
declare @UserID as int
set @UserID = 403959
*/

select 
MF.CitiCode,
I.IsinCode As ISIN,
I.Sedol,
MF.InstrumentCode As StockName,
I.DisplayName As StockDescription,
I.SecurityType As AssetType,
'UK' As MarketLocation,
STRQD.CounterpartyName As EFM,
Adv.Company,
STRQD.SchemeClAccountID As SchemeNumber,
SECA.AccountName As SchemeName,
'IIP' As ProductType,
STRQ.Quantity,
STRQ.Cost As EstimatedValue,
STRQ.Status,
Case
When TCL.DateChanged > STRQ.LastModified Then TCL.DateChanged
Else STRQ.LastModified
End As UpdateDate,
STRQ.TransferCompleted,
STRQ.RequestedDateTime,
Case
When STRQ.TransferDirection = 'ToFNZC' Then 'In'
Else 'Out' 
End As TransferInOut,
MFNGS.FundCode,
INGS.DisplayName As FundName,
Case
When STRWCD.Status = 'Completed' Then 'Y'
Else 'N' 
End As TransferComplete,
STRQ.RequestID

 from discovery..ScripTransferRequest As STRQ
Inner Join res_db..ManagedFunds As MF ON STRQ.InstrumentCode = MF.InstrumentCode
Inner Join res_db..Instruments As I ON STRQ.InstrumentCode = I.Security
Inner Join discovery..ScripTransferRequestDetails As STRQD ON STRQ.RequestID = STRQD.RequestID
Inner Join clientAccount..SEClientAccount As SECA ON SECA.ClAccountID = STRQD.SchemeClAccountID
Inner join res_db..AccountInstrumentMappings As AIM on AIM.ClaccountID = STRQ.ClAccountID
Inner Join res_db..ManagedFunds As MFNGS ON AIM.InstrumentCode = MFNGS.InstrumentCode
Inner Join res_db..Instruments As INGS ON AIM.InstrumentCode = INGS.Security
Inner Join 
(select distinct identityvalue,DateChanged from clientaccount..vwtablechangelog 
	where TableConstant = 'dpsScripTransferRequest') As TCL
	ON TCL.IdentityValue = STRQ.ID 
Inner Join clientaccount..vwScriptransferRequestWithClientDetails As STRWCD ON STRWCD.RequestID = STRQ.RequestID And STRWCD.ClientID = @UserID
Inner Join clientaccount..advisor As ADV on ADV.AdvCode = SECA.PrimaryAdviser
where STRQ.RequestedDateTime >= @fromDate And STRQ.RequestedDateTime < dateAdd(day,1,@toDate)
GO
