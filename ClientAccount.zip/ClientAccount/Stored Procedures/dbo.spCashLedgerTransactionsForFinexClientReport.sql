/***
<StoredProcedure>
    <Description>
		Returns the CLT rows used in producing the FinEx Client Report - it was based on
		vwCashLedgerTransExclCMT and should match what's shown in the Cash -> Statement 
		screen on the Admin site
	</Description>
		<Parameters>
		<Parameter Name="@ClAccountId">
			<Description>Subaccount to retrieve CLT lines for</Description>
		</Parameter>
		<Parameter Name="@FromDate">
			<Description>Start of date range for search (@fromDate gt CashLedgerTransactions.LedgerDate)</Description>
		</Parameter>		
		<Parameter Name="@ToDate">
			<Description>End of date range for search  (@toDate lteq CashLedgerTransactions.LedgerDate)</Description>
		</Parameter>		
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE dbo.spCashLedgerTransactionsForFinexClientReport (@ClAccountId VARCHAR(20), @FromDate DATETIME, @ToDate DATETIME)
AS

/*
DECLARE @claccountid as varchar(20)
DECLARE @FromDate as DateTime
DECLARE @ToDate as DateTime
SET @claccountid = 'AV2041135-001';
SET @fromDate = '31-dec-1999 00:00:00';
SET @todate = '21-feb-2018 10:12:55';
*/

DECLARE @LocalFromDate DATETIME
SET @LocalFromDate = @FromDate
DECLARE @LocalToDate DATETIME
SET @LocalToDate = @ToDate

SELECT 
	T.TransId, 
	T.ClAccountID,
	T.CorpActId,
	T.OrderId,
	T.ARLId,
	T.Amount,
	T.Narrative,
	T.LedgerDate,
	T.OriginatingCashEntryId,
	T.MovementSource,
	T.MovementType
INTO #CashTransactions
FROM CashLedger.vwTransactionsA T
WHERE
	T.ClAccountId = @ClAccountId
	AND T.DisplayToClient = 1
    AND T.MovementType <> 'CALL_TRANSACTION'
    AND T.Amount <> 0
	AND T.LedgerDate > @LocalFromDate
	AND T.LedgerDate <= @LocalToDate;

CREATE CLUSTERED INDEX CIDX_TransId ON #CashTransactions(TransId);

With Transactions
AS
(
	SELECT
		CT.ClAccountId,
		CT.TransId, 
		-CT.Amount AS Amount,
		CT.Narrative,
		CT.LedgerDate,
		CT.MovementSource,
		CT.MovementType,
		CASE
			WHEN CT.Amount <= 0 THEN 'Incoming'
			WHEN CT.Amount > 0 THEN 'Outgoing'
		END AS MovementDirection,
		B.BatchType,
		B.BatchInstrumentType,
		CE.SubType,
		CE.Method,
		CE.Type AS CashEntryType,
		CE.Source AS CashEntrySource,
		CE.TaxType,
		NULL AS CorpActType,
		RWP.ID AS RegularWithdrawalId,
		CE.PaymentSubType,
		HCFT.FeeTranType AS TranType,
		HCLT.FETransactionType,
		NULL AS SecuritySubType,
		CT.ClAccountId ReportingReference,
		'Account' AccountType,
		NULL AS InstrumentCode,
		CT.OriginatingCashEntryId
	FROM
		#CashTransactions CT
		INNER JOIN Discovery.dbo.CashEntry CE on CT.OriginatingCashEntryId = CE.Id
		INNER JOIN Discovery.dbo.Batch B on CE.Batchid = B.BatchId
		LEFT JOIN Discovery.dbo.RegularWithdrawalPayments RWP on RWP.CashEntry = CE.Id
		LEFT JOIN dbo.HistoricCashFeeTranTypes HCFT ON CT.TransID = HCFT.CashLedgerId		
		LEFT JOIN dbo.HistoricCashLedgerTransactionTypes AS HCLT ON HCLT.CashLedgerId = CT.TransId

	UNION

	SELECT
		CT.ClAccountId,
		CT.TransId, 
		-CT.Amount AS Amount,
		CT.Narrative,
		CT.LedgerDate,
		CT.MovementSource,
		CT.MovementType,
		CASE
			WHEN CT.Amount <= 0 THEN 'Incoming'
			WHEN CT.Amount > 0 THEN 'Outgoing'
		END AS MovementDirection,
		NULL AS BatchType,
		NULL AS BatchInstrumentType,
		NULL AS SubType,
		NULL AS Method,
		NULL AS CashEntryType,
		NULL AS CashEntrySource,
		NULL AS TaxType,
		CA.Type AS CorpActType,
		NULL AS RegularWithdrawalId,
		NULL AS PaymentSubType,
		HCFT.FeeTranType AS TranType,
		HCLT.FETransactionType,
		NULL AS SecuritySubType,
		CT.ClAccountId ReportingReference,
		'Account' AccountType,
		NULL AS InstrumentCode,
		CT.OriginatingCashEntryId
	FROM
		#CashTransactions CT
		INNER JOIN CorporateActions.dbo.CorporateAction CA on CT.CorpActId = CA.Id	
		LEFT JOIN CorporateActions.dbo.Takeover TK ON CT.CorpActId = TK.CorpActID
		LEFT JOIN dbo.HistoricCashFeeTranTypes HCFT ON CT.TransID = HCFT.CashLedgerId		
		LEFT JOIN dbo.HistoricCashLedgerTransactionTypes AS HCLT ON HCLT.CashLedgerId = CT.TransId
		WHERE (TK.TakeoverCorporateActionType != 'FullRedemption' OR TK.TakeoverCorporateActionType IS NULL)

	UNION 

	SELECT
		CT.ClAccountId,
		CT.TransId, 
		-CT.Amount AS Amount,
		CT.Narrative,
		CT.LedgerDate,
		CT.MovementSource,
		CT.MovementType,
		CASE
			WHEN CT.Amount <= 0 THEN 'Incoming'
			WHEN CT.Amount > 0 THEN 'Outgoing'
		END AS MovementDirection,
		NULL AS BatchType,
		NULL AS BatchInstrumentType,
		NULL AS SubType,
		NULL AS Method,
		NULL AS CashEntryType,
		NULL AS CashEntrySource,
		NULL ASTaxType,
		NULL AS CorpActType,
		NULL AS RegularWithdrawalId,
		NULL AS PaymentSubType,
		COALESCE(ARL.TranType,HCFT.FeeTranType) AS TranType,
		HCLT.FETransactionType,
		NULL AS SecuritySubType,
		CT.ClAccountId ReportingReference,
		'Account' AccountType,
		NULL AS InstrumentCode,
		CT.OriginatingCashEntryId
	FROM
		#CashTransactions CT
		INNER JOIN Discovery.dbo.AdvisorRevenueLedger ARL on ARL.Id = CT.ARLId
		LEFT JOIN dbo.HistoricCashFeeTranTypes HCFT ON CT.TransID = HCFT.CashLedgerId
		LEFT JOIN dbo.HistoricCashLedgerTransactionTypes AS HCLT ON HCLT.CashLedgerId = CT.TransId

	UNION

	SELECT
		CT.ClAccountId,
		CT.TransId, 
		-CT.Amount AS Amount,
		CT.Narrative,
		CT.LedgerDate,
		CASE 
			WHEN I.SecuritySubType = 'Commercial Property' THEN 'CashToClientSys'
			ELSE CT.MovementSource 
		END AS MovementSource,
		CASE 
			WHEN I.SecuritySubType = 'Commercial Property' AND CT.Amount <= 0 THEN 'CAPITAL_IN'
			WHEN I.SecuritySubType = 'Commercial Property' AND CT.Amount > 0 THEN 'CAPITAL_OUT'
			ELSE CT.MovementType
		END AS MovementType,
		CASE
			WHEN CT.Amount <= 0 THEN 'Incoming'
			WHEN CT.Amount > 0 THEN 'Outgoing'
		END AS MovementDirection,
		NULL AS BatchType,
		B.BatchInstrumentType,
		CASE 
			WHEN I.SecuritySubType = 'Commercial Property' THEN 'Transfer'
			ELSE NULL
		END AS SubType,
		NULL AS Method,
		NULL AS CashEntryType,
		NULL AS CashEntrySource,
		NULL AS TaxType,
		NULL AS CorpActType,
		NULL AS RegularWithdrawalId,
		NULL AS PaymentSubType,
		HCFT.FeeTranType AS TranType,
		HCLT.FETransactionType,
		I.SecuritySubType,
		CT.ClAccountId ReportingReference,
		'Account' AccountType,
		NULL AS InstrumentCode,
		CT.OriginatingCashEntryId
	FROM
		#CashTransactions CT
		INNER JOIN Discovery.dbo.OrderCurrent AS OC ON CT.OrderID = OC.OrderID
		INNER JOIN Discovery.dbo.Batch B on OC.Batchid = B.BatchId
		INNER JOIN Res_db.dbo.Instruments AS I ON OC.InstrumentCode = I.[Security]
		LEFT JOIN dbo.HistoricCashFeeTranTypes HCFT ON CT.TransID = HCFT.CashLedgerId		
		LEFT JOIN dbo.HistoricCashLedgerTransactionTypes AS HCLT ON HCLT.CashLedgerId = CT.TransId
)
SELECT 
	T.ClAccountId,
	T.TransId, 
	T.Amount,
	T.Narrative,
	T.LedgerDate,
	T.MovementSource,
	T.MovementType,
	T.MovementDirection,
	T.BatchType,
	T.BatchInstrumentType,
	T.SubType,
	T.Method,
	T.CashEntryType,
	T.CashEntrySource,
	T.TaxType,
	T.CorpActType,
	T.RegularWithdrawalId,
	T.PaymentSubType,
	T.TranType,
	T.FETransactionType,
	T.SecuritySubType,
	T.ClAccountId ReportingReference,
	T.AccountType,
	T.InstrumentCode,
	T.OriginatingCashEntryId
FROM Transactions T

UNION ALL

SELECT
	CT.ClAccountId,
	CT.TransId, 
	-CT.Amount AS Amount,
	CT.Narrative,
	CT.LedgerDate,
	CT.MovementSource,
	CT.MovementType,
	CASE
		WHEN CT.Amount <= 0 THEN 'Incoming'
		WHEN CT.Amount > 0 THEN 'Outgoing'
	END AS MovementDirection,
	NULL AS BatchType,
	NULL AS BatchInstrumentType,
	NULL AS SubType,
	NULL AS Method,
	NULL AS CashEntryType,
	NULL AS CashEntrySource,
	NULL AS TaxType,
	NULL AS CorpActType,
	NULL AS RegularWithdrawalId,
	NULL AS PaymentSubType,
	HCFT.FeeTranType AS TranType,
	HCLT.FETransactionType,
	NULL AS SecuritySubType,
	CT.ClAccountId ReportingReference,
	'Account' AccountType,
	NULL AS InstrumentCode,
	CT.OriginatingCashEntryId
FROM
	#CashTransactions CT
	LEFT JOIN dbo.HistoricCashFeeTranTypes HCFT ON CT.TransID = HCFT.CashLedgerId	
	LEFT JOIN dbo.HistoricCashLedgerTransactionTypes AS HCLT ON HCLT.CashLedgerId = CT.TransId
	WHERE NOT EXISTS (
		SELECT 1
		FROM CorporateActions.dbo.CorporateAction CA
		LEFT JOIN CorporateActions.dbo.Takeover TK ON CT.CorpActId = TK.CorpActID
		WHERE CA.Id = CT.CorpActId
		AND TK.TakeoverCorporateActionType = 'FullRedemption'
	)
	AND NOT EXISTS (
		SELECT T.TransId 
		FROM  Transactions T
		WHERE T.TransId = CT.TransID)
	AND NOT EXISTS (
		SELECT CashTr.TransId
		FROM #CashTransactions CashTr
		INNER JOIN Discovery.dbo.CashEntry CE on CashTr.OriginatingCashEntryId = CE.Id
		INNER JOIN Discovery.dbo.Batch B on CE.Batchid = B.BatchId
		WHERE CE.Method = 'Internal Transfer' AND CE.Source IN ('ModelTransferIn', 'ModelTransferOut')
			AND CashTr.TransId = CT.TransID
	)
	AND NOT EXISTS (
		SELECT OrderTr.TransId
		FROM #CashTransactions OrderTr
		INNER JOIN Discovery.dbo.OrderCurrent OC 
			ON Oc.OrderID = OrderTr.OrderId
		INNER JOIN Res_db.dbo.Instruments i
			ON i.[Security] = OC.InstrumentCode
		WHERE i.SecuritySubType IN ('Dfm Model', 'Advisor Model', 'MPS Model')
			AND OrderTr.TransId = CT.TransID
	);

DROP TABLE #CashTransactions;