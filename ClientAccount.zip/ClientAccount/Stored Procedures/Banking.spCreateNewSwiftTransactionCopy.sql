 /***
 <StoredProcedure>
 	<Description>Creates a new swift transaction based on @OriginalSwiftTransactionId. Used when the @OriginalSwiftTransactionId is being transferred to another bankaccount or has been partially returned</Description>
 	<Parameters>
 		<Parameter Name="@OriginalSwiftTransactionId">
 			<Description>The Id of the swift transaction to copy from</Description>
 		</Parameter>
		<Parameter Name="@NewStatusId">
 			<Description>Status of the new swift transaction</Description>
 		</Parameter>
		<Parameter Name="@NewJournalBatchId">
 			<Description>JournalBatchId of the new swift transaction</Description>
 		</Parameter>
		<Parameter Name="@NewAmount">
 			<Description>Amout of the new swift transaction. Optional. Same as original transaction if not supplied</Description>
 		</Parameter>
		<Parameter Name="@NewGladBankAccountId">
 			<Description>GladBankAccountId of the new swift transaction. Optional. Same as original transaction if not supplied</Description>
		</Parameter>
		<Parameter Name="@NarrativeSuffix">
 			<Description>NarrativeSuffix of the new swift transaction. Optional. Same as original transaction if not supplied</Description>
		</Parameter>
 	</Parameters>
 </StoredProcedure>
 ***/
 CREATE PROCEDURE Banking.spCreateNewSwiftTransactionCopy 
	@OriginalSwiftTransactionId INT, 
	@NewStatusId TINYINT, 
	@NewJournalBatchId INT = NULL, 
	@NewAmount MONEY = NULL, 
	@NewGladBankAccountId INT = NULL,
	@NarrativeSuffix VARCHAR(50) = NULL
	AS
	
	/*
		USE ClientAccount
		GO

		DECLARE @OriginalSwiftTransactionId INT = 36
		DECLARE @NewAmount MONEY = 50.0
		DECLARE @NewGladBankAccountId INT = 111
		DECLARE @NewStatusId TINYINT = 2
		DECLARE @NewJournalBatchId INT = 123456789
	*/

	DECLARE @NewSwiftTransactionId INT

	INSERT INTO Banking.SwiftTransactions
	(SwiftMessageReference, GladBankAccountId, TransactionDate, IsInterAccountMovement, DebitCreditMark, Currency, Amount, AccountReference, BankReference, Narrative, StatusId, CreatedDateTime)
	SELECT
		SwiftMessageReference,
		ISNULL(@NewGladBankAccountId, GladBankAccountId),
		TransactionDate,
		IsInterAccountMovement,
		DebitCreditMark,
		Currency,
		ISNULL(@NewAmount, Amount),
		AccountReference,
		BankReference,
		CASE
			WHEN LEN(Narrative+ISNULL(@NarrativeSuffix,'')) > 255
			THEN LEFT(REPLACE(Narrative+ISNULL(@NarrativeSuffix,''), 'Split from SwiftTransactionId ', 'SplitFromSwiftID'), 255)
			ELSE Narrative+ISNULL(@NarrativeSuffix,'')
		END,
		@NewStatusId StatusId,
		GETDATE() 
	FROM Banking.SwiftTransactions
	WHERE SwiftTransactionId = @OriginalSwiftTransactionId

	SET @NewSwiftTransactionId = SCOPE_IDENTITY()

	IF @NewJournalBatchId IS NOT NULL
	BEGIN
		INSERT INTO Banking.SwiftTransactionAccounting
		(SwiftTransactionId, JournalBatchId)
		SELECT
			@NewSwiftTransactionId,
			@NewJournalBatchId
	END

	INSERT INTO Banking.SwiftTransactionSources
	(SwiftTransactionId, SwiftInterimTransactionId, SwiftStatementTransactionId, SwiftCreditTransferMessageId, SwiftCreditConfirmationMessageId)
	SELECT
		@NewSwiftTransactionId,
		SwiftInterimTransactionId,
		SwiftStatementTransactionId,
		SwiftCreditTransferMessageId,
		SwiftCreditConfirmationMessageId 
	FROM Banking.SwiftTransactionSources
	WHERE SwiftTransactionId = @OriginalSwiftTransactionId

	SELECT @NewSwiftTransactionId NewSwiftTransactionId 

GO

