
/***
<StoredProcedure>
	<Description>Calculate Account Assumed Holdings</Description>
	<Parameters>
		<Parameter Name="@AccountId">
			<Description>The main head account id</Description>
		</Parameter>
		<Parameter Name="@UserId">
			<Description>The user id</Description>
		</Parameter>
		<Parameter Name="@CustomerId">
			<Description>The customer id to check the linked account</Description>
		</Parameter>
		<Parameter Name="@SubAccountIdToExclude">
			<Description>The sub account to be excluded</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE dbo.spCalculateAccountAssumedHoldings
(
@AccountId INT,
@UserId INT,
@CustomerId INT,
@SubAccountIdToExclude INT = 0
)
AS
/*
use clientaccount
DECLARE @AccountId INT = 133999,
@UserId INT = 8245,
@Customerid INT = 8245,
@SubAccountIdToExclude INT = 134490
*/
CREATE TABLE #ValidHeadAccounts
(
AccountId INT
)

CREATE TABLE #SubAccounts
(
SubAccountId INT,
ClAccountId VARCHAR(20)
)

declare @SubAccountTypeToExclude  varchar(20) = ''

if @SubAccountIdToExclude > 0 
begin
	/* For pensions, want to exclude other pension sub accounts belonging to main head account, but not for any other wrapper type*/
	set @SubAccountTypeToExclude = (select SubAccountType from dbo.SeClientAccount S
	inner join Discovery.dbo.ClientAccount C on S.ClAccountID = C.ClAccountId
	 where s.Id = @SubAccountIdToExclude)
	 if @SubAccountTypeToExclude <> 'SIPP' 
	 begin
		set @SubAccountTypeToExclude = ''
	 end 
end



CREATE INDEX UIDX_ClAccountId ON #SubAccounts(ClAccountId)

DECLARE @CurrentDate DATE = GETDATE()

IF @CustomerId > 0 BEGIN

	INSERT INTO #ValidHeadAccounts
	SELECT		SE.Id
	FROM		Platform.DBAAccount.CustomerRoles CR
	INNER JOIN	Platform.DBAAccount.CustomerRoleTypes CRT ON CR.CustomerRoleTypeId = CRT.CustomerRoleTypeId
	INNER JOIN	Platform.DBAAccount.SEClientAccount se ON cr.AccountId = SE.Id
	INNER JOIN	Platform.DBAAccount.ClientDetails cd ON SE.ClAccountId = CD.ClAccountId
	INNER JOIN	Platform.DBAAccount.ClientAccount ca ON SE.ClAccountId = CA.ClAccountId
	INNER JOIN	Platform.DBAAccount.ProductDetails pd ON SE.ClAccountId = PD.ClAccountId
	LEFT JOIN	Platform.DBAAccount.ClientAccountSecurity cad ON cad.AdvisorCodes = SE.PrimaryAdviser AND CAD.ClAccountId IS NULL AND CAD.ClientId = @UserId
	LEFT JOIN	Platform.DBAAccount.ClientAccountSecurity cac ON cac.ClAccountId = SE.ClAccountId AND CAC.ClientId = @UserId
	WHERE		CR.CustomerId = @CustomerId
	AND (
	crt.CustomerRoleType in ('IndividualAccountHolder', 'JointAccountHolder')
	OR (crt.CustomerRoleType = 'RegisteredContact' AND cd.IsJuniorAccount = 1)
	)
	AND			(CAD.ClientId IS NOT NULL OR CAC.ClientId IS NOT NULL)

END

INSERT INTO #ValidHeadAccounts
SELECT @AccountId AS AccountID
WHERE NOT Exists (SELECT AccountID FROM #ValidHeadAccounts where AccountId = @AccountId)
UNION 
SELECT L.LinkedAccountId AS AccountID 
FROM One.Charges.LinkedAccounts L
WHERE L.AccountId = @AccountId
AND NOT EXISTS (SELECT AccountID FROM #ValidHeadAccounts V where V.AccountId = L.LinkedAccountId)

INSERT INTO #SubAccounts (SubAccountId, ClAccountId)
SELECT
 SubSECA.Id,
 SubSECA.ClAccountId
FROM #ValidHeadAccounts vHeadIds 
  INNER JOIN dbo.SeClientAccount secaHead
    ON secaHead.Id = vHeadIds.AccountID
  INNER JOIN dbo.Consolidate con
    ON con.ClAccountId =secaHead.ClAccountId AND CON.ClAccountId <> CON.SubClAccountId  
  INNER JOIN Platform.Accounts.SEClientAccount SubSECA 
   ON SubSECA.ClAccountId = CON.SubClAccountId
  INNER JOIN Discovery.dbo.ClientAccount CA
   ON CA.ClAccountId = SubSECA.ClAccountId
  INNER JOIN dbo.ClientAccountSecurity CAS
    ON CAS.AdvisorCodes = secaHead.PrimaryAdviser
  AND CAS.ClientId = @UserId
WHERE SubSECA.Id <> @SubAccountIdToExclude
AND (CA.SubAccountType <> @SubAccountTypeToExclude OR secaHead.Id <> @AccountId)

SELECT
    B.InstrumentCode,
    SUM(B.Quantity) AS Quantity
    FROM (
		SELECT     
			A.SubAccountId,
			ST.CLAccountID,
			ST.InstrumentCode,
			ST.Location,
			SUM(ST.Quantity) AS Quantity
        FROM #SubAccounts A
        INNER JOIN dbo.ScripTransactions ST ON A.ClAccountId = ST.CLAccountId		
        WHERE      ST.AsAt < GETDATE() + 1
        AND        ST.TransStatus <> 'Cancelled'
        AND        ISNULL(ST.Cutover, 0) = 0
        GROUP BY   A.SubAccountId, ST.ClAccountId, ST.InstrumentCode, ST.[Location]

        UNION ALL

        SELECT
			A.SubAccountId,
            SA.ClAccountId,
            SA.InstrumentCode,
            'Custody',
            SUM(SA.Quantity) AS qty
        FROM       #SubAccounts A
        INNER JOIN dbo.ScripAdjustments SA ON A.ClAccountId = SA.CLAccountId		
        WHERE      SA.LedgerDate < GETDATE() + 1
        AND        SA.Reversed = 0
        GROUP BY   A.SubAccountId, SA.ClAccountId, SA.InstrumentCode
    ) B
    GROUP BY B.InstrumentCode
    HAVING   SUM(B.Quantity) > 0

UNION

SELECT 'GBPCash' AS InstrumentCode, -SUM(CLT.Amount) AS Quantity
FROM dbo.CashLedgerTransactions CLT
INNER JOIN #SubAccounts SA ON SA.ClAccountID = CLT.CLAccountID
group by sa.Claccountid
having sum(CLT.Amount) <> 0

union all

SELECT 'GBPCash' AS InstrumentCode, -SUM(CLA.Amount) AS Quantity
FROM dbo.CashLedgerAdjustments CLA
INNER JOIN #SubAccounts SA ON SA.ClAccountID = CLA.CLAccountID
where CLA.PortfolioAdjust = 1
group by sa.Claccountid
having sum(CLA.Amount) <> 0

union all

SELECT 'GBPCash' AS InstrumentCode, SUM(CMT.Amount) AS Quantity
FROM dbo.CmtTrans CMT
INNER JOIN #SubAccounts SA ON SA.ClAccountID = CMT.CLAccountID
group by sa.Claccountid
having sum(CMT.Amount) <> 0
DROP TABLE #SubAccounts, #ValidHeadAccounts