/***
<StoredProcedure>
    <Description>Return all SWIFT customer statement message (MT940) details to process.</Description>
    <Parameters>
        <Parameter Name="@StatementDate">
            <Description>Statement date to return messages for.</Description>
        </Parameter>
        <Parameter Name="@StatementNumber">
            <Description>Statement number to return messages for.</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE Banking.spGetSwiftStatementMessagesToProcess
(
    @StatementDate DATE,
    @StatementNumber INT,
	@AccountNumber VARCHAR(35)
)
AS

    SELECT 
        SSM.SwiftStatementMessageId,
        SSM.AccountNumber,
        SSM.Currency,
        SSM.SequenceNumber,
        SSM.OpeningBalanceDebitCreditMark,
        SSM.OpeningBalance,
        SSM.ClosingBalanceDebitCreditMark,
        SSM.ClosingBalance
    FROM 
        Banking.SwiftStatementMessages SSM		
    WHERE 
        SSM.ClosingBalanceDate = @StatementDate
        AND SSM.StatementNumber = @StatementNumber
		AND SSM.AccountNumber = @AccountNumber
    ORDER BY 
        SSM.SequenceNumber
	