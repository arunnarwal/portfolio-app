CREATE PROCEDURE dbo.spActivateSubAccountAfterCreditCardPayment
(
@SubAccountId INT
)

AS

--DECLARE @SubAccountId INT = 23933

DECLARE @ClAccountId VARCHAR(20)

SELECT @ClAccountId = ClAccountId FROM dbo.SEClientAccount WHERE Id = @SubAccountId

UPDATE dbo.SEClientAccount SET Status = 'Active' WHERE Id = @SubAccountId

UPDATE dbo.ClientDetails SET InceptionDate = GETDATE() WHERE ClAccountId = @ClAccountId

UPDATE Discovery.dbo.ClientAccount SET Status = 'Active' WHERE ClAccountId = @ClAccountId 