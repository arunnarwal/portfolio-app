/***
<StoredProcedure>
    <Description>
        Returns accrued charge position for all pending accrued adviser 'rebate' charges
        Copied from spGetAccruedAdvisorTrailAndNominatedTrailPositions and simplified
    </Description>
    <Parameters>
        <Parameter Name="@Today">
            <Description>Todays' date</Description>
        </Parameter>
        <Parameter Name="@SubClAccountId">
            <Description>Client sub-account</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE Charges.spGetAccruedAdvisorTrailAndNominatedTrailPositionsBySubClAccountId
(
    @Today DATE,
    @SubClAccountId VARCHAR(20)
)
AS
    DECLARE @LocalAsAt DATE
    SET @LocalAsAt = @Today

    DECLARE @AccountId INT
    SELECT @AccountId = Id FROM dbo.SEClientAccount WHERE ClAccountId = @SubClAccountId

    SELECT ROUND(SUM(-MFR.TrailAmount), 2) AS Amount, 'AdviserTrail' as ChargeType  -- Minus here becasue reported as a charge
    FROM dbo.Fee_Accrual_Mfr MFR
    WHERE @LocalAsAt BETWEEN MFR.AsAt AND MFR.ChargeDate
    AND MFR.ChargeBasisId = 1
    AND MFR.IsProcessed = 0
    AND MFR.SECAId = @AccountId
    GROUP BY MFR.SecaId
    HAVING ROUND(SUM(MFR.TrailAmount), 2) <> 0

    UNION ALL

    SELECT ROUND(SUM(NT.Amount), 2) AS Amount, 'NominatedTrailCharge' as ChargeType
    FROM dbo.Fee_Accrual_NominatedTrail NT
    WHERE @LocalAsAt BETWEEN NT.AsAt AND NT.ChargeDate
    AND NT.IsProcessed = 0
    AND NT.SubAccountId = @AccountId
    GROUP BY NT.SubAccountId
    HAVING ROUND(SUM(NT.Amount), 2) <> 0
