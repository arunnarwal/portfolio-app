/***
<StoredProcedure>
    <Description>Accrue the TAMFR Rebate</Description>
	<Service>Charges</Service>
    <Feature>Tasks</Feature>
    <Parameters>
        <Parameter Name="@AsAt">
            <Description>The date of the fee run</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/

CREATE PROCEDURE [dbo].[spAccrueTAMFRFee] ( @AsAt DATETIME )
AS /*
DECLARE @AsAt SMALLDATETIME
SET @AsAt = '30 Jul 2013'
*/

     BEGIN TRY
        BEGIN TRANSACTION T1

        IF OBJECT_ID(N'tempdb..#Accruals', N'U') IS NOT NULL
            BEGIN
                DROP TABLE #Accruals
            END

        DECLARE @firstNextMonth DATETIME
        SET @firstNextMonth = DATEADD(m, 1, DATEADD(d, 1 - DAY(@AsAt), @AsAt))

        DECLARE @TranType VARCHAR(10)

        SET @TranType = 'TAMFR'

        CREATE TABLE #Accruals
            (
              ToBeAppliedFeesId INT ,
              AsAt SMALLDATETIME ,
              SecaId INT ,
              InstrumentId INT ,
              Valuation MONEY ,
              Amount MONEY ,
              Rate NUMERIC(7, 4) ,
              ChargeDate SMALLDATETIME ,
              IsProcessed BIT ,
              CompanyId INT ,
              Units MONEY ,
              TaxAmount MONEY ,
              WrapAmount MONEY ,
              CompanyAmount MONEY ,
              ClientAmount MONEY ,
              WrapProviderId INT ,
              CurrencyId INT
            )

        INSERT  INTO #Accruals
                ( ToBeAppliedFeesId ,
                  AsAt ,
                  SecaID ,
                  InstrumentId ,
                  Valuation ,
                  Amount ,
                  Rate ,
                  ChargeDate ,
                  IsProcessed ,
                  CompanyId ,
                  Units ,
                  TaxAmount ,
                  WrapAmount ,
                  CompanyAmount ,
                  ClientAmount ,
                  WrapProviderId ,
                  CurrencyId 
		        )
                SELECT  ToBeApplied.Id AS ToBeAppliedFeesId ,
                        Fum.AsAt ,
                        Fum.SECAId ,
                        Fum.InstrumentId ,
                        ROUND(COALESCE(( Fum.NonCashAmount - Fum.BTAAmount ), 0), 4) AS Valuation ,
                        ROUND(COALESCE(( ( Fum.NonCashAmount - Fum.BTAAmount ) * ToBeApplied.Rate / 100 / 365.25 ), 0), 4) AS Amount ,
                        COALESCE(ToBeApplied.Rate, 0) AS Rate ,
                        @firstNextMonth ,
                        0 AS IsProcessed ,
                        Fum.CompanyId ,
                        Fum.Quantity ,
                        0 AS TaxAmount /*add in future*/ ,
                        0 AS WrapAmount /*add in future*/ ,
                        0 AS CompanyAmount /*add in future*/ ,
                        0 AS ClientAmount /*add in future*/ ,
                        WrapProvider.Id AS WrapProviderId ,
                        Fum.CurrencyId
                FROM    Cache.dbo.Fee_FUM_ByInstrument AS Fum
                        INNER JOIN dbo.SEClientAccount AS SecaId ON SecaId.Id = Fum.SECAId
                        INNER JOIN Discovery.dbo.ClientAccount AS ClientAccount ON ClientAccount.ClAccountId = SecaId.ClAccountId
                        INNER JOIN dbo.WrapProvider AS WrapProvider ON WrapProvider.Id = Fum.WrapProviderId
                        INNER JOIN dbo.FeeTranTypes AS FeeTranTypes ON FeeTranTypes.TranType IN ( @TranType )
                                                                       AND FeeTranTypes.WrapProvider = WrapProvider.WrapProvider
                        INNER JOIN dbo.ToBeAppliedFees_ByInstV2 AS ToBeApplied ON ToBeApplied.AsAt = Fum.AsAt
                                                                                  AND Fum.SECAId = ToBeApplied.SECAId
                                                                                  AND ToBeApplied.Applied = 0
                                                                                  AND FeeTranTypes.Id = ToBeApplied.FeeTranTypesId
                                                                                  AND Fum.InstrumentId = ToBeApplied.InstrumentId
                        INNER JOIN Res_DB.dbo.Instruments INS ON fum.InstrumentId = INS.Id
                        INNER JOIN Res_DB.dbo.CurrencyFormat CFI ON INS.InstrumentCCY = CFI.ISOCode
                WHERE   Fum.AsAt = @AsAt
                        AND Fum.CurrencyId = CFI.Id

        INSERT  INTO #Accruals
                ( ToBeAppliedFeesId ,
                  AsAt ,
                  SecaID ,
                  InstrumentId ,
                  Valuation ,
                  Amount ,
                  Rate ,
                  ChargeDate ,
                  IsProcessed ,
                  CompanyId ,
                  Units ,
                  TaxAmount ,
                  WrapAmount ,
                  CompanyAmount ,
                  ClientAmount ,
                  WrapProviderId ,
                  CurrencyId 
		        )
                SELECT  ToBeApplied.Id AS ToBeAppliedFeesId ,
                        Fum.AsAt ,
                        Fum.SECAId ,
                        Fum.InstrumentId ,
                        ROUND(COALESCE(( ( Fum.NonCashAmount * COALESCE(FX2.A, 1) ) - ( Fum.BTAAmount * COALESCE(FX2.A, 1) ) ), 0), 4) AS Valuation ,
                        ROUND(COALESCE(( ( ( Fum.NonCashAmount * COALESCE(FX2.A, 1) ) - ( Fum.BTAAmount * COALESCE(FX2.A, 1) ) ) * ToBeApplied.Rate / 100 / 365.25 ),
                                       0), 4) AS Amount ,
                        COALESCE(ToBeApplied.Rate, 0) AS Rate ,
                        @firstNextMonth ,
                        0 AS IsProcessed ,
                        Fum.CompanyId ,
                        Fum.Quantity ,
                        0 AS TaxAmount /*add in future*/ ,
                        0 AS WrapAmount /*add in future*/ ,
                        0 AS CompanyAmount /*add in future*/ ,
                        0 AS ClientAmount /*add in future*/ ,
                        WrapProvider.Id AS WrapProviderId ,
                        CF.Id
                FROM    Cache.dbo.Fee_FUM_ByInstrument AS Fum
                        INNER JOIN dbo.SEClientAccount AS SecaId ON SecaId.Id = Fum.SECAId
                        INNER JOIN Discovery.dbo.ClientAccount AS ClientAccount ON ClientAccount.ClAccountId = SecaId.ClAccountId
                        INNER JOIN dbo.WrapProvider AS WrapProvider ON WrapProvider.Id = Fum.WrapProviderId
                        INNER JOIN dbo.FeeTranTypes AS FeeTranTypes ON FeeTranTypes.TranType IN ( @TranType )
                                                                       AND FeeTranTypes.WrapProvider = WrapProvider.WrapProvider
                        INNER JOIN dbo.ToBeAppliedFees_ByInstV2 AS ToBeApplied ON ToBeApplied.AsAt = Fum.AsAt
                                                                                  AND Fum.SECAId = ToBeApplied.SECAId
                                                                                  AND ToBeApplied.Applied = 0
                                                                                  AND FeeTranTypes.Id = ToBeApplied.FeeTranTypesId
                                                                                  AND Fum.InstrumentId = ToBeApplied.InstrumentId
                        INNER JOIN Res_DB.dbo.Instruments INS ON fum.InstrumentId = INS.Id
                        INNER JOIN Res_DB.dbo.CurrencyFormat CFI ON INS.InstrumentCCY = CFI.ISOCode
                        LEFT JOIN Res_DB.dbo.Securities AS FX2 ON Fx2.Security = CFI.ISOCode + 'USD'
                                                                  AND Fx2.Date = @AsAt
                        INNER JOIN Res_DB.dbo.CurrencyFormat CF ON Fum.CurrencyId = CF.Id
                                                                   AND CF.ISOCode = 'USD'
                WHERE   Fum.AsAt = @AsAt
                        AND Fum.CurrencyId <> CFI.ID

        INSERT  INTO #Accruals
                ( ToBeAppliedFeesId ,
                  AsAt ,
                  SecaID ,
                  InstrumentId ,
                  Valuation ,
                  Amount ,
                  Rate ,
                  ChargeDate ,
                  IsProcessed ,
                  CompanyId ,
                  Units ,
                  TaxAmount ,
                  WrapAmount ,
                  CompanyAmount ,
                  ClientAmount ,
                  WrapProviderId ,
                  CurrencyId 
		        )
                SELECT  ToBeApplied.Id AS ToBeAppliedFeesId ,
                        Fum.AsAt ,
                        Fum.SECAId ,
                        Fum.InstrumentId ,
                        ROUND(COALESCE(( Fum.NonCashAmount * COALESCE(FX2.A, 1) / COALESCE(FX1.A, 1) ) - ( Fum.BTAAmount * COALESCE(FX2.A, 1) / COALESCE(FX1.A, 1) ),
                                       0), 4) AS Valuation ,
                        ROUND(COALESCE(( ( ( Fum.NonCashAmount * COALESCE(FX2.A, 1) / COALESCE(FX1.A, 1) ) - ( Fum.BTAAmount * COALESCE(FX2.A, 1) / COALESCE(FX1.A,
                                                                                                                                                1) ) )
                                         * ToBeApplied.Rate / 100 / 365.25 ), 0), 4) AS Amount ,
                        COALESCE(ToBeApplied.Rate, 0) AS Rate ,
                        @firstNextMonth ,
                        0 AS IsProcessed ,
                        Fum.CompanyId ,
                        Fum.Quantity ,
                        0 AS TaxAmount /*add in future*/ ,
                        0 AS WrapAmount /*add in future*/ ,
                        0 AS CompanyAmount /*add in future*/ ,
                        0 AS ClientAmount /*add in future*/ ,
                        WrapProvider.Id AS WrapProviderId ,
                        CF.Id
                FROM    Cache.dbo.Fee_FUM_ByInstrument AS Fum
                        INNER JOIN dbo.SEClientAccount AS SecaId ON SecaId.Id = Fum.SECAId
                        INNER JOIN Discovery.dbo.ClientAccount AS ClientAccount ON ClientAccount.ClAccountId = SecaId.ClAccountId
                        INNER JOIN dbo.WrapProvider AS WrapProvider ON WrapProvider.Id = Fum.WrapProviderId
                        INNER JOIN dbo.FeeTranTypes AS FeeTranTypes ON FeeTranTypes.TranType IN ( @TranType )
                                                                       AND FeeTranTypes.WrapProvider = WrapProvider.WrapProvider
                        INNER JOIN dbo.ToBeAppliedFees_ByInstV2 AS ToBeApplied ON ToBeApplied.AsAt = Fum.AsAt
                                                                                  AND Fum.SECAId = ToBeApplied.SECAId
                                                                                  AND ToBeApplied.Applied = 0
                                                                                  AND FeeTranTypes.Id = ToBeApplied.FeeTranTypesId
                                                                                  AND Fum.InstrumentId = ToBeApplied.InstrumentId
                        INNER JOIN Res_DB.dbo.Instruments INS ON fum.InstrumentId = INS.Id
                        INNER JOIN Res_DB.dbo.CurrencyFormat CFI ON INS.InstrumentCCY = CFI.ISOCode
                        LEFT JOIN Res_DB.dbo.Securities AS FX2 ON Fx2.Security = CFI.ISOCode + 'USD'
                                                                  AND Fx2.Date = @AsAt
                        INNER JOIN Res_DB.dbo.CurrencyFormat CF ON Fum.CurrencyId = CF.Id
                                                                   AND CF.ISOCode <> 'USD'
                        LEFT JOIN Res_DB.dbo.Securities AS FX1 ON Fx1.Security = CF.ISOCode + 'USD'
                                                                  AND Fx1.Date = @AsAt
                WHERE   Fum.AsAt = @AsAt
                        AND Fum.CurrencyId <> CFI.ID

        INSERT  INTO dbo.Fee_Accrual_TAMFR
                ( AsAt ,
                  SecaID ,
                  InstrumentID ,
                  Valuation ,
                  TotalAmount ,
                  Rate ,
                  ChargeDate ,
                  IsProcessed ,
                  CompanyId ,
                  Units ,
                  TaxAmount ,
                  WrapAmount ,
                  CompanyAmount ,
                  ClientAmount ,
                  WrapProviderId ,
                  CurrencyId 
		        )
                SELECT  #Accruals.AsAt ,
                        #Accruals.SECAId ,
                        #Accruals.InstrumentId ,
                        #Accruals.Valuation ,
                        -#Accruals.Amount AS Amount ,
                        #Accruals.Rate ,
                        #Accruals.ChargeDate ,
                        #Accruals.IsProcessed ,
                        #Accruals.CompanyId ,
                        #Accruals.Units ,
                        -#Accruals.TaxAmount AS TaxAmount ,
                        #Accruals.WrapAmount ,
                        #Accruals.CompanyAmount ,
                        #Accruals.ClientAmount ,
                        #Accruals.WrapProviderId ,
                        #Accruals.CurrencyId
                FROM    #Accruals
    END TRY

    BEGIN CATCH
        ROLLBACK TRANSACTION T1

        DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;

        IF OBJECT_ID(N'tempdb..#Accruals', N'U') IS NOT NULL
            BEGIN
                DROP TABLE #Accruals
            END

        SELECT  @ErrorMessage = ERROR_MESSAGE() ,
                @ErrorSeverity = ERROR_SEVERITY() ,
                @ErrorState = ERROR_STATE();

        RAISERROR (
			@ErrorMessage
			,@ErrorSeverity
			,@ErrorState
			);
    END CATCH;

    IF @@TRANCOUNT > 0
        BEGIN
            SELECT  'Success' AS Result

            UPDATE  dbo.ToBeAppliedFees_ByInstV2
            SET     Applied = 1 ,
                    ProcessedDate = GETDATE()
            WHERE   Id IN ( SELECT  ToBeAppliedFeesId
                            FROM    #Accruals )

            INSERT  INTO dbo.AppliedFees_ByInstV2
                    ( FeeTranTypesId ,
                      SECAId ,
                      InstrumentId ,
                      Rate ,
                      ProcessedDate ,
                      DateCreated ,
                      AsAt ,
                      ApplyVat
		            )
                    SELECT  ToBeApplied.FeeTranTypesId ,
                            ToBeApplied.SECAId ,
                            ToBeApplied.InstrumentId ,
                            ToBeApplied.Rate ,
                            ToBeApplied.ProcessedDate ,
                            ToBeApplied.DateCreated ,
                            ToBeApplied.AsAt ,
                            ToBeApplied.ApplyVAT
                    FROM    dbo.ToBeAppliedFees_ByInstV2 ToBeApplied
                    WHERE   Id IN ( SELECT  #Accruals.ToBeAppliedFeesId
                                    FROM    #Accruals )

            DELETE  dbo.ToBeAppliedFees_ByInstV2
            WHERE   Id IN ( SELECT  ToBeAppliedFeesId
                            FROM    #Accruals )

            IF OBJECT_ID(N'tempdb..#Accruals', N'U') IS NOT NULL
                BEGIN
                    DROP TABLE #Accruals
                END

            COMMIT TRANSACTION T1
        END
GO