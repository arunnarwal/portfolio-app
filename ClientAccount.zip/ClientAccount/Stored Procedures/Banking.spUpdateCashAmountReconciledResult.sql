/***
<StoredProcedure>
    <Description>Updated the rec amount (auto adjust cash entry amount in case it is diffrent from swift transaction)</Description>
    <Parameters>
        <Parameter Name="@CashEntryID">
            <Description>Cash Entry ID Which Needs Update</Description>
        </Parameter>
		 <Parameter Name="@BatchID">
            <Description>Batch ID Which Needs Update</Description>
        </Parameter>
		<Parameter Name="@recTableConstant">
            <Description>Reconciliation table constant</Description>
        </Parameter>
		 <Parameter Name="@Amount">
            <Description>Amount to be updated</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [Banking].[spUpdateCashAmountReconciledResult]
(
    @CashEntryID INT,
	@BatchID INT,
	@recTableConstant  VARCHAR (50),
	@Amount NUMERIC (18, 4)
)
AS
BEGIN

	UPDATE 
	dbo.ReconciledResults
	SET RecAmount = @Amount
	WHERE
	IDFieldValue = @CashEntryID 
	AND BatchID = @BatchID 
	AND TableConstant = @recTableConstant

END
