/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>8A5364DA06B72790A8C1D23B85D3BEB5</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS OFF
GO
CREATE PROCEDURE [dbo].[spAddNetworkCompanyPagePermissioning](@UserGroupID int)  AS

delete from webdb..UserFunctionsToGroups
where UserGroupID = @UserGroupId and UserFunctionID in (2989,2990,96999,97017,4775,4778,4776,4777,4806,4808,4809,4817)
-- Authorisations menu
insert into webdb..UserFunctionsToGroups (UserGroupID, UserFunctionID)
values (@UserGroupID, 2989)
-- Authorise Processes
insert into webdb..UserFunctionsToGroups (UserGroupID, UserFunctionID)
values (@UserGroupID, 2990)
-- Archived Authorisations
insert into webdb..UserFunctionsToGroups (UserGroupID, UserFunctionID)
values (@UserGroupID, 96999)
-- Archived Reviews
insert into webdb..UserFunctionsToGroups (UserGroupID, UserFunctionID)
values (@UserGroupID, 97017)
-- Profitability menu
insert into webdb..UserFunctionsToGroups (UserGroupID, UserFunctionID)
values (@UserGroupID, 4775)
-- View Client Profitability
insert into webdb..UserFunctionsToGroups (UserGroupID, UserFunctionID)
values (@UserGroupID, 4778)
-- Add Time
insert into webdb..UserFunctionsToGroups (UserGroupID, UserFunctionID)
values (@UserGroupID, 4776)
-- View Time and Cost Totals
insert into webdb..UserFunctionsToGroups (UserGroupID, UserFunctionID)
values (@UserGroupID, 4777)
-- Rules menu
insert into webdb..UserFunctionsToGroups (UserGroupID, UserFunctionID)
values (@UserGroupID, 4806)
-- Authorisation (rules)
insert into webdb..UserFunctionsToGroups (UserGroupID, UserFunctionID)
values (@UserGroupID, 4808)
-- Review (rules)
insert into webdb..UserFunctionsToGroups (UserGroupID, UserFunctionID)
values (@UserGroupID, 4809)
-- Rule detail popup
insert into webdb..UserFunctionsToGroups (UserGroupID, UserFunctionID)
values (@UserGroupID, 4817)

delete from cache..wrapmenucache
GO
