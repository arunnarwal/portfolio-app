/***
<StoredProcedure>
    <Description>Gets tier structure permissions by TierStructureId</Description>
	<Parameters>
		<Parameter Name="@TierStructureId">
			<Description>The id of the tier structure</Description>
		</Parameter>
	</Parameters>	
</StoredProcedure>
***/
CREATE PROCEDURE Charges.spGetTierStructurePermissions (@TierStructureId INT) AS

	SELECT tsp.HierarchyLevelNameId, tsp.EntityId
	FROM Charges.TierStructurePermissions tsp
	WHERE tsp.TierStructureId = @TierStructureId
	