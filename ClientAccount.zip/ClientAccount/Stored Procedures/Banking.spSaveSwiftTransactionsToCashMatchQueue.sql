/*** 
<StoredProcedure>
	<Description>Saves items to the automated cash matching queue</Description>
	<Parameters>
		<Parameter Name="@Items">
			<Description>Xml document containing automated cash matching queue items</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROC Banking.spSaveSwiftTransactionsToCashMatchQueue
	@Items VARCHAR(MAX)
AS
	DECLARE @ItemsXml XML = CAST(@Items AS XML)

	SELECT
		ROW_NUMBER() OVER(ORDER BY T.x.value('@TransactionId', 'INT')) Id,
		T.x.value('@TransactionId', 'INT') TransactionId,
		T.x.value('@DateAdded', 'DATETIME') DateAdded,
		T.x.value('@LastAttempted', 'DATETIME') LastAttempted,
		T.x.value('@MaxAttemptDays', 'INT') MaxAttemptDays,
		T.x.value('@Complete', 'BIT') Complete
	INTO #Items
	FROM
		@ItemsXml.nodes('Items/Item') T(x)

	CREATE CLUSTERED INDEX IDX_Items ON #Items (Id)

	MERGE INTO Banking.SwiftTransactionsToCashMatchQueue T
	USING (SELECT TransactionId, LastAttempted,DateAdded, MaxAttemptDays, Complete FROM #Items) S
		ON T.TransactionId = S.TransactionId
	WHEN MATCHED AND S.Complete <> 1 AND T.DateAdded + T.MaxAttemptDays >= GetDate() THEN
		UPDATE
		SET	LastAttempted = S.LastAttempted
	WHEN MATCHED AND (S.Complete = 1 OR T.DateAdded + T.MaxAttemptDays < GetDate()) THEN
		DELETE
	WHEN NOT MATCHED THEN
		INSERT (TransactionId,DateAdded, LastAttempted, MaxAttemptDays)
		VALUES (S.TransactionId,S.DateAdded, S.LAstAttempted, S.MaxAttemptDays);

	INSERT Banking.SwiftTransactionsToCashMatchQueueHistory (TransactionId,DateAdded, LastAttempted, MaxAttemptDays, Complete)
	SELECT TransactionId,DateAdded, LastAttempted, MaxAttemptDays, Complete
	FROM #Items
	WHERE Complete = 1 OR DateAdded + MaxAttemptDays < GetDate()

	DROP TABLE #Items
