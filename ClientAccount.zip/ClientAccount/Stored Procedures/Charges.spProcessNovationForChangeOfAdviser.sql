/***
<StoredProcedure>
    <Description>Process novation for change of adviser wizard</Description>
	<Parameters>
		<Parameter Name="@ClAccountId">
			<Description>The account need to move</Description>
		</Parameter>
		<Parameter Name="@UserId">
			<Description>user who requests the process</Description>
		</Parameter>
	</Parameters>	
</StoredProcedure>
***/
CREATE PROCEDURE Charges.spProcessNovationForChangeOfAdviser
(
    @ClAccountId VARCHAR(20),
    @UserId INT
)
AS
-- DECLARE @ClAccountId VARCHAR(20)='AC2534302'
--DECLARE @UserId INT=1063804
DECLARE @SubAccountHierarchyLevelId TINYINT;

SELECT @SubAccountHierarchyLevelId = HierarchyLevelNameId
FROM Platform.HierarchyEntities.HierarchyLevelNames
WHERE HierarchyLevelName = 'SubAccount';

DECLARE @SubClAccountsWithTierStructureId AS TABLE
(
    AccountId INT,
    ClAccountId VARCHAR(20),
    ClientFBRCSettingsId INT,
    TierStructureId INT,
    PRIMARY KEY CLUSTERED (
                              AccountId,
                              ClAccountId,
                              ClientFBRCSettingsId
                          )
);

INSERT INTO @SubClAccountsWithTierStructureId
(
    AccountId,
    ClAccountId,
    ClientFBRCSettingsId,
    TierStructureId
)
SELECT SCA.ID,
       SCA.ClAccountID,
       CFS.Id AS ClientFBRCSettingsId,
       CFS.TierStructureId
FROM dbo.SEClientAccount SCA
    INNER JOIN dbo.fnHeadAccounts() HA
        ON HA.ClAccountID = SCA.ClAccountID
    INNER JOIN dbo.ClientFBRCSettings CFS
        ON CFS.ClAccountID = SCA.ClAccountID
WHERE HA.HeadClAccountID = @ClAccountId
      AND CFS.TierStructureId IS NOT NULL
      AND CFS.TierStructureId > 0
      AND CFS.Active = 1
      AND NOT EXISTS
(
    SELECT 1
    FROM Charges.TierStructureNovationLogs TSNL
    WHERE TSNL.ClAccountId = SCA.ClAccountID
          AND TSNL.OriginTierStructureId = CFS.TierStructureId
);

--Add subAccount level permission 
INSERT INTO Charges.TierStructurePermissions
(
    TierStructureId,
    HierarchyLevelNameId,
    EntityId
)
SELECT NTSD.TierStructureId,
       @SubAccountHierarchyLevelId,
       NTSD.AccountId
FROM @SubClAccountsWithTierStructureId NTSD
WHERE NOT EXISTS
(
    SELECT 1
    FROM Charges.TierStructurePermissions TSP
    WHERE TSP.TierStructureId = NTSD.TierStructureId
          AND TSP.HierarchyLevelNameId = @SubAccountHierarchyLevelId
          AND TSP.EntityId = NTSD.AccountId
);

--write log

INSERT INTO Charges.TierStructureNovationLogs
(
    ClAccountId,
    OriginTierStructureId,
    NovatedTierStructureId,
    AuditBy,
    LogDateTime
)
SELECT Temp.ClAccountId,
       Temp.TierStructureId,
       Temp.TierStructureId,
       @UserId,
       GETDATE()
FROM @SubClAccountsWithTierStructureId Temp;
