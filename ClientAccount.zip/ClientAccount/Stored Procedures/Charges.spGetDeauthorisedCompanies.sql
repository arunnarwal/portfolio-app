/***
<StoredProcedure>
    <Description>Gets the Ids of deauthorised companies</Description>
    <Service>Charges</Service>
    <Feature>Charges</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE [Charges].[spGetDeauthorisedCompanies] AS
BEGIN	
	SELECT 	
		co.Id CompanyId
	FROM dbo.Company co
	WHERE FSAAuthorisationStatus = 'Deauthorised'
END	
