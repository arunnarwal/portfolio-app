/***
<StoredProcedure>
    <Description>CGT Tool Income Summary</Description>
    <Parameters>
        <Parameter Name="@ClAccountIds">
            <Description>ClAccount Id</Description>
        </Parameter>
		<Parameter Name="@IncludePreMigrationTransactions">
            <Description>Switch to consider pre migrated transactions or not</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE dbo.spCGTToolIncomeSummaryInclExternal
    @ClAccountIds VARCHAR(MAX),
	@IncludePreMigrationTransactions BIT = 0
AS

--DECLARE @ClAccountIds VARCHAR(MAX) = 'AC2016973-002,AC2016975-002,AC2017115-002,AC2013375-002,AC2007963-002,AC2016462-003,AC2019717-003'
--DECLARE @IncludePreMigrationTransactions BIT = 0

SELECT
    CAST(TabValue AS VARCHAR(20)) AS ClAccountId
INTO #ClAccountIds
FROM CSFBMaster.dbo.[fn_convert_comma_to_table_char](@ClAccountIds)

CREATE CLUSTERED INDEX IDX_ClAccountIds_ClAccountId ON #ClAccountIds (ClAccountId)


DECLARE @MigrationDateOffset int = (SELECT [Value] FROM SystemVariables.dbo.SystemVariables AS SV WHERE ID = 105549)
declare @MigrationDate DateTime

select @MigrationDate = tid.RequestDateTime from Discovery.Dbo.Clientaccount CA
inner join Discovery.Dbo.Transactionid TID on CA.TransactionID =TID.TransactionID
inner join #ClAccountIds Acc on Acc.ClAccountId = CA.ClAccountID
where TID.Callersource = 'MIG' 
order by tid.RequestDateTime desc

declare @MigrationDateMinusMigrationOffset DateTime = DateAdd(d, -1 * (@MigrationDateOffset), @MigrationDate)


SELECT
	Con.ClAccountID,
    Con.SubClAccountID AS SubClAccountId,
	LET.LegalEntityTypeId

INTO #AccountDetails
FROM #ClAccountIds TAB
	INNER JOIN dbo.Consolidate CON ON Con.ClAccountID = Tab.ClAccountId
	INNER JOIN Discovery.dbo.ProductDetails AS PD ON PD.ClAccountID = CON.SubClAccountID
	INNER JOIN dbo.ClientDetails CD ON CD.CLAccountID = CON.ClAccountID
	INNER JOIN dbo.Company CO ON CO.Company = CD.Company
	INNER JOIN dbo.VwWrapProviderWithJurisdiction vww ON vww.WrapProvider=CO.WrapProvider
	LEFT JOIN One.Tax.LegalEntityType let ON (case when CD.InvestorType='individ' then 'individual' else CD.InvestorType end) = let.LegalEntityType and let.IsSubType = 0
	INNER JOIN Platform.ProductWrappers.ProductWrapperTypes pwt on pwt.ProductType=PD.ProductType
	INNER JOIN Tax.CGT_TaxableProductWrapperTypes TPWT ON TPWT.ProductWrapperTypeId = PWT.ProductWrapperTypeId
	LEFT JOIN One.Tax.CGTProductWrapperException cgt 
		ON cgt.JurisdictionID=vww.JurisdictionID 
		AND (let.LegalEntityTypeId=cgt.LegalEntityType or cgt.LegalEntityType is null) 
		AND (CD.LegalEntitySubType=cgt.LegalEntitySubType or cgt.LegalEntitySubType is null) 
		AND (CD.LegalEntitySubSubType=cgt.LegalEntitySubSubType or cgt.LegalEntitySubSubType is null) 
		AND (pwt.ProductWrapperTypeId=cgt.ProductWrapperType or cgt.ProductWrapperType is null) 
		AND (PD.ProductSubTypeId=cgt.ProductWrapperSubType or cgt.ProductWrapperSubType is null)
WHERE 
	cd.IsCgtExempt <> 1
	AND ( cgt.JurisdictionID is null And cgt.LegalEntityType is null and cgt.LegalEntitySubType is null and cgt.LegalEntitySubSubType is null and cgt.ProductWrapperType is null and cgt.ProductWrapperSubType is null)
	
CREATE UNIQUE CLUSTERED INDEX CIDX_ClAccountIds_SubClAccountID ON #AccountDetails (SubClAccountID)

SELECT
    CON.ClAccountID
,	INC.HubAccountId
,   CON.LegalEntityTypeId
,   INC.Id
,   INC.LedgerDate
,   CA.ExDate
,   ISNULL(INC.InstrumentCode, CA.InstrumentCode) AS Instrumentcode
,   INC.QualifyingHolding
,   COALESCE(INC.Equalisation, 0) AS Equalisation
,   CASE WHEN INC.FinalProcessType NOT IN ('AccFund', 'ERI') AND INC.Equalisation > 0 THEN 0
         ELSE INC.TargetNetAmount
    END AS NetAmount
,   INC.CorpActID
,   INC.Group1Group2
FROM dbo.ExternallyReceivedIncomeSummary AS INC
INNER JOIN #AccountDetails AS CON ON CON.SubClAccountID = INC.ClAccountID
INNER JOIN CorporateActions.dbo.CorporateAction AS CA ON CA.Id = INC.CorpActID
LEFT JOIN CorporateActions.dbo.Dividend AS D ON D.CorpActID = INC.CorpActID

WHERE
	 INC.[QualifyingHolding] IS NOT NULL
AND  INC.[Reversal] IS NULL
AND (INC.FinalProcessType IN ('AccFund', 'ERI') OR INC.Equalisation > 0)

AND EXISTS ( SELECT 1 FROM Res_db.dbo.Instruments AS I 
	WHERE CA.InstrumentCode = I.[Security]
	AND  I.[SecuritySubType] in ('ManagedFund','Exchange Traded Fund')	
)
AND (
		D.PayDate >= @MigrationDateMinusMigrationOffset OR
		@MigrationDateMinusMigrationOffset IS NULL OR
		@IncludePreMigrationTransactions = 1
	)	 	

UNION ALL

SELECT
    CON.ClAccountID
,	NULL AS 'HubAccountId'
,   CON.LegalEntityTypeId
,   INC.Id
,   INC.LedgerDate
,   CA.ExDate
,   ISNULL(INC.InstrumentCode, CA.InstrumentCode) AS Instrumentcode
,   INC.QualifyingHolding
,   COALESCE(INC.Equalisation, 0) AS Equalisation
,   CASE WHEN INC.FinalProcessType NOT IN ('AccFund', 'ERI') AND INC.Equalisation > 0 THEN 0
         ELSE INC.TargetNetAmount
    END AS NetAmount
,   INC.CorpActID
,   INC.Group1Group2
FROM dbo.IncomeSummary AS INC
INNER JOIN #AccountDetails AS CON ON CON.SubClAccountID = INC.ClAccountID
INNER JOIN CorporateActions.dbo.CorporateAction AS CA ON CA.Id = INC.CorpActID
LEFT JOIN CorporateActions.dbo.Dividend AS D ON D.CorpActID = INC.CorpActID
WHERE
	 INC.[QualifyingHolding] IS NOT NULL
AND  INC.[Reversal] IS NULL
AND (INC.FinalProcessType IN ('AccFund', 'ERI') OR INC.Equalisation > 0)

AND EXISTS ( SELECT 1 FROM Res_db.dbo.Instruments AS I 
	WHERE CA.InstrumentCode = I.[Security]
	AND  I.[SecuritySubType] in ('ManagedFund','Exchange Traded Fund')	
)
AND (
		D.PayDate >= @MigrationDateMinusMigrationOffset OR
		@MigrationDateMinusMigrationOffset IS NULL OR
		@IncludePreMigrationTransactions = 1
	)	 	

DROP TABLE #ClAccountIds
DROP TABLE #AccountDetails

GO