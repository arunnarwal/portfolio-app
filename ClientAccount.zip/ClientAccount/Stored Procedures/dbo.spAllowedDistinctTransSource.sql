/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>470AFB6D775D4C7B92F788400923451A</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- =============================================
-- Author:		<Dan Lord>
-- Create date: <25-Jan-2007>
-- Description:	<Gets a distinct List of TransSources that are available to a User. 
--It does this By Finding out which ClAccounts the user has Access to with vwAllowedClientAccountsQuickLookup
-- then joins that onto scriptransactions then selects distinct transSource. easy>
-- =============================================

	-- Add the parameters for the stored procedure here
 
Create PROCEDURE [dbo].[spAllowedDistinctTransSource] (@ClientId int) AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	select distinct transSource from clientaccount.dbo.scriptransactions as st
	inner join clientaccount.dbo.vwAllowedClientAccountsQuickLookup as ac 
		on st.claccountid = ac.claccountid

where clientid = @ClientId

END
GO
