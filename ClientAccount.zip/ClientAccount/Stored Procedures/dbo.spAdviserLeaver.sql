/***
<StoredProcedure>
    <Description>Procedure to process advisor leaving platform</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE [dbo].[spAdviserLeaver](
                @AdviserCode VARCHAR(20),
				@Company VARCHAR(20),
				@TaskRequestId INT)
AS
  DECLARE  @ErrorMessage VARCHAR(MAX)
  
/*
DECLARE @Company VARCHAR(20), @AdviserCode VARCHAR(20)
SELECT @Company = 'AXAWrap', @AdviserCode = 'AXAWrap000002'
*/
  SET nocount  ON

  DECLARE	@Today DATETIME,
			@id            INT,
			@oldValues VARCHAR(500),
			@TransactionId INT,
			@currStep INT,
			@UserID INT,
			@ActionType       VARCHAR(70) 

  SET @Today = Getdate()    
   
  BEGIN TRY
  BEGIN TRANSACTION
	/*================= Getting ActionType and UserRequestedId ===============================*/
    SELECT @ActionType = ActionType,
           @UserId = RequestClientID
    FROM   TaskDB.dbo.TaskRequests AS tr
           INNER JOIN Discovery.dbo.RequestInterfaceActions AS ria
             ON ria.TaskId = tr.TaskId
    WHERE  tr.Id = @TaskRequestId

	IF @UserId IS NOT NULL
	BEGIN
	INSERT INTO Discovery.dbo.RequestInterfaceTransactions
             (ActionName,
              ClAccountID,
              RequestedBy,
              RequestDate)
	VALUES     ('AdviserLeaver',@AdviserCode,@userId,@Today)
  
	SELECT @TransactionId = Scope_identity(), @currStep = 0  

	INSERT INTO Discovery.dbo.RequestInterfaceTaskRequests (TransactionID, TaskRequestID)
	VALUES (@TransactionId, @TaskRequestId)
  
		SELECT @id = ID, @oldValues = 'AdvCode=' + AdvCode + '|Company=' + Company
		FROM dbo.Advisor
		WHERE  Advcode = @AdviserCode

	--Update PrimaryAdviser in SEClientAccount
		UPDATE dbo.Advisor
		SET    Company = @Company,
				IsActive = 0
		WHERE  Id = @id
		
		--Insert new entry into AdvisorCodeLog
		INSERT INTO dbo.AdvisorCodeLog
				(AdvisorID,
				AdvCode,
				Company,
				AdvCodeDateCreated,
				Source,
				Note)
		VALUES (@id,@AdviserCode,@Company,Getdate(),'ClientAccount.dbo.spAdviserLeaver','TransactionId = ' + Convert(VARCHAR,@TransactionId))
  
		INSERT INTO Discovery.dbo.RequestInterfaceChangeLog
                     (TransactionId,
                      TableRowIdentifier,
                      DatabaseName,
                      TableName,
					  OldValues,
                      NewValues)
		VALUES (@TransactionId,@id,'ClientAccount','Advisor',@oldValues, 'AdvCode=' + @AdviserCode + '|Company=' + @Company )
    
	WHILE EXISTS (SELECT 1 FROM ClientDB3.dbo.TblClients WHERE AdvCode = @AdviserCode AND OSTEnabled = 1)
	BEGIN
		SELECT TOP 1 @id = ClientId, @oldValues = 'AdvCode=' + AdvCode + '|Company=' + Company
		FROM ClientDB3.dbo.TblClients
		WHERE  AdvCode = @AdviserCode
			AND OSTEnabled = 1

		UPDATE ClientDB3.dbo.TblClients
		SET    Company = @Company,
				OSTEnabled = 0
		WHERE  ClientId = @id

		INSERT INTO Discovery.dbo.RequestInterfaceChangeLog
                     (TransactionId,
                      TableRowIdentifier,
                      DatabaseName,
                      TableName,
					  OldValues,
                      NewValues)
		VALUES (@TransactionId,@id,'ClientDB3','TBLClients',@oldValues, 'AdvCode=' + @AdviserCode + '|Company=' + @Company )
	END
	END
	ELSE
	BEGIN
		RAISERROR ('Unable to find the Task Request or there is no RI action defined for this TaskId', 11,1)
	END

	COMMIT TRANSACTION
  
	SELECT NULL AS errormessage

  END TRY
  
  BEGIN CATCH
    SET @ErrorMessage = Error_message()
    
    ROLLBACK TRANSACTION
  
	SELECT @ErrorMessage AS errormessage
  END CATCH
GO
