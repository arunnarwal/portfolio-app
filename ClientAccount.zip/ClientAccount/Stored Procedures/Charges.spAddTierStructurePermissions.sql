/***
<StoredProcedure>
    <Description>Adds permissions to a tier structure</Description>
	<Parameters>
		<Parameter Name="@TierStructureId">
			<Description>The Id of the tier structure to add permissions to</Description>
		</Parameter>
		<Parameter Name="@HierarchyLevelNameId">
			<Description>The hierarchy level of the permissions being added</Description>
		</Parameter>
		<Parameter Name="@EntityIdCsv">
			<Description>The entity ids being permissioned</Description>
		</Parameter>
	</Parameters>	
</StoredProcedure>
***/
CREATE PROCEDURE Charges.spAddTierStructurePermissions (
	@TierStructureId INT,
	@HierarchyLevelNameId INT,
	@EntityIdCsv VARCHAR(MAX)) AS

	SELECT Tabvalue as EntityId
	INTO #EntityIds
	FROM CSFBMaster.dbo.fn_convert_comma_to_table_int(@EntityIdCsv)

	INSERT INTO Charges.TierStructurePermissions
		(TierStructureId, HierarchyLevelNameId, EntityId)
	SELECT @TierStructureId, @HierarchyLevelNameId, e.EntityId
	FROM #EntityIds e
