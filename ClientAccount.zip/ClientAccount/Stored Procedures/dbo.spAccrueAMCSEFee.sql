/***
<StoredProcedure>
    <Description>Accrue the Tiered Per Member (Employer)</Description>
	<Service>Charges</Service>
    <Feature>Tasks</Feature>
    <Parameters>
        <Parameter Name="@AsAt">
            <Description>The date of the fee run</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/

CREATE PROCEDURE [dbo].[spAccrueAMCSEFee] (@AsAt DATETIME)
AS

--DECLARE @AsAt SMALLDATETIME
--SET @AsAt = '08 May 2014'

BEGIN TRY
	BEGIN TRANSACTION T1

	IF OBJECT_ID(N'tempdb..#ClientAccruals', N'U') IS NOT NULL
	BEGIN
		DROP TABLE #ClientAccruals
	END

	IF OBJECT_ID(N'tempdb..#SchemeAccruals', N'U') IS NOT NULL
	BEGIN
		DROP TABLE #SchemeAccruals
	END

	DECLARE @TranType VARCHAR(10)
	SET @TranType = 'AMCSE'

	SELECT 
		ToBeApplied.Id AS ToBeAppliedFeesId
		,SchemeDetails.Id As SchemeId
		,Fum.AsAt
		,TierGroup.IsOffPlatform
		,Fum.SECAId
		,COALESCE(ToBeApplied.Rate, 0) AS Rate
		,Fum.CurrencyId 
	INTO #ClientAccruals
	FROM Cache.dbo.Fee_FUM_ByAccount AS Fum 
	INNER JOIN dbo.Advisor Advisor
		ON Fum.AdvisorId = Advisor.Id
	INNER JOIN dbo.CorporateSchemeDetails SchemeDetails
		ON SchemeDetails.AdvisorCode = Advisor.AdvCode
	INNER JOIN dbo.[WrapProvider] AS WrapProvider
		ON WrapProvider.Id = Fum.WrapProviderId
	INNER JOIN dbo.FeeTranTypes AS FeeTranTypes
		ON FeeTranTypes.TranType = @TranType
			AND FeeTranTypes.WrapProvider = WrapProvider.WrapProvider
	INNER JOIN dbo.ToBeAppliedFees_ByAccV2 AS ToBeApplied
		ON ToBeApplied.AsAt = Fum.AsAt
			AND Fum.SECAId = ToBeApplied.SECAId
			AND ToBeApplied.Applied = 0
			AND FeeTranTypes.Id = ToBeApplied.FeeTranTypesId
		AND Fum.AsAt = @AsAt 
	INNER JOIN dbo.SEClientAccount SecaId
		ON SecaId.Id = Fum.SECAId
	INNER JOIN Discovery.dbo.ProductDetails ProductDetails
		ON ProductDetails.ClAccountId = SecaId.ClAccountId	
	INNER JOIN dbo.CorporateTieredAMC TierGroup
		ON TierGroup.SchemeId = SchemeDetails.Id  
			AND TierGroup.FeeTranTypeId = FeeTranTypes.Id 
			AND TierGroup.ProductType = ProductDetails.ProductType  
			AND @AsAt  >= TierGroup.FromDate AND ( TierGroup.ToDate IS NULL OR @AsAt <= TierGroup.ToDate )
			
	SELECT
			0 As SecaId
			,#ClientAccruals.SchemeId
			,#ClientAccruals.AsAt As AsAt
			,#ClientAccruals.IsOffPlatform
			,MAX(#ClientAccruals.Rate) As Amount
			,COUNT(*) As MemberCount
			,MAX(#ClientAccruals.Rate) AS Rate
			,#ClientAccruals.CurrencyId
			,@AsAt As ChargeDate
	INTO #SchemeAccruals
	FROM #ClientAccruals
	GROUP BY #ClientAccruals.SchemeId, #ClientAccruals.AsAt, #ClientAccruals.IsOffPlatform, #ClientAccruals.CurrencyId
		
	UPDATE #SchemeAccruals
	SET SecaId = SecaId.Id
		,ChargeDate = FRQRanged.ToDate
	FROM #SchemeAccruals
	INNER JOIN dbo.CorporateSchemeDetails SchemeDetails
		ON #SchemeAccruals.SchemeId = SchemeDetails.Id
	INNER JOIN dbo.CorporateSchemeEmployerDetails EmployerDetails
		ON SchemeDetails.EmployerDetailsId = EmployerDetails.Id
	INNER JOIN dbo.CorporateEmployer Employer
		ON EmployerDetails.EmployerId = Employer.Id
	INNER JOIN dbo.Branches Branches
		ON Employer.BranchId = Branches.Id
	INNER JOIN dbo.Advisor Advisor
		ON Branches.Id = Advisor.BranchId
	INNER JOIN dbo.SEClientAccount SecaId
		ON SecaId.PrimaryAdviser = Advisor.AdvCode
	INNER JOIN dbo.fnHeadAccounts() Head 
		ON SecaId.ClAccountId = Head.ClAccountId AND Head.Consolidated = 0
	CROSS APPLY dbo.fnGetDateRangesForFrequencies(@AsAt,DATEADD(dd, 0, DATEDIFF(dd, 0, SecaId.DateCreated + 1))) FRQRanged
WHERE FRQRanged.Frequency = 'M'
	AND SECAId.InvestorType = 'EmployerReserve' 
	AND Head.ClAccountId <> Head.HeadClAccountId
	
	INSERT INTO dbo.Fee_Accrual_AMCSE (
		AsAt
		,SchemeId
		,SecaId
		,IsOffPlatform
		,Amount
		,MemberCount
		,Rate
		,ChargeDate
		,IsProcessed
		,CurrencyId
		)
	SELECT AsAt
		,#SchemeAccruals.SchemeId
		,#SchemeAccruals.SecaId
		,#SchemeAccruals.IsOffPlatform
		,#SchemeAccruals.Amount
		,#SchemeAccruals.MemberCount
		,#SchemeAccruals.Rate
		,#SchemeAccruals.ChargeDate
		,0 As IsProcessed
		,#SchemeAccruals.CurrencyId
	FROM #SchemeAccruals WHERE #SchemeAccruals.SecaId > 0 -- /** Bad data from TE48 **/		
END TRY

BEGIN CATCH
	ROLLBACK TRANSACTION T1

	DECLARE @ErrorMessage NVARCHAR(4000);
	DECLARE @ErrorSeverity INT;
	DECLARE @ErrorState INT;

	IF OBJECT_ID(N'tempdb..#ClientAccruals', N'U') IS NOT NULL
	BEGIN
		DROP TABLE #ClientAccruals
	END

	IF OBJECT_ID(N'tempdb..#SchemeAccruals', N'U') IS NOT NULL
	BEGIN
		DROP TABLE #SchemeAccruals
	END

	SELECT @ErrorMessage = ERROR_MESSAGE()
		,@ErrorSeverity = ERROR_SEVERITY()
		,@ErrorState = ERROR_STATE();

	RAISERROR (
			@ErrorMessage
			,@ErrorSeverity
			,@ErrorState
			);
END CATCH;

IF @@TRANCOUNT > 0
BEGIN
	SELECT 'Success' AS Result

	UPDATE dbo.ToBeAppliedFees_ByAccV2 
	SET Applied = 1
		,ProcessedDate = GETDATE()
	WHERE Id IN (
			SELECT ToBeAppliedFeesId
			FROM #ClientAccruals
			)

	INSERT INTO dbo.AppliedFees_ByAccV2 (
		[FeeTranTypesID]
		,[SecaId]
		,[Rate]
		,[ProcessedDate]
		,[DateCreated]
		,[AsAt]
		,[ApplyVAT]
		)
	SELECT ToBeApplied.[FeeTranTypesId]
		,ToBeApplied.[SECAId]
		,ToBeApplied.[Rate]
		,ToBeApplied.[ProcessedDate]
		,ToBeApplied.[DateCreated]
		,ToBeApplied.[AsAt]
		,ToBeApplied.[ApplyVAT]
	FROM dbo.ToBeAppliedFees_ByAccV2 ToBeApplied
	WHERE ToBeApplied.Id IN (
			SELECT Accruals.ToBeAppliedFeesId
			FROM #ClientAccruals Accruals
			)

	DELETE dbo.ToBeAppliedFees_ByAccV2
	WHERE Id IN (
			SELECT ToBeAppliedFeesId
			FROM #ClientAccruals Accruals
			)

	IF OBJECT_ID(N'tempdb..#ClientAccruals', N'U') IS NOT NULL
	BEGIN
		DROP TABLE #ClientAccruals
	END

	IF OBJECT_ID(N'tempdb..#SchemeAccruals', N'U') IS NOT NULL
	BEGIN
		DROP TABLE #SchemeAccruals
	END

	COMMIT TRANSACTION T1
END
GO