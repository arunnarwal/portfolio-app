/***
<StoredProcedure>
  <Description>Gets the data for Barclays Client Data file</Description>
</StoredProcedure>
***/
CREATE PROCEDURE [dbo].[spClientDataFileReportData](@WrapProvider VarChar(20), @From DateTime, @To DateTime) AS
BEGIN
SELECT 
	ccl.ClAccountId As AccountID,
	ah.CustomerId As [CustomerID],
	ccl.DateModified As UpdateTime,
	ccl.ModifiedBy As UserID,
	ah.Given As FirstName,
	ah.Surname As Surname,
	ccl.FieldName As FieldAmended,
	ccl.NewValue As NewValue,
	ccl.OriginalValue As OldValue
FROM dbo.ClientChangeLog ccl
INNER JOIN dbo.AccountHolders ah ON ccl.ClAccountId = ah.ClAccountId
INNER JOIN dbo.SEClientAccount As SECA ON ccl.ClAccountId = SECA.ClAccountId
LEFT JOIN dbo.Advisor As ADV ON ADV.AdvCode = SECA.PrimaryAdviser
LEFT JOIN dbo.Company As CMP ON CMP.Company = ADV.Company
WHERE DateModified between @From and @To and CMP.WrapProvider = @WrapProvider  and ah.CustomerId IS NOT NULL
END
