/***
<StoredProcedure>
    <Description>Permissions clients client fee FUM flags for OMC</Description>
	<Service>Charges</Service>
    <Feature>Tasks</Feature>
    <Parameters>
        <Parameter Name="@AsAt">
            <Description>The date of the fee run</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [dbo].[spApplyFeeFlags_ByAcc_OMC] (@AsAt DATETIME)
AS
/*
declare @AsAt datetime 
set @AsAt = '6-Mar-2013'
*/
IF OBJECT_ID(N'tempdb.dbo.#FeeAccrual', N'U') IS NOT NULL
BEGIN
	DROP TABLE #FeeAccrual
END

DECLARE @TranType VARCHAR(10)

SET @TranType = 'OMC'

CREATE TABLE #FeeAccrual (
	SecaId INT
	,AsAt SMALLDATETIME
	,FeeTranTypesId INT
	,Applies BIT
	,Status_NoteId INT
	,Rate NUMERIC(7, 4)
	,ApplyVat BIT
	)

	/*;
WITH
UKTaxResCounts
As ( 
	SELECT ClAccountId, COUNT(*) As UKCount
		FROM ClientAccount..AccountHolders
	WHERE UKResident = 'Yes' 
	GROUP BY ClAccountId
)*/

INSERT INTO #FeeAccrual
SELECT Fum.SECAId
	,@AsAt AS AsAt
	,FeeTranTypes.Id AS FeeTranTypesId
	,CASE 
		WHEN (isnull(FeeTranTypes.IsAllowed, 0) = 1)
			AND (ModelSchedule.rate > 0)
			AND (Fum.CashAmount + Fum.NonCashAmount) > 0
			AND (isnull(ProductDetails.FullyWithdrawn, 0) = 0)
			THEN 1
		ELSE 0
		END AS Applies
	,CASE 
		WHEN isnull(FeeTranTypes.IsAllowed, 0) = 0
			THEN 1
		WHEN ModelSchedule.rate IS NULL
			THEN 2
		WHEN isnull(ModelSchedule.rate, 0) = 0
			THEN 3
		WHEN (Fum.CashAmount + Fum.NonCashAmount) <= 0
			THEN 4
		WHEN (isnull(ProductDetails.FullyWithdrawn, 0) = 1)
			THEN 5
		ELSE 0
		END AS Status_NoteId
	,ModelSchedule.Rate
	,CASE WHEN ((ISNULL(VATProduct.VATEnabled, 0) = 1) AND (ISNULL(VATFee.VATEnabled, 0) = 1) ) AND Tax.TaxResidency = 'UK'
			THEN 1
		ELSE 0
		END AS ApplyVAT

FROM Cache.dbo.Fee_FUM_ByAccount AS Fum
INNER JOIN dbo.WrapProvider AS WrapProvider
	ON Fum.WrapProviderID = WrapProvider.Id
INNER JOIN dbo.SEClientAccount AS SecaId
	ON Fum.SecaId = SecaId.Id
INNER JOIN dbo.AccountTaxDetails as Tax
	ON SecaId.ID = Tax.SecaId
INNER JOIN Discovery.dbo.ClientAccount AS ClientAccount
	ON SecaId.ClAccountID = ClientAccount.ClAccountID
LEFT JOIN Discovery.dbo.ProductDetails AS ProductDetails
	ON ProductDetails.CLAccountID = SecaId.CLAccountID
INNER JOIN dbo.Advisor AS Advisor
	ON SecaId.PrimaryAdviser = Advisor.AdvCode
INNER JOIN dbo.FeeTranTypes AS FeeTranTypes
	ON FeeTranTypes.TranType IN (@TranType)
		AND FeeTranTypes.WrapProvider = WrapProvider.WrapProvider
CROSS APPLY dbo.fnGetFeeScheduleIdOfModelAccount(SecaId.CLAccountID) AS Schedules
INNER JOIN dbo.vwVATProductTypeByCompany VATProduct
	ON VATProduct.ProductType = ProductDetails.ProductType AND VATProduct.Company = Advisor.Company
INNER JOIN dbo.vwVATFeeByCompany VATFee
	ON VATFee.FeeTranTypeID =  FeeTranTypes.ID AND VATFee.Company = Advisor.Company		
LEFT JOIN dbo.ModelOngoingChargeSchedule AS ModelSchedule
	ON ModelSchedule.FeeScheduleId = Schedules.FeeScheduleId
LEFT JOIN dbo.AppliedFees_ByAccV2 AS Applied
	ON Applied.AsAt = @AsAt
		AND Applied.SecaId = Fum.SecaId
		AND Applied.FeeTranTypesId = FeeTranTypes.Id
WHERE Fum.AsAt = @AsAt
	AND ClientAccount.PortfolioId > 0
	AND Applied.Id IS NULL /*ensures that only non-already-applied fees will be created*/
	AND NOT EXISTS (SELECT 1 FROM dbo.Fee_Fum_ExcludeAccountTypes EXAT 
					WHERE EXAT.WrapProviderID = Fum.WrapProviderID 
					AND EXAT.FeeTranTypeID = FeeTranTypes.ID 
					AND EXAT.AccountType = SecaId.InvestorType)

INSERT INTO dbo.ToBeAppliedFees_ByAccV2 (
	SecaId
	,AsAt
	,FeeTranTypesId
	,Applied
	,Rate
	,ApplyVAT
	)
SELECT FeeAccrual.SECAId
	,FeeAccrual.AsAt
	,FeeAccrual.FeeTranTypesId
	,0 AS Applied
	,FeeAccrual.Rate
	,FeeAccrual.ApplyVat
FROM #FeeAccrual as FeeAccrual
LEFT JOIN dbo.ToBeAppliedFees_ByAccV2 as ToBeApplied
	ON FeeAccrual.SecaId = ToBeApplied.SecaId AND FeeAccrual.AsAt = ToBeApplied.AsAt AND FeeAccrual.FeeTranTypesId = ToBeApplied.FeeTranTypesId
WHERE FeeAccrual.Applies = 1 AND ToBeApplied.SECAID IS NULL

INSERT INTO dbo.NonAppliedFees_ByAccV2 (
	SecaId
	,AsAt
	,FeeTranTypesId
	,Status_NoteId
	)
SELECT FeeAccrual.SECAId
	,FeeAccrual.AsAt
	,FeeAccrual.FeeTranTypesId
	,FeeAccrual.Status_NoteId
FROM #FeeAccrual as FeeAccrual
LEFT JOIN dbo.NonAppliedFees_ByAccV2 as NonApplied
	ON FeeAccrual.SecaId = NonApplied.SecaId  AND FeeAccrual.AsAt = NonApplied.AsAt AND FeeAccrual.FeeTranTypesId = NonApplied.FeeTranTypesId
WHERE FeeAccrual.Applies = 0 AND NonApplied.SecaId IS NULL

IF OBJECT_ID(N'tempdb.dbo.#FeeAccrual', N'U') IS NOT NULL
BEGIN
	DROP TABLE #FeeAccrual
END
GO


