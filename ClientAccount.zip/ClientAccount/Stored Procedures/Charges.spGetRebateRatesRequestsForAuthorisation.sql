/***
<StoredProcedure>
    <Description>Get any pending rebate rates requests for to be authorised</Description>
    <Service>Charges</Service>
    <Feature>Charges</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE Charges.spGetRebateRatesRequestsForAuthorisation
	
AS
BEGIN
	SELECT 
		rbs.RebateRequestId, 
		rbs.InstrumentsID,
		ins.Security as InstrumentCode,
		ins.Descript as InstrumentName, 
		ins.IsinCode,
		rbs.BundledRate,
		rbs.UnbundledRate,
		rbs.TrailRate,
		rbs.FromDate,
		rbs.UserRequested as UserIdRequested,
		tbl.FullName as UserNameRequested
	
	FROM dbo.RebateBySystemProviderRequests rbs
	INNER JOIN Res_db.dbo.Instruments ins on rbs.InstrumentsId = ins.Id
	INNER JOIN ClientDB3.dbo.TblClients tbl on rbs.UserRequested = tbl.ClientId
	Where rbs.Status = 'Pending'	
	
END
GO

