/***
<StoredProcedure>
	<Description>Calculates which project charges require disinvestments
	
	</Description>
	<Parameters>
		<Parameter Name="@AsAt">
			<Description>
			    The effective date to get available cash balance figures for. 
			</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/

CREATE PROCEDURE Charges.spProcessProjectedChargeDisinvestments @AsAt DATETIME

AS
	/*
	DECLARE @AsAt AS DATETIME
	SET @AsAt = '2016-11-30'
	*/

	DECLARE @BatchId AS INT
	DECLARE @CashEntryId AS INT
	DECLARE @ExcludePlatformFundSwitch AS INT

	SET @BatchId = 0
	SET @CashEntryId = NULL
	SET @ExcludePlatformFundSwitch = NULL

	-- Get pending projected arl lines to calc what disinvestment required
	SELECT
		parl.Id,
		parl.CLAccountId,
		parl.TotalAmount,
		SUM(parl.TotalAmount) OVER (PARTITION BY ClAccountId ORDER BY parl.Id) RunningTotal,
		cf.ISOCode AS CCYCode
	INTO #ProjectedCharges
	FROM Discovery.Charges.ProjectedAdvisorRevenueLedger parl
	INNER JOIN Discovery.Charges.ProjectedDisinvestmentStatus pds on pds.ProjectedDisinvestmentStatusId = parl.ProjectedDisinvestmentStatusId
	INNER JOIN Res_Db.dbo.CurrencyFormat cf on cf.Id = parl.CurrencyId
	WHERE pds.Status = 'Pending'

	SELECT DISTINCT CLAccountId
	INTO #ProjectedChargeAccounts
	FROM #ProjectedCharges
		
		
	-- Available cash calcs for projected fee disinvestment
	-- this is extracted from ClientAccount..fnAvailableCashBalancebyCCY_Base as  appears to be the l;atest tuned version
	-- The only changes are removing sections and returned cash columns that are not required and updating the AvailableCash total - there are no logic changes
	-- The only expection to this is the addition of a PROJECTEDFEE section
    SELECT  CLIENTSANDCCY.ClAccountId,
            CLIENTSANDCCY.CCYCode,
            CLIENTSANDCCY.WrapProvider,
            ISNULL(CLT.CLTBalance, 0) AS CLTBalance,
            ISNULL(CMT.CMTBalance, 0) AS CMTBalance,
            ISNULL(CLA.CLABalance, 0) AS CLABalance,
            ISNULL(WD.Withdrawals, 0) AS Withdrawals,
            ISNULL(ORD.SellOrders, 0) AS SellOrders,
            ISNULL(DEAL.BuyDealsInProgress, 0) AS BuyDealsInProgress,
            ISNULL(FEE.FeeExpectations, 0) AS FeeExpectations,
            ISNULL(PROJECTEDFEE.FeeExpectations, 0) AS ProjectedFeeExpectations,
			ISNULL(CLT.CLTbalance, 0) 
				+ ISNULL(CMT.CMTBalance, 0) 
				+ ISNULL(CLA.CLAbalance, 0) 
				- ISNULL(WD.Withdrawals, 0) 
				- ISNULL(DEAL.BuyDealsInProgress, 0) 
				+ ISNULL(ORD.SellOrders, 0)
				- ISNULL(FEE.FeeExpectations, 0)
				- ISNULL(PROJECTEDFEE.FeeExpectations, 0) AS AvailableBalance
	INTO #AvailableCash
    FROM ( 
			SELECT  Q1.ClAccountId,
					GC.CurrencyCode CCYCode,
                    C.WrapProvider
            FROM dbo.ClientDetails Q1
				INNER JOIN #ProjectedChargeAccounts PCA on PCA.ClAccountID = Q1.ClAccountId
				LEFT JOIN dbo.Company C ON Q1.Company = C.Company
                CROSS JOIN dbo.GladCurrency GC

		  ) CLIENTSANDCCY
		
			/* CLT 
				ISNULL(CLT.CLTBalance, 0) AS CLTBalance ,
				AvailableBalance		

				Added: UnsettledCash
			*/
			LEFT JOIN ( SELECT  ClAccountID ,
								CCYCode ,
								-SUM(Amount) AS CLTBalance
						FROM    dbo.CashLedgerTransactions CLT
						WHERE   CLT.LedgerDate <= @AsAt
						GROUP BY ClAccountID ,
								CCYCode
						) CLT ON CLIENTSANDCCY.CLAccountID = CLT.ClAccountID
								AND CLIENTSANDCCY.CCYCode = CLT.CCYCode


			/* CMT 
				ISNULL(CMT.CMTBalance, 0) AS CMTBalance ,
				AvailableBalance
			*/
            LEFT JOIN ( SELECT  CMT.ClAccountID ,
                                CMT.Currency ,
                                SUM(CMT.Amount) AS CMTBalance
                        FROM    dbo.CMTTrans CMT
                        WHERE   CMT.TranDate <= @AsAt
                        GROUP BY CMT.ClAccountID ,
                                CMT.Currency
                      ) CMT ON CMT.CLAccountID = CLIENTSANDCCY.CLAccountID
                               AND CMT.Currency = CLIENTSANDCCY.CCYCode

			/* CLA 
				    ISNULL(CLA.CLABalance, 0) AS CLABalance ,
					ISNULL(CLA.CLAAvailableAdjustBalance, 0) AS CLAAvailableAdjustBalance ,
					ISNULL(CLA.CLAPortfolioAdjustBalance, 0) AS CLAPortfolioAdjustBalance ,
			        ISNULL(CLA.SettlingToday, 0) AS SettlingToday ,
					ISNULL(CLA.UnclearedCheques, 0) AS UnclearedCheques 
					AvailableBalance
			*/
            LEFT JOIN ( SELECT  cla.ClAccountID ,
                                cla.CCYCode ,
                                -SUM(CASE WHEN cla.AdjustmentType <> 'UNCLEARED_CHEQUE' THEN cla.Amount ELSE 0 END) AS CLABalance
                        FROM    dbo.CashLedgerAdjustments cla
						/* 
							added AwOrderID <> 0 and OrderBuySell = 'Sell' 
							- attempt to prevent joining to things that don't need this data.

							Would almost consider splitting off SettlingToday so all the other CLA 
							doesn't risk this
						*/
                        LEFT JOIN Discovery.dbo.OrderCurrent oc 
							ON oc.OrderID = cla.AWOrderID 
							AND oc.OrderBuySell = 'Sell'
							AND cla.AWOrderID <> 0

                        WHERE   cla.LedgerDate <= @AsAt
                        GROUP BY cla.ClAccountID ,
                                cla.CCYCode
                      ) CLA ON CLA.ClAccountID = CLIENTSANDCCY.CLAccountID
                               AND CLA.CCYCode = CLIENTSANDCCY.CCYCode


			/*
				CE
				  ISNULL(WD.Withdrawals, 0) AS Withdrawals ,
				  AvailableBalance
			*/
            LEFT JOIN ( SELECT  CE.ClAccountID ,
                                CE.Currency ,
                                SUM(CE.Amount) AS Withdrawals
                        FROM    Discovery.dbo.CashEntry CE
                                INNER JOIN Discovery.dbo.Batch B ON B.BatchID = CE.BatchID

								/*  This table doesn't seem to introduce the same problems OrderStatus does
									But is worth long term consideration.
								 */
                                INNER JOIN Discovery.dbo.CashEntryStatus S ON S.[Status] = CE.[Status]
                        WHERE   CE.[Type] = 'Withdrawal'
                                AND B.BatchType IN ( 'Auto', 'One-Off' )
                                AND S.[Open] = 1

                                AND ( B.StandingNextCashDate <= @AsAt OR B.StandingNextCashDate IS NULL )
                                AND ( @CashEntryId IS NULL OR CE.ID <> @CashEntryId )

						/* This part is to exclude the Next Tax Year ISA from displaying in front office until matched */
						/* changed this from NOT IN to NOT EXISTS */
                                AND NOT EXISTS (
									SELECT  CE.ID
									FROM     Discovery.dbo.LinkedCashEntryMappings LCEM 
									WHERE   CE.[Status] = 'Confirmed'
											AND CE.[Type] = 'Withdrawal'
											AND CE.Method = 'Internal Transfer' 
											AND CE.ID = LCEM.LinkedCashEntryId
										)
                        GROUP BY CE.ClAccountID ,
                                CE.Currency
                      ) WD 
					ON WD.ClAccountID = CLIENTSANDCCY.CLAccountID
                    AND WD.Currency = CLIENTSANDCCY.CCYCode




			/* 
				OC
					ISNULL(BUYORD.BuyOrders, 0) AS BuyOrders ,
			        ISNULL(BUYORD.BuyOrdersExComm, 0) AS BuyOrdersExComm ,
					AvailableBalance

					This used to just be BuyOrders but merged buy/sells together since I don't want to scan that portion of data twice
					Moved these in:
						ISNULL(SELLORD.SellOrders, 0) AS SellOrders ,
						ISNULL(SELLORD.SwitchSellOrders, 0) AS SwitchSellOrders
						AvailableBalance

			*/
            LEFT JOIN ( SELECT  OC.ClAccountID ,
                                OC.OrderSettCurrency ,
								SUM(ABS(CASE WHEN OC.OrderBuySell = 'Sell' AND OC.SwitchID IS NULL THEN OC.DisplayValue ELSE 0 END)) AS SellOrders

                        FROM    Discovery.dbo.OrderCurrent OC
                                INNER JOIN Discovery.dbo.Batch B ON B.BatchID = OC.BatchID

								INNER JOIN res_db.dbo.Instruments Inst ON Inst.[Security] = OC.InstrumentCode
                        WHERE   							
								B.BatchType IN ( 'Auto', 'One-Off' )
                                AND B.BatchID != @BatchId
                                
								/* just like adding the extra line since it clearly shows everything factored into this query */
								AND OC.Status IN ('Authorised','AuthorisedSwitch','Confirmed','Placed','Pooled','Processing', 'Completed' )
								AND ( --S.[Open] = 1
									  OC.Status IN ('Authorised','AuthorisedSwitch','Confirmed','Placed','Pooled','Processing' )
                                      
									  /*  This is why the OrderCurrent ClAccountID index was modified to include these columns 1000-4000 logical IO difference from this */
									  OR ( OC.[Status] = 'Completed'
                                           AND OC.SettlementStatus NOT IN ( 'Completed', 'NotRequired' )
                                         )
                                    )

                                --AND CE.BatchID IS NULL
								-- the cashEntry check doesn't apply to Sells
								AND NOT EXISTS ( SELECT 1 FROM Discovery.dbo.CashEntry CE WHERE OC.BatchID = CE.BatchID AND OC.OrderBuySell = 'Buy' )
								AND NOT EXISTS (
									SELECT 1 FROM Res_Db.dbo.ManagedFunds M 
									WHERE M.InstrumentCode = OC.InstrumentCode
									AND M.InsuredFund = 1
								)

								-- but ignore switches, conversions and insured fund
								-- Really don't know why the switchID part doesn't apply to sells, but leaving as is.
                                AND (OC.SwitchID IS NULL OR OC.OrderBuySell = 'Sell')
                                AND OC.ConversionID IS NULL


								/* not a fan of this, but tried restructuring as a NOT EXISTS
									and had detrimental affects to performance.
									
									This bit should only apply to Buys
								*/
                                AND ( 
									  OC.OrderBuySell = 'Sell'
									  /* The compare against 0 was never in here, so meant if you explicitly stated no override
										they got excluded.  Written this way to avoid the test since i'm ok with it in this case
										BUT don't want the whole file excluded from the test.
									  */
				
									  OR NULLIF(@ExcludePlatformFundSwitch, 0) IS NULL
                                      OR ( @ExcludePlatformFundSwitch = 1
                                           AND ( Inst.SecurityType <> 'Platform fund'
                                                 OR ( Inst.SecurityType = 'Platform fund'
                                                      AND Inst.SecuritySubType = 'Platform fund'
                                                      AND OC.SwitchID IS NULL
                                                    )
                                               )
                                         )
                                    )
                        GROUP BY OC.ClAccountID ,
                                OC.OrderSettCurrency
                      ) ORD 
					ON ORD.ClAccountID = CLIENTSANDCCY.CLAccountID
                    AND ORD.OrderSettCurrency = CLIENTSANDCCY.CCYCode

			/*
				OC
			        ISNULL(DEAL.DealsInProgress, 0) AS DealsInProgress ,
					ISNULL(DEAL.SellDealsInProgress, 0) AS SellDealsInProgress ,
					ISNULL(DEAL.BuyDealsInProgress, 0) AS BuyDealsInProgress ,

					Can't merge these back into Ords
					It has 
						AND NOT EXISTS (
									SELECT 1 FROM Discovery.dbo.CashEntry CE WHERE OC.BatchID = CE.BatchID
								)
					Which complicates doing that.
			*/
            LEFT JOIN ( SELECT  OC.ClAccountID ,
                                OC.OrderSettCurrency ,
                                SUM(CASE WHEN OC.OrderBuySell = 'Buy'
                                         THEN OC.DisplayValue
                                         ELSE 0
                                    END) AS BuyDealsInProgress

						FROM (

							/* both sides of the union all are similar - the only differences are:
									Top one deals with
									AND OC.Status IN ( 'Placed', 'Pooled', 'Authorised')--, 'Completed' )
									
									the bottom with
									AND OC.Status = 'Completed'
				

									The work the optimizer was doing made this split necessary since it was looking up 
									data based on status a bit differently (considerably more Completed than other status'
									so the statistiscal difference there made an impact.
							*/
							SELECT 
								OC.ClAccountID ,
								OC.OrderSettCurrency ,
								OC.OrderBuySell,
								OC.Status,
								OC.DisplayValue,
								Inst.SecuritySubType,
								Inst.Sec_Type
							FROM    Discovery.dbo.OrderCurrent OC
									INNER JOIN Discovery.dbo.Batch B ON B.BatchID = OC.BatchID
									INNER JOIN res_db.dbo.Instruments Inst ON Inst.[Security] = OC.InstrumentCode
							WHERE   B.BatchType IN ( 'Auto', 'One-Off' )
									AND B.BatchID <> @BatchId
									AND OC.Status IN ( 'Placed', 'Pooled', 'Authorised')
									AND ( ( --S.[InProgress] = 1
											OC.Status IN ( 'Placed', 'Pooled' )
											OR ( OC.Status = 'Authorised'
												 AND OC.PoolOrderID IS NOT NULL
											   )
										  )
									)
								-- but ignore switches, conversionsa and insured fund
									AND NOT EXISTS (
										SELECT 1 FROM res_db.dbo.ManagedFunds M 
										WHERE M.InstrumentCode = OC.InstrumentCode
										AND M.InsuredFund = 1
									)
									AND OC.SwitchID IS NULL
									AND OC.ConversionID IS NULL

							UNION ALL


							SELECT 
								OC.ClAccountID ,
								OC.OrderSettCurrency ,
								OC.OrderBuySell,
								OC.Status,
								OC.DisplayValue,
								Inst.SecuritySubType,
								Inst.Sec_Type
							FROM    Discovery.dbo.OrderCurrent OC
									INNER JOIN Discovery.dbo.Batch B ON B.BatchID = OC.BatchID
									INNER JOIN Res_db.dbo.Instruments Inst ON Inst.[Security] = OC.InstrumentCode
							WHERE   B.BatchType IN ( 'Auto', 'One-Off' )
									AND B.BatchID <> @BatchId
									AND (  ( OC.Status = 'Completed'
											   AND OC.SettlementStatus NOT IN ( 'Completed', 'NotRequired' )
											 )
										)
							-- but ignore switches, conversionsa and insured fund
									AND NOT EXISTS (
										SELECT 1 FROM res_db.dbo.ManagedFunds M 
										WHERE M.InstrumentCode = OC.InstrumentCode
										AND M.InsuredFund = 1
									)
									AND OC.SwitchID IS NULL
									AND OC.ConversionID IS NULL
							) OC

                        GROUP BY OC.ClAccountID ,
                                OC.OrderSettCurrency
                      ) DEAL ON DEAL.ClAccountID = CLIENTSANDCCY.CLAccountID
                                AND DEAL.OrderSettCurrency = CLIENTSANDCCY.CCYCode


			/*
				ARL
		            ISNULL(FEE.FeeExpectations, 0) AS FeeExpectations ,
		            ISNULL(FEE.FutureDatedFeeExpectations, 0) AS FutureDatedFeeExpectations ,
		            ISNULL(FEE.UnsettledCashPostedFees, 0) AS UnsettledCashPostedFees ,
			*/
            LEFT JOIN ( SELECT 
							   T.ClAccountID ,
							   T.CCYCode AS CCYCode ,
							   SUM(UnsettledCashPostedFees) AS UnsettledCashPostedFees,
							   SUM(FeeExpectations) AS FeeExpectations
						FROM (	SELECT  
									    ARL.ClAccountID ,
									    CF.ISOCode AS CCYCode ,
									    OC.OrderID ,
										CASE 
											WHEN ARL.AsAt <= @AsAt 
													AND OC.OrderBuySell = 'SELL' 
													AND EXISTS(SELECT 1
															FROM dbo.Trades TR
															WHERE TR.OrderID = OC.OrderID
																AND TR.Status = 'Booked')
											THEN ARL.TotalAmount
											ELSE 0
										END AS UnsettledCashPostedFees,
										CASE 
											WHEN ARL.AsAt <= @AsAt 
													AND ARL.GLPosted = 'NO' 
											THEN ARL.TotalAmount
											ELSE 0
										END AS FeeExpectations
								FROM Discovery.dbo.AdvisorRevenueLedger ARL
									 LEFT JOIN dbo.ClientDetails CD ON ARL.ClAccountID = CD.ClAccountID
									 LEFT JOIN dbo.Company CO ON CD.Company = CO.Company
									 LEFT JOIN dbo.FeeTranTypes FTT ON ARL.TranType = FTT.TranType AND FTT.WrapProvider = CO.WrapProvider
									 LEFT JOIN Discovery.dbo.OrderCurrent OC ON OC.OrderID = ARL.OrderID
									 INNER JOIN res_db.dbo.CurrencyFormat CF ON CF.ID = ARL.CurrencyId
								WHERE
									 ISNULL(ARL.Reversed, 0) <> 1
									 AND ( ARL.PendingAdvisorPost = 'YES'
										  OR FTT.IncludeUnauthorisedFeesInAvailCash = 1
									 )
									 AND ARL.AdvisorPostMethod <> 'DLT'
									 AND ARL.TranType NOT IN ( 'Advisor FBRC Charge', 'LS Introducer Commission', 'RIC Charge' )
									 AND FTT.ExcludeAuthorisedFeesInAvailableCash <> 1

									 /* next three statements replaced with not exists */
									 AND ( OC.OrderID IS NULL
										  OR OC.[Status] = 'Completed'
									 )
									 /* doing these this way prevent a multiplication of stats 1:m OC, 1:M CashEntry 1:M2 (really big number) */
									 AND NOT EXISTS ( 
													  SELECT 1
									 				  FROM   Discovery.dbo.Batch B
													  WHERE  B.BatchID = ARL.BatchID
															 AND B.BatchType = 'Standing' 
													)
									 AND NOT EXISTS ( 
													  SELECT 1
													  FROM   Discovery.dbo.CashEntry CE
													  WHERE  CE.BatchID = ARL.BatchID
															 AND CE.InstructionType = 'Standing' 
													)

									 AND ARL.ClAccountID IS NOT NULL
								)T
								GROUP BY T.ClAccountID, T.CCYCode

                      ) FEE ON FEE.ClAccountID = CLIENTSANDCCY.CLAccountID
					  /* this was missing which meant i didn't get a match up of 1:1 and ALWAYS looked this up; even if I didn't need it */
					  AND FEE.CCYCode = CLIENTSANDCCY.CCYCode

			LEFT JOIN ( SELECT
							PC.ClAccountID,
							PC.CCYCode,
							SUM(PC.TotalAmount) AS FeeExpectations
						FROM ( SELECT 
										PARL.ClAccountID,
										CF.ISOCode AS CCYCode,
										PARL.TotalAmount
								FROM Discovery.Charges.ProjectedAdvisorRevenueLedger PARL
									INNER JOIN Res_DB.dbo.CurrencyFormat CF ON CF.ID = PARL.CurrencyId
									INNER JOIN Discovery.Charges.ProjectedDisinvestmentStatus PDS ON PDS.ProjectedDisinvestmentStatusId = PARL.ProjectedDisinvestmentStatusId
								WHERE  PARL.ChargeDate > @AsAt
								AND PDS.STATUS <> 'Pending'
						) PC
						GROUP BY PC.ClAccountID, PC.CCYCode
					) PROJECTEDFEE ON PROJECTEDFEE.ClAccountID = CLIENTSANDCCY.ClAccountID AND PROJECTEDFEE.Ccycode = CLIENTSANDCCY.Ccycode
					
	CREATE UNIQUE CLUSTERED INDEX idx_availablecash ON #AvailableCash (ClAccountID, Ccycode)

	
	-- Genrated FeeDisinvestment lines if running total > available cash
	INSERT INTO dbo.FeeDisinvestment
		(ClAccountID,AmountRequired,CCYCode,DateAdded,AlertSent,ProjectedFeeId)
	SELECT
		pc.CLAccountId,
		pc.TotalAmount,
		pc.CCYCode,
		GetDate(),
		0,
		pc.Id
	FROM #ProjectedCharges pc
	INNER JOIN #AvailableCash ac ON ac.CLAccountId = pc.ClAccountId AND ac.CCYCode = pc.CCYCode
	WHERE pc.RunningTotal > ac.AvailableBalance
		
	DECLARE @ProcessedStatusId INT
	SELECT @ProcessedStatusId = ProjectedDisinvestmentStatusId FROM Discovery.Charges.ProjectedDisinvestmentStatus WHERE Status = 'Processed'
		
	-- update projected arl lines to Processed
	UPDATE parl
	SET
		parl.ProjectedDisinvestmentStatusId = @ProcessedStatusId
	FROM Discovery.Charges.ProjectedAdvisorRevenueLedger parl
	INNER JOIN Discovery.Charges.ProjectedDisinvestmentStatus pds on pds.ProjectedDisinvestmentStatusId = parl.ProjectedDisinvestmentStatusId
	INNER JOIN Res_Db.dbo.CurrencyFormat cf on cf.Id = parl.CurrencyId
	WHERE pds.Status = 'Pending'
			
	DROP TABLE #ProjectedCharges
	DROP TABLE #ProjectedChargeAccounts
	DROP TABLE #AvailableCash	
GO