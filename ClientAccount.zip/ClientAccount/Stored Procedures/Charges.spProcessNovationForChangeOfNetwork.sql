/***
<StoredProcedure>
    <Description>Process novation for change of network wizard</Description>
	<Parameters>
		<Parameter Name="@Network">
			<Description>The target network</Description>
		</Parameter>
		<Parameter Name="@CompanyCode">
			<Description>The company adv is moving into</Description>
		</Parameter>
		<Parameter Name="@UserId">
			<Description>user who requests move adviser process</Description>
		</Parameter>
	</Parameters>	
</StoredProcedure>
***/
CREATE PROCEDURE Charges.spProcessNovationForChangeOfNetwork
(
    @Network VARCHAR(50),
    @CompanyCode VARCHAR(20),
    @UserId INT
)
AS
--DECLARE     @Network VARCHAR(50)='PLNW01654',
--    @CompanyCode VARCHAR(20)='PLAR09420',
--    @UserId INT=8245
DECLARE @NetworkHierarchyLevelId TINYINT,
        @NetworkId INT,
		@SubAccountHierarchyLevelId TINYINT;

SELECT @NetworkId = N.Id
FROM dbo.Network N
WHERE N.Network = @Network;

SELECT @NetworkHierarchyLevelId = HierarchyLevelNameId
FROM Platform.HierarchyEntities.HierarchyLevelNames
WHERE HierarchyLevelName = 'Network';

SELECT @SubAccountHierarchyLevelId = HierarchyLevelNameId
FROM Platform.HierarchyEntities.HierarchyLevelNames
WHERE HierarchyLevelName = 'SubAccount';

CREATE TABLE #TierStructureOwnedByTargetNetwork
(
    TierStructureId INT,
    Name VARCHAR(70)
);
--insert network level
INSERT INTO #TierStructureOwnedByTargetNetwork
(
    TierStructureId,
    Name
)
SELECT TS.TierStructureId,
       TS.TierStructureName
FROM Charges.TierStructures TS
    INNER JOIN Platform.HierarchyEntities.HierarchyLevelNames HL
        ON HL.HierarchyLevelNameId = TS.OwnerHierarchyLevelNameId
WHERE TS.OwnerEntityId = @NetworkId
AND HL.HierarchyLevelName='Network';

--insert company level
INSERT INTO #TierStructureOwnedByTargetNetwork
(
    TierStructureId,
    Name
)
SELECT TS.TierStructureId,
       TS.TierStructureName
FROM Charges.TierStructures TS
    INNER JOIN Platform.HierarchyEntities.HierarchyLevelNames HL
        ON HL.HierarchyLevelNameId = TS.OwnerHierarchyLevelNameId
WHERE HL.HierarchyLevelName = 'Company'
      AND EXISTS
(
    SELECT 1
    FROM dbo.Network N
        INNER JOIN dbo.Company C
            ON C.Network = N.Network
    WHERE N.Id = @NetworkId
          AND TS.OwnerEntityId = C.Id
)
      AND NOT EXISTS
(
    SELECT 1
    FROM #TierStructureOwnedByTargetNetwork T
    WHERE T.TierStructureId = TS.TierStructureId
);

--insert tier structures owned by @CompanyCode itself, as they will moving to target network with the firm
INSERT INTO #TierStructureOwnedByTargetNetwork
(
    TierStructureId,
    Name
)
SELECT TS.TierStructureId,
       TS.TierStructureName
FROM Charges.TierStructures TS
    INNER JOIN Platform.HierarchyEntities.HierarchyLevelNames HL
        ON HL.HierarchyLevelNameId = TS.OwnerHierarchyLevelNameId
		INNER JOIN dbo.Company C ON C.ID=TS.OwnerEntityId
WHERE HL.HierarchyLevelName = 'Company'
      AND C.Company=@CompanyCode
      AND NOT EXISTS
(
    SELECT 1
    FROM #TierStructureOwnedByTargetNetwork T
    WHERE T.TierStructureId = TS.TierStructureId
);

--insert Branch level
INSERT INTO #TierStructureOwnedByTargetNetwork
(
    TierStructureId,
    Name
)
SELECT TS.TierStructureId,
       TS.TierStructureName
FROM Charges.TierStructures TS
    INNER JOIN Platform.HierarchyEntities.HierarchyLevelNames HL
        ON HL.HierarchyLevelNameId = TS.OwnerHierarchyLevelNameId
WHERE HL.HierarchyLevelName = 'Branch'
      AND EXISTS
(
    SELECT 1
    FROM dbo.Network N
        INNER JOIN dbo.Company C
            ON C.Network = N.Network
			INNER JOIN dbo.Branches B ON B.Company = C.Company
    WHERE N.Id = @NetworkId
          AND TS.OwnerEntityId = B.Id
)
      AND NOT EXISTS
(
    SELECT 1
    FROM #TierStructureOwnedByTargetNetwork T
    WHERE T.TierStructureId = TS.TierStructureId
);

--insert tier structures owned by branchs under @CompanyCode itself, as they will moving to target network with the firm
INSERT INTO #TierStructureOwnedByTargetNetwork
(
    TierStructureId,
    Name
)
SELECT TS.TierStructureId,
       TS.TierStructureName
FROM Charges.TierStructures TS
    INNER JOIN Platform.HierarchyEntities.HierarchyLevelNames HL
        ON HL.HierarchyLevelNameId = TS.OwnerHierarchyLevelNameId
		INNER JOIN dbo.Branches B ON b.Id=TS.OwnerEntityId
		INNER JOIN dbo.Company C ON C.Company=b.Company
WHERE HL.HierarchyLevelName = 'Branch'
      AND C.Company=@CompanyCode
      AND NOT EXISTS
(
    SELECT 1
    FROM #TierStructureOwnedByTargetNetwork T
    WHERE T.TierStructureId = TS.TierStructureId
);

--insert Adviser level
INSERT INTO #TierStructureOwnedByTargetNetwork
(
    TierStructureId,
    Name
)
SELECT TS.TierStructureId,
       TS.TierStructureName
FROM Charges.TierStructures TS
    INNER JOIN Platform.HierarchyEntities.HierarchyLevelNames HL
        ON HL.HierarchyLevelNameId = TS.OwnerHierarchyLevelNameId
WHERE HL.HierarchyLevelName = 'Advisor'
      AND EXISTS
(
    SELECT 1
    FROM dbo.Network N
        INNER JOIN dbo.Company C
            ON C.Network = N.Network
			INNER JOIN dbo.Advisor A ON A.Company = C.Company
    WHERE N.Id = @NetworkId
          AND TS.OwnerEntityId = A.Id
)
      AND NOT EXISTS
(
    SELECT 1
    FROM #TierStructureOwnedByTargetNetwork T
    WHERE T.TierStructureId = TS.TierStructureId
);

--insert tier structures owned by adv under @CompanyCode itself, as they will moving to target network with the firm
INSERT INTO #TierStructureOwnedByTargetNetwork
(
    TierStructureId,
    Name
)
SELECT TS.TierStructureId,
       TS.TierStructureName
FROM Charges.TierStructures TS
    INNER JOIN Platform.HierarchyEntities.HierarchyLevelNames HL
        ON HL.HierarchyLevelNameId = TS.OwnerHierarchyLevelNameId
		INNER JOIN dbo.Advisor A ON A.Id=TS.OwnerEntityId
		INNER JOIN dbo.Company C ON C.Company=A.Company
WHERE HL.HierarchyLevelName = 'Advisor'
      AND C.Company=@CompanyCode
      AND NOT EXISTS
(
    SELECT 1
    FROM #TierStructureOwnedByTargetNetwork T
    WHERE T.TierStructureId = TS.TierStructureId
);

--insert subAccount level
INSERT INTO #TierStructureOwnedByTargetNetwork
(
    TierStructureId,
    Name
)
SELECT TS.TierStructureId,
       TS.TierStructureName
FROM Charges.TierStructures TS
    INNER JOIN Platform.HierarchyEntities.HierarchyLevelNames HL
        ON HL.HierarchyLevelNameId = TS.OwnerHierarchyLevelNameId
WHERE HL.HierarchyLevelName = 'SubAccount'
      AND EXISTS
(
    SELECT 1
    FROM dbo.Network N
        INNER JOIN dbo.Company C
            ON C.Network = N.Network
			INNER JOIN dbo.Advisor A ON A.Company = C.Company
			INNER JOIN dbo.SEClientAccount SEA ON SEA.PrimaryAdviser=A.AdvCode
			INNER JOIN Discovery.dbo.ClientAccount CA ON CA.CLAccountId = SEA.ClAccountId
    WHERE N.Id = @NetworkId
          AND TS.OwnerEntityId =SEA.Id AND CA.DPSAccountType = 'Sub-Account'
)
      AND NOT EXISTS
(
    SELECT 1
    FROM #TierStructureOwnedByTargetNetwork T
    WHERE T.TierStructureId = TS.TierStructureId
);

--Remove permission of old network/firm/branch from target firm and underlying branch/adv ,except permission of tier structure owned by target firm and underlying branch/adv

DELETE TSP
FROM Charges.TierStructurePermissions TSP
    INNER JOIN dbo.Advisor A
        ON TSP.EntityId = A.ID
    INNER JOIN dbo.Company C
        ON C.Company = A.Company
    INNER JOIN Platform.HierarchyEntities.HierarchyLevelNames HLN
        ON HLN.HierarchyLevelNameId = TSP.HierarchyLevelNameId
    INNER JOIN Charges.TierStructures TS
        ON TS.TierStructureId = TSP.TierStructureId
WHERE HLN.HierarchyLevelName = 'Advisor'
      AND C.Company = @CompanyCode
      AND
      (
          TS.OwnerEntityId <> A.ID
          OR TS.OwnerHierarchyLevelNameId <> HLN.HierarchyLevelNameId
      );

DELETE TSP
FROM Charges.TierStructurePermissions TSP
    INNER JOIN dbo.Branches B
        ON TSP.EntityId = B.Id
    INNER JOIN dbo.Company C
        ON C.Company = B.Company
    INNER JOIN Platform.HierarchyEntities.HierarchyLevelNames HLN
        ON HLN.HierarchyLevelNameId = TSP.HierarchyLevelNameId
    INNER JOIN Charges.TierStructures TS
        ON TS.TierStructureId = TSP.TierStructureId
WHERE HLN.HierarchyLevelName = 'Branch'
      AND C.Company = @CompanyCode
      AND
      (
          TS.OwnerEntityId <> B.Id
          OR TS.OwnerHierarchyLevelNameId <> HLN.HierarchyLevelNameId
      );

DELETE TSP
FROM Charges.TierStructurePermissions TSP
    INNER JOIN dbo.Company C
        ON C.ID = TSP.EntityId
    INNER JOIN Platform.HierarchyEntities.HierarchyLevelNames HLN
        ON HLN.HierarchyLevelNameId = TSP.HierarchyLevelNameId
    INNER JOIN Charges.TierStructures TS
        ON TS.TierStructureId = TSP.TierStructureId
WHERE HLN.HierarchyLevelName = 'Company'
      AND C.Company = @CompanyCode
      AND
      (
          TS.OwnerEntityId <> C.ID
          OR TS.OwnerHierarchyLevelNameId <> HLN.HierarchyLevelNameId
      );

CREATE TABLE #ClAccountsUnderAdviserWithTierStructureId
(
    ClAccountId VARCHAR(20),
    ClientFBRCSettingsId INT,
    TierStructureId INT
);

INSERT INTO #ClAccountsUnderAdviserWithTierStructureId
(
    ClAccountId,
    ClientFBRCSettingsId,
    TierStructureId
)
SELECT SCA.ClAccountId,
       CFS.Id AS ClientFBRCSettingsId,
       CFS.TierStructureId
FROM dbo.SEClientAccount SCA
    INNER JOIN dbo.ClientFBRCSettings CFS
        ON CFS.ClAccountId = SCA.ClAccountId
    INNER JOIN dbo.Advisor A
        ON SCA.PrimaryAdviser = A.AdvCode
    INNER JOIN dbo.Company C
        ON C.Company = A.Company
WHERE C.Company = @CompanyCode
      AND CFS.TierStructureId IS NOT NULL
      AND CFS.TierStructureId > 0
      AND CFS.Active = 1
      AND NOT EXISTS
(
    SELECT 1
    FROM Charges.TierStructureNovationLogs TSNL
    WHERE TSNL.ClAccountId = SCA.ClAccountId
          AND TSNL.OriginTierStructureId = CFS.TierStructureId
);

CREATE NONCLUSTERED INDEX IdX_ClientFBRCSettingsIdTierStructureId
ON #ClAccountsUnderAdviserWithTierStructureId (
                                                  ClientFBRCSettingsId,
                                                  TierStructureId
                                              );


CREATE TABLE #TierStructures
(
    OldTierStructureId INT,
    OldTierStructureName VARCHAR(70),
    NewTierStructureId INT,
    NewTierStructureName VARCHAR(70),
	ClAccountId VARCHAR(20)
);

INSERT INTO #TierStructures
(
    OldTierStructureId,
    OldTierStructureName,
    NewTierStructureId,
    NewTierStructureName,
	ClAccountId
)
SELECT DISTINCT
       TS.TierStructureId AS OldTierStructureId,
       TS.TierStructureName AS OldTierStructureName,
	   NULL,
       CASE
           WHEN NOT EXISTS
                    (
                        SELECT 1
                        FROM #TierStructureOwnedByTargetNetwork TS1
                        WHERE TS1.Name = TS.TierStructureName
                    ) THEN
               TS.TierStructureName
           ELSE
       (
           SELECT CONCAT(TS.TierStructureName, '-', COUNT(1) + 1)
           FROM #TierStructureOwnedByTargetNetwork TS2
           WHERE TS2.Name LIKE CONCAT(TS.TierStructureName, '-%')
       )
       END AS NewTierStructureName,
	   T.ClAccountId
FROM #ClAccountsUnderAdviserWithTierStructureId T
    INNER JOIN Charges.TierStructures TS
        ON TS.TierStructureId = T.TierStructureId;

CREATE NONCLUSTERED INDEX IdX_NewTierStructureName
ON #TierStructures (NewTierStructureName);

CREATE TABLE #NewTierStructureDetails
(
    TierStructureId INT,
    TierStructureName VARCHAR(70),
	ClAccountId VARCHAR(20)
);

--duplicate tier structure 
INSERT INTO Charges.TierStructures
(
    TierStructureName,
    OwnerHierarchyLevelNameId,
    OwnerEntityId,
    CreatedBy,
    DateTimeCreated
)
OUTPUT INSERTED.TierStructureId,
       INSERTED.TierStructureName,
	   NULL
INTO #NewTierStructureDetails
SELECT DISTINCT TS.NewTierStructureName,
       @NetworkHierarchyLevelId,
       @NetworkId,
       @UserId,
       GETDATE()
FROM #TierStructures TS
    INNER JOIN Charges.TierStructures TS1
        ON TS1.TierStructureId = TS.OldTierStructureId
WHERE NOT EXISTS
(
    SELECT 1
    FROM Charges.TierStructures TS2
    WHERE TS2.OwnerEntityId = @NetworkId
          AND TS2.OwnerHierarchyLevelNameId = @NetworkHierarchyLevelId
          AND TS2.TierStructureName = TS.NewTierStructureName
);
CREATE NONCLUSTERED INDEX IdX_TierStructureNameClAccountId 
ON #NewTierStructureDetails (TierStructureName,ClAccountId );

-- add tier details into new tier structure
INSERT INTO Charges.TierStructureTiers
(
    TierStructureId,
    TierBoundaryId,
    Rate
)
SELECT NTSD.TierStructureId,tst.TierBoundaryId,TST.Rate FROM 
#NewTierStructureDetails NTSD 
INNER JOIN #TierStructures TS ON TS.NewTierStructureName=NTSD.TierStructureName
INNER JOIN Charges.TierStructureTiers TST ON TST.TierStructureId = TS.OldTierStructureId;

-- de-active current seeting 
UPDATE CFS
SET CFS.Active = 0
FROM dbo.ClientFBRCSettings CFS
WHERE EXISTS
(
    SELECT 1
    FROM #ClAccountsUnderAdviserWithTierStructureId Temp
        INNER JOIN #TierStructures TS
            ON Temp.TierStructureId = TS.OldTierStructureId
    WHERE Temp.ClientFBRCSettingsId = CFS.Id
);

-- add active setting 
INSERT INTO dbo.ClientFBRCSettings
(
    ClAccountId,
    FBRCRate,
    UseFundFBRCRate,
    AsAt,
    DateAdded,
    UserAddedBy,
    CallerSource,
    SessionId,
    Note,
    FBRCAmount,
    Active,
    ActivationDate,
    plannerservicefeetype,
    DateAuthorised,
    UserAuthorised,
    DateRejected,
    UserRejected,
    AdviceGiven,
    ACARequiredToActivate,
    AdviceType,
    Accrue,
    PostToOldAdviserOnCOA,
    TierStructureId
)
SELECT CFS.ClAccountId,
       CFS.FBRCRate,
       CFS.UseFundFBRCRate,
       GETDATE(),
       GETDATE(),
       @UserId,
       'Tier Structure Novation For Change Of Network',
       CFS.SessionId,
       CFS.Note,
       CFS.FBRCAmount,
       1,
       GETDATE(),
       CFS.plannerservicefeetype,
       CFS.DateAuthorised,
       CFS.UserAuthorised,
       CFS.DateRejected,
       CFS.UserRejected,
       CFS.AdviceGiven,
       CFS.ACARequiredToActivate,
       CFS.AdviceType,
       CFS.Accrue,
       CFS.PostToOldAdviserOnCOA,
       NTSD.TierStructureId
FROM dbo.ClientFBRCSettings CFS
    INNER JOIN #ClAccountsUnderAdviserWithTierStructureId Temp
        ON Temp.ClientFBRCSettingsId = CFS.Id
    INNER JOIN #TierStructures TS
        ON Temp.TierStructureId = TS.OldTierStructureId
    INNER JOIN #NewTierStructureDetails NTSD
        ON TS.NewTierStructureName = NTSD.TierStructureName;
--Add subAccount level permission 
INSERT INTO Charges.TierStructurePermissions
(
    TierStructureId,
    HierarchyLevelNameId,
    EntityId
)
SELECT NTSD.TierStructureId,
       @SubAccountHierarchyLevelId,
       SEA.Id
FROM #NewTierStructureDetails NTSD
    INNER JOIN #TierStructures TS
        ON TS.NewTierStructureName = NTSD.TierStructureName
    INNER JOIN dbo.SEClientAccount SEA
        ON SEA.ClAccountId = TS.ClAccountId
WHERE NOT EXISTS
(
    SELECT 1
    FROM Charges.TierStructurePermissions TSP
    WHERE TSP.TierStructureId = NTSD.TierStructureId
          AND TSP.HierarchyLevelNameId = @SubAccountHierarchyLevelId
          AND TSP.EntityId = SEA.Id
);

--write log

INSERT INTO Charges.TierStructureNovationLogs
(
    ClAccountId,
    OriginTierStructureId,
    NovatedTierStructureId,
    AuditBy,
    LogDateTime
)
SELECT Temp.ClAccountId,
       TS.OldTierStructureId,
       NTSD.TierStructureId,
       @UserId,
       GETDATE()
FROM #ClAccountsUnderAdviserWithTierStructureId Temp
    INNER JOIN #TierStructures TS
        ON Temp.TierStructureId = TS.OldTierStructureId
    INNER JOIN #NewTierStructureDetails NTSD
        ON TS.NewTierStructureName = NTSD.TierStructureName;

DROP TABLE #ClAccountsUnderAdviserWithTierStructureId;
DROP TABLE #TierStructures;
DROP TABLE #NewTierStructureDetails;
DROP TABLE #TierStructureOwnedByTargetNetwork;