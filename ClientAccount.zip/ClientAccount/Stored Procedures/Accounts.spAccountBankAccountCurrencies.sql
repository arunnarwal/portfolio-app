/***
<StoredProcedure>
    <Description>Get Current InterestRate Package By ProductType</Description>
    <Service>Interest</Service>
    <Feature>Interest</Feature>
	<Parameters>
		<Parameter Name="@account">
			<Description>head account</Description>
		</Parameter>		
	</Parameters>
</StoredProcedure>

--***/
CREATE PROCEDURE [Accounts].[spAccountBankAccountCurrencies] (@account varchar(20)) AS

/*declare @account as varchar(20)
set @account = 'SA1000047'*/

SELECT 
		CF.Id AS CurrencyID,
		CF.IsoCode, 
		CF.CurrencyName, 
		CF.ValueDP, 
		CF.RateDP, 
		CF.CurrencySymbol,
		WP.WrapProvider,
		CASE WP.DefaultCurrencyID
			WHEN CF.Id THEN 1
			ELSE 0
		END AS IsDefaultCurrency		
FROM dbo.BankAccountToClAccountIdContext BC
INNER JOIN Discovery.dbo.BankAccount B
	ON BC.BankAccountId = B.ID
INNER JOIN dbo.fnHeadAccounts() ha
	ON ha.HeadClAccountID = b.ClAccountID
LEFT JOIN Res_db.dbo.CurrencyFormat CF
	ON B.CurrencyId = CF.Id
LEFT JOIN dbo.SEClientAccount SE 
	ON BC.ClAccountId = SE.ClAccountId
LEFT JOIN dbo.Advisor ADV 
	ON SE.PrimaryAdviser = ADV.AdvCode
LEFT JOIN dbo.Company CO 
	ON ADV.Company = CO.Company
LEFT JOIN dbo.WrapProvider WP 
	ON CO.WrapProvider = WP.WrapProvider
WHERE 
	ha.ClAccountId = @account And BC.Context = 'settlement' And BC.Active = 1
GO


