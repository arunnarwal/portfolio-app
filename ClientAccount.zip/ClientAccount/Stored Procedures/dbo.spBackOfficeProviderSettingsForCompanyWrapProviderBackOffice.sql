
CREATE PROCEDURE [dbo].[spBackOfficeProviderSettingsForCompanyWrapProviderBackOffice] @CompanyId INT, @WrapProviderId INT, @BackOfficeProviderId INT AS

	/*
		DECLARE @CompanyId int;
		DECLARE @WrapProviderId int;
		DECLARE @BackOfficeProviderId int;
		SET @CompanyId = 3163;
		SET @WrapProviderId = 7;
		SET @BackOfficeProviderId = 1;
	*/

	SELECT	COALESCE(BOS.OverrideBackOfficeProviderDisplayName, BOW.BackOfficeProviderDisplayName) As BackOfficeProviderDisplayName,
			BOW.BackOfficeProviderServicesName,
			BOS.TwoWayIntegration,
			BOS.AdHocContractEnquiry,
			XGM1.[Version] AdHocContractEnquiryFileVersion,
			BOS.BulkContractEnquiry,
			XGM2.[Version] BulkContractEnquiryFileVersion,
			BOS.BulkContractEnquiryStartOn,
			BOW.BulkContractEnquiryFrequencyMon, 
			BOW.BulkContractEnquiryFrequencyTues, 
			BOW.BulkContractEnquiryFrequencyWed, 
			BOW.BulkContractEnquiryFrequencyThurs, 
			BOW.BulkContractEnquiryFrequencyFri, 
			BOW.BulkContractEnquiryFrequencySat, 
			BOW.BulkContractEnquiryFrequencySun,
			BOP.[Provider]
	FROM dbo.BackOfficeProviderCompanySettings BOS
		INNER JOIN dbo.BackOfficeProviderWrapProviderSettings BOW ON BOS.BackOfficeProviderId = BOW.BackOfficeProviderId 
																AND BOW.WrapProviderId = @WrapProviderId AND BOW.IsEnabled = 1
		INNER JOIN dbo.BackOfficeProvider BOP ON BOW.BackOfficeProviderId = BOP.BackOfficeProviderId 
																AND BOP.IsEnabled = 1 AND BOP.BackOfficeProviderId = @BackOfficeProviderId
		LEFT JOIN Discovery.dbo.XMLGenericMessage XGM1 ON BOS.AdHocContractEnquiryXMLGenericMessageId = XGM1.Id
		LEFT JOIN Discovery.dbo.XMLGenericMessage XGM2 ON BOS.BulkContractEnquiryXMLGenericMessageId = XGM2.Id
	WHERE BOS.CompanyID = @CompanyId
GO
