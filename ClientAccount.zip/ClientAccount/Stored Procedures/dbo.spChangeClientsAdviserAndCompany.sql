/***
<StoredProcedure>
   <Description>Change Clients Adviser And Company Procedure. Task 18881</Description>
</StoredProcedure>
***/

CREATE PROCEDURE [dbo].[spChangeClientsAdviserAndCompany](
               @TaskRequestId INT,
               @ClAccountID   VARCHAR(20),
               @AdviserCode   VARCHAR(20),
               @Company       VARCHAR(20)  = '')
AS
  DECLARE  @ErrorMessage VARCHAR(MAX)
  
  SET nocount  ON
  
  /*
DECLARE @ClAccountID VARCHAR(20), 
@AdviserCode VARCHAR(20),   
@TaskRequestId INT,   
@Company VarChar(20)  

SET @ClAccountID = 'AV2013830'   
SET @AdviserCode = 'NIL0998'   
SET @TaskRequestId = 1287163
SET @Company = 'ORPHANCOMP' 
--  */
  DECLARE  @id               INT,
           @userId           INT,
           @TransactionId    INT,
           @ActionType       VARCHAR(70),
           @oldValues        VARCHAR(500),
           @currClAccountId  VARCHAR(20),
           @CompanyFieldName VARCHAR(100),
           @CompanyNewValue  VARCHAR(100),

		   @Today			 DATETIME,
		   @oldAdvCode       VARCHAR(20)

  SELECT @Today = dateadd(day, datediff(day, 0, getdate()),0) --used for accrual processing
  
  CREATE TABLE #HeadAccounts (
    HeadClAccountId VARCHAR(15),
	claccountid VARCHAR(20),
    processed   BIT)
	
  DECLARE @T TABLE (id INT, OldValues VARCHAR(MAX))
  
  DECLARE @Users TABLE (ClientID INT, OldCompany VARCHAR(20), Processed BIT)
  
  BEGIN TRANSACTION
  
  BEGIN TRY
	/*================= Getting ActionType and UserRequestedId ===============================*/
    SELECT @ActionType = actiontype,
           @UserId = requestclientid
    FROM   TaskDB.dbo.TaskRequests AS tr
           INNER JOIN Discovery.dbo.RequestInterfaceActions AS ria
             ON ria.TaskId = tr.TaskId
    WHERE  tr.Id = @TaskRequestId
    
    IF @UserId IS NOT NULL
      BEGIN
        /*================= Inserting RI transaction ===============================*/
        INSERT INTO discovery.dbo.RequestInterfaceTransactions
                   (actionname,
                    claccountid,
                    requestedby,
                    requestdate)
        VALUES     (@ActionType,@ClAccountID,@userId,Getdate())
        
        SELECT @TransactionId = Scope_identity()
        
        INSERT INTO discovery.dbo.RequestInterfaceTaskrequests
                   (transactionid,
                    taskrequestid)
        VALUES     (@TransactionId,@TaskRequestId)
        
		/* ========================== setting default Company if needed ================================ */
		DECLARE @Application VARCHAR(30)
		SET @Application = 'ClientMoves_DefaultValues' 

		SELECT @Company = Value
		FROM SystemVariables.dbo.SystemVariables 
		WHERE Application = @Application 
			AND Variable = @ActionType + '_Company'

		IF @Company <> ''
			BEGIN
			  SELECT @CompanyFieldName = '|Company=',
					 @CompanyNewValue = '|Company=' + @Company
			END
		  ELSE
			BEGIN
			  SELECT @CompanyFieldName = '',
					 @CompanyNewValue = ''
			END

		/* ========================== setting default Adviser if needed ================================ */
		SELECT @AdviserCode = Value
		FROM SystemVariables.dbo.SystemVariables 
		WHERE Application = @Application
			AND Variable = @ActionType + '_Adviser'

		/*================= Temp Table of subAccounts ===============================*/
		INSERT INTO #HeadAccounts
		SELECT DISTINCT ha.HeadClAccountId,
						ha.ClAccountId,
						0
		FROM   dbo.fnHeadAccounts() ha				
		WHERE  ha.HeadClAccountId = @ClAccountID 
				AND ha.Consolidated = 0
		UNION 
		SELECT	dbo.fngetheadaccountid(CLAccountID) AS HeadClAccountId,
				CLAccountId,
				0
		FROM dbo.ClientDetails
		WHERE InvestorType = 'Consolidated' 
				AND CLAccountID LIKE @ClAccountID + '%'

		IF @Company IS NOT NULL AND LEN(@Company) > 0
		BEGIN
			/*======================= Update Company in TblClients =========================*/

			
			INSERT INTO @Users
			SELECT DISTINCT T.ClientId,
							T.Company,
							0
			FROM   #HeadAccounts AS H
				   INNER JOIN dbo.ClientAccountSecurity AS CAS
						ON H.HeadClAccountId = CAS.ClAccountId
						AND CAS.SuperUser IS NULL
				   INNER JOIN ClientDB3.dbo.TblClients AS T ON cas.ClientId = T.ClientId

			
			WHILE EXISTS (SELECT 1
						  FROM   @Users
						  WHERE  processed = 0)
			  BEGIN
				SELECT TOP 1 @id = U.ClientId,
							 @oldValues = 'Company=' + U.OldCompany
				FROM   @Users AS U
				WHERE  processed = 0
				
				UPDATE clientdb3.dbo.TblClients
				SET    company = @Company
				WHERE  clientid = @id
				
				INSERT INTO discovery.dbo.requestinterfacechangelog
						   (transactionid,
						    tablerowidentifier,
						    databasename,
						    tablename,
						    oldvalues,
						    newvalues)
				VALUES     (@TransactionId,@id,'ClientDB3','TblClients',@oldValues,'Company=' + @Company)
				
				UPDATE @Users
				SET    processed = 1
				WHERE  clientid = @id
			  END


			/*======================= Update Company in FeeStanding =========================*/
			
			IF OBJECT_ID('tempdb..#FeeIds') IS NOT NULL DROP TABLE #FeeIds

			SELECT Id 
			INTO #FeeIds
			FROM dbo.FeeStanding 
			WHERE Claccountid like @ClAccountID + '%' AND Active = 1 AND ( Amount <> 0 OR [Continue] not in ( 'DELETED','CANCELLED') )

			DECLARE @now DATETIME
			SET @now = GETDATE()

			IF (@ActionType != 'OrphanClient')
			BEGIN
				INSERT INTO dbo.FeeStanding(	[Claccountid], [AddedByUserID], [DateCreated],	[Amount], [Frequency], [NextPayDate], [Continue], [EndDate], [Active], [PayOutCount], [Company]	, [BatchID], [AdvisorPostMethod], [RequestMethod], [SourceValuaton], [TransferRequestID], [TranType], [ExecuteOnOrderBatchCreation], [SubAccountType], [MatchedToCashEntry], [MaxPayOutCount], [FailedPayOutCount], [OriginatingFeeStandingID],	[DateAuthorised], [UserAuthorised], [DateRejected], [UserRejected], [AdviceGiven], [TotalChargeAmount], [AdviceType], [DateCancelled], [UserCancelled]) 
				SELECT							[Claccountid], [AddedByUserID], @now,			[Amount], [Frequency], [NextPayDate], [Continue], [EndDate], [Active], [PayOutCount], @Company	, [BatchID], [AdvisorPostMethod], [RequestMethod], [SourceValuaton], [TransferRequestID], [TranType], [ExecuteOnOrderBatchCreation], [SubAccountType], [MatchedToCashEntry], [MaxPayOutCount], [FailedPayOutCount], [ID],						[DateAuthorised], [UserAuthorised], [DateRejected], [UserRejected], [AdviceGiven], [TotalChargeAmount], [AdviceType], [DateCancelled], [UserCancelled]
				FROM dbo.FeeStanding WHERE ID in (SELECT ID from #FeeIds)
			END

			UPDATE dbo.FeeStanding 
			SET  [Continue] = 'DELETED', [EndDate] = @now, [Active] = 0 , [DateCancelled] = @now, [UserCancelled] = @UserID
			FROM dbo.FeeStanding WHERE ID in (SELECT ID from #FeeIds)

			DROP TABLE #FeeIds
			/*===================== END Update Company in FeeStanding =======================*/
		END

		
		/*======================= Gather old permissions in CustomerSecurity ==============================*/
		DECLARE @OldCustomerIds AS TABLE (CustomerId INT)
			
		SELECT TOP 1 @oldAdvCode = primaryAdviser
        FROM   dbo.SEClientAccount
        WHERE  claccountid = @ClAccountID
		
		INSERT INTO @OldCustomerIds(CustomerId)
		SELECT cs.CustomerId
		FROM Platform.DBACustomer.CustomerSecurity cs
			INNER JOIN Platform.DBAAccount.CustomerRoles cr ON cr.CustomerId = cs.CustomerId
			INNER JOIN dbo.SEClientAccount se ON se.Id = cr.AccountId
			INNER JOIN dbo.Advisor a ON a.Id = cs.EntityId
		WHERE se.ClAccountID = @ClAccountID
			AND cr.CustomerRoleStatusId = 1 --and cs.EntityTypeId = 5
			AND a.AdvCode = @oldAdvCode
				
		DECLARE @AdvisorIdNew as int
		SELECT @AdvisorIdNew = id
		FROM dbo.Advisor
		WHERE AdvCode = @AdviserCode


		DECLARE @OldPermissionsTable As TABLE (CustomerId INT,EntityTypeId TINYINT,EntityId INT)
		
		INSERT INTO @OldPermissionsTable (CustomerId,EntityTypeId,EntityId)
		SELECT DISTINCT CS.CustomerId,CS.EntityTypeId,CS.EntityId
		FROM dbo.SEClientAccount SECA
			INNER JOIN Platform.DBAAccount.CustomerRoles CR ON SECA.ID = CR.AccountId
			INNER JOIN Platform.DBACustomer.CustomerSecurity CS ON CR.CustomerId = CS.CustomerId
			INNER JOIN dbo.Advisor A ON CS.EntityId = A.ID AND CS.EntityTypeId = 5
		WHERE
			CR.CustomerId IN (SELECT CustomerId FROM @OldCustomerIds)
			
		/*======================= END Gather old permissions in CustomerSecurity ==============================*/

		-- clear Customer's documents
		DELETE documents.dbo.CustomerDocumentLibrary
		WHERE CustomerId IN (SELECT id FROM @T)

		-- clear CKA/AI/SOW information
		DELETE One.Suitability.Forms
		WHERE FormId IN (SELECT FormId FROM One.Suitability.CustomerForms WHERE CustomerId IN (SELECT id FROM @T))


        /*================= Cycle processing all the subAccounts ===============================*/
        WHILE EXISTS (SELECT 1
                      FROM   #HeadAccounts
                      WHERE  processed = 0)
          BEGIN
            SELECT TOP 1 @currClAccountId = claccountid
            FROM   #HeadAccounts
            WHERE  processed = 0
            
            /*======================= Update PrimaryAdviser in SEClientAccount =========================*/
            SET @id = NULL
            
            SELECT TOP 1 @id = id,
                         @oldValues = 'PrimaryAdviser=' + primaryadviser,
                         @oldAdvCode = primaryAdviser
            FROM   dbo.SEClientAccount
            WHERE  claccountid = @currClAccountId
            
            IF @id IS NOT NULL
              BEGIN
                UPDATE dbo.SEClientAccount
                SET    primaryadviser = @AdviserCode
                WHERE  id = @id
                
                INSERT INTO discovery.dbo.requestinterfacechangelog
                           (transactionid,
                            tablerowidentifier,
                            databasename,
                            tablename,
                            oldvalues,
                            newvalues)
                VALUES     (@TransactionId,@id,'ClientAccount','SEClientAccount',@oldValues,'PrimaryAdviser=' + @AdviserCode)
              END
            
            /*======================= Update advcode (and Company) in AdvisorRevenueLedger =========================*/
			DELETE FROM @T  

			INSERT INTO @T (id, OldValues)
			SELECT arl.Id, 'AdvCode=' + arl.AdvCode + @CompanyFieldName +	CASE @Company 
																	   WHEN '' THEN ''
																	   ELSE arl.Company
																	 END
			FROM Discovery.dbo.AdvisorRevenueLedger arl
				INNER JOIN dbo.Company com on com.Company = arl.Company
				INNER JOIN dbo.FeeTranTypes ftt on com.WrapProvider = ftt.WrapProvider AND arl.TranType = ftt.TranType
			WHERE  arl.glposted = 'NO'
				   AND arl.claccountid = @currClAccountId
				   AND arl.AdvCode = @oldAdvCode
				   AND ftt.AdvisorCharge = 0
				   AND arl.ClawbackAuditId IS NULL
					
			UPDATE discovery.dbo.advisorrevenueledger
			SET    advcode = @AdviserCode,
				   company = CASE @Company 
							   WHEN '' THEN ARL.company
							   ELSE @Company
							 END				   
			FROM @T AS T
				INNER JOIN Discovery.dbo.AdvisorRevenueLedger AS ARL ON ARL.Id = T.Id

                
			INSERT INTO discovery.dbo.requestinterfacechangelog
					   (transactionid,
						tablerowidentifier,
						databasename,
						tablename,
						oldvalues,
						newvalues)
			SELECT  @TransactionId,
					Id,
					'Discovery',
					'AdvisorRevenueLedger',
					OldValues,
					'AdvCode=' + @AdviserCode + @CompanyNewValue
			FROM @T

			/*====== Cancel IAC if unposted and this is Orphan company actionType =========*/
			DELETE FROM @T

			IF (@ActionType = 'OrphanClient')
			BEGIN
				INSERT INTO @T (id, OldValues)
				SELECT arl.Id, 'AdvisorPostMethod=' + arl.AdvisorPostMethod + ', DisplayToClient=' DisplayToClient
				FROM Discovery.dbo.AdvisorRevenueLedger arl
				WHERE  glposted = 'NO'
				   AND arl.claccountid = @currClAccountId
				   AND arl.TranType = 'IAC'
				   AND arl.ClawbackAuditId IS NULL

				UPDATE	Discovery.dbo.AdvisorRevenueLedger
				SET		AdvisorPostMethod = 'DLT',
						DisplaytoClient = 0,
						SystemNote = ARL.SystemNote + ' cancelled as part of orphan client process'
				FROM @T as T
				INNER JOIN Discovery.dbo.AdvisorRevenueLedger AS ARL ON ARL.Id = T.Id

				INSERT INTO discovery.dbo.requestinterfacechangelog
					   (transactionid,
						tablerowidentifier,
						databasename,
						tablename,
						oldvalues,
						newvalues)
				SELECT  @TransactionId,
						Id,
						'Discovery',
						'AdvisorRevenueLedger',
						OldValues,
						'AdvisorPostMethod=DLT, DisplayToClient=0'
				FROM @T
			END


            /*======================= Update AdvisorCodes (and Company) in ClientAccountSecurity =========================*/
		    DELETE FROM @T 

			INSERT INTO @T (id, OldValues)
			SELECT 0, 'AdvisorCodes=' + AdvisorCodes +	CASE @Company 
														 WHEN '' THEN ''
														 ELSE '|Companies=' + Companies
														END
			FROM   dbo.ClientAccountSecurity 
			WHERE  claccountid = @currClAccountId			
			--select every1 who has direct access to ClaccountID	            

	                




			INSERT INTO discovery.dbo.requestinterfacechangelog
						   (transactionid,
							tablerowidentifier,
							databasename,
							tablename,
							oldvalues,
							newvalues)
			SELECT  @TransactionId,
					Id,
					'ClientAccount',
					'ClientAccountSecurity',
					OldValues,
					'AdvisorCodes=' + @AdviserCode + @CompanyNewValue
			FROM @T
				

            IF @Company IS NOT NULL AND LEN(@Company) > 0
              BEGIN
                /*======================= Update Company in ClientDetails =========================*/
                SET @id = NULL
                
                SELECT TOP 1 @id = id,
                             @oldValues = 'Company=' + company
                FROM   dbo.ClientDetails
                WHERE  claccountid = @currClAccountId
                
                IF @id IS NOT NULL
                  BEGIN
                    UPDATE ClientAccount.dbo.clientdetails
                    SET    company = @Company
                    WHERE  id = @id
                    
                    INSERT INTO discovery.dbo.requestinterfacechangelog
                               (transactionid,
                                tablerowidentifier,
                                databasename,
                                tablename,
                                oldvalues,
                                newvalues)
                    VALUES     (@TransactionId,@id,'ClientAccount','ClientDetails',@oldValues,'Company=' + @Company)
                  END
                
                /*======================= Update Company in InstrumentSettings =========================*/
                SET @id = NULL
                
                SELECT TOP 1 @id = i.Id,
                             @oldValues = 'Name=' + i.name
                FROM   Res_DB.dbo.InstrumentSettings AS i
                       INNER JOIN Discovery.dbo.ClientAccount AS ca
                         ON ca.ClaccountId = i.Instrumentcode
                            AND i.Type = 'Company'
                       INNER JOIN Discovery.dbo.ModelPortfolio AS mp
                         ON ca.PortfolioId = mp.PortfolioId
                            AND mp.Type = 'OBSR'
                            AND ca.Status <> 'Closed'
                WHERE  ca.claccountid = @currClAccountId
                
				IF @id IS NOT NULL
				  BEGIN
				    UPDATE res_db.dbo.instrumentsettings
					SET name = @Company
					WHERE id = @id
					INSERT INTO discovery.dbo.requestinterfacechangelog
						(transactionid,
						tablerowidentifier,
						databasename,
						tablename,
						oldvalues,
						newvalues)
					VALUES (@TransactionId,@id,'Res_DB','InstrumentSettings',@oldValues,'Name=' + @Company)
					END
				/*======================= Update Company in InstrumentSettings for DFM subaccounts (not DFM models) =========================*/ 
				SET @id = NULL 
				SELECT TOP 1 @id = i.Id, 
				@oldValues = 'Name=' + i.name 
				FROM Res_DB.dbo.InstrumentSettings AS i 
				INNER JOIN Discovery.dbo.ClientAccount AS ca 
					ON ca.ClaccountId = i.Instrumentcode 
						AND i.Type = 'Company' 
				INNER JOIN Discovery.dbo.ProductDetails AS PD
					ON ca.ClaccountId = PD.ClaccountId
						AND PD.IsPlatformFund = 1
						AND PD.IsDFMManaged = 1 
				WHERE ca.claccountid = @currClAccountId 
					AND ca.status <> 'Closed' 
					AND CA.PortfolioID = 0
                
                IF @id IS NOT NULL
                  BEGIN
                    UPDATE res_db.dbo.instrumentsettings
                    SET    name = @Company
                    WHERE  id = @id
                    
                    INSERT INTO discovery.dbo.requestinterfacechangelog
                               (transactionid,
                                tablerowidentifier,
                                databasename,
                                tablename,
                                oldvalues,
                                newvalues)
                    VALUES     (@TransactionId,@id,'Res_DB','InstrumentSettings',@oldValues,'Name=' + @Company)
                  END
              END

			/*==============Deal with future dated accruals in FAD2/accruals table=============*/
			
			/*Add audit trail to show totalamounts of each fee category/instrumentcode we are updating */
			INSERT INTO dbo.AuditTrail (ProcessName, Source, IdentifierType, Identifier, UserID, Details)
			SELECT	@actionType, 
					'spChangeClientsAdviserAndCompany', 
					'ClAccountID', 
					ClaccountId, 
					COALESCE(@userID,8245), 
					'Updated chargedate to ' + CONVERT(varchar(12), @Today) + ' for category: ' + Category + ', instrumentcode: ' + COALESCE(InstrumentCode,'(NA)') + ' accruals totalling: ' + CONVERT(varchar(max),SUM(TotalAmount))
			FROM dbo.FeeAccrualDetail2 
			WHERE	claccountid = @currClAccountId AND 
					category IN ('OA') AND 
					chargedate >= @Today AND
					arltransferid IS NULL AND 
					restrictByChargeDate = 1
			GROUP BY ClaccountId, Category, InstrumentCode
			
			UNION ALL --fbrc rebates
			SELECT	@actionType, 
					'spChangeClientsAdviserAndCompany', 
					'ClAccountID', 
					SECA.ClAccountId, 
					COALESCE(@userID,8245), 
					'Updated chargedate to ' + CONVERT(varchar(12), @Today) + ' for category: ' + CASE WHEN F.IsClient = 1 THEN 'Client FBRC' ELSE 'Advisor FBRC' END + ', instrumentcode: ' + I.Security + ' accruals totalling: ' + CONVERT(varchar(max),SUM(F.Amount))
			FROM dbo.Fee_Accrual_FBRCRebates F
				INNER JOIN dbo.SEClientAccount AS SECA 
						ON SECA.Id = F.SECAId
				INNER JOIN Res_DB.dbo.Instruments I
						ON F.InstrumentId = I.Id
			WHERE	
					F.Processed = 0
					AND chargedate >= @Today
					AND SECA.claccountid = @currClAccountId
			GROUP BY SECA.ClAccountId,
					CASE WHEN F.IsClient = 1 THEN 'Client FBRC' ELSE 'Advisor FBRC' END, 
					I.Security
			
			

			/*Lastly do the actual update of the chargedate*/
			UPDATE dbo.feeaccrualdetail2 
			SET chargedate = @Today
			WHERE	claccountid = @currClAccountId AND 
					category IN ('OA') AND 
					chargedate >= @Today AND
					arltransferID IS NULL AND 
					restrictByChargeDate = 1

			UPDATE  dbo.Fee_Accrual_FBRCRebates
			SET	chargeDate = @Today
			FROM dbo.Fee_Accrual_FBRCRebates F
					INNER JOIN dbo.SEClientAccount AS SECA 
						ON SECA.Id = F.SECAId
									
			WHERE	F.Processed = 0 
					AND F.ChargeDate >= @Today
					AND SECA.ClaccountID = @currClAccountId

			
			/*========== End FeeAccrual logic ====================*/

			
			IF (@ActionType = 'OrphanClient')
			/*========== Remove FBRC (OAC) settings if this is 'OrphanClient' actionType - by adding a new row that will be activated from tommorow with zero rate ======*/
			BEGIN
				IF NOT EXISTS (SELECT 1 FROM dbo.ClientFbrcSettings WHERE ClAccountID = @currClAccountId AND AsAt = @Today AND CallerSource = 'spChangeClientsAdviserAndCompany')
				BEGIN
					INSERT INTO dbo.ClientFbrcSettings (ClAccountID, FbrcRate, UseFundFBRCRate, AsAt, DateAdded, UserAddedBy, CallerSource, Note, Active, AdviceGiven)
					SELECT @currClAccountId, 
						0 as FBRCRate, 
						0 as UseFundFBRCRAte, 
						@Today as AsAt, 
						GetDate() as DateAdded, 
						@userId as UserAddedBy,
						'spChangeClientsAdviserAndCompany' as CallerSource,
						'Set to 0% as part of orphan client process' as Note, 
						0 as Active, 
						0 as AdviceGiven						
				END
				
				/*========End Fbrc/oac removal for orphan client ============*/					

				/*======= Set Nominated Trail to zero for orphan client =======*/
				--remove nom trail by setting it to zero - this will take place from tommorow
				DECLARE @SubAccountId AS INT
				DECLARE @NowDate AS Date
				SELECT @SubAccountId = ID FROM dbo.SEClientAccount WHERE ClAccountId = @currClAccountId
				SET @NowDate = GETDATE()				
				EXEC One.Charges.spSetSubAccountNominatedTrailRate @SubAccountId = @SubAccountId, @Rate = 0, @UserAdded = @userId, @Today = @NowDate

				/*======= End Set Nominated Trail to zero =======*/
			END           
			
			UPDATE #HeadAccounts
            SET    processed = 1
            WHERE  claccountid = @currClAccountId
          END

		/*======================= Perform permissions update in CustomerSecurity after the change ==============================*/

		DECLARE @AccountId AS INT
		SELECT @AccountId = ID FROM dbo.SEClientAccount WHERE ClAccountId = @ClAccountID

		DECLARE @OmwDefAdvisorId AS INT
		SELECT @OmwDefAdvisorId = Id FROM dbo.Advisor WHERE AdvCode = 'OMWADVISOR'

		EXEC Platform.DBACustomer.spSetCustomerOwnerByAccount @AuditUserId = 8245, @AccountId = @AccountId, @AdvisorId = @OmwDefAdvisorId

	
		DECLARE @NewPermissionsTable As TABLE (CustomerId INT,EntityTypeId TINYINT,EntityId INT)
		
		INSERT INTO @NewPermissionsTable (CustomerId,EntityTypeId,EntityId)
		SELECT CS.CustomerId,CS.EntityTypeId,CS.EntityId
		FROM dbo.SEClientAccount SECA
			INNER JOIN Platform.DBAAccount.CustomerRoles CR ON SECA.ID = CR.AccountId
			INNER JOIN Platform.DBACustomer.CustomerSecurity CS ON CR.CustomerId = CS.CustomerId
			INNER JOIN dbo.Advisor A ON CS.EntityId = A.ID AND CS.EntityTypeId = 5
		WHERE
			CR.CustomerId IN (SELECT CustomerId FROM @OldCustomerIds)
	

		/* Change Log */
		-- add deleted permissions
		INSERT INTO discovery.dbo.requestinterfacechangelog
					(transactionid,
					tablerowidentifier,
					databasename,
					tablename,
					oldvalues,
					newvalues)
		SELECT  @TransactionId,
				T.CustomerId,
				'Platform',
				'DBACustomer.CustomerSecurity',
				'DELETED',
				'EntityId=' + CAST(old.EntityId as varchar(20))
		FROM @OldCustomerIds T
			INNER JOIN @OldPermissionsTable old ON T.CustomerId = old.CustomerId
			LEFT JOIN @NewPermissionsTable new ON old.CustomerId = new.CustomerId AND old.EntityId = new.EntityId AND old.EntityTypeId = new.EntityTypeId
		WHERE new.CustomerId IS NULL
				
		-- add newly inserted permissions		
		INSERT INTO discovery.dbo.requestinterfacechangelog
					(transactionid,
					tablerowidentifier,
					databasename,
					tablename,
					oldvalues,
					newvalues)
		SELECT  @TransactionId,
				T.CustomerId,
				'Platform',
				'DBACustomer.CustomerSecurity',
				'INSERTED',
				'EntityId=' + CAST(new.EntityId as varchar(20))
		FROM @OldCustomerIds T
			INNER JOIN @NewPermissionsTable new ON T.CustomerId = new.CustomerId
			LEFT JOIN @OldPermissionsTable old ON old.CustomerId = new.CustomerId AND old.EntityId = new.EntityId AND old.EntityTypeId = new.EntityTypeId
		WHERE old.CustomerId IS NULL
			
		/*======== Customer assigned adviser ============*/	

		DECLARE @CustomerId INT
		
		SELECT @CustomerId = CAA.CustomerId
		FROM Platform.DBAAccount.CustomerRoles CA
		INNER JOIN Platform.DBACustomer.CustomerAssignedAdvisers CAA ON CAA.CustomerId = CA.CustomerId
		WHERE CA.AccountId = @AccountId AND CA.IsPrimaryRole = 1

		UPDATE Platform.DBACustomer.CustomerAssignedAdvisers
		SET AdviserId = @AdvisorIdNew
		WHERE CustomerId = @CustomerId

		/*======== END Customer assigned adviser ============*/	
		
      END
    ELSE
      BEGIN
        SET @ErrorMessage = 'Unable to find the Task Request or there is no RI action defined for this TaskId'

      END
      
      COMMIT TRANSACTION
      IF OBJECT_ID('tempdb..#Headaccounts') IS NOT NULL
		DROP TABLE #Headaccounts

  END TRY
  
  BEGIN CATCH
	ROLLBACK TRANSACTION
    SET @ErrorMessage = Error_message()
    IF OBJECT_ID('tempdb..#Headaccounts') IS NOT NULL
		DROP TABLE #Headaccounts
  END CATCH
 
  SELECT @ErrorMessage AS Errormessage

GO
