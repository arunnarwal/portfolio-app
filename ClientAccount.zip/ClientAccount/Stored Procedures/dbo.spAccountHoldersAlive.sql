/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>2414DF1968415568BE997E2EBE5E3DB5</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[spAccountHoldersAlive] (@HeadAccountID varchar(20) = 'ALL')
AS
BEGIN
--	DECLARE @HeadAccountID varchar(20)
--	SET @HeadAccountID = 'GS2003130'
	select CLAccountID,Count(ID) as Total,0 as Deceased from clientaccount..accountholders WHERE CLAccountID = @HeadAccountID OR @HeadAccountID = 'ALL' Group By CLAccountID
	UNION ALL
	select CLAccountID,0 as Total,Count(ID) as Deceased from clientaccount..accountholders WHERE (CLAccountID = @HeadAccountID OR @HeadAccountID = 'ALL') AND Deceased = 1 Group By CLAccountID
END
GO
