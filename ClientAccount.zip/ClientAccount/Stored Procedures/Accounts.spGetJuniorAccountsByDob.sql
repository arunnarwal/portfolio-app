/***
<StoredProcedure>
    <Description>Get Current InterestRate Package By ProductType</Description>
    <Service></Service>
    <Feature></Feature>
	<Parameters>
		<Parameter Name="@DateOfBirth">
			<Description>Date of bitrh of the main holder</Description>
		</Parameter>
		<Parameter Name="@WrapperType">
			<Description>Wrapper type that we are searching on</Description>
		</Parameter>		
	</Parameters>
</StoredProcedure>
***/

CREATE PROCEDURE [Accounts].[spGetJuniorAccountsByDob] (@DateOfBirth Date, @WrapperType VARCHAR(30) = '') AS

/*
USE ClientAccount

DECLARE @DateOfBirth as datetime
SET @DateOfBirth = '2018-07-16 00:00:00'
DECLARE @WrapperType as varchar(30)
SET @WrapperType = ''
*/

SELECT 
	I.CustomerId,
	RCCR.CustomerId AS RegisteredContactCustomerId,
	SECA.ClAccountId AS HeadClAccountId,
	PD.ClAccountId,
	PD.ProductType,
	I.DateOfBirth,
	I.GivenName,
	I.FamilyName
FROM Platform.DBACustomer.Individuals AS I
	INNER JOIN Platform.DBAAccount.CustomerRoles AS CR ON CR.CustomerId = I.CustomerId AND CR.IsPrimaryRole = 1
	INNER JOIN dbo.SEClientAccount SECA ON SECA.Id = CR.AccountId
	INNER JOIN dbo.ClientDetails AS CD ON CD.ClAccountId = SECA.ClAccountId AND CD.IsJuniorAccount = 1
	INNER JOIN dbo.fnHeadAccounts() AS HA ON HA.HeadClAccountID = SECA.ClAccountID AND HA.Consolidated = 0 AND HA.ClAccountID <> HA.HeadClAccountId
	INNER JOIN Discovery.dbo.ProductDetails AS PD ON PD.ClAccountID = HA.ClAccountID
	LEFT JOIN Platform.DBAAccount.CustomerRoles AS RCCR ON RCCR.AccountId = SECA.Id AND RCCR.CustomerRoleTypeId = 3 --RegisteredContact
WHERE I.DateOfBirth <= @DateOfBirth 
	AND (PD.ProductType = @WrapperType OR @WrapperType = '')
GO
