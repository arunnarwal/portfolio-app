/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>D9DD96F3F313037C684E9C17A7F8C4EF</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[spCheckCashAndInvestmentTransactions]
	(@FromDate as datetime, 
	 @ToDate as datetime, 
	 @CLAccountID as varChar(20))
AS
BEGIN

/*
DECLARE @ClAccountId VARCHAR(20) 
DECLARE @FromDate DATETIME
DECLARE @ToDate DATETIME
SET @ClAccountId = 'CL0004956'
SET @FromDate = '2012-04-30 00:00:00.000'
SET @ToDate = '2012-10-31 00:00:00.000'
*/

SELECT 1 FROM [dbo].[ScripTransactions]
WHERE
(Location IN ('Custody','Registry') OR (Location = 'BTA' AND TransStatus = 'Unsettled')) AND (AsAt BETWEEN  @FromDate AND @ToDate)
AND clAccountId LIKE @ClAccountId + '%'

UNION
SELECT 1 FROM [dbo].[cmttrans]
WHERE
TransType IN('Interest','AIL','RWT','NRWT') AND
displaytoclient = 1 AND
amount <> 0 
AND (trandate BETWEEN  @FromDate AND @ToDate)
AND clAccountId LIKE @ClAccountId + '%'

UNION
SELECT 1 FROM [dbo].[cashledgertransactions]
WHERE
(ledgerdate BETWEEN @FromDate AND @ToDate) AND
clAccountId LIKE @ClAccountId + '%' AND
displaytoclient = 1
AND movementtype <> 'CALL_TRANSACTION'
AND amount <> 0

END
GO
