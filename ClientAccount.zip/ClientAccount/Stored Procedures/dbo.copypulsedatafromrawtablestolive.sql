/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>7910B6BC87313D41E9A773275D44A707</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[copypulsedatafromrawtablestolive] 

AS

DECLARE @ResultValue INT

DECLARE @RowsCopied INT

DECLARE @RowsInRawTables INT

DECLARE @Lock INT

BEGIN TRANSACTION PulseDataCopyTransaction

SET @Lock = (select count(1)  from clientaccount..PulseTransactions where 1 = 0)

SET @Lock = (select count(1) from Clientaccount..PulseHoldings where 1 = 0)

SET @Lock = (select count(1) from Clientaccount..PulsePortfolios where 1 = 0)

SET @Lock = (select count(1) from Clientaccount..PulseSecurities where 1 = 0)

SET @Lock = (select count(1) from Clientaccount..PulsePrices where 1 = 0)

BEGIN TRY

DELETE FROM Clientaccount..PulseTransactions

DELETE FROM Clientaccount..PulseHoldings

DELETE FROM Clientaccount..PulsePortfolios

DELETE FROM Clientaccount..PulseSecurities

SET @RowsInRawTables = (SELECT Count(* )

FROM Clientaccount..PulsePortfoliosRawData)

SET @RowsInRawTables = @RowsInRawTables + (SELECT Count(* )

FROM Clientaccount..PulseSecuritiesRawData)

SET @RowsInRawTables = @RowsInRawTables + (SELECT Count(* )

FROM Clientaccount..PulseTransactionsRawData)

SET @RowsInRawTables = @RowsInRawTables + (SELECT Count(* )

FROM Clientaccount..PulseHoldingsRawData)

SET @RowsInRawTables = @RowsInRawTables + (SELECT Count(* )

FROM Clientaccount..PulsePricesRawData)

INSERT INTO Clientaccount..PulsePortfolios

SELECT [PortfolioID],

[PulseReference],

[PortfolioCode],

[PortfolioName],

[PortfolioType],

[PortfolioTypeDetail],

[ClientName],

[PortfolioCurrency],

[IntermediaryReference],

[TrusteeReference]

FROM Clientaccount..PulsePortfoliosRawData

SET @RowsCopied = @RowsCopied + @@ROWCOUNT

INSERT INTO Clientaccount..PulseSecurities

SELECT [Sedol],

[InstrumentName],

[AssetType],

[Sector],

[GeographicRegion],

[PriceDate],

[ExDividendFlag]

FROM Clientaccount..PulseSecuritiesRawData

SET @RowsCopied = @RowsCopied + @@ROWCOUNT

INSERT INTO Clientaccount..PulseTransactions

SELECT [PortfolioID],

[Sedol],

[TransactionType],

[Cord],

[Quantity],

[Cost],

[RollingQuantity],

[RollingCost],

[TransactionDate],

[Details]

FROM Clientaccount..PulseTransactionsRawData

SET @RowsCopied = @RowsCopied + @@ROWCOUNT

INSERT INTO Clientaccount..PulseHoldings

SELECT [PortfolioID],

[Sedol],

[Income],

[EstimatedIncome],

[Quantity],

MarketValue

FROM Clientaccount..PulseHoldingsRawData

SET @RowsCopied = @RowsCopied + @@ROWCOUNT

INSERT INTO Clientaccount..PulsePrices

SELECT [Sedol],

[ValueDate],

[Price],

[Currency],

[PriceInGBP],

[PriceInUSD],

[PriceInEUR]

FROM Clientaccount..PulsePricesRawData /*Pulse Prices Table is not deleted, just concat new prices*/

SET @RowsCopied = @RowsCopied + @@ROWCOUNT
END TRY
BEGIN CATCH
END CATCH
IF @@ERROR <> 0

OR @RowsInRawTables <> @RowsCopied

OR (SELECT Count(* )

FROM Clientaccount..PulseTransactions) = 0

OR (SELECT Count(* )

FROM Clientaccount..PulseHoldings) = 0

OR (SELECT Count(* )

FROM Clientaccount..PulseSecurities) = 0

OR (SELECT Count(* )

FROM Clientaccount..PulsePortfolios) = 0

BEGIN

ROLLBACK TRANSACTION PulseDataCopyTransaction

SET @ResultValue = 0 

END

ELSE BEGIN

COMMIT TRANSACTION PulseDataCopyTransaction

SET @ResultValue  = 1 

END

SELECT @ResultValue As Result

GO
