/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>F7617F8EA12AE94F05DC964142D143A2</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE [dbo].[spAddEarlyAccrualPostingForChangeOfAdvisor](@ClAccountIdCSV varchar(max), @OldAdvisor varchar(30), @DateAdded smalldatetime)  
AS

/*
declare @ClAccountIdCSV varchar(max)
declare @oldAdvisor varchar(30)
declare @dateAdded smalldatetime

set @ClAccountIdCSV = 'el123458,el456789,el884455,el445566'
set @OldAdvisor = 'axa123456'
set @DateAdded = '2013/10/25'
*/

BEGIN

	/*put csv into temp table */
	SELECT tabvalue as ClAccountID  
	INTO #accounts
	FROM CSFBMaster.dbo.fn_convert_comma_to_table_char(@ClAccountIdCSV)

	--select * from #accounts

	/* We only ever insert one of these per client per day. 
	   This is to ensure the only entry in thie table contains the original advisor in case of errors and multiple change of advisors per day.*/
	INSERT INTO clientaccount..EarlyAccrualPostingForChangeOfAdvisor (ClAccountID, OldAdvisor, DateOfChange)
	SELECT AC.ClAccountID, @OldAdvisor, @DateAdded
	FROM #accounts AC
		LEFT JOIN clientaccount..EarlyAccrualPostingForChangeOfAdvisor EA on EA.DateOfChange = @DateAdded and EA.ClAccountID = AC.claccountID 
	WHERE EA.ClAccountID IS NULL


	IF OBJECT_ID('tempdb..#accounts')>0 DROP TABLE #accounts

END
GO