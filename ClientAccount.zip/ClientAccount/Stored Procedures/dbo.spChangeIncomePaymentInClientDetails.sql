/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>97FEC51F82B770B3ED71B13F52A79807</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO

/* 
====================================================================
 Author:		Jana Pospisilova
 Create date:	Apr 2013
 Description:	Changes IncomePaymentExternal and DRP in ClientAccount.dbo.ClientDetails 
====================================================================
*/

CREATE PROCEDURE [dbo].[spChangeIncomePaymentInClientDetails] (	
	@UserID as integer,
	@SubAccountId As Varchar(15),
	@TransactionId INT,
	@IncomePaymentExternal VARCHAR(50),
	@DRP INT = NULL)
AS

/*
DECLARE @SubAccountId AS Varchar(15),
		@TransactionId INT,
		@UserID AS integer

SET @SubAccountId = ''
SET @TransactionId = 
SET @UserID = 
*/

BEGIN
	BEGIN TRY

		SET NOCOUNT ON
			DECLARE @ProcedureName VARCHAR(100),
					@Processed VARCHAR(20),
					@ClAccountId VARCHAR(20),
					@TAbConst VARCHAR(70),
					@TabName VARCHAR(70),
					@Change VARCHAR(20),
					@ClAccountIdField VARCHAR(20),
					@FieldName VARCHAR(50),
					@FieldValue VARCHAR(50),
					@RowsAffected INT

			SELECT @Change = 'Change', @TabName = 'Client Details', @TAbConst = 'claClientDetails', @ClAccountIdField = 'ClAccountId', @Processed = 'Processed', @ProcedureName = 'spChangeIncomePaymentInClientDetails'
			
/* ======================= IncomePaymentExternal ========================== */

			SELECT @FieldName = 'IncomePaymentExternal', @FieldValue = @IncomePaymentExternal

			INSERT INTO clientaccount.dbo.clientchangelog
					   (authorised,
						callersource,
						changestatus,
						claccountid,
						datemodified,
						fieldname,
						identifier,
						identifierfield,
						modifiedby,
						newvalue,
						originalvalue,
						tableconstant,
						tablename,
						transactionid,
						TYPE)
			SELECT 1,
				   @ProcedureName,
				   @Processed,
				   dbo.Fngetheadaccountid(@SubAccountId),
				   Getdate(),
				   @FieldName,
				   claccountid,
				   @ClAccountIdField,
				   @UserID,
				   @FieldValue,
				   incomepaymentexternal,
				   @TAbConst,
				   @TabName,
				   @TransactionId,
				   @Change
			FROM   clientaccount.dbo.clientdetails
			WHERE  claccountid = @SubAccountId AND IncomePaymentExternal <> @IncomePaymentExternal		

			UPDATE ClientAccount.dbo.ClientDetails 
			SET IncomePaymentExternal = @IncomePaymentExternal
			WHERE CLAccountID = @SubAccountId AND IncomePaymentExternal <> @IncomePaymentExternal	

			SET @RowsAffected = @@ROWCOUNT

/* ======================= DRP ========================== */
		IF @Drp IS NOT NULL
		BEGIN
			SELECT @FieldName = 'DRP', @FieldValue = @DRP

			INSERT INTO clientaccount.dbo.clientchangelog
					   (authorised,
						callersource,
						changestatus,
						claccountid,
						datemodified,
						fieldname,
						identifier,
						identifierfield,
						modifiedby,
						newvalue,
						originalvalue,
						tableconstant,
						tablename,
						transactionid,
						TYPE)
			SELECT 1,
				   @ProcedureName,
				   @Processed,
				   dbo.Fngetheadaccountid(@SubAccountId),
				   Getdate(),
				   @FieldName,
				   claccountid,
				   @ClAccountIdField,
				   @UserID,
				   @FieldValue,
				   incomepaymentexternal,
				   @TAbConst,
				   @TabName,
				   @TransactionId,
				   @Change
			FROM   clientaccount.dbo.clientdetails
			WHERE  claccountid = @SubAccountId AND Drp <> @DRP	

			UPDATE ClientAccount.dbo.ClientDetails 
			SET DRP = @DRP
			WHERE CLAccountID = @SubAccountId AND Drp <> @DRP	
		END

		SET NOCOUNT OFF

		RETURN @RowsAffected + @@ROWCOUNT

	END TRY
	BEGIN CATCH
		SET NOCOUNT ON
		SELECT -1 As ErrCode, ERROR_MESSAGE() As ErrMessage, @ProcedureName As TableConstant
		SET NOCOUNT OFF
		RETURN -1
	END CATCH
END

/*
GO
GRANT EXECUTE ON [dbo].[spChangeIncomePaymentInClientDetails] TO [fnzs_rw]
GRANT VIEW DEFINITION ON [dbo].[spChangeIncomePaymentInClientDetails] TO [fnzc_ro]
GRANT VIEW DEFINITION ON [dbo].[spChangeIncomePaymentInClientDetails] TO [fnz_dev]
GRANT EXECUTE ON [dbo].[spChangeIncomePaymentInClientDetails] TO [fnz_dev]

GO
EXEC csfbmaster..Spupdatemetadb
  @DBName = 'ClientAccount' ,
  @TableName = 'spChangeIncomePaymentInClientDetails' ,
  @TableConstant = 'clapChangeIncomePaymentInClientDetails'
*/