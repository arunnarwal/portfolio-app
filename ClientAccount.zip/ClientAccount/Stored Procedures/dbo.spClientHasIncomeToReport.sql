/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>78EFD469B74D031E57FC22C5A46226CF</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[spClientHasIncomeToReport] (@ClAccountID varchar(20), @FromDate datetime, @ToDate datetime, @IncomeType varchar(20)) AS

IF @IncomeType = 'Dividend'
	Select Count(*) as Num
	From IncomeSummary INC INNER JOIN Consolidate C ON C.ClAccountID = INC.ClAccountID
	Where C.ClAccountID = @ClAccountID and LedgerDate >= @FromDate and LedgerDate < @ToDate + 1 and Reversal is null
	Group By C.ClAccountID

ELSE IF @IncomeType = 'Coupon'
	Select Count(*) as Num
	From InterestIncome INC INNER JOIN Consolidate C ON C.ClAccountID = INC.ClAccountID
	Where C.ClAccountID = @ClAccountID and PayDate >= @FromDate and PayDate < @ToDate + 1 and Reversal is null
	Group By C.ClAccountID

ELSE IF @IncomeType = 'Rebate'
	Select Count(*) as Num
	From Discovery..Rebate INC INNER JOIN Consolidate C ON C.ClAccountID = INC.ClAccountID
	Where C.ClAccountID = @ClAccountID and AsAt >= @FromDate and AsAt < @ToDate + 1
	Group By C.ClAccountID

ELSE IF @IncomeType = 'Fee'
	Select Count(*) as Num
	From Discovery..AdvisorRevenueLedger INC INNER JOIN Consolidate C ON C.ClAccountID = INC.ClAccountID
	Where C.ClAccountID = @ClAccountID and LedgerDate >= @FromDate and LedgerDate < @ToDate + 1 And TranType LIKE '%Fee'
	Group By C.ClAccountID
GO
