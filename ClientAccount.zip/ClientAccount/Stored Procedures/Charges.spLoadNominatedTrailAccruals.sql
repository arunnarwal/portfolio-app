/***
<StoredProcedure>
    <Description>Loads nominated trail accruals from the Platform ETL (fnz charges) staging tables into the fnz one database</Description>
    <Service>Charges</Service>
    <Feature>Charges</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE [Charges].[spLoadNominatedTrailAccruals] AS
BEGIN	
	DECLARE @DateCreated DATETIME = GetDate()

	INSERT INTO dbo.Fee_Accrual_NominatedTrail	(
		AsAt,
		ChargeDate,
		SubAccountId,
		AdviserId,
		Valuation,
		Rate,
		Amount,
		CurrencyId,
		DateCreated)
	SELECT 	
		nta.AsAt,
		DATEADD(d, 1, EOMONTH(nta.AsAt)) as ChargeDate, --Gets the first day of the next month
		nta.SubAccountId,
		adv.Id,
		nta.Valuation,
		nta.Rate,
		nta.Amount, 
		nta.CurrencyId,
		@DateCreated
	FROM PlatformETL.RebatesStaging.NominatedTrailAccruals nta
	INNER JOIN dbo.SEClientAccount seca on seca.Id = nta.SubAccountId
	INNER JOIN dbo.Advisor adv on adv.AdvCode = seca.PrimaryAdviser
END	
