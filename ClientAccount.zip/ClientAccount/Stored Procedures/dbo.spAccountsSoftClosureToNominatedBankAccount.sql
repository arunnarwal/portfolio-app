SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Luis Santamarta
-- Create date: 26/01/2015
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[spAccountsSoftClosureToNominatedBankAccount](@AsAt as Datetime)
AS
BEGIN

	--DECLARE @AsAt as DateTime
	--SET @AsAt = '26 Jan 2015'

	SELECT CE.AccountNumber,
		   A.Claccountid,
           A.Ccycode,
           A.WrapProvider,
           A.CLTbalance,
           A.CMTbalance,
           A.CLAbalance,
           A.CLAAvailableAdjustBalance,
           A.CLAPortfolioAdjustBalance,
           A.Withdrawals,
           A.BuyOrders,
           A.InsuredFundsBuyOrders,
           A.SellOrders,
           A.SellOrdersSameBatch,
           A.AvailableBalance,
           A.UnclearedCheques,
           A.DealsInProgress,
           A.SellDealsInProgress,
           A.BuyDealsInProgress,
           A.FeeExpectations,
           A.UnsettledCash,
           A.UnclearedDeposits,
           A.SettlingToday,
           A.SwitchSellOrders
	FROM dbo.fnAvailableCashBalancebyCCY(@AsAt, 0) A
		INNER JOIN Discovery.dbo.ProductDetails PD ON PD.Claccountid = A.Claccountid -- We have to be sure they are only from 2 specific Wrappers
		INNER JOIN Discovery.dbo.ClientAccount CA ON A.Claccountid = CA.Claccountid  -- The account must be in Closing status only
		INNER JOIN Discovery.dbo.CashEntry CE ON CE.Claccountid = CA.ClAccountID     -- Final Payment out must be done already
		INNER JOIN (
					SELECT Distinct Reason , Identifier
					FROM dbo.ClientChangeLog
					WHERE NewValue ='Closing'
				   ) as CH ON CH.Identifier = CA.ClAccountID and CH.Reason IS NOT NULL -- The reason for closure must be different from "Transferred out"
	WHERE CE.FullWithdrawal=1 AND CE.InstructionType='One-Off' AND
		  CA.Status= 'Closing' AND
		  PD.ProductType in('Stocks/Shares','Personal Portfolio','Cash') AND
		  CH.Reason <> 'Transferred Out'

END
GO
