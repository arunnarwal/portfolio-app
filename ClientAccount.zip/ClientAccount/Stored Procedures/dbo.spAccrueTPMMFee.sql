/***  
<StoredProcedure>  
    <Description>Accrue the Tiered Per Member (Employee)</Description>  
 <Service>Charges</Service>  
    <Feature>Tasks</Feature>  
    <Parameters>  
        <Parameter Name="@AsAt">  
            <Description>The date of the fee run</Description>  
        </Parameter>  
    </Parameters>  
</StoredProcedure>  
***/  
  
CREATE PROCEDURE [dbo].[spAccrueTPMMFee] (@AsAt DATETIME)  AS  
  
--DECLARE @AsAt SMALLDATETIME  
--SET @AsAt = '05 May 2014'  
  
BEGIN TRY  
 BEGIN TRANSACTION T1  
 
 DECLARE @TranType VARCHAR(10)  
 SET @TranType = 'TPMM'  
  
 DECLARE @TranTypeId INT
 SET @TranTypeId = (SELECT id FROM dbo.FeeTranTypes WHERE TranType = @TranType)
  
SELECT  
 tempPropotion.ToBeAppliedFeesId
 ,tempPropotion.Valuation
 ,tempPropotion.AsAt  
 ,tempPropotion.SECAId  
 ,tempPropotion.HeadSecaId
 ,tempPropotion.CurrencyId 
 ,tempPropotion.WrapProviderId
 ,tempPropotion.FeeTranTypesId
 ,tempPropotion.ProductType
 ,CASE WHEN ROW_NUMBER() OVER(PARTITION BY HeadClAccountID,ProductType ORDER BY tempPropotion.Propotion DESC) = 1 
 THEN tempPropotion.Propotion + 1 - SUM(tempPropotion.Propotion) OVER(PARTITION BY tempPropotion.HeadClAccountID,ProductType)
 ELSE tempPropotion.Propotion END AS Proportion  
 ,tempPropotion.Rate
 INTO #AccrualProportion  
 FROM (
 SELECT 
 ToBeApplied.Id AS ToBeAppliedFeesId
 ,s.ClAccountId
 ,h.ClAccountId as HeadClAccountId
 ,ROUND(COALESCE((Fum.CashAmount + Fum.NonCashAmount), 0), 4) AS Valuation 
 ,Fum.AsAt  
 ,Fum.SECAId 
 ,h.Id As HeadSecaId  
 ,Fum.CurrencyId 
 ,Fum.WrapProviderId
 ,ToBeApplied.FeeTranTypesId
 ,ROUND(COALESCE((Fum.CashAmount + Fum.NonCashAmount), 0) / SUM(Fum.CashAmount + Fum.NonCashAmount) OVER(PARTITION BY fh.HeadClAccountID, pd.ProductType), 2, 1) AS Propotion  
 ,ToBeApplied.Rate
 ,pd.ProductType
 FROM dbo.fnHeadAccounts() fh
 INNER JOIN dbo.SEClientAccount s ON fh.ClAccountId = s.ClAccountId
 INNER JOIN dbo.SEClientAccount h ON fh.HeadClAccountId = h.ClAccountId
 INNER JOIN Cache.dbo.Fee_FUM_ByAccount Fum ON Fum.SECAId = s.Id
 INNER JOIN Discovery.dbo.ProductDetails pd ON pd.ClAccountId = s.ClAccountId
 INNER JOIN dbo.ToBeAppliedFees_ByAccV2 AS ToBeApplied
  ON ToBeApplied.AsAt = Fum.AsAt  
   AND s.Id = ToBeApplied.SECAId  
   AND ToBeApplied.Applied = 0   
 WHERE fh.Consolidated = 0 AND fh.ClAccountID <> fh.HeadClAccountID 
	AND Fum.AsAt = @AsAt 
	AND (Fum.CashAmount + Fum.NonCashAmount) > 0
	AND ToBeApplied.FeeTranTypesID = @TranTypeId
) tempPropotion
  
SELECT   
  Fum.ToBeAppliedFeesId  
  ,Fum.AsAt  
  ,Fum.SECAId  
  ,Fum.Valuation  
  ,CASE WHEN ROW_NUMBER() OVER(PARTITION BY Fum.HeadSecaId,Fum.ProductType ORDER BY Fum.Proportion DESC) = 1 
 THEN ROUND(COALESCE(Fum.Rate, 0) * Fum.Proportion, 2, 1) + COALESCE(Fum.Rate, 0) - SUM(ROUND(COALESCE(Fum.Rate, 0) * Fum.Proportion, 2, 1)) OVER(PARTITION BY Fum.HeadSecaId,Fum.ProductType)
 ELSE ROUND(COALESCE(Fum.Rate, 0) * Fum.Proportion, 2, 1) END AS Amount
  ,COALESCE(Fum.Rate, 0) AS Rate  
  ,FRQRanged.ToDate As ChargeDate 
  ,0 AS IsProcessed,  
  Fum.CurrencyId  
 INTO #Accruals
 FROM #AccrualProportion AS Fum   
 INNER JOIN dbo.[SEClientAccount] AS Seca  
  ON Seca.Id = Fum.SECAId  
 INNER JOIN dbo.[WrapProvider] AS WrapProvider  
  ON WrapProvider.Id = Fum.WrapProviderId  
 INNER JOIN dbo.FeeTranTypes AS FeeTranTypes  
  ON FeeTranTypes.TranType = @TranType
   AND FeeTranTypes.WrapProvider = WrapProvider.WrapProvider  
   AND FeeTranTypes.Id = Fum.FeeTranTypesId  
 CROSS APPLY dbo.fnGetDateRangesForFrequencies(@AsAt,DATEADD(dd, 0, DATEDIFF(dd, 0, Seca.DateCreated + 1))) FRQRanged  
 WHERE FRQRanged.Frequency = 'M' /** Should this be moved somewhere????? **/  
 AND Fum.AsAt = @AsAt   
  
 DROP TABLE #AccrualProportion 

 INSERT INTO dbo.Fee_Accrual_TPMM (  
  AsAt  
  ,SecaId  
  ,Valuation  
  ,Amount  
  ,ChargeDate  
  ,IsProcessed  
  ,CurrencyId  
  )  
 SELECT AsAt  
  ,#Accruals.SECAId  
  ,#Accruals.Valuation  
  ,#Accruals.Amount  
  ,DATEADD(dd, 0, DATEDIFF(dd, 0, #Accruals.ChargeDate))  
  ,#Accruals.IsProcessed  
  ,#Accruals.CurrencyId  
 FROM #Accruals  
END TRY  
  
BEGIN CATCH  
 ROLLBACK TRANSACTION T1  
  
 DECLARE @ErrorMessage NVARCHAR(4000);  
 DECLARE @ErrorSeverity INT;  
 DECLARE @ErrorState INT;  
  
 IF OBJECT_ID(N'tempdb..#Accruals', N'U') IS NOT NULL  
 BEGIN  
  DROP TABLE #Accruals  
 END  
  
 SELECT @ErrorMessage = ERROR_MESSAGE()  
  ,@ErrorSeverity = ERROR_SEVERITY()  
  ,@ErrorState = ERROR_STATE();  
  
 RAISERROR (  
   @ErrorMessage  
   ,@ErrorSeverity  
   ,@ErrorState  
   );  
END CATCH;  
  
IF @@TRANCOUNT > 0  
BEGIN  
 SELECT 'Success' AS Result
  
 UPDATE dbo.ToBeAppliedFees_ByAccV2   
 SET Applied = 1  
  ,ProcessedDate = GETDATE()  
 WHERE Id IN (  
   SELECT ToBeAppliedFeesId  
   FROM #Accruals  
   )  
  
 INSERT INTO dbo.AppliedFees_ByAccV2 (  
  [FeeTranTypesID]  
  ,[SecaId]  
  ,[Rate]  
  ,[ProcessedDate]  
  ,[DateCreated]  
  ,[AsAt]  
  ,[ApplyVAT]  
  )  
 SELECT ToBeApplied.[FeeTranTypesId]  
  ,ToBeApplied.[SECAId]  
  ,ToBeApplied.[Rate]  
  ,ToBeApplied.[ProcessedDate]  
  ,ToBeApplied.[DateCreated]  
  ,ToBeApplied.[AsAt]  
  ,ToBeApplied.[ApplyVAT]  
 FROM dbo.ToBeAppliedFees_ByAccV2 ToBeApplied  
 WHERE ToBeApplied.Id IN (  
   SELECT Accruals.ToBeAppliedFeesId  
   FROM #Accruals Accruals  
   )  
  
 DELETE dbo.ToBeAppliedFees_ByAccV2  
 WHERE Id IN (  
   SELECT ToBeAppliedFeesId  
   FROM #Accruals Accruals  
   )  
  
 DROP TABLE #Accruals  

 COMMIT TRANSACTION T1  
END  
