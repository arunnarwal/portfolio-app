/***
<StoredProcedure>
    <Description>Get static charge schedule for account and market jurisdiction</Description>
    <Service>Charges</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE [Charges].[spGetStaticChargeSchedule] (
	@ClAccountId VARCHAR(20),
	@JurisdictionId INT
)
AS
BEGIN

--DECLARE @ClAccountId VARCHAR(20);
--DECLARE @JurisdictionId INT;
--SET @ClAccountId = 'DM1009770';
--SET @JurisdictionId = 62;

SELECT
	SEC.ClAccountId,
	COALESCE(MAP_ACC.StaticScheduleId,MAP_COM.StaticScheduleId,MAP_WP.StaticScheduleId,MAP_SYST.StaticScheduleId) AS StaticScheduleId,
	COALESCE(MAP_ACC.HierarchyLevelId,MAP_COM.HierarchyLevelId,MAP_WP.HierarchyLevelId,MAP_SYST.HierarchyLevelId) AS HierarchyLevelId,
	COALESCE(MAP_ACC.MarketJurisdictionId,MAP_COM.MarketJurisdictionId,MAP_WP.MarketJurisdictionId,MAP_SYST.MarketJurisdictionId) AS MarketJurisdictionId
INTO #HierarchyScheduleMapping
FROM
	[dbo].SEClientAccount SEC 
	INNER JOIN [dbo].Advisor ADV ON SEC.PrimaryAdviser = ADV.AdvCode 
	INNER JOIN [dbo].Company COM ON ADV.Company = COM.Company
	INNER JOIN [dbo].WrapProvider WP ON COM.WrapProvider = WP.WrapProvider
	INNER JOIN [dbo].SystemProvider SYST ON WP.SystemProvider = SYST.SystemProvider
	LEFT JOIN [Charges].[StaticScheduleMapping] MAP_SYST ON MAP_SYST.HierarchyLevelId = 1 --SYSTEM PROVIDER
															AND MAP_SYST.EntityId = SYST.Id
															AND MAP_SYST.MarketJurisdictionId = @JurisdictionId
	LEFT JOIN [Charges].[StaticScheduleMapping] MAP_WP ON 	MAP_WP.HierarchyLevelId = 2 --WRAP PROVIDER
															AND MAP_WP.EntityId = WP.Id
															AND MAP_WP.MarketJurisdictionId = @JurisdictionId
	LEFT JOIN [Charges].[StaticScheduleMapping] MAP_COM ON  MAP_COM.HierarchyLevelId = 4 --COMPANY
															AND MAP_COM.EntityId = COM.Id
															AND MAP_COM.MarketJurisdictionId = @JurisdictionId
	LEFT JOIN [Charges].[StaticScheduleMapping] MAP_ACC ON 	MAP_ACC.HierarchyLevelId = 6 --CLIENT ACCOUNT
															AND MAP_ACC.EntityId = SEC.Id
															AND MAP_ACC.MarketJurisdictionId = @JurisdictionId
WHERE
	SEC.ClAccountId = @ClAccountId

SELECT
	MAP.StaticScheduleId,
	MAP.HierarchyLevelId,
	COU.Currency_Code AS CurrencyCode,
	TIER.StaticScheduleTierId,
	TIER.FeeType,
	TIER.FeeValue,
	TIER.TierFrom,
	TIER.TierTo
FROM 
	#HierarchyScheduleMapping MAP
	INNER JOIN [Charges].[StaticScheduleTiers] TIER ON MAP.StaticScheduleId = TIER.StaticScheduleId
	INNER JOIN [Res_Db].dbo.[Country] COU ON COU.Id = MAP.MarketJurisdictionId

DROP TABLE #HierarchyScheduleMapping

END