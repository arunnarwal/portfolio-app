/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>F522D44D9C1FE14375A52CDA04871775</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[spClientCompanyMove] (@ClAccountID varchar(20), @AdviserCode varchar(20), @CompanyCode varchar(20)) AS

DECLARE @ErrorMessage varchar(max)

SET NOCOUNT ON

BEGIN TRANSACTION

BEGIN TRY

--Update PrimaryAdviser in SEClientAccount

UPDATE SEClientAccount

SET PrimaryAdviser = @AdviserCode

WHERE ClAccountID IN (

SELECT ClAccountID FROM fnHeadAccounts() HA WHERE HA.Headclaccountid = @ClAccountID

)

END TRY

BEGIN CATCH

SET @ErrorMessage = error_message()

GOTO HANDLE_ERROR

END CATCH

BEGIN TRY

--Update Company in ClientDetails

UPDATE ClientDetails

SET Company = @CompanyCode

WHERE ClAccountID IN (

SELECT ClAccountID FROM fnHeadAccounts() HA WHERE HA.Headclaccountid = @ClAccountID

)

END TRY

BEGIN CATCH

SET @ErrorMessage = error_message()

GOTO HANDLE_ERROR

END CATCH

BEGIN TRY

--Update AdvCode and Company in advisorrevenueledger

UPDATE Discovery..advisorrevenueledger

SET AdvCode = @AdviserCode,

Company = @CompanyCode

WHERE ClAccountID IN (

SELECT ClAccountID FROM fnHeadAccounts() HA WHERE HA.Headclaccountid = @ClAccountID

) and glposted = 'NO'

END TRY

BEGIN CATCH

SET @ErrorMessage = error_message()

GOTO HANDLE_ERROR

END CATCH

BEGIN TRY

--Update Company in OBSR models

UPDATE res_db..instrumentsettings

SET name = @CompanyCode

WHERE instrumentcode IN (

SELECT DCA.claccountid FROM discovery..clientaccount DCA

inner join discovery..modelportfolio MP ON DCA.portfolioid = MP.portfolioid

WHERE DCA.claccountid IN (

SELECT ClAccountID FROM fnHeadAccounts() HA WHERE HA.Headclaccountid = @ClAccountID

) and MP.type='OBSR' and DCA.status <> 'Closed'

) and type = 'company'

END TRY

BEGIN CATCH

SET @ErrorMessage = error_message()

GOTO HANDLE_ERROR

END CATCH

BEGIN TRY

--Update company in tblclients

UPDATE clientdb3..tblclients

SET company = @CompanyCode

WHERE ClientID IN (

SELECT CAS.ClientID FROM clientaccount..clientaccountsecurity CAS

INNER JOIN WebDB..UsersToGroups UTG on UTG.ClientID = CAS.ClientID and UTG.UserGroupID = 4238 /* RO client acces */

WHERE ClAccountID = @ClAccountID

)

END TRY

BEGIN CATCH

SET @ErrorMessage = error_message()

GOTO HANDLE_ERROR

END CATCH

BEGIN TRY

--Update advisorcodes and companies in clientaccountsecurity

UPDATE clientaccountsecurity

SET advisorcodes = @AdviserCode,

companies = @CompanyCode

WHERE ClAccountID IN (

SELECT ClAccountID FROM fnHeadAccounts() HA WHERE HA.Headclaccountid = @ClAccountID

)

END TRY

BEGIN CATCH

SET @ErrorMessage = error_message()

GOTO HANDLE_ERROR

END CATCH

COMMIT TRANSACTION

SELECT null as ErrorMessage

HANDLE_ERROR:

ROLLBACK TRANSACTION

SELECT @ErrorMessage as ErrorMessage
GO
