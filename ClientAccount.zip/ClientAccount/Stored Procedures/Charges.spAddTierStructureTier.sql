/***
<StoredProcedure>
    <Description>Adds a tier to a tier structure</Description>
	<Parameters>
		<Parameter Name="@TierStructureId">
			<Description>The Id of the tier structure to add to</Description>
		</Parameter>
		<Parameter Name="@LowerLimit">
			<Description>The lower limit of the tier</Description>
		</Parameter>
		<Parameter Name="@UpperLimit">
			<Description>The upper limit of the tier, NULL if no upper limit</Description>
		</Parameter>
		<Parameter Name="@Rate">
			<Description>The tier rate</Description>
		</Parameter>
	</Parameters>	
</StoredProcedure>
***/
CREATE PROCEDURE Charges.spAddTierStructureTier (
	@TierStructureId INT,
	@LowerLimit NUMERIC(19,2),
	@UpperLimit NUMERIC(19,2) = NULL,
	@Rate NUMERIC(5,2)) AS

	DECLARE @BoundaryId AS SMALLINT
	EXEC Res_DB.Charges.spAddTierBoundary @LowerLimit, @UpperLimit, @BoundaryId OUTPUT

	INSERT INTO Charges.TierStructureTiers
	(TierStructureId, TierBoundaryId, Rate)      
	VALUES
	(@TierStructureId, @BoundaryId, @Rate)
