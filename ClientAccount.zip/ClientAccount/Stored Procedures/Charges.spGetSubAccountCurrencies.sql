/***
<StoredProcedure>
    <Description>Gets sub accounts currencies - not required in this platform so return no data</Description>
    <Service>Charges</Service>
    <Feature>Charges</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE Charges.spGetSubAccountCurrencies
AS
BEGIN

DECLARE @EmptySubAccountCurrencies TABLE ( SubAccountId INT, CurrencyId INT )

SELECT SubAccountId, CurrencyId FROM @EmptySubAccountCurrencies

END
GO
