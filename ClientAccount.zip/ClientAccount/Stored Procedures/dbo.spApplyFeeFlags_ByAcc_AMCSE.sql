/***
<StoredProcedure>
    <Description>Permissions clients client fee FUM flags for AMC Scheme Fee (Employer)</Description>
	<Service>Charges</Service>
    <Feature>Tasks</Feature>
    <Parameters>
        <Parameter Name="@AsAt">
            <Description>The date of the fee run</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/

CREATE PROCEDURE [dbo].[spApplyFeeFlags_ByAcc_AMCSE] (@AsAt DATETIME) AS

    --DECLARE @AsAt DATETIME 
    --SET @AsAt = '08 May 2014'

    DECLARE @TranType VARCHAR(10)
    SET @TranType = 'AMCSE';

    SELECT 	
	    SchemeDetails.Id As SchemeId
	    ,Count(*) AS MemberCount 
    INTO #MemberCounts
    FROM dbo.CorporateSchemeDetails SchemeDetails
    INNER JOIN dbo.CorporateMemberSchemeDetails MemberDetails
	    ON MemberDetails.SchemeId = SchemeDetails.Id
    GROUP BY SchemeDetails.Id

    SELECT 
	    Fum.SecaId AS SecaId
	    ,SchemeDetails.Id AS SchemeId
	    ,Fum.AsAt AS AsAt 
	    ,FeeTranTypes.Id AS FeeTranTypesID
	    ,CAmcTiers.TierRate AS Rate
	    ,0 AS ApplyVAT 
	    ,Fum.CashAmount + Fum.NonCashAmount FumTotal
	    ,EmployerFRQRanged.ToDate AS EmployerChargeDate
    INTO #FeeAccrual
    FROM Cache.dbo.Fee_FUM_ByAccount Fum
    INNER JOIN dbo.WrapProvider WrapProvider
	    ON Fum.WrapProviderId = WrapProvider.ID
    INNER JOIN dbo.FeeTranTypes AS FeeTranTypes
	    ON FeeTranTypes.TranType = @TranType AND FeeTranTypes.WrapProvider = WrapProvider.WrapProvider 
    INNER JOIN dbo.Advisor Advisor
	    ON Fum.AdvisorId = Advisor.Id
    INNER JOIN dbo.CorporateSchemeDetails SchemeDetails
	    ON SchemeDetails.AdvisorCode = Advisor.AdvCode
    INNER JOIN dbo.SEClientAccount SecaId
	    ON SecaId.Id = Fum.SecaId
    INNER JOIN Discovery.dbo.ProductDetails ProductDetails
	    ON ProductDetails.ClAccountId = SecaId.ClAccountID
    INNER JOIN #MemberCounts MemberCounts
	    ON MemberCounts.SchemeId = SchemeDetails.Id
    INNER JOIN dbo.CorporateTieredAMC CAmc
	    ON CAmc.SchemeId = SchemeDetails.Id  
	    AND CAmc.FeeTranTypeId = FeeTranTypes.Id 
	    AND CAmc.ProductType = ProductDetails.ProductType  
	    And @AsAt  >= CAmc.FromDate And ( CAmc.ToDate IS NULL OR @AsAt <= CAmc.ToDate )
    INNER JOIN  dbo.CorporateTieredAMCTiers CAmcTiers
	    ON CAmcTiers.CorporateTieredAMCId = CAmc.Id
    AND MemberCounts.MemberCount >= CAmcTiers.FromRange AND (CAmcTiers.ToRange IS NULL OR MemberCounts.MemberCount <= CAmcTiers.ToRange )

    /** Employer Reserve Account **/
    INNER JOIN dbo.CorporateSchemeEmployerDetails  EmployerDetails
	    ON EmployerDetails.Id = SchemeDetails.Employerdetailsid 
    INNER JOIN dbo.CorporateEmployer Employer
	    ON Employer.Id = EmployerDetails.EmployerID 
    INNER JOIN dbo.Branches Branches
	    ON Branches.Id = Employer.BranchId 
    INNER JOIN dbo.Advisor EmployerAdvisor 
	    ON EmployerAdvisor.BranchID = Branches.Id 
    INNER JOIN dbo.SEClientAccount EmployerSeca
	    ON EmployerSeca.PrimaryAdviser = EmployerAdvisor .Advcode AND EmployerSeca.InvestorType = 'EmployerReserve'
    INNER JOIN dbo.fnHeadAccounts() Head 
	    ON EmployerSeca.ClAccountID = Head.ClAccountID and Head.Consolidated = 0 AND Head.ClAccountID <> Head.HeadClAccountID
    /** END of Employer Reserve Account **/

    LEFT JOIN dbo.AppliedFees_ByAccV2 AS Applied
	    ON Applied.AsAt = @AsAt
		    AND Applied.SecaId = Fum.SecaId
		    AND Applied.FeeTranTypesID = FeeTranTypes.Id
    CROSS APPLY dbo.fnGetDateRangesForFrequencies(@AsAt,DATEADD(dd, 0, DATEDIFF(dd, 0, EmployerSeca.DateCreated + 1))) EmployerFRQRanged
    WHERE 
	    Fum.AsAt = @AsAt 
	    AND Applied.ID IS NULL
	    AND 'M' = EmployerFRQRanged.Frequency
	    AND EmployerFRQRanged.ToDate = @asAt 
	    AND NOT EXISTS (SELECT 1 FROM dbo.Fee_Fum_ExcludeAccountTypes EXAT 
			    WHERE EXAT.WrapProviderID = Fum.WrapProviderID 
			    AND EXAT.FeeTranTypeID = FeeTranTypes.ID 
			    AND EXAT.AccountType = SecaId.InvestorType)


    INSERT INTO dbo.ToBeAppliedFees_ByAccV2 (
	    SecaId
	    ,[AsAt]
	    ,FeeTranTypesID
	    ,Applied
	    ,Rate
	    ,ApplyVAT
	    )
    SELECT FeeAccrual.SecaId
	    ,FeeAccrual.[AsAt]
	    ,FeeAccrual.FeeTranTypesID
	    ,0 As Applied/*Applied*/
	    ,FeeAccrual.Rate
	    ,FeeAccrual.ApplyVAT
    FROM #FeeAccrual as FeeAccrual
    LEFT JOIN dbo.ToBeAppliedFees_ByAccV2 as ToBeApplied
	    ON FeeAccrual.SecaId = ToBeApplied.SecaId 
	    AND FeeAccrual.AsAt = ToBeApplied.AsAt 
	    AND FeeAccrual.FeeTranTypesID = ToBeApplied.FeeTranTypesID
    WHERE ToBeApplied.SecaId IS NULL and FeeAccrual.Rate > 0 and FeeAccrual.FumTotal > 0

    INSERT INTO dbo.NonAppliedFees_ByAccV2 (
	    SecaId
	    ,[AsAt]
	    ,FeeTranTypesID
	    ,Status_NoteID
	    )
    SELECT FeeAccrual.SecaId
	    ,FeeAccrual.[AsAt]
	    ,FeeAccrual.FeeTranTypesID
	    ,0 As Status_NoteID
    FROM #FeeAccrual as FeeAccrual
    LEFT JOIN dbo.NonAppliedFees_ByAccV2 as NotToBeApplied
	    ON FeeAccrual.SecaId = NotToBeApplied.SecaId 
	    AND FeeAccrual.AsAt = NotToBeApplied.AsAt 
	    AND FeeAccrual.FeeTranTypesID = NotToBeApplied.FeeTranTypesID
    WHERE NotToBeApplied.SecaId IS NULL and FeeAccrual.Rate = 0 and FeeAccrual.FumTotal = 0

    DROP TABLE #FeeAccrual
    DROP TABLE #MemberCounts

GO