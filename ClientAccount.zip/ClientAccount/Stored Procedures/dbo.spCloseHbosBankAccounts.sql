

CREATE PROCEDURE [dbo].[spCloseHbosBankAccounts]
@AsAt DateTime, 
@sortCode VARCHAR(6) = NULL
AS
UPDATE GCBA
	SET GCBA.Status = 'CLOSED', 
		GCBA.StatusLastUpdated = GETDATE()
	FROM dbo.GladClientBankAccount GCBA 
	WHERE GCBA.SortCode = @sortCode AND 
	NOT EXISTS (
		SELECT 1 
		FROM dbo.HbosBalanceSummary BS 
		WHERE BS.AccountNumber = GCBA.AccountNumber 
		AND BS.SortCode = GCBA.SortCode 
		AND DATEADD(dd, 0, DATEDIFF(dd, 0, BS.Date)) = DATEADD(dd, 0, DATEDIFF(dd, 0, @AsAt))
	);
GO
