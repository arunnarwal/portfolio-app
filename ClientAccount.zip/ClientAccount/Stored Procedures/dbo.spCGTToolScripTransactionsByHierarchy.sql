CREATE PROCEDURE dbo.spCGTToolScripTransactionsByHierarchy
	@HierarchyEntityId INTEGER
AS

/*
 USE ClientAccount

 DECLARE @HierarchyEntityId INTEGER

 SELECT @HierarchyEntityId = 5517

-- */

SELECT
	st.Cost * CASE	WHEN ISNULL(FXCost, 0) = 0 THEN 1
				    ELSE FXCost
		      END AS Cost
,	COALESCE(st.CncyCode,
			 st.SettlementCcy) CncyCode
,	st.TransDate
,	st.AsAt
,	st.TransSource
,	st.TransType
,	st.FxCost
,	st.Group1
,	st.Group2
,	epp.ExternalPropositionProductId
,	ca.EventId
,	streq.PolicyNumber
,	t.TradeDate
,	st.Quantity
FROM dbo.ScripTransactions st
INNER JOIN Res_Db.dbo.Instruments i
	ON st.InstrumentCode = i.Security
INNER JOIN dbo.vwAccountPlatformMembership apm
	ON st.ClAccountId = apm.ClAccountId
INNER JOIN dbo.HierarchyEntities he
	ON st.ClAccountId = he.EntityCOde
INNER JOIN dbo.ExternalProposition ep
	ON apm.PlatformId = ep.Id
INNER JOIN dbo.ExternalPropositionProductIds epp
	ON ep.ExternalPropositionEnvironmentId = epp.ExternalPropositionEnvironmentId
	   AND i.Id = epp.ProductId
LEFT JOIN CorporateActions.dbo.CorporateAction ca
	ON st.CorpActId = ca.Id
LEFT JOIN Discovery.dbo.ScripTransferRequest streq
	ON st.AwScripTransferId = streq.RequestId
LEFT JOIN dbo.Trades t
	ON st.TradeId = t.Id
WHERE st.TransStatus = 'Settled'
	AND st.TransType <> 'MFRollFwd'
	AND st.Location = 'Registry'
	AND st.Cutover = 0
	AND NOT EXISTS (
		SELECT 1
		FROM Res_Db.dbo.Bonds b
		WHERE b.Bond_Code = st.InstrumentCode
			AND BondType = 'Gilt')
	AND he.HierarchyEntityId = @HierarchyEntityId
ORDER BY st.TransId
