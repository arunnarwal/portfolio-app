/***
<StoredProcedure>
    <Description>Loads MFR rebate accruals from the Platform ETL (fnz charges) staging tables into the fnz one database</Description>
    <Service>Charges</Service>
    <Feature>Charges</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE [Charges].[spLoadRebateAccruals] AS
BEGIN	
	DECLARE @DateCreated DATETIME = GetDate()

	INSERT INTO dbo.Fee_Accrual_MFR	(
		AsAt,
		ChargeDate,
		SECAId,
		AdviserId,
		ChargeBasisId,
		InstrumentId,
		Valuation,
		Units,
		Rate, --trail rate also - add later into fnz charges if needed
		TotalAmount,
		TrailAmount,
		CurrencyId,
		DateCreated)
	SELECT 	
		ra.AsAt,
		DATEADD(d, 1, EOMONTH(ra.AsAt)) as ChargeDate, --Gets the first day of the next month
		ra.SubAccountId,
		adv.Id,
		ra.RebateCategoryId,
		ra.InstrumentId,
		ra.Valuation,
		ra.Quantity,
		ra.Rate,
		-ra.TotalAmount, 
		-ra.TrailAmount, 
		ra.CurrencyId,
		@DateCreated
	FROM PlatformETL.RebatesStaging.RebateAccruals ra
	INNER JOIN dbo.SEClientAccount seca on seca.Id = ra.SubAccountId
	INNER JOIN dbo.Advisor adv on adv.AdvCode = seca.PrimaryAdviser
	WHERE NOT EXISTS (SELECT 1 FROM dbo.Fee_Accrual_MFR MFR WHERE AsAt = ra.AsAt AND InstrumentId = ra.InstrumentId AND SecaId = ra.SubAccountId)
END	



