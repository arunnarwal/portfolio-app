/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>C64E4056BEF50D9606CE938FB224E510</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE Procedure [dbo].[spClosingBankAndLedgerBalances](@Table1MatchField varchar(100), @Table1Name varchar(100), @Table1DateField varchar(100),
		@StaticCriteria1 varchar(2000), @Table2MatchField varchar(100), @Table2Name varchar(100), @Table2DateField varchar(100),
		@StaticCriteria2 varchar(2000), @DateParam varchar(20) )  WITH RECOMPILE AS
DECLARE @SqlStatement varchar(8000)

SELECT @SqlStatement = 	' SELECT TableName, SUM(Balance) AS Total' +
			' FROM ' +
				'(SELECT ''Table1ClosingBalance'' as TableName, SUM(T1.' + @Table1MatchField + ') AS Balance ' +
				' FROM ' + @Table1Name + ' T1 ' +
				' WHERE T1.' + @Table1DateField + ' < CONVERT(DATETIME, ''' + @DateParam + ''', 102)  ' +  @StaticCriteria1 +
			' UNION ALL ' +
				'SELECT ''Table2ClosingBalance'', SUM(T2.' + @Table2MatchField + ') ' +
				'FROM ' + @Table2Name + ' T2 ' +
				' WHERE T2.' + @Table2DateField + ' < CONVERT(DATETIME, ''' + @DateParam + ''', 102)  '  + @StaticCriteria2 +
				') DTBL ' +
			'GROUP BY TableName'			
EXEC (@SqlStatement)
GO





GO
