/***
<StoredProcedure>
    <Description>Gets a tier structure by TierStructureId</Description>
	<Parameters>
		<Parameter Name="@TierStructureId">
			<Description>The id of the tier structure</Description>
		</Parameter>
	</Parameters>	
</StoredProcedure>
***/
CREATE PROCEDURE Charges.spGetTierStructure (@TierStructureId INT) AS

	SELECT
		ts.TierStructureId,
		ts.TierStructureName,
		ts.OwnerHierarchyLevelNameId,
		ts.OwnerEntityId,
		ts.CreatedBy,
		ts.DateTimeCreated
	FROM Charges.TierStructures ts
	WHERE ts.TierStructureId = @TierStructureId
	