/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>35AFD7AE3ECD044097140EB28793DB1D</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS OFF
GO
CREATE PROCEDURE [dbo].[spAddThreeSixtyAMP](@Company varchar(20))  AS

DELETE FROM Discovery..OptionsDetail
WHERE		Company = @Company and OptionID = 229 and OptionSubName = 'Aggregate Asset Management Plan'

INSERT INTO Discovery..OptionsDetail (Company, OptionID, OptionValues, ClientID, OptionSubName, Active)
VALUES		(@Company, 229, 'planTemplateID', 31322, 'Both', 0)
INSERT INTO Discovery..OptionsDetail (Company, OptionID, OptionValues, ClientID, OptionSubName, Active)
VALUES		(@Company, 229, 'planTemplateID', 31322, 'Standard Plan', 325)
INSERT INTO Discovery..OptionsDetail (Company, OptionID, OptionValues, ClientID, OptionSubName, Active)
VALUES		(@Company, 229, 'planTemplateID', 31322, 'Suitability Letter', 120)
GO
