CREATE PROCEDURE [dbo].[GetAccountSettings]
    (
      @SeClientAccountId INT
    )
AS
    SELECT  CD.IsSwitchAllowed ,
            CD.SuspendAccount ,
            COALESCE(CO.EditPayroll, 0) as EditPayroll
    FROM    dbo.SeClientAccount AS CA
            INNER JOIN dbo.ClientDetails AS CD ON CA.ClaccountId = CD.ClaccountId
            INNER JOIN dbo.fnHeadAccounts() HA ON CA.ClAccountID = HA.ClAccountID
            LEFT JOIN dbo.CorporateMemberSchemeDetails CS ON CS.AccountId = HA.HeadClAccountID
            LEFT JOIN dbo.CorporateSchemeOptions CO ON CS.SchemeId = CO.Id
    WHERE   CA.Id = @SeClientAccountId