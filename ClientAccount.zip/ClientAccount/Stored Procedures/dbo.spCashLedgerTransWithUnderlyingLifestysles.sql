/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>A0E0FB86238DFEBC717944A09A0E5993</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[spCashLedgerTransWithUnderlyingLifestysles](@fromDate as Datetime, @toDate as DateTime, @ClAccountId varChar(20))
AS  

/*
Declare @fromDate As Datetime
Set @fromDate = '2013-07-15'

Declare @toDate As Datetime
Set @toDate = '2013-07-16'

Declare @ClAccountId As varChar(20)
Set @ClAccountId = 'ZU2004145-001'
*/
;

With Transactions as
(
	SELECT clt.transid,
		   clt.ledgerdate,
		   con.claccountid,
		   clt.linenumber,
		   clt.movementtype,
		   clt.movementsource,
		   clt.ccycode,
		   -clt.amount           AS amount,
		   clt.narrative,
		   clt.displaytoclient,
		   clt.capital,
		   clt.datecreated,
		   clt.ledgersource,
		   clt.ledgersourceid,
		   clt.fromccycode,
		   clt.toccycode,
		   clt.baseccycode,
		   clt.fxrate,
		   con.subclaccountid,
		   pd.producttype,
		   pd.arrangementtype,
		   clt.reference,
		   clt.narrativedetail,
		   pd.productdisplayname,
		   mcr.cltnarration,
		   clt.OrderID,
		   clt.OriginatingCashEntryID,
		   o.InstrumentCode,
		   ins.Descript As InstrumentDescription
	FROM   clientaccount.dbo.cashledgertransactions AS clt
		   INNER JOIN clientaccount.dbo.consolidate AS con
			 ON con.subclaccountid = clt.claccountid
		   LEFT OUTER JOIN discovery.dbo.productdetails AS pd
			 ON con.subclaccountid = pd.claccountid
		   LEFT JOIN clientaccount.dbo.manualcashadjustmentrequests mcr
			 ON clt.MCAid = MCR.ID
				AND clt.movementsource = 'ManualCashAdj'
		   LEFT OUTER JOIN Discovery.dbo.OrderCurrent AS o ON o.OrderID = clt.OrderID 
		   LEFT OUTER JOIN Res_db.dbo.Instruments AS ins ON ins.Security = o.InstrumentCode
		   LEFT JOIN ClientAccount.dbo.Trades AS tr ON tr.id = clt.TradeId
	WHERE  clt.displaytoclient = 1
		   AND clt.movementtype <> 'CALL_TRANSACTION'
		   AND clt.amount <> 0
		   AND clt.ledgerdate >= @fromDate and clt.ledgerdate < DATEADD(day, 1, @toDate)	
		   AND con.claccountid = @ClAccountId
		   AND (tr.status != 'Cancelled' Or tr.status IS NULL)
),
--This might seem a little bizzare, but it is because lifestyle ledgering has changed and we want the old ledgering to be compatible with the new one (when displayed)
TransIdToOrderId as
(
	SELECT max(TransId) as TransId, OrderId, Count(*) As NumberOfLines
	FROM Transactions TR
	GROUP BY OrderId
),

UnsortedResult as
(
	SELECT *, NULL As ParrentTransId FROM Transactions

	UNION

	SELECT clt.transid,
		   clt.ledgerdate,
		   con.claccountid,
		   clt.linenumber,
		   clt.movementtype,
		   clt.movementsource,
		   clt.ccycode,
		   -clt.amount           AS amount,
		   clt.narrative,
		   clt.displaytoclient,
		   clt.capital,
		   clt.datecreated,
		   clt.ledgersource,
		   clt.ledgersourceid,
		   clt.fromccycode,
		   clt.toccycode,
		   clt.baseccycode,
		   clt.fxrate,
		   con.subclaccountid,
		   pd.producttype,
		   pd.arrangementtype,
		   clt.reference,
		   clt.narrativedetail,
		   pd.productdisplayname,
		   mcr.cltnarration,
		   clt.OrderID,
		   clt.OriginatingCashEntryID,
		   o.InstrumentCode,
		   ins.Descript As InstrumentDescription,
		   CASE WHEN TR.NumberOfLines = 1 THEN TR.TransId ELSE NULL END As ParrentTransId
	FROM   
		   TransIdToOrderId TR
		   INNER JOIN Discovery..OrderRelationship ORL
			 ON ORL.FromOrderId = TR.OrderId
		   INNER JOIN clientaccount.dbo.cashledgertransactions AS clt
			 ON clt.OrderId = ORL.ToOrderId
		   INNER JOIN clientaccount.dbo.consolidate AS con
			 ON con.subclaccountid = clt.claccountid AND con.subclaccountid <> con.claccountid
		   INNER JOIN res_db..InvestmentProgrammeAccountMapping IPAM
			 ON IPAM.IPAccount = clt.ClAccountId
		   LEFT OUTER JOIN discovery.dbo.productdetails AS pd
			 ON con.subclaccountid = pd.claccountid
		   LEFT JOIN clientaccount.dbo.manualcashadjustmentrequests mcr
			 ON clt.MCAid = MCR.ID
				AND clt.movementsource = 'ManualCashAdj'
		   LEFT OUTER JOIN Discovery.dbo.OrderCurrent AS o ON o.OrderID = clt.OrderID 
		   LEFT OUTER JOIN Res_db.dbo.Instruments AS ins ON ins.Security = o.InstrumentCode
)

SELECT * 
FROM UnsortedResult
ORDER BY LedgerDate, TransId desc 




