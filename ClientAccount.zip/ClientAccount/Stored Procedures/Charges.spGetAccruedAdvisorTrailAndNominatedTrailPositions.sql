/***
<StoredProcedure>
	<Description>
		Returns accrued charge position for all pending accrued adviser 'rebate' charges
		Not to be run in the past as date no longer valid, due to being processed.
		This is a bespoke report addition to the accrued fees position report for OMW.
	</Description>	
	<Parameters>
		<Parameter Name="@Today">
			<Description>Todays' date</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE Charges.spGetAccruedAdvisorTrailAndNominatedTrailPositions(@Today DATE) AS

--DECLARE @Today DATE
--SET @Today = GETDATE()
DECLARE @LocalAsAt DATE
SET @LocalAsAt = @Today
      
	SELECT
		ROUND(SUM(-mfr.TrailAmount), 2) Amount, --  minus here becasue reported as a charge
		0 as VatAmount,
		mfr.SecaId as AccountId,
		pd.ProductType,
		'AdviserTrail' as ChargeType,
		'Monthly' as Frequency,				
		AVG(Round(CASE WHEN MFR.Valuation > 0 THEN -MFR.TrailAmount/MFR.Valuation * 36525 ELSE 0 END ,2)) as Rate, --trailRate not stored curently so computed. Minus here too
		CASE
			WHEN DateAdd(day, -1, MIN(mfr.AsAt)) <= ahead.DateCreated THEN NULL
			ELSE MIN(mfr.AsAt)
		END LastBillngDate, --billed on 1st of month though
		MIN(mfr.AsAt) as FromDate,
		mfr.ChargeDate as NextBillingDate
	FROM dbo.Fee_Accrual_Mfr mfr
	INNER JOIN dbo.SEClientAccount asub ON asub.ID = mfr.SecaId
	INNER JOIN dbo.Consolidate con ON con.SubCLAccountId = aSub.CLAccountId
	INNER JOIN dbo.ClientDetails cd ON cd.ClAccountId = con.CLAccountId AND cd.InvestorType <> 'Consolidated'
	INNER JOIN Discovery.dbo.ClientAccount ca	ON ca.CLAccountId = con.CLAccountId	AND ca.DPSAccountType = 'Account'	
	INNER JOIN dbo.SEClientAccount ahead ON ahead.ClAccountId = con.ClAccountID
	INNER JOIN Discovery.dbo.ProductDetails pd ON pd.ClAccountId = asub.ClAccountId
	WHERE @LocalAsAt BETWEEN mfr.AsAt and mfr.ChargeDate
	AND MFR.ChargeBasisId = 1 AND MFR.IsProcessed = 0
	GROUP BY mfr.SecaId, pd.ProductType, ahead.DateCreated, mfr.ChargeDate
	HAVING ROUND(SUM(mfr.TrailAmount), 2) <> 0

	UNION ALL
	SELECT
		ROUND(SUM(nom.Amount), 2) Amount,
		0 as VatAmount,
		nom.SubAccountId as AccountId,
		pd.ProductType,
		'NominatedTrailCharge' as ChargeType,
		'Monthly' as Frequency,				
		AVG(nom.Rate) as Rate,
		CASE
			WHEN DateAdd(day, -1, MIN(nom.AsAt)) <= ahead.DateCreated THEN NULL
			ELSE MIN(nom.AsAt)
		END LastBillngDate,
		MIN(nom.AsAt) as FromDate,
		nom.ChargeDate as NextBillingDate
	FROM dbo.Fee_Accrual_NominatedTrail nom
	INNER JOIN dbo.SEClientAccount asub ON asub.ID = nom.SubAccountId
	INNER JOIN dbo.Consolidate con ON con.SubCLAccountId = aSub.CLAccountId
	INNER JOIN dbo.ClientDetails cd ON cd.ClAccountId = con.CLAccountId AND cd.InvestorType <> 'Consolidated'
	INNER JOIN Discovery.dbo.ClientAccount ca	ON ca.CLAccountId = con.CLAccountId	AND ca.DPSAccountType = 'Account'	
	INNER JOIN dbo.SEClientAccount ahead ON ahead.ClAccountId = con.ClAccountID
	INNER JOIN Discovery.dbo.ProductDetails pd ON pd.ClAccountId = asub.ClAccountId
	WHERE @LocalAsAt BETWEEN nom.AsAt and nom.ChargeDate
	AND Nom.IsProcessed = 0
	GROUP BY nom.SubAccountId, pd.ProductType, ahead.DateCreated, nom.ChargeDate
	HAVING ROUND(SUM(nom.Amount), 2) <> 0

	ORDER BY AccountId
