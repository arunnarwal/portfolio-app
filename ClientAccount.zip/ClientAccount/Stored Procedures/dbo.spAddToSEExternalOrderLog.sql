/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>01BF4232723A94DBA618931EBAEDDAC3</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS OFF
GO
CREATE PROCEDURE [dbo].[spAddToSEExternalOrderLog](@OrderSource varchar(20),@OrderType varchar(20), @OrderRefID varchar(20), @MessageSent text, @ResponseReceived text, @Status Varchar(20) ,@SEOrderID int)  AS

Insert into SEExternalOrderLog (OrderSource, OrderType, OrderRefID, MessageSent, ResponseReceived, Status, SEOrderID) values (@OrderSource, @OrderType, @OrderRefID, @MessageSent, @ResponseReceived, @Status, @SEOrderID)
select @@ROWCOUNT as RowsEffected
GO
