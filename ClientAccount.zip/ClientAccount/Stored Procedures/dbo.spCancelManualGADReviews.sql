/***
<StoredProcedure>
    <Description>Cancel manual GAD reviews</Description>
	<Service>TaxWrappers</Service>
    <Feature>GADReview</Feature>
    <Parameters>
		<Parameter Name="@subClAccountId">
            <Description>SubAccount</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/

CREATE PROCEDURE [dbo].[spCancelManualGADReviews](@clAccountId varchar(20), @subClAccountId varchar(20), @userId int, @now datetime, @reason varchar(1000)) AS
/*
DECLARE @subClAccountId varchar(20)
SET @subClAccountId = 'AV2015013-002'
*/

SELECT S.Id AS sessionId , CR.Id AS requestId INTO #Reviews 
FROM dbo.WwCS S
	INNER JOIN dbo.WwCR CR ON S.Id = CR.WizardSessionId
WHERE S.WizardId = 269 
	AND S.ClientID <> 8245
	AND S.Status NOT IN ('DELETED', 'Cancelled')
	AND S.ClAccountId = @clAccountId
	AND S.SessionParameters = 'SubClAccountID=' + @subClAccountId
	AND CR.SubClAccountID = @subClAccountId
	AND CR.Status IN ('PENDING', 'FAILED', 'DELAYED', 'PENDINGAUTHORISATION', 'INCOMPLETE', 'CANCELLED')

UPDATE dbo.WwCR 
SET
	Status = 'DELETED'
WHERE Id IN (SELECT requestId from #Reviews)

UPDATE dbo.WwCS 
SET
	Status = 'DELETED',
	Reason = @reason,
	UserDeleted = @userId,
	DateDeleted = @now
WHERE Id IN (SELECT sessionId from #Reviews)	

DROP TABLE #Reviews

GO
