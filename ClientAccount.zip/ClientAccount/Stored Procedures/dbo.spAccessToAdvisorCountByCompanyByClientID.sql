/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>87AA099EE8970B4EF7AC6F182695A5DB</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[spAccessToAdvisorCountByCompanyByClientID](@Company AS VARCHAR(20), @TargetAdvisorCount int = -1) as 

select	count(clientid) as AdvisorCount, ClientID 
from	ClientAccount.dbo.ClientAccountSecurity 
where	Companies = @Company and claccountid is null 
group by ClientID	
having (count(clientid) = @TargetAdvisorCount or @TargetAdvisorCount = -1)
GO
