/***
<StoredProcedure>
    <Description>Permissions clients client fee FUM flags for Trustee (Member/Employee)</Description>
	<Service>Charges</Service>
    <Feature>Tasks</Feature>
   <Parameters>
        <Parameter Name="@AsAt">
            <Description>The date of the fee run</Description>
        </Parameter>
		<Parameter Name="@TranType">
            <Description>The tran type of the fee required.</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/

CREATE PROCEDURE [dbo].[spApplyFeeFlags_ByAcc_AMCT] (@AsAt DATETIME, @TranType VARCHAR(10))
AS

--DECLARE @AsAt DATETIME 
--SET @AsAt = '11 April 2014'

--DECLARE @TranType VARCHAR(10)
--SET @TranType = 'AMCTM'
;


IF OBJECT_ID(N'tempdb..#FeeAccrual', N'U') IS NOT NULL
BEGIN
	DROP TABLE #FeeAccrual
END

CREATE TABLE #FeeAccrual (
	SecaId INT
	,SchemeId INT
	,AsAt SMALLDATETIME 
	,FeeTranTypesID INT
	,Rate NUMERIC(7, 4)
	,ApplyVAT BIT
	,FumTotal NUMERIC(20, 4)
	,SchemeFumTotal NUMERIC(20, 4)
	)
;

INSERT INTO #FeeAccrual
SELECT 
	Fum.SecaId AS SecaId
	,SchemeDetails.Id AS SchemeId
	,Fum.AsAt AS AsAt 
	,FeeTranTypes.Id AS FeeTranTypesID
	,0 AS Rate
	,0 AS ApplyVAT 
	,Fum.CashAmount + Fum.NonCashAmount FumTotal
	,SUM(Fum.CashAmount + Fum.NonCashAmount) OVER(PARTITION BY SchemeDetails.ID) AS SchemeFumTotal
FROM Cache.dbo.Fee_FUM_ByAccount Fum
INNER JOIN dbo.WrapProvider WrapProvider
	ON Fum.WrapProviderId = WrapProvider.ID
INNER JOIN dbo.SEClientAccount AS SecaId
	ON Fum.SECAID = SecaId.ID
INNER JOIN dbo.FeeTranTypes AS FeeTranTypes
	ON FeeTranTypes.TranType = @TranType AND FeeTranTypes.WrapProvider = WrapProvider.WrapProvider
INNER JOIN dbo.Advisor Advisor
	ON Fum.AdvisorId = Advisor.Id
INNER JOIN dbo.CorporateSchemeDetails SchemeDetails
	ON SchemeDetails.AdvisorCode = Advisor.AdvCode
LEFT JOIN dbo.AppliedFees_ByAccV2 AS Applied
	ON Applied.AsAt = @AsAt
		AND Applied.SecaId = Fum.SecaId
		AND Applied.FeeTranTypesID = FeeTranTypes.Id
WHERE Fum.AsAt = @AsAt AND Applied.ID IS NULL
	AND NOT EXISTS (SELECT 1 FROM dbo.Fee_Fum_ExcludeAccountTypes EXAT 
				WHERE EXAT.WrapProviderID = Fum.WrapProviderID 
				AND EXAT.FeeTranTypeID = FeeTranTypes.ID 
				AND EXAT.AccountType = SecaId.InvestorType)

UPDATE #FeeAccrual
Set Rate = CAmcTiers.TierRate
FROM #FeeAccrual
INNER JOIN dbo.SEClientAccount SecaId
	ON SecaId.Id = #FeeAccrual.SecaId
INNER JOIN Discovery.dbo.ProductDetails ProductDetails
	ON ProductDetails.ClAccountId = SecaId.ClAccountID
INNER JOIN dbo.CorporateTieredAMC CAmc
	ON CAmc.SchemeId = #FeeAccrual.SchemeId
	AND CAmc.FeeTranTypeId = #FeeAccrual.FeeTranTypesID 
	AND CAmc.ProductType = ProductDetails.ProductType  
	And @AsAt  >= CAmc.FromDate And ( CAmc.ToDate IS NULL OR @AsAt <= CAmc.ToDate )
INNER JOIN  dbo.CorporateTieredAMCTiers CAmcTiers
	ON CAmcTiers.CorporateTieredAMCId = CAmc.Id
AND #FeeAccrual.SchemeFumTotal >= CAmcTiers.FromRange AND (CAmcTiers.ToRange IS NULL OR #FeeAccrual.SchemeFumTotal <= CAmcTiers.ToRange )

INSERT INTO dbo.ToBeAppliedFees_ByAccV2 (
	SecaId
	,[AsAt]
	,FeeTranTypesID
	,Applied
	,Rate
	,ApplyVAT
	)
SELECT FeeAccrual.SecaId
	,FeeAccrual.[AsAt]
	,FeeAccrual.FeeTranTypesID
	,0 As Applied/*Applied*/
	,FeeAccrual.Rate
	,FeeAccrual.ApplyVAT
FROM #FeeAccrual as FeeAccrual
LEFT JOIN dbo.ToBeAppliedFees_ByAccV2 as ToBeApplied
	ON FeeAccrual.SecaId = ToBeApplied.SecaId AND FeeAccrual.AsAt = ToBeApplied.AsAt AND FeeAccrual.FeeTranTypesID = ToBeApplied.FeeTranTypesID
WHERE ToBeApplied.SecaId IS NULL and FeeAccrual.Rate > 0 and FeeAccrual.FumTotal > 0

INSERT INTO dbo.NonAppliedFees_ByAccV2 (
	SecaId
	,[AsAt]
	,FeeTranTypesID
	,Status_NoteID
	)
SELECT FeeAccrual.SecaId
	,FeeAccrual.[AsAt]
	,FeeAccrual.FeeTranTypesID
	,0 As Status_NoteID
FROM #FeeAccrual as FeeAccrual
LEFT JOIN dbo.NonAppliedFees_ByAccV2 as NotToBeApplied
	ON FeeAccrual.SecaId = NotToBeApplied.SecaId AND FeeAccrual.AsAt = NotToBeApplied.AsAt AND FeeAccrual.FeeTranTypesID = NotToBeApplied.FeeTranTypesID
WHERE NotToBeApplied.SecaId IS NULL and FeeAccrual.Rate = 0 and FeeAccrual.FumTotal = 0

IF OBJECT_ID(N'tempdb..#FeeAccrual', N'U') IS NOT NULL
BEGIN
	DROP TABLE #FeeAccrual
END
GO