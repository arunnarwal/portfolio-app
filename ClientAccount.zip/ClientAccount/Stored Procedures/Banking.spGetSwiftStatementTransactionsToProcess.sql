/***
<StoredProcedure>
    <Description>Returns SWIFT customer statement transactions (MT940) to process.</Description>
    <Parameters>
        <Parameter Name="@SwiftStatementMessageId">
            <Description>The SWIFT statement message Id</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE Banking.spGetSwiftStatementTransactionsToProcess
(
    @SwiftStatementMessageId INT
)
AS
    SELECT
        SM.SwiftMessageId,
        SST.SwiftStatementTransactionId AS TransactionId,
        SM.SwiftMessageReference,
        SSM.AccountNumber,
        SST.ValueDate,
        SST.EntryDate,
        SST.DebitCreditMark,
        SSM.Currency,
        SST.Amount,
        SST.TransactionType,
        SST.TransactionCode,
        SST.AccountReference,
        SST.BankReference,
        SST.SupplementaryDetails,
        SSTAI.AdditionalInformationLine1,
        SSTAI.AdditionalInformationLine2,
        SSTAI.AdditionalInformationLine3,
        SSTAI.AdditionalInformationLine4,
        SSTAI.AdditionalInformationLine5,
        SSTAI.AdditionalInformationLine6,
        SSTAI.TransactionType AS SwiftTransactionType,
        CASE WHEN SSTTJ.ShouldJournal IS NULL THEN 1
            ELSE SSTTJ.ShouldJournal
        END AS ShouldJournalTransactionType
    FROM
        Banking.SwiftMessages SM
        INNER JOIN Banking.SwiftStatementMessages SSM ON SM.SwiftMessageId = SSM.SwiftMessageId
        INNER JOIN Banking.SwiftStatementTransactions SST ON SSM.SwiftStatementMessageId = SST.SwiftStatementMessageId
        LEFT JOIN Banking.SwiftStatementTransactionAdditionalInformation SSTAI ON SST.SwiftStatementTransactionId = SSTAI.SwiftStatementTransactionId
        LEFT JOIN Banking.SwiftStatementTransactionTypesJournalling SSTTJ ON SSTTJ.SwiftTransactionType = SSTAI.TransactionType
    WHERE
        SSM.SwiftStatementMessageId = @SwiftStatementMessageId
