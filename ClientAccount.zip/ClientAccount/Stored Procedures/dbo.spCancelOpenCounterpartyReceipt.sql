/***
<StoredProcedure>
    <Description>Cancels an open counterparty receipt if it can be cancelled. Throws an error if it cannot</Description>
    <Parameters>
        <Parameter Name="@CounterpartyReceiptId">
            <Description>The open counterparty receipt id to cancel</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE dbo.spCancelOpenCounterpartyReceipt
(
    @CounterpartyReceiptId INT
)
AS

    UPDATE
        dbo.CounterpartyReceipts
    SET
        [Status] = 'Cancelled'
    WHERE
        Id = @CounterpartyReceiptId
        AND [Status] = 'Created'

    IF @@ROWCOUNT = 0
    BEGIN
        DECLARE @CurrentStatus AS VARCHAR(30)
        SELECT @CurrentStatus = [Status] FROM dbo.CounterpartyReceipts WHERE Id = @CounterpartyReceiptId

        DECLARE @Error NVARCHAR(128) = N'Receipt ' + CONVERT(VARCHAR(30), @CounterpartyReceiptId) + ' could not be cancelled because it '
            + CASE WHEN @CurrentStatus IS NULL THEN 'does not exist.' ELSE 'is at Status ''' + @CurrentStatus + ''' which cannot be cancelled.' END

        RAISERROR(@Error, 16, 1)
    END
