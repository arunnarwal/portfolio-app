/***
<StoredProcedure>
	<Description>Returns the value held in unpresented cheque control accounts. Custom OMW client money requirement figure</Description>
	<Parameters>
		<Parameter Name="@AsAt">
			<Description>The date to return balances for</Description>
		</Parameter>
		<Parameter Name="@WrapProvider">
			<Description>The WrapProvider to return balances for</Description>
		</Parameter>
		<Parameter Name="@DivisionCode">
			<Description>The DivisionCode to return balances for</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE ClientMoney_Omw.spGetUnpresentedChequesAmount @AsAt DATE, @WrapProvider VARCHAR(20), @DivisionCode VARCHAR(6) AS

	/*
		USE ClientAccount
		GO
		BEGIN TRY DROP TABLE #Accounts END TRY BEGIN CATCH END CATCH
		DECLARE @AsAt DATE = '2020-03-06'
		DECLARE @WrapProvider VARCHAR(20) = 'OM'
		DECLARE @DivisionCode VARCHAR(6) = 'OM'
	*/
		
	SELECT agp.ClAccountId
	INTO #Accounts
	FROM dbo.vwGenericOptionsByWrapProvider g
		CROSS APPLY CSFBMaster.dbo.fn_convert_comma_to_table_char(g.OptionValue) x
		INNER JOIN dbo.vwAccountGladProperties agp ON agp.ClAccountId = x.TabValue
	WHERE g.OptionName = 'ChequePaymentAccounts'
		AND g.WrapProvider = @WrapProvider
		AND agp.DivisionCode = @DivisionCode

	CREATE UNIQUE CLUSTERED INDEX CUIDX_CLAccountId ON #Accounts(ClAccountId)

	SELECT gt.CurrencyCode, -SUM(gt.Amount) UnpresentedChequeAmount
	FROM CashLedger.vwGladTransactions gt
		INNER JOIN #Accounts a ON a.ClAccountId = gt.ClAccountId
	WHERE ISNULL(gt.RestrictSweepUntil, gt.LedgerDate) <= @AsAt
	GROUP BY gt.CurrencyCode

	DROP TABLE #Accounts
GO