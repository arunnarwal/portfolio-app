/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>Gets the active bank accounts with inactive direct debits over some period</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE procedure [dbo].[BankAccountIdInactiveDirectDebitsForPeriod] (@transactionsFrom datetime, @wrapProviderId int) As

/*
Declare @transactionsFrom datetime
Declare @wrapProviderId int
Set @transactionsFrom = '2014-04-21'
Set @wrapProviderId = 22
*/

Select
	BA.Id,
	BA.ClaccountId
From Discovery.dbo.BankAccount BA
	Inner Join dbo.SEClientAccount SEC
		On BA.ClaccountId = SEC.ClaccountId
		Inner Join dbo.Advisor ADV 
			On ADV.AdvCode = SEC.PrimaryAdviser
		Inner Join dbo.Company COM 
			On COM.Company = ADV.Company
		Inner Join dbo.WrapProvider WP 
			On WP.WrapProvider = COM.WrapProvider And WP.Id = @wrapProviderId
Where BA.Status = 'Active' And BA.DDIRec = 1

Except

Select
	BA.Id,
	BA.ClaccountId
From Discovery.dbo.CashEntry CA
	Inner Join dbo.SEClientAccount SEC
		On CA.ClaccountId = SEC.ClaccountId
		Inner Join dbo.Advisor ADV 
			On ADV.AdvCode = SEC.PrimaryAdviser
		Inner Join dbo.Company COM 
			On COM.Company = ADV.Company
		Inner Join dbo.WrapProvider WP 
			On WP.WrapProvider = COM.WrapProvider And WP.Id = @wrapProviderId
	Inner Join Discovery.dbo.BankAccount BA
		On CA.ClaccountId = BA.ClaccountId And CA.AccountNumber = BA.AccountNumber And CA.SortCode = BA.SortCode And BA.Status = 'Active' And BA.DDIRec = 1
Where CA.DateCreated >= @transactionsFrom And CA.Status = 'Completed'