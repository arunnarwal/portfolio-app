/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>BD3FD1CE78320F5A4680712CDEE5422F</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[spAMCRebateInvoicesByClientType](@DateFrom datetime, @DateTo datetime,@ClAccountId VarChar(20)= NULL) 
WITH  EXECUTE AS CALLER  AS  

SELECT	FAD.InstrumentCode, 
		sum(FAD.TotalAmount) as TotalAmount,
		abs(sum(FAD.TotalAmount)) as Amount, 
		coalesce(AO.ClAccountID,FM.ClAccountID) as ClAccountID, 
		I.ManagerID, 
		I.displayname as FundName,
		DateAdd(m,-1,FAD.ChargeDate) as FromDate,
		DateAdd(d,-1,FAD.ChargeDate) as ToDate,
		CA.SubAccountType, 
		CO.WrapProvider,
		CD.Discretionary,
		CA.PortfolioID

FROM	ClientAccount..FeeAccrualDetail2 as FAD
INNER JOIN Res_DB..instruments as I
	on	FAD.instrumentcode = I.security
INNER JOIN Res_DB..ManagedFunds as MF 
	ON I.security = MF.InstrumentCode 
LEFT OUTER JOIN Res_DB..FundManager as FM 
	ON I.ManagerID = FM.ManagerID
LEFT OUTER JOIN Res_DB..FundManagerAccountOverrides as AO 
	ON AO.InstrumentCode = I.security
inner join clientaccount..fnheadaccounts() FN    
		ON fn.claccountid = FAD.claccountid 	
inner join ClientAccount..ClientDetails AS CD
	on	Fn.HeadClAccountID = CD.ClAccountID
inner join Discovery.dbo.ClientAccount AS CA
	on	FAD.ClAccountID = CA.ClAccountID
INNER JOIN ClientAccount..Company as CO
	ON	CO.Company = CD.Company 

WHERE	
	fad.type = 'MFR' and 
	fad.category = 'AMC' and 
	fad.asat >= @DateFrom and 
	fad.asat < @DateTo and 
	-- so far we want all, even if processed. Its for invoicing not processing. fad.processedDateTime is null and
	CA.subaccounttype in ('PEP','ISA','SIPP','ONSHORE BOND','OFFSHORE BOND','PERSONAL PORTFOLIO','RETAIL BOND','RETAIL SIPP','Platform Fund','JISA') AND 
	coalesce(AO.ClAccountID,FM.ClAccountID)=ISNULL(@ClAccountID,coalesce(AO.ClAccountID,FM.ClAccountID))

GROUP BY
	FAD.InstrumentCode, 
	coalesce(AO.ClAccountID,FM.ClAccountID), 
	FAD.ChargeDate, 
	I.ManagerID, 
	I.displayname, 
	CA.SubAccountType, 
	CO.WrapProvider,
	CD.Discretionary,
	CA.PortfolioID

HAVING round(sum(FAD.TotalAmount),2) <> 0 

ORDER BY	
	coalesce(AO.ClAccountID,FM.ClAccountID), 
	FAD.InstrumentCode

GO
