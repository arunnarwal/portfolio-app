/***
<StoredProcedure>
    <Description>Set outstanding fees as being required to be processed ( posted to fad and then journaled )</Description>
	<Service>Charges</Service>
    <Feature>Tasks</Feature>
    <Parameters>
        <Parameter Name="@clAccountId">
            <Description>The id from SeClientAccount of the head account being closed</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/

CREATE PROCEDURE [dbo].[spAccountClosureSetOutstandingFeesAsProcessable] (@clAccountId AS varchar(20))
AS

DECLARE @now AS DATETIME
set @now = DATEADD(dd, 0, DATEDIFF(dd, 0, GETDATE())) --yyy-mm-dd 00:00:00.000

IF OBJECT_ID(N'tempdb..#accounts', N'U') IS NOT NULL
BEGIN
	DROP TABLE #accounts
END

declare @secaAccountId AS int
set @secaAccountId = (select top 1 Id from dbo.SECLientAccount where ClAccountId = @clAccountId )

-- PAMCM: Platform AMC (Employee)
UPDATE dbo.Fee_Accrual_PAMCM
	SET ChargeDate = @now 
WHERE IsProcessed = 0 And SecaId = @secaAccountId 


-- AMCTM: Trustee Fee (Employee)
UPDATE dbo.Fee_Accrual_AMCTM
	SET ChargeDate = @now 
WHERE IsProcessed = 0 And SecaId = @secaAccountId 

-- TPMM: Tiered Per Member Member (Employee)
UPDATE dbo.Fee_Accrual_TPMM
SET ChargeDate = @now 
WHERE IsProcessed = 0 And SecaId = @secaAccountId 

-- MFR: Manage Fund Rebate
UPDATE dbo.Fee_Accrual_MFR
	SET ChargeDate = @now 
FROM dbo.Fee_Accrual_MFR As FeeMFR
WHERE IsProcessed = 0 And SecaId = @secaAccountId 

IF OBJECT_ID(N'tempdb..#accounts', N'U') IS NOT NULL
BEGIN
	DROP TABLE #accounts
END