/***
<StoredProcedure>
  <Description>Gets the data for Barclays Bad Debt report</Description>
</StoredProcedure>
***/
CREATE PROCEDURE [dbo].[spBadDebtReportData](@WrapProvider VarChar(20)) AS
BEGIN
SELECT 
	cd.ClAccountId As AccountID,
	ah.CustomerId As [CustomerID],
	max(ccl.DateModified) As BadDebtFrom,
	ah.ClientID As UserID,
	ah.Given As FirstName,
	ah.Surname As Surname 
FROM dbo.ClientDetails cd
JOIN dbo.AccountHolders ah on cd.ClAccountId = ah.ClAccountId
INNER JOIN dbo.ClientChangeLog ccl on cd.ClAccountId = ccl.ClAccountId
INNER JOIN dbo.SEClientAccount As SECA ON cd.ClAccountId = SECA.ClAccountId
LEFT JOIN dbo.Advisor As ADV ON ADV.AdvCode = SECA.PrimaryAdviser
LEFT JOIN dbo.Company As CMP ON CMP.Company = ADV.Company
WHERE cd.BadDebt = 1 AND ccl.FieldName = 'baddebt' AND ccl.NewValue = 'True' AND ccl.ChangeStatus = 'Processed' and CMP.WrapProvider = @WrapProvider
GROUP BY cd.ClAccountId,ah.CustomerId,ah.ClientID,ah.given,ah.surname
END
