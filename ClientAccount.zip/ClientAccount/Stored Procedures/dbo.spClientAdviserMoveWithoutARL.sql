/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>BE93EA884BFE2AFA361F560718D1CC07</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[spClientAdviserMoveWithoutARL] (@ClAccountID varchar(20), @AdviserCode varchar(20)) AS

DECLARE @ErrorMessage varchar(max)

SET NOCOUNT ON

BEGIN TRANSACTION

BEGIN TRY
--Update PrimaryAdviser in SEClientAccount
UPDATE SEClientAccount
SET PrimaryAdviser = @AdviserCode
WHERE ClAccountID IN (
SELECT ClAccountID FROM fnHeadAccounts() HA WHERE HA.Headclaccountid = @ClAccountID
)
END TRY
BEGIN CATCH
SET @ErrorMessage = error_message()
GOTO HANDLE_ERROR
END CATCH


BEGIN TRY
--Update advisorcodes in clientaccountsecurity
UPDATE clientaccountsecurity
SET advisorcodes = @AdviserCode
WHERE ClAccountID IN (
SELECT ClAccountID FROM fnHeadAccounts() HA WHERE HA.Headclaccountid = @ClAccountID
)
END TRY
BEGIN CATCH
SET @ErrorMessage = error_message()
GOTO HANDLE_ERROR
END CATCH

COMMIT TRANSACTION
SELECT null as ErrorMessage

HANDLE_ERROR:
ROLLBACK TRANSACTION
SELECT @ErrorMessage as ErrorMessage
GO
