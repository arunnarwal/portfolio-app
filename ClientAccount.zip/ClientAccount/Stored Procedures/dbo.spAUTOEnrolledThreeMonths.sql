/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>88A2FABBB2F358F7E7E88BD4163D430F</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[spAUTOEnrolledThreeMonths]

AS
BEGIN
declare @now as datetime
declare @threemonthsLower as datetime
declare @fourmonthsUpper as datetime

set @now = getdate()

set @threemonthsLower = DateAdd(ww, -12, getdate() )
set @fourmonthsUpper = DateAdd(mm, -13, getdate() )

;

select PD.ClAccountID, PDH.ClAccountID As HeadClAccountID
from 
Discovery..ProductDetails PD
INNER JOIN ClientAccount..fnHeadAccounts() fh 
      on PD.ClAccountID = FH.ClAccountID and FH.Consolidated = 0
INNER JOIN Discovery..ProductDetails PDH
      on PDH.ClAccountID = FH.HeadClAccountID
where PD.ProductType = 'NPR'
and DateAdd( hh, -1, PD.DateCreated) < PDH.DateCreated
and PDH.DateCreated >@fourmonthsUpper and PDH.DateCreated < @threemonthsLower
END
GO
