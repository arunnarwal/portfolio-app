/***
<StoredProcedure>
    <Description>Returns SWIFT interim transaction report (MT942) details to process.</Description>
    <Parameters>
        <Parameter Name="@SwiftMessageId">
            <Description>The SWIFT message Id</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE Banking.spGetSwiftInterimTransactionsToProcess
(
    @SwiftMessageId INT
)
AS
    SELECT
        SM.SwiftMessageId,
        SIT.SwiftInterimTransactionId AS TransactionId,
        SM.SwiftMessageReference,
        SITM.AccountNumber,
        SIT.EntryDate AS TransactionDate,
        SIT.DebitCreditMark,
        SITM.Currency,
        SIT.Amount,
        SIT.TransactionType,
        SIT.TransactionCode,
        SIT.AccountReference,
        SIT.BankReference,
        SIT.SupplementaryDetails,
        SITAI.AdditionalInformationLine1,
        SITAI.AdditionalInformationLine2,
        SITAI.AdditionalInformationLine3,
        SITAI.AdditionalInformationLine4,
        SITAI.AdditionalInformationLine5,
        SITAI.AdditionalInformationLine6,
        SITAI.TransactionType AS SwiftTransactionType,
        CASE WHEN SSTTJ.ShouldJournal IS NULL THEN 1
            ELSE SSTTJ.ShouldJournal
        END AS ShouldJournalTransactionType
    FROM
        Banking.SwiftMessages SM
        INNER JOIN Banking.SwiftInterimTransactionMessages SITM ON SM.SwiftMessageId = SITM.SwiftMessageId
        INNER JOIN Banking.SwiftInterimTransactions SIT ON SITM.SwiftInterimTransactionMessageId = SIT.SwiftInterimTransactionMessageId
        LEFT JOIN Banking.SwiftInterimTransactionAdditionalInformation SITAI ON SIT.SwiftInterimTransactionId = SITAI.SwiftInterimTransactionId
        LEFT JOIN Banking.SwiftStatementTransactionTypesJournalling SSTTJ ON SSTTJ.SwiftTransactionType = SITAI.TransactionType
    WHERE
        SM.SwiftMessageId = @SwiftMessageId
