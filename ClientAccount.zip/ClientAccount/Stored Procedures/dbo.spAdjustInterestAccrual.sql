/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>0A785EC26AD7935432ED4591207290D8</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE [dbo].[spAdjustInterestAccrual] (
  @TranType VARCHAR(10), 
  @AsAtDate DATETIME,
  @ClAccountID VARCHAR(20), 
  @Currency VARCHAR(3),
  @GrossAmount NUMERIC (18,8),
  @NetAmount NUMERIC(18,8),
  @Rwt NUMERIC(18,8),
  @Nrwt NUMERIC(18,8)
)
AS
BEGIN
	SET NOCOUNT ON;

	UPDATE dbo.CmtAccruedInt
	SET
		GrossAmount = GrossAmount + @GrossAmount,
		NetAmount = NetAmount + @NetAmount,
		RWT = RWT + @Rwt,
		NRWT = NRWT + @Nrwt
	WHERE 
		Trantype = @TranType 
		AND AsAtDate = @AsAtDate 
		AND ClAccountID = @ClAccountID 
		AND Currency = @Currency

	IF @@rowcount = 0
	BEGIN
		INSERT INTO dbo.CmtAccruedInt (Trantype, asatdate, claccountid, currency, GrossAmount, NetAmount, RWT, NRWT)
		SELECT @TranType, @AsAtDate, @ClAccountID, @Currency, @GrossAmount, @NetAmount, @Rwt, @Nrwt
	END	
END

GO