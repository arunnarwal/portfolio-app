/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>95D3DC01752388C4EE1538B57F542C59</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[spCheckGSCMTAttributionExists](@From datetime, @To datetime) AS

SELECT     asat
FROM         CMTAttribution
WHERE     (ClAccountID LIKE 'gs%') AND (AsAt >= @From) AND (AsAt <= @To)
GROUP BY asat
GO
