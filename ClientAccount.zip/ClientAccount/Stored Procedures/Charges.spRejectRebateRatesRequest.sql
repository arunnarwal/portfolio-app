/***
<StoredProcedure>
    <Description>Rejects a request to save or update rebate rates for specified entity and instrument</Description>
    <Service>Charges</Service>
    <Feature>Charges</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE Charges.spRejectRebateRatesRequest (@RequestId INT, @EntityType VARCHAR(20), @UserId INT, @Now Date)
	
AS
BEGIN

	BEGIN TRY		
		IF (@EntityType = 'SystemProvider') --only supported type for day 1
		BEGIN
			--check request exists
			IF NOT EXISTS (SELECT 1 FROM dbo.RebateBySystemProviderRequests WHERE RebateRequestID = @RequestId AND [Status] = 'Pending')
			BEGIN
				RAISERROR('Request does not exist', 16, 1)
			END			

			--Stamp this request as Rejected status
			UPDATE dbo.RebateBySystemProviderRequests
			SET [Status] = 'Rejected', UserRejected = @UserId, DateRejected = GETDATE() 
			WHERE [RebateRequestID] = @RequestId AND [Status] = 'Pending'
		
		END	

		--todo Wrap and Company support if required in future

	END TRY
	BEGIN CATCH
		PRINT 'Rejecting rebate rate request failed';
		THROW;
	END CATCH
END
GO

