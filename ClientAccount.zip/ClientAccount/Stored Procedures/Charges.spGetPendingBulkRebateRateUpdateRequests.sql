/***
<StoredProcedure>
    <Description>Gets pending bulk rebate rate update requests</Description>
    <Service>Charges</Service>
    <Feature>Charges</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE Charges.spGetPendingBulkRebateRateUpdateRequests
AS
BEGIN
	SELECT
		brrur.BulkRebateRateUpdateRequestId,
		brrur.EntityType,
		brrur.EntityName,
		brrur.OriginalFileName,
		brrur.DocumentStoreId,
		brrur.UserRequested,
		c.WebName UsernameRequested,
		brrur.DateRequested
	FROM dbo.BulkRebateRateUpdateRequests brrur
	INNER JOIN ClientDB3.dbo.TblClients c on c.ClientId = brrur.UserRequested
	WHERE brrur.Status = 'Pending'
END
GO

