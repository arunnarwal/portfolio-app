/***
<StoredProcedure>
    <Description>Rejects a bulk request to save or update rebate rates</Description>
    <Service>Charges</Service>
    <Feature>Charges</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE Charges.spRejectBulkRebateRatesUpdateRequest (
	@BulkRequestId INT, 
	@UserId INT)
AS
BEGIN

	BEGIN TRY		
		--Stamp this request as Rejected status
		UPDATE dbo.BulkRebateRateUpdateRequests
		SET [Status] = 'Rejected', UserRejected = @UserId, DateRejected = GETDATE() 
		WHERE [BulkRebateRateUpdateRequestId] = @BulkRequestId AND [Status] = 'Pending'		

	END TRY
	BEGIN CATCH
		PRINT 'Rejecting bulk rebate rate request failed';
		THROW;
	END CATCH
END
GO

