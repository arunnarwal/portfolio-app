/***
<StoredProcedure>
    <Description>Retrieves account level AML data</Description>
    <Parameters>
        <Parameter Name="@ClientID">
            <Description>Used for account security access</Description>
        </Parameter>
		<Parameter Name="@FromDate">
            <Description>Include accounts created from this date</Description>
        </Parameter>
		<Parameter Name="@ToDate">
            <Description>Include accounts created before this date</Description>
        </Parameter>
		<Parameter Name="@AMLStatus">
            <Description>Optional; will only return account with specified AML status</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/

CREATE PROCEDURE [dbo].[spClientAMLStatus] (@ClientID INT, @FromDate DATETIME, @ToDate DATETIME, @AMLStatus VARCHAR = null,  @WrapProvider varchar(20) = null)  
AS
BEGIN

SET NOCOUNT ON

	/*
	USE ClientAccount

	DECLARE @ClientID AS INT
	DECLARE @FROMDate AS DATETIME
	DECLARE @ToDate AS DATETIME
	DECLARE @AMLStatus AS VARCHAR
	DECLARE @WrapProvider as VarChar(20)

	SET @ClientID = 8245
	SET @FROMDate = '11 Jul 2018'
	SET @ToDate = '12 Jul 2018'
	SET @AMLStatus = NULL
	set @WrapProvider = 'OM'
	*/

	SELECT Allowed.ClAccountid
	INTO #Accounts
	FROM dbo.vwBaseAllowedClAccountID Allowed
	WHERE Allowed.ClientID = @ClientID

	SELECT Ac.ClAccountID, Ad.Address1, Ad.Address2, Ad.Address3, Ad.Address4, Ad.Address5
	INTO #Addresses
	FROM Discovery.dbo.Address Ad
		INNER JOIN #Accounts Ac ON Ad.ClAccountID = Ac.ClAccountid
	WHERE @WrapProvider IS NULL 
		AND ((Ad.PrimaryContact = 'Yes' AND Ad.PostalAddress = 'Yes' AND (Ad.AllCorrespondence != 1 OR Ad.AllCorrespondence IS NULL)) OR Ad.AllCorrespondence = 1)
		OR Ad.[Type] = 'Residential'

    SELECT	
		@ClientID ClientID,
		ACAWA.ClAccountID,
		AH.Given AS GivenName,
		AH.Surname AS Surname,
		AMLCheck.AMLStatus AS AMLStatus,
		PEPCheck.PEPStatus AS PEPStatus,
		ISNULL(AH.OFACStatus, FiSCheck.FiSStatus) AS OFACStatus,  
		Ad.Address1,
		Ad.Address2,
		Ad.Address3,
		Ad.Address4,
		Ad.Address5,
		CO.CompanyName,
		CO.DistributionChannel,
		SP.ServicePropositionName AS ServiceProposition,
		SCMP.SubCompanyName AS AdviserRegion,
		SBR.SuperBranchName AS AdviserArea,
		BR.Branch AS AdviserBranch,
		ADV.Name AS AdviserName,
		CAH.Status AS SubAccountStatus, /* ??? this whole report IS head account level */
		CAH.Staff AS StaffFlag,
		SECA.StartDate AS AccountOpenDate,
		ISNULL(AH.AMLServiceProvider, AMLCheck.AMLProvider) AS AMLServiceProvider,
		CASE WHEN HasUs.ClAccountID IS NULL THEN 0 ELSE 1 END AS HasUS
	FROM 
		#Accounts ACAWA 
		INNER JOIN dbo.AccountHolders AH ON AH.ClAccountID = ACAWA.ClAccountID
		INNER JOIN dbo.SeClientAccount SECA ON SECA.ClAccountID = AH.ClAccountID
		LEFT JOIN Platform.DBAAccount.CustomerRoles CustR ON CustR.AccountId = SECA.ID
			
		LEFT JOIN (
			SELECT RegC_AML.CustomerId AS AMLCustomerId, RegCS_AML.RegulatoryCheckStatus AS AMLChecStatus, RegC_AML.ServiceProvider AS AMLProvider, RegRES_AML.RegulatoryCheckResult AS AMLStatus
			FROM Platform.DBACustomer.RegulatoryChecks RegC_AML 
				INNER JOIN Platform.DBACustomer.RegulatoryCheckTypes RegCT_AML ON RegCT_AML.RegulatoryCheckTypeId = RegC_AML.RegulatoryCheckTypeId AND RegCT_AML.RegulatoryCheckType = 'AML'
				INNER JOIN Platform.DBACustomer.RegulatoryCheckStatuses RegCS_AML ON RegCS_AML.RegulatoryCheckStatusId = RegC_AML.RegulatoryCheckStatusId				
				INNER JOIN Platform.DBACustomer.RegulatoryCheckResults RegRES_AML ON RegRES_AML.RegulatoryCheckTypeId = RegC_AML.RegulatoryCheckTypeId AND RegRES_AML.RegulatoryCheckResultId = RegC_AML.RegulatoryCheckResultId
		) AMLCheck ON AMLCheck.AMLCustomerId = CustR.CustomerId

		LEFT JOIN (
			SELECT RegC_PEP.CustomerId AS PEPCustomerId, RegCS_PEP.RegulatoryCheckStatus AS PEPCheckStatus, RegC_PEP.ServiceProvider AS PEPProvider, RegRES_PEP.RegulatoryCheckResult AS PEPStatus
			FROM Platform.DBACustomer.RegulatoryChecks RegC_PEP 
				INNER JOIN Platform.DBACustomer.RegulatoryCheckTypes RegCT_PEP ON RegCT_PEP.RegulatoryCheckTypeId = RegC_PEP.RegulatoryCheckTypeId AND RegCT_PEP.RegulatoryCheckType = 'PEP'
				INNER JOIN Platform.DBACustomer.RegulatoryCheckStatuses RegCS_PEP ON RegCS_PEP.RegulatoryCheckStatusId = RegC_PEP.RegulatoryCheckStatusId
				INNER JOIN Platform.DBACustomer.RegulatoryCheckResults RegRES_PEP ON RegRES_PEP.RegulatoryCheckTypeId = RegC_PEP.RegulatoryCheckTypeId AND RegRES_PEP.RegulatoryCheckResultId = RegC_PEP.RegulatoryCheckResultId
		) PEPCheck ON PEPCheck.PEPCustomerId = CustR.CustomerId

		LEFT JOIN (
			SELECT RegC_FiS.CustomerId AS FiSCustomerId, RegCS_FiS.RegulatoryCheckStatus AS FiSStatus, RegC_FiS.ServiceProvider AS FiSProvider
			FROM Platform.DBACustomer.RegulatoryChecks RegC_FiS 
				INNER JOIN Platform.DBACustomer.RegulatoryCheckTypes RegCT_FiS ON RegCT_FiS.RegulatoryCheckTypeId = RegC_FiS.RegulatoryCheckTypeId AND RegCT_FiS.RegulatoryCheckType = 'Financial Sanctions'
				INNER JOIN Platform.DBACustomer.RegulatoryCheckStatuses RegCS_FiS ON RegCS_FiS.RegulatoryCheckStatusId = RegC_FiS.RegulatoryCheckStatusId				
		) FiSCheck ON FiSCheck.FisCustomerId = CustR.CustomerId

		LEFT JOIN (
			SELECT ST.ClAccountID 
			FROM dbo.ScripTransactions AS ST 
				INNER JOIN Res_db.dbo.Instruments AS I ON ST.InstrumentCode = I.Security 
			WHERE I.COR = 'USA' 
				AND ST.TransStatus <> 'Cancelled' 
				AND ST.Location = 'Custody'
				AND ST.AsAt < DATEADD(d,1,@FROMDate) /*change FROMdate to getdate*/
			GROUP BY ST.ClAccountID
			HAVING SUM(ST.Quantity) > 0

			UNION
		
			/*remove this statement*/
			SELECT DISTINCT ST.ClAccountID 
			FROM dbo.ScripTransactions AS ST 
				INNER JOIN Res_db.dbo.Instruments AS I ON ST.InstrumentCode = I.Security 
			WHERE I.COR = 'USA' 
				AND ST.TransStatus <> 'Cancelled' 
				AND ST.Location = 'Custody'
				AND ST.AsAt BETWEEN @FROMDate AND @ToDate
		
			UNION

			SELECT DISTINCT O.ClAccountID
			FROM Discovery.dbo.OrderCurrent O
				INNER JOIN Res_db.dbo.Instruments AS I ON O.InstrumentCode = I.Security 
			WHERE I.COR = 'USA' 
				AND O.DateCreated BETWEEN @FROMDate AND @ToDate /*remove this line*/
				AND O.Status NOT IN ('Completed', 'Cancelled')
		) HasUS ON HasUS.ClAccountID = ACAWA.ClAccountID

		LEFT JOIN #Addresses Ad ON Ad.ClAccountID = AH.ClAccountID
		LEFT JOIN dbo.vwJuniorAccountClientDetails AS JACD ON ACAWA.ClAccountID = JACD.ClAccountID
		INNER JOIN dbo.Advisor ADV ON ADV.AdvCode = SECA.PrimaryAdviser
		INNER JOIN Discovery.dbo.ClientAccount CAH ON CAH.ClAccountID = ACAWA.ClAccountID	
		INNER JOIN dbo.ClientDetails CD ON CD.ClAccountID = ACAWA.ClAccountID
		INNER JOIN dbo.Company CO ON CO.Company = CD.Company
		LEFT JOIN dbo.Branches BR ON ADV.BranchID = BR.ID
		LEFT JOIN dbo.SuperBranch SBR ON BR.SuperBranchId = SBR.Id
		LEFT JOIN dbo.SubCompany SCMP ON SBR.SubCompanyId = SCMP.Id
		LEFT JOIN dbo.ServiceProposition SP ON SP.ServicePropositionId = CO.ServiceProposition
	WHERE 
		SECA.StartDate BETWEEN @FromDate AND @ToDate
		AND (AH.AMLStatus LIKE COALESCE(@AMLStatus, '%') OR AMLCheck.AmlStatus LIKE COALESCE(@AMLStatus, '%'))

DROP TABLE #Accounts
DROP TABLE #Addresses

END
GO
