/***
<StoredProcedure>
    <Description>CGT Tool Income Summary</Description>
    <Parameters>
        <Parameter Name="@ClAccountIds">
            <Description>ClAccount Id</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE dbo.spCGTToolIncomeSummaryExternal
    @ClAccountIds VARCHAR(MAX)
AS

SELECT
    CAST(TabValue AS VARCHAR(20)) AS ClAccountId
INTO #ClAccountIds
FROM CSFBMaster.dbo.[fn_convert_comma_to_table_char](@ClAccountIds)

CREATE CLUSTERED INDEX IDX_ClAccountIds_ClAccountId ON #ClAccountIds (ClAccountId)

SELECT
    CON.ClAccountID
,   let.LegalEntityTypeId
,   INC.Id
,   INC.LedgerDate
,   CA.ExDate
,   ISNULL(INC.InstrumentCode, CA.InstrumentCode) AS Instrumentcode
,   INC.QualifyingHolding
,   COALESCE(INC.Equalisation, 0) AS Equalisation
,   CASE WHEN INC.FinalProcessType NOT IN ('AccFund', 'ERI') AND INC.Equalisation > 0 THEN 0
         ELSE INC.NetAmount
    END AS NetAmount
,   INC.CorpActID
,   INC.Group1Group2
FROM dbo.ExternallyReceivedIncomeSummary AS INC
	INNER JOIN dbo.Consolidate AS CON ON CON.SubClAccountID = INC.ClAccountID
	INNER JOIN Discovery.dbo.ProductDetails AS PD ON PD.ClAccountID = CON.SubClAccountID
	INNER JOIN dbo.ClientDetails CD ON CD.CLAccountID = CON.ClAccountID
	INNER JOIN dbo.Company CO ON CO.Company = CD.Company
	INNER JOIN CorporateActions.dbo.CorporateAction AS CA ON CA.Id = INC.CorpActID
	INNER JOIN Res_db.dbo.Instruments AS I ON CA.InstrumentCode = I.[Security]
	INNER JOIN Platform.ProductWrappers.ProductWrapperTypes pwt on pwt.ProductType=PD.ProductType
	INNER JOIN dbo.VwWrapProviderWithJurisdiction vww ON vww.WrapProvider=co.WrapProvider
	INNER JOIN Tax.CGT_TaxableProductWrapperTypes TPWT ON TPWT.ProductWrapperTypeId = PWT.ProductWrapperTypeId
	LEFT JOIN One.Tax.LegalEntityType let ON (case when cd.InvestorType='individ' then 'individual' else cd.InvestorType end) = let.LegalEntityType and let.IsSubType = 0
	LEFT JOIN One.Tax.CGTProductWrapperException cgt 
	ON cgt.JurisdictionID=vww.JurisdictionID 
	AND (let.LegalEntityTypeId=cgt.LegalEntityType or cgt.LegalEntityType is null) 
	AND (cd.LegalEntitySubType=cgt.LegalEntitySubType or cgt.LegalEntitySubType is null) 
	AND (cd.LegalEntitySubSubType=cgt.LegalEntitySubSubType or cgt.LegalEntitySubSubType is null) 
	AND (pwt.ProductWrapperTypeId=cgt.ProductWrapperType or cgt.ProductWrapperType is null) 
	AND (pd.ProductSubTypeId=cgt.ProductWrapperSubType or cgt.ProductWrapperSubType is null)
WHERE
    CON.[ClAccountID] IN (SELECT ClAccountId FROM #ClAccountIds)
	AND  INC.[QualifyingHolding] IS NOT NULL
	AND  INC.[Reversal] IS NULL
	AND  I.[SecuritySubType] in ('ManagedFund','Exchange Traded Fund')
	AND ( cgt.JurisdictionID is null And cgt.LegalEntityType is null and cgt.LegalEntitySubType is null and cgt.LegalEntitySubSubType is null and cgt.ProductWrapperType is null and cgt.ProductWrapperSubType is null)
	AND (INC.FinalProcessType IN ('AccFund', 'ERI') OR INC.Equalisation > 0)
	AND cd.IsCgtExempt <> 1

DROP TABLE #ClAccountIds

GO

