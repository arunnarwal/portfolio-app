/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>575F288D6E8A5BF5BEEC659CBB0ED128</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[spCloneWorkflowWizardSessionExternalData](
                @OldId      INT,
                @NewId		INT)
AS

INSERT INTO [ClientAccount].[dbo].[WorkflowWizardSessionExternalData]
           ([SessionId],[distributer_id],[intermediary_case_reference_number],[completed_notification_url],[OriginalRequest],[message_id],[BackOfficeProviderId],[BusinessProcess])
SELECT @NewId, distributer_id, intermediary_case_reference_number, completed_notification_url, OriginalRequest, message_id, BackOfficeProviderId, BusinessProcess
FROM [ClientAccount].[dbo].[WorkflowWizardSessionExternalData]
WHERE SessionId=@OldId
SELECT  @@ROWCOUNT as [RowCount]
     