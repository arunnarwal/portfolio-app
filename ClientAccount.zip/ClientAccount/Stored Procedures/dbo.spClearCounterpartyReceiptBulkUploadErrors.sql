/***
<StoredProcedure>
	<Description>Clears existing error details held against a CounterpartyReceiptBulkUpload (to allow reprocessing)</Description>
	<Parameters>
		<Parameter Name="@CounterpartyReceiptBulkUploadId">
			<Description>The CounterpartyReceiptBulkUploadId to remove errors from</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE dbo.spClearCounterpartyReceiptBulkUploadErrors @CounterpartyReceiptBulkUploadId INT AS

	UPDATE dbo.CounterpartyReceiptBulkUploads
	SET RowsRejected = 0
	WHERE CounterpartyReceiptBulkUploadId = @CounterpartyReceiptBulkUploadId

	DELETE FROM dbo.CounterpartyReceiptBulkUploadErrors
	WHERE CounterpartyReceiptBulkUploadId = @CounterpartyReceiptBulkUploadId
	
GO