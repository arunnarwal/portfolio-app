/***
<StoredProcedure>
    <Description>Returns any previously generated SWIFT transactions for match processing.</Description>
    <Parameters>
        <Parameter Name="@GladBankAccountId">
            <Description>Id of the associated GLAD bank accounts the transactions are for.</Description>
        </Parameter>
        <Parameter Name="@StatementDate">
            <Description>The statement date the transactions are for.</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE Banking.spGetSwiftTransactionsToMatch
(
    @GladBankAccountId INT,
    @StatementDate DATE
)
AS

    SELECT
        ST.SwiftTransactionId,
        ST.SwiftMessageReference,
		ST.TransactionDate,
        ST.DebitCreditMark,
        ST.Currency,
        ST.Amount,
        ST.AccountReference,
        ST.BankReference,
        ST.Narrative,
		ST.SupplementaryDetails,
		ST.AdditionalInformationLine1,
		ST.AdditionalInformationLine2,
		ST.AdditionalInformationLine3,
		ST.AdditionalInformationLine4,
		ST.AdditionalInformationLine5,
		ST.AdditionalInformationLine6
    FROM
        Banking.vwSwiftTransactions ST
    WHERE
        ST.GladBankAccountId = @GladBankAccountId
        AND ST.TransactionDate = @StatementDate