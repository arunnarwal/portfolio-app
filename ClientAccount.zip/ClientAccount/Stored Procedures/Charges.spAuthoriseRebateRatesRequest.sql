/***
<StoredProcedure>
    <Description>Authorise a request to save or update rebate rates for specified entity and instrument</Description>
    <Service>Charges</Service>
    <Feature>Charges</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE Charges.spAuthoriseRebateRatesRequest (@RequestId INT, @EntityType VARCHAR(20), @UserId INT, @Now Date)
	
AS
BEGIN

	BEGIN TRY
		DECLARE @Tomorrow DATE = DateAdd(day, 1, @Now)
		DECLARE @InstrumentID INT
		DECLARE @EntityId INT
		DECLARE @BundledRate NUMERIC(9,6)
		DECLARE @UnBundledRate NUMERIC(9,6)
		DECLARE @TrailRate NUMERIC(9,6)
		DECLARE @FromDate DATE
		DECLARE @ToDate DATE
		 
		IF (@EntityType = 'SystemProvider') --only supported type for day 1
		BEGIN
			--check request exists
			IF NOT EXISTS (SELECT 1 FROM dbo.RebateBySystemProviderRequests WHERE RebateRequestID = @RequestId AND [Status] = 'Pending')
			BEGIN
				RAISERROR('Request does not exist', 16, 1)
			END
			ELSE
			BEGIN
				SELECT 
					@InstrumentID = InstrumentsID, 
					@EntityId = ProviderId, 
					@UnBundledRate = UnbundledRate,
					@BundledRate = BundledRate,
					@TrailRate = TrailRate,
					@FromDate = FromDate
				FROM dbo.RebateBySystemProviderRequests 
				WHERE RebateRequestID = @RequestId
			END

			--check if future dated rates already exist 
			IF EXISTS(SELECT 1 FROM dbo.RebateBySystemProvider WHERE ProviderID = @EntityId AND InstrumentsId = @InstrumentId AND FromDate > @Tomorrow) 
			BEGIN
				RAISERROR('Future instrument rebate rates already set', 16, 1) --this wont be possible via UI but protects the DB just in case
			END

			--update existing schdule for fromDate if exists (i.e. they make mistake and need to update tommorows)
			--Allow updating of rate only if FromDate is tommorow 
			IF EXISTS(SELECT 1 FROM dbo.RebateBySystemProvider WHERE ProviderID = @EntityId AND InstrumentsID = @InstrumentId  AND FromDate = @Tomorrow) 
			BEGIN
				UPDATE dbo.RebateBySystemProvider
				SET BundledRate = @BundledRate, UnBundledRate = @UnBundledRate, TrailRate = @TrailRate, RebateRequestID = @RequestId 
				WHERE InstrumentsId = @InstrumentId AND ProviderID = @EntityId
				AND FromDate = @Tomorrow
			END
			ELSE
			BEGIN
			--else update/stamp toDate on old line and insert new
				SET @ToDate = dateadd(day, -1, @FromDate)

				UPDATE dbo.RebateBySystemProvider
				SET ToDate = @ToDate
				WHERE ProviderID = @EntityId AND InstrumentsID = @InstrumentID AND (ToDate IS NULL OR ToDate >= @Now) 

				INSERT INTO dbo.RebateBySystemProvider
				(ProviderID, InstrumentsID, Rate, UnbundledRate, BundledRate, TrailRate, FromDate, ToDate, RebateRequestId) 
				VALUES(@EntityId, @InstrumentID, 0, @UnBundledRate, @BundledRate, @TrailRate, @FromDate, NULL, @requestId)				
			END		
							
			--finally stamp this request as Authorised status
			UPDATE dbo.RebateBySystemProviderRequests
			SET [Status] = 'Authorised', UserAuthorised = @UserId, DateAuthorised = GETDATE() 
			WHERE [RebateRequestID] = @RequestId AND [Status] = 'Pending'		
		END	

		--todo Wrap and Company support if required in future

	END TRY
	BEGIN CATCH
		PRINT 'Authorising rebate rate request failed';
		THROW;
	END CATCH
END
GO

