/***
<StoredProcedure>
    <Description>CGT Tool Script Transactions
        Should be kept aligned with spCGTToolScripTransactionsExternal
    </Description>
    <Parameters>
        <Parameter Name="@ClAccountIds">
            <Description>Comma separated list of ClAccountIds</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/

CREATE PROCEDURE dbo.spCGTToolScripTransactions
    @ClAccountIds VARCHAR(MAX)
AS


DECLARE @BaseCCY VARCHAR(3)
SET @BaseCCY = 'GBP'

SELECT
    TabValue AS ClAccountId
INTO  #ClAccountIds
FROM CSFBMaster.dbo.fn_convert_comma_to_table_char(@ClAccountIds)


SELECT
    Acc.ClAccountId,
    Let.LegalEntityTypeId
INTO #Accounts
FROM #ClAccountIds Acc
INNER JOIN Discovery.dbo.ProductDetails AS PD
    ON PD.ClAccountID = Acc.ClAccountID
INNER JOIN [Platform].ProductWrappers.ProductWrapperTypes pwt
    ON pwt.ProductType=PD.ProductType

INNER JOIN dbo.ClientDetails AS CD
    ON CD.ClAccountID = Acc.ClAccountID
INNER JOIN dbo.Company CO
    ON CO.Company = CD.Company
INNER JOIN dbo.vwWrapProviderWithJurisdiction vww
    ON vww.WrapProvider=co.WrapProvider

LEFT JOIN One.Tax.LegalEntityType let
    ON (case when cd.InvestorType='individ' then 'individual' else cd.InvestorType end)=let.LegalEntityType
    AND let.IsSubType = 0

LEFT JOIN One.Tax.CGTProductWrapperException cgtE
    ON cgtE.JurisdictionID=vww.JurisdictionID
    AND (let.LegalEntityTypeId=cgtE.LegalEntityType or cgtE.LegalEntityType is null)
    AND (cd.LegalEntitySubType=cgtE.LegalEntitySubType or cgtE.LegalEntitySubType is null)
    AND (cd.LegalEntitySubSubType=cgtE.LegalEntitySubSubType or cgtE.LegalEntitySubSubType is null)
    AND (pwt.ProductWrapperTypeId=cgtE.ProductWrapperType or cgtE.ProductWrapperType is null)
    AND (pd.ProductSubTypeId=cgtE.ProductWrapperSubType  or cgtE.ProductWrapperSubType is null)

WHERE ( cgtE.JurisdictionID is null
    AND cgtE.LegalEntityType is null
    AND cgtE.LegalEntitySubType is null
    AND cgtE.LegalEntitySubSubType is null
    AND cgtE.ProductWrapperType is null
    AND cgtE.ProductWrapperSubType is null)

AND cd.IsCgtExempt <> 1

CREATE UNIQUE CLUSTERED INDEX uidx_ClAccountID ON #Accounts (CLAccountID)

;WITH Custody AS (
    SELECT
        CASE WHEN CGT.cgtTotalValue IS NOT NULL
                    AND ST.Quantity IS NOT NULL
                    AND ST.Quantity <> 0 THEN CONVERT(DECIMAL(18, 8), ABS(CGT.CgtTotalValue) / ABS(ST.Quantity))

            ELSE ST.COST
        END AS Cost
    ,   ST.TransId
    ,   ST.TransDate
    ,   COALESCE (CGT.cgtDate, ST.AsAt) AS AsAt
    ,   ST.CLAccountID
    ,   #Accounts.LegalEntityTypeId
    ,   ST.Quantity
    ,   ST.InstrumentCode
    ,   ST.TransSource
    ,   ST.CorpActID
    ,   ST.TransType
    ,   ST.FXCost
    ,   ST.CncyCode
    ,   ST.AWOrderID
    ,   ST.AWScripTransferID
    ,   ST.Group1Group2
    ,   ST.TradeId
    ,   ST.Group1
    ,   ST.Group2
    ,   CGT.CgtExempt AS CgtExempt
    ,   CGT.CgtTotalValue
    ,   CGT.TaxBookStatus
    ,   CGT.ExcludeFrom30DayRule

    FROM dbo.ScripTransactions AS ST
    INNER JOIN #Accounts
        ON #Accounts.ClAccountID = St.CLAccountID

    LEFT JOIN dbo.CgtTransactions AS CGT
        ON ST.TransId = CGT.scripTransactionID

    WHERE
        ST.CLAccountID IN (SELECT ClAccountId FROM #ClAccountIds)
    AND ST.Cutover = 0
    AND ST.TransType <> 'MFRollFwd'
    AND ( (ST.TransStatus = 'Settled' AND ST.Location = 'Custody') OR (ST.TransStatus = 'Unsettled' AND ST.Location = 'BTA') )

), Bta AS (
    SELECT
    ST.AWOrderID
    ,   ST.TradeID
    ,   COALESCE(CGT.cgtDate, ST.AsAt) AS AsAt
    FROM dbo.ScripTransactions AS ST
    LEFT JOIN dbo.CgtTransactions AS CGT ON ST.TransId = CGT.scripTransactionID

    WHERE
        ST.CLAccountID IN (SELECT ClAccountId FROM #ClAccountIds)
    AND ST.TransStatus = 'Settled'
    AND ST.TransType <> 'MFRollFwd'
    AND ST.TransSource IN ('Sell Trade','Buy Trade')
    AND ST.Location = 'BTA'
    AND ST.Cutover = 0
)
SELECT
    C.Cost AS Cost
,   C.TransId
,   C.TransDate
,   COALESCE(B.AsAt, C.AsAt) AS AsAt
,   C.AsAt AS PriceAsAt
,   C.CLAccountID
,   C.LegalEntityTypeId
,   C.Quantity
,   C.InstrumentCode
,   C.TransSource
,   C.CorpActID
,   C.TransType
,   C.FXCost
,   C.CncyCode
,   C.AWOrderID
,   C.AWScripTransferID
,   C.Group1Group2
,   C.TradeId
,   C.Group1
,   C.Group2
,   C.CGTExempt
,   C.CgtTotalValue
,   C.TaxBookStatus
,   C.ExcludeFrom30DayRule
INTO #ScripTrans
FROM Custody C
LEFT JOIN Bta B
    ON C.AWOrderID = B.AWOrderID
    AND C.TradeID = B.TradeID;

CREATE CLUSTERED INDEX #cuix_data ON #ScripTrans (TradeId, AWOrderID)

SELECT
    d.ClAccountID
,   d.LegalEntityTypeId
,   d.Cost
,   d.TransDate
,   d.TransId
,   d.AsAt
,   d.PriceAsAt
,   d.Quantity
,   d.InstrumentCode
,   d.TransSource
,   d.CorpActID
,   d.TransType
,   d.FXCost
,   d.CncyCode
,   d.AWOrderID
,   d.AWScripTransferID
,   d.Group1Group2
,   d.TradeId
,   d.Group1
,   d.Group2
,   i.ID InstrumentId
,   i.SecurityType
,   i.SecuritySubType
,   i.DistributorReportingStatus
,   t.TradeDate
,   tfb.Amount AS AccruedInterest
,   cst.ConversionId
,   d.CgtExempt
,   IsOffshoreFund =
        CAST(
            COALESCE(
                CASE
                    WHEN IP.FundType = 'OffshoreFund' AND IP.ReportingOffshoreFund = 1 AND RP.EffectiveFrom IS NULL THEN 1
                    WHEN IP.FundType = 'OffshoreFund' AND IP.ReportingOffshoreFund = 0 THEN 1
                    ELSE 0
                END
            , 0) AS BIT
        )
,   CAST(CASE WHEN S104.CorpActId IS NOT NULL THEN 1
                ELSE 0
    END AS BIT) AS IsS104CorporateAction
,   D.TaxBookStatus
,   CAST(CASE WHEN S104.CorpActId IS NOT NULL THEN S104.CheckSameDay
              WHEN d.TransSource = 'AccountTransfer' AND d.ExcludeFrom30DayRule = 1 THEN 1
              ELSE 0
    END AS BIT) AS CheckSameDay
,   D.CgtTotalValue
,   D.ExcludeFrom30DayRule

INTO #ScripTransWithInsAndTrades
FROM #ScripTrans d
INNER JOIN Res_db.dbo.Instruments i
    ON i.[Security] = d.InstrumentCode
LEFT JOIN One.Tax.vwS104CorporateActionIds S104
    ON S104.CorpActId = d.CorpActId
LEFT JOIN dbo.ConversionScripTransactions cst
    ON cst.ScripTransactionId = d.TransID
LEFT JOIN dbo.Trades t
    ON t.Id = d.TradeId
LEFT JOIN dbo.TradesFeesBreakdown tfb
    ON  t.Id = tfb.TradeId
    AND tfb.Description = 'AccruedInterest'
LEFT JOIN One.Tax.HmrcFundReportingStatusEffectivePeriod RP
    ON RP.InstrumentId = I.ID
    AND d.AsAt BETWEEN ISNULL(RP.EffectiveFrom, '1900-01-01') AND ISNULL(RP.EffectiveTo, GETDATE())
LEFT JOIN Res_DB.dbo.InstrumentProperties IP
    ON IP.InstrumentCode = I.Security
WHERE NOT EXISTS (
    SELECT 1
    FROM res_db.dbo.Bonds b
    WHERE b.bond_code = d.InstrumentCode
    AND BondType = 'Gilt'
)

SELECT  s.Security, s.O, s.Date
INTO #Prices
FROM Res_DB.dbo.Securities s
WHERE s.Security IN (
    SELECT DISTINCT d.CncyCode + 'USD'
    FROM #ScripTransWithInsAndTrades d
    UNION ALL
    SELECT @BaseCCY + 'USD'
)
AND s.Date IN (
    SELECT DISTINCT DATEADD(dd, 0 , (DATEDIFF( dd, 0, d.PriceAsAt)))
    FROM #ScripTransWithInsAndTrades d )

CREATE UNIQUE CLUSTERED INDEX cuidx_SecurityDate ON #Prices (Security, Date)


SELECT mf.InstrumentCode, IncomeAccumulation
INTO #MF
FROM Res_db.dbo.ManagedFunds mf
WHERE mf.InstrumentCode IN (
    SELECT DISTINCT d.InstrumentCode
    FROM #ScripTransWithInsAndTrades d
)

CREATE UNIQUE CLUSTERED INDEX cuidx_InstrumentCode ON #MF (InstrumentCode)

SELECT
   d.ClAccountID
,   d.LegalEntityTypeId
,   d.Cost
,   d.TransDate
,   d.TransId
,   d.AsAt
,   d.Quantity
,   d.InstrumentCode
,   d.TransSource
,   d.CorpActID
,   d.TransType
,   d.FXCost
,   CASE
        WHEN D.CgtTotalValue IS NOT NULL THEN 1
        WHEN D.CncyCode = 'USD' THEN S2.o
        WHEN S1.o IS NULL THEN 1
    ELSE
        Cast(S2.o AS FLOAT(53)) / Cast(S1.o AS FLOAT(53))
    END AS CgtFxRate
,   d.CncyCode
,   d.AWOrderID
,   d.AWScripTransferID
,   d.Group1Group2
,   d.TradeId
,   d.Group1
,   d.Group2
,   d.InstrumentId
,   d.SecurityType
,   d.SecuritySubType
,   d.DistributorReportingStatus
,   mf.IncomeAccumulation
,   d.TradeDate
,   d.AccruedInterest
,   d.ConversionId
,   d.CgtExempt
,   D.IsOffshoreFund
,   IsRelevantSecurity =
        CAST(
            CASE
                WHEN TPT.TaxParcelTypeId IS NOT NULL AND TPT2.TaxParcelTypeId IS NULL THEN 1
                WHEN TPT2.TaxParcelTypeId IS NOT NULL AND RP.EffectiveFrom IS NULL THEN 1
                ELSE 0
            END AS BIT
        )

,   D.IsS104CorporateAction
,   D.TaxBookStatus
,   D.CheckSameDay
,   D.ExcludeFrom30DayRule

FROM #ScripTransWithInsAndTrades d
LEFT JOIN #MF mf
    ON mf.InstrumentCode = d.InstrumentCode

LEFT JOIN #Prices S1
    ON S1.Security = d.CncyCode + 'USD'
    AND S1.Date = DATEADD(dd, 0 , (DATEDIFF( dd, 0, d.PriceAsAt)))
    AND d.CncyCode <> @BaseCCY
LEFT JOIN #Prices S2
    ON S2.Security = @BaseCCY + 'USD'
    AND S2.Date = DATEADD(dd, 0 , (DATEDIFF( dd, 0, d.PriceAsAt)))

LEFT JOIN One.Tax.ProductClassification PC ON PC.ProductClassification = d.SecuritySubType
LEFT JOIN One.Tax.ProductClassificationTaxRule PCTR ON PCTR.ProductClassificationID = PC.ProductClassificationID AND PCTR.JurisdictionID = 61
LEFT JOIN One.Tax.ProductTaxRulesUK PTR ON PTR.ProductTaxRuleID = PCTR.ProductTaxRuleID
LEFT JOIN One.Tax.TaxParcelType TPT ON TPT.TaxParcelTypeId = PTR.TaxParcelTypeId AND TPT.TaxParcelType = 'RelevantSecurity'

LEFT JOIN One.Tax.ProductTaxRuleException PTRE ON PTRE.InstrumentCode = d.InstrumentCode AND PTRE.JurisdictionID = 61
LEFT JOIN One.Tax.ProductTaxRulesUK PTR2 ON PTR2.ProductTaxRuleID = PTRE.ProductTaxRuleID
LEFT JOIN One.Tax.TaxParcelType TPT2 ON TPT2.TaxParcelTypeId = PTr2.TaxParcelTypeID AND TPT2.TaxParcelType = 'RelevantSecurity'

LEFT JOIN One.Tax.HmrcFundReportingStatusEffectivePeriod RP ON RP.InstrumentId = d.InstrumentID AND d.AsAt BETWEEN ISNULL(RP.EffectiveFrom, '1900-01-01') AND ISNULL(RP.EffectiveTo, GETDATE())


ORDER BY d.TransDate ASC;

DROP TABLE #MF
DROP TABLE #Prices
DROP TABLE #ScripTransWithInsAndTrades
DROP TABLE #ScripTrans;
DROP TABLE #Accounts
DROP TABLE #ClAccountIds;

GO


