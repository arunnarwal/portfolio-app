/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>A771C71550BDAF6314B041C02D4D69C3</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[spActivateAccount](
                @UserId      INT,
                @ClAccountId VARCHAR(20))
AS
  /*
 
  DECLARE @UserId INT,
  
  @ClAccountId VARCHAR(15)
  
  SET @ClAccountId = 'EL1016872' 
  
  SET @UserId = 424192
   */

IF EXISTS (SELECT 1 FROM Discovery..ProductDetails WHERE ClaccountId = @ClAccountId AND ProductType IS NOT NULL)
BEGIN  
  DECLARE @Today DATETIME

  SET @Today = Getdate()
    
  BEGIN TRANSACTION ActivateAccount
  
  DECLARE  @id            INT,
           @oldValues     VARCHAR(500),
           @newValues     VARCHAR(500),
           @TransactionId INT
  
  INSERT INTO discovery..requestinterfacetransactions
             (actionname,
              claccountid,
              requestedby,
              requestdate)
  VALUES     ('ActivateAccount',@ClAccountId,@userId,@Today)
  
  SELECT @TransactionId = Scope_identity()
  
	SELECT @id = id
	FROM discovery..clientaccount
	WHERE ClAccountId = @ClAccountId AND Status <> 'Active'

	IF @id IS NULL 
	BEGIN
		RAISERROR ('Unable to find the account',12,-1)
		ROLLBACK TRANSACTION ActivateAccount
	END 	
	ELSE
	BEGIN  
		exec dbo.spActivateSubAccount @TransactionId = @TransactionId, @userId = @userId, @SubClAccountId = @ClAccountId
	  
		COMMIT TRANSACTION ActivateAccount
	END
END
ELSE 
BEGIN
	RAISERROR ('Unable to find the account. Check the account is not Head account.',12,-1)
END
GO
