/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>0B820F55E653CFF4C40EBD69811D5680</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE [dbo].[spAcornCommissionRevenueByTransactionSummaryFL](@WrapProvider as VarChar(20), @advisorPostMethod as varchar(16), @glPosted as varchar(16), @pendingAdvisorPost as varchar(16), @clientID as int, @paymentTransactionID as int) As

--declare @glPosted as varchar(16)
--declare @WrapProvider as VarChar(20)
--declare @advisorPostMethod as varchar(16)
--declare @pendingAdvisorPost as varchar(16)
--declare @clientID as int
--declare @paymentTransactionID as int
--
--set @glPosted = 'YES'
--set @wrapProvider = 'GS'
--set @advisorPostMethod = 'ACORN'
--set @pendingAdvisorPost =  'YES'
--set @clientID = 406510
--set @paymentTransactionID = 2988


SELECT	
		SUM(ARL.TotalAmount) AS TotalAmount,
		CSD.Name AS SchemeName,
		CSD.ReferenceNumber AS SchemeNumber
		
FROM	Discovery.dbo.advisorrevenueledger ARL
		INNER JOIN ClientAccount..CorporateSchemeDetails CSD
			ON ARL.ADVCODE = CSD.AdvisorCode 
		INNER JOIN ClientAccount.dbo.vwAllowedClientAccounts ACA 
			ON ARL.ClAccountID = ACA.ClAccountID
		INNER JOIN ClientAccount..AcornCommissionPayments PAY 
			ON (PAY.ID = ARL.CommissionPaymentID OR PAY.ID = ARL.CommissionPaymentIDReported)
WHERE ACA.ClientID = @clientID 
	AND ARL.GLPosted = @glPosted 
	AND ARL.PendingAdvisorPost = @pendingAdvisorPost 
	AND ACA.WrapProvider = @wrapProvider 
	AND ARL.AdvisorPostMethod = @advisorPostMethod
	AND PAY.PaymentTransactionID = @paymentTransactionID
GROUP BY CSD.Name, CSD.ReferenceNumber


GO
