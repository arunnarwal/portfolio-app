/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>965A6FB5B536061884A43F49F0891B5A</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[spAddUrl](
                @UserId      INT,
				@Url VARCHAR(100))
AS
  /*
  
  DECLARE	@UserId INT,  
			@Url VARCHAR(100)
  
  SET @Url = 'iifjisji'
  
  SET @UserId = 433247
  
  */

DECLARE @HasError BIT
SET @HasError = 0

  IF LEN(@Url) <= 0
  BEGIN
	SET @HasError = 1
	RAISERROR ('URL not specified',12,-1)
  END

  IF EXISTS ( SELECT 1
			  FROM   webdb..website
			  WHERE  url = @Url + '.elevateplatform.co.uk')
  BEGIN
	RAISERROR ('URL exists already',12,-1)		
	SET @HasError = 1
  END

  DECLARE @Today DATETIME
  SET @Today = Getdate()
    
IF @HasError = 0
BEGIN

  BEGIN TRANSACTION AddUrl
  
  DECLARE  @id            INT,
           @TransactionId INT  
  
  INSERT INTO discovery..requestinterfacetransactions
             (actionname,
              claccountid,
              requestedby,
              requestdate)
  VALUES     ('ConfigUrl','',@userId,@Today)
  
  SELECT @TransactionId = Scope_identity()

  INSERT INTO webdb..website
             (url,
              stylesheetfolder,
              websitename)
  VALUES(@Url + '.elevateplatform.co.uk',
         'Elevate',
         @Url)
  
  SELECT @id = Scope_identity()  

  INSERT INTO discovery..requestinterfacechangelog
                     (transactionid,
                      tablerowidentifier,
                      databasename,
                      tablename,
                      newvalues)
  VALUES     (@TransactionId,@id,'WebDB','WebSite','URL=' + @Url + '.elevateplatform.co.uk|StyleSheetFolder=Elevate|WebSiteName=' + @Url)
  
  COMMIT TRANSACTION AddUrl
END

GO
