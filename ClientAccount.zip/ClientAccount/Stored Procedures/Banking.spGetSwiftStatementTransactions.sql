/***
<StoredProcedure>
    <Description>Return all SWIFT customer statement (MT940) transactions for a given account, date and statement number.</Description>
    <Parameters>
        <Parameter Name="@StatementDate">
            <Description>Statement date to return messages for.</Description>
        </Parameter>
        <Parameter Name="@StatementNumber">
            <Description>Statement number to return messages for.</Description>
        </Parameter>
        <Parameter Name="@AccountNumber">
            <Description>Account number to return messages for.</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE Banking.spGetSwiftStatementTransactions
(
    @AccountNumber VARCHAR(35),
    @StatementDate DATE,
    @StatementNumber INT
)
AS
    SELECT
        STS.SwiftTransactionId AS TransactionId,
        SM.SwiftMessageReference,
        SSM.AccountNumber,
        SST.EntryDate AS ValueDate,
        SST.DebitCreditMark,
        SSM.Currency,
        SST.Amount,
        SST.AccountReference,
        SST.BankReference,
        SSTAI.AdditionalInformationLine1,
        SSTAI.AdditionalInformationLine2,
        SSTAI.AdditionalInformationLine3,
        SSTAI.AdditionalInformationLine4,
        SSTAI.AdditionalInformationLine5,
        SSTAI.AdditionalInformationLine6
    FROM
        Banking.SwiftMessages SM
        INNER JOIN Banking.SwiftStatementMessages SSM ON SM.SwiftMessageId = SSM.SwiftMessageId
        INNER JOIN Banking.SwiftStatementTransactions SST ON SSM.SwiftStatementMessageId = SST.SwiftStatementMessageId
        LEFT JOIN Banking.SwiftStatementTransactionAdditionalInformation SSTAI ON SST.SwiftStatementTransactionId = SSTAI.SwiftStatementTransactionId
        LEFT JOIN Banking.SwiftTransactionSources STS ON SST.SwiftStatementTransactionId = STS.SwiftStatementTransactionId
    WHERE
        SSM.StatementNumber = @StatementNumber
        AND SSM.ClosingBalanceDate = @StatementDate
        AND SSM.AccountNumber = @AccountNumber
