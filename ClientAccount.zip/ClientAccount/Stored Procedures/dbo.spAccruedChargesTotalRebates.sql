/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>8C1DD7B3B3E05B5FEA7FC569DEA81C71</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[spAccruedChargesTotalRebates](@fromDate as Datetime, @toDate as DateTime)
AS  

--
--Declare @fromDate As Datetime
--Set @fromDate = '28 Dec 2012 00:00'

--Declare @toDate As Datetime
--Set @toDate = '28 Dec 2012 23:59'

;

With EFMRebates as(
select sum(value) EFMRebateValue, Type, PlatformFund, FundCode
from ClientAccount..AccruedChargesFile
where Type = 'EFM AMC Rebate Accrual' and datecreated >= @fromDate and datecreated <= @toDate
group by fundcode, type, platformfund
)

, EFMCharges as(

select sum(value) EFMChargeValue, Type, PlatformFund, FundCode
from ClientAccount..AccruedChargesFile
where Type = 'EFM AMC Accrual' and datecreated >= @fromDate and datecreated <= @toDate
group by fundcode, type, platformfund
)

select 
I.sedol, 
acf.EFMChargeValue as ChargeValue, 
(acf.EFMChargeValue - acf2.EFMRebateValue) SHValue, 
acf2.EFMRebateValue as EFMValue,
 acf.PlatformFund, 
 acf.Fundcode,
 @fromDate as Datecreated   

from EFMCharges acf
inner join EFMRebates acf2
on acf.fundcode = acf2.fundcode 
inner join res_db..instruments I
on I.security = acf.PlatformFund

GO
