/***
<StoredProcedure>
    <Description>This procedure retrieves all qualifying accounts for Tax certificates that were suppressed for given reason</Description>
    <Parameters>
        <Parameter Name="@FromDate">
            <Description>The from date</Description>
        </Parameter>
		<Parameter Name="@ToDate">
            <Description>The to date</Description>
        </Parameter>
		<Parameter Name="@AccountPrefix">
            <Description>The account prefix</Description>
        </Parameter>
		<Parameter Name="@ReasonID">
            <Description>The reason for suppression</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/

CREATE PROCEDURE [dbo].[spClientsToGenerateTaxCertsSuppressed](@FromDate datetime, @ToDate datetime, @AccountPrefix varchar(30) = '%', @ReasonID int) AS
--------------------------------------------------------------------------------------------------------------------------------------------
-- This procedure retrieves all qualifying accounts for Tax certificates that were suppressed for given reason.
--
-- !!! Please REMEMBER that there is also "spClientsToGenerateTaxCerts" which retreives all Tax Certificates.
-- If you change some common logic here, you should take look at the other function to be sure it doesn't need to be changed as well !!!
--------------------------------------------------------------------------------------------------------------------------------------------

--DECLARE 
--	 @FromDate		DATETIME
--	,@ToDate		DATETIME
--	,@AccountPrefix VARCHAR(30)
--	,@ReasonID		INT

--SELECT
--	 @FromDate		= '2020-04-06 00:00:00.000'
--	,@ToDate		= '2021-04-05 00:00:00.000'
--	,@AccountPrefix = '%'
--	,@ReasonID	= 1

SELECT 
				Name										ClAccountId 
INTO			#SuppressedAccounts
FROM			TaskDB.dbo.WrapDocSup
WHERE			Suppressed = 1 
				AND	Name LIKE @AccountPrefix
				AND	TaskID = 10495
				AND	ReasonID = @ReasonID
				AND	Type = 'Client'

CREATE UNIQUE CLUSTERED INDEX CUIDX_ClAccountId ON #SuppressedAccounts(ClAccountId)

-- Get suppressed accounts with rebates

SELECT DISTINCT
				SECA.ClAccountId
INTO			#AccountsWithRebates
FROM			Discovery.dbo.XhubAdvisorRevenueLedger		XARL
INNER JOIN		dbo.ModelAccountInstrumentMapping			MAIA		ON MAIA.HubAccountId = XARL.HierarchyEntityId
INNER JOIN		dbo.SEClientAccount							SECA		ON SECA.Id = MAIA.SubAccountId
INNER JOIN		dbo.Consolidate								C			ON C.SubClAccountID = SECA.ClAccountID
INNER JOIN		#SuppressedAccounts							SA			ON SA.ClAccountId = C.ClAccountID
INNER JOIN		Discovery.dbo.ProductDetails				PD			ON PD.ClAccountId = SECA.ClAccountId
WHERE			XARL.LedgerDate >= @FromDate
				AND XARL.LedgerDate <= @ToDate
				AND PD.ProductType = 'Personal Portfolio'

UNION

SELECT DISTINCT 
				R.ClAccountID
FROM			Discovery.dbo.Rebate						R
INNER JOIN		dbo.Consolidate								C			ON C.SubClAccountID = R.ClAccountID
INNER JOIN		#SuppressedAccounts							SA			ON SA.ClAccountId = C.ClAccountID
INNER JOIN		Discovery.dbo.ProductDetails				PD			ON R.ClAccountId = PD.ClAccountId AND PD.ProductType = 'Personal Portfolio'
WHERE			R.AsAt <= @ToDate
				AND	R.AsAt >= @FromDate

CREATE UNIQUE CLUSTERED INDEX CUIDX_ClAccountId ON #AccountsWithRebates(ClAccountId)

SELECT DISTINCT 
				CO.WrapProvider, 
				C.ClAccountID								HeadClAccountId
FROM			#AccountsWithRebates						AWR
INNER JOIN		dbo.Consolidate								C			ON AWR.ClAccountID = C.SubClAccountID AND C.SubClAccountID <> C.ClAccountID
INNER JOIN		dbo.ClientDetails							CD			ON CD.CLAccountID = C.ClAccountID
INNER JOIN		dbo.Company									CO			ON CO.Company = CD.Company	

UNION

SELECT DISTINCT 
				TIDFU.WrapProvider, 
				TIDFU.HeadClAccountID
FROM			#SuppressedAccounts							SA
INNER JOIN		dbo.vwTaxableIncomeDataForUK				TIDFU		ON SA.ClAccountId = TIDFU.HeadClAccountID
WHERE 
				TIDFU.SubAccountType IN ('Wrap Cash','Personal Portfolio')
				AND TIDFU.LedgerDate BETWEEN @FromDate AND @ToDate
				AND TIDFU.ClAccountId <> TIDFU.HeadClAccountID
				AND NOT EXISTS (--Gets all the accounts that have had reversals
										SELECT 1
										FROM			dbo.vwTaxableIncomeDataForUK TIDFUR
										WHERE			TIDFU.ClAccountId = TIDFUR.ClAccountID 
														AND (TIDFUR.Reversal = 'reversal' OR TIDFUR.Reversal = '1')
														AND TIDFUR.LedgerDate BETWEEN @FromDate AND @ToDate
														AND NOT EXISTS (--Gets all the accounts that have not had reversals
																				SELECT 1
																				FROM dbo.vwTaxableIncomeDataForUK TIDFUWR
																				WHERE TIDFUR.ClAccountID = TIDFUWR.ClAccountID 
																					AND (TIDFUWR.Reversal = '0' OR TIDFUWR.Reversal IS NULL)
																					AND TIDFUWR.LedgerDate BETWEEN @FromDate AND @ToDate
																		)
								)

DROP TABLE #SuppressedAccounts
DROP TABLE #AccountsWithRebates

GO
