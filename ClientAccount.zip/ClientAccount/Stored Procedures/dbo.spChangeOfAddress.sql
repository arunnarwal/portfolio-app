/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>D11DF549DF1DD55C63D24944CEF270EB</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[spChangeOfAddress] (@From DateTime,@To DateTime, @DailyTask smallint = 0) 

AS

IF @DailyTask = 1 
BEGIN
	SET @From = DATEADD(HOUR,17,DATEDIFF(d,0,@From))
	SET @To = DATEADD(HOUR,17,DATEDIFF(d,0,@To))
END	
ELSE
	SET @To = DATEADD(DAY, 1, DATEDIFF(DAY, 0, @To));

select distinct
ah.logdate,a.id,a.claccountid,
sca.accountname,a.address1,a.address2,a.address3,a.address4,a.country,ah.address1
 as OldAddress1,ah.address2 
as OldAddress2,ah.address3
 as OldAddress3,ah.address4 
as OldAddress4,ah.country 
as OldCountry,ah.type 
as AddressType,adv.name
 as AdviserName,sc.subcompanyname
 as HubLocation,hub.emailaddress 
as HubEmail,hub.address1 
as HubAddress1,hub.address2
 as HubAddress2,hub.address3 
as HubAddress3,hub.postcode
 as HubPostCode
from
	discovery..address a
	inner join discovery..addresshistory ah on ah.addressid = a.id 
	left join clientaccount..seclientaccount sca on a.claccountid = sca.claccountid
	left join clientaccount..advisor adv on sca.primaryadviser = adv.advcode
	left join clientaccount..branches b on adv.branchid = b.id
	left join clientaccount..subcompanycontactdetails hub on b.subcompanyid = hub.subcompanyid
	left join clientaccount..subcompany sc on b.subcompanyid = sc.id
where
	a.lastupdated >= @From and a.lastupdated < @To and
	ah.logdate >= @From and ah.logdate < @To
	and(a.address1 <> ah.address1 or
	a.address2 <> ah.address2 or
	a.address3 <> ah.address3 or
	a.address4 <> ah.address4 or
	a.country <> ah.country)and a.claccountid like 'CL%' 
	and a.PrimaryContact = 'Yes'
	-- hides internal updates of UKWsorder by logdate desc
GO

/*exec CSFBMaster..spUpdateMetaDB @DBName='ClientAccount', @TableName='spChangeOfAddress', @TableConstant='pChangeOfAddress'*/
