/***
<StoredProcedure>
    <Description>Gets outstanding fees</Description>
	<Service>Charges</Service>
    <Feature>Tasks</Feature>
    <Parameters>
        <Parameter Name="@accountid">
            <Description>The id from SeClientAccount of the head account being closed</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/

CREATE PROCEDURE [dbo].[spAccountClosureGetOutstandingBalance] (@accountid AS INT, @clAccountId as VARCHAR(20))
AS

--declare @accountid as int
--set @accountId = 2684 --2367

IF OBJECT_ID(N'tempdb.dbo.#Accounts', N'U') IS NOT NULL
BEGIN
	DROP TABLE #Accounts
END

-- Find All SubAccounts
SELECT 
	HeadAccounts.ClAccountId As ClAccountId, 
	SubSECLientAccount.Id AS SecaId, 
	SECLientAccount.Id As HeadSecaId, 
	HeadAccounts.HeadClAccountId As HeadClAccountId 
INTO #Accounts
FROM dbo.fnHeadAccounts() HeadAccounts
INNER JOIN dbo.SECLientAccount As SECLientAccount
	ON SECLientAccount.ClAccountID = HeadAccounts.HeadClAccountID 
		AND HeadAccounts.Consolidated = 0 
		AND ( SECLientAccount.Id = @accountId Or SECLientAccount.ClAccountID  = @clAccountId )
INNER JOIN dbo.SECLientAccount As SubSECLientAccount
	ON SubSECLientAccount.ClAccountId = HeadAccounts.ClAccountID

-- PAMCM: Platform AMC (Employee)
select 
	'PAMCM' As FeeTranType
	,#Accounts.HeadSecaId
	,#Accounts.HeadClAccountId 
	,#Accounts.SecaId
	,#Accounts.ClAccountId
	,SUM(FeePamcm.Amount) AS TotalAmount
	,FeePamcm.CurrencyId As CurrencyId
	,CurrencyFormat.IsoCode As CurrencyCode
FROM dbo.Fee_Accrual_PAMCM As FeePamcm
	INNER JOIN #Accounts 
		ON FeePamcm.SecaId = #Accounts.SecaId
	INNER JOIN Res_Db.dbo.CurrencyFormat AS CurrencyFormat
		on CurrencyFormat.Id = FeePamcm.CurrencyId
WHERE FeePamcm.IsProcessed = 0
GROUP BY FeePamcm.SecaId
		,FeePamcm.CurrencyId
		,CurrencyFormat.IsoCode
		,#Accounts.ClAccountId
		,#Accounts.SecaId
		,#Accounts.HeadSecaId
		,#Accounts.HeadClAccountId 
UNION ALL

-- AMCTM: Trustee Fee (Employee)
select 
	'AMCTM' As FeeTranType
	,#Accounts.HeadSecaId
	,#Accounts.HeadClAccountId 
	,#Accounts.SecaId
	,#Accounts.ClAccountId
	,SUM(FeeAMCTM.Amount) AS TotalAmount
	,FeeAMCTM.CurrencyId As CurrencyId
	,CurrencyFormat.IsoCode As CurrencyCode
FROM dbo.Fee_Accrual_AMCTM As FeeAMCTM
	INNER JOIN #Accounts 
		ON FeeAMCTM.SecaId = #Accounts.SecaId
	INNER JOIN Res_Db.dbo.CurrencyFormat AS CurrencyFormat
		on CurrencyFormat.Id = FeeAMCTM.CurrencyId
WHERE FeeAMCTM.IsProcessed = 0
GROUP BY FeeAMCTM.SecaId
		,FeeAMCTM.CurrencyId
		,CurrencyFormat.IsoCode
		,#Accounts.ClAccountId
		,#Accounts.SecaId
		,#Accounts.HeadSecaId
		,#Accounts.HeadClAccountId 

UNION ALL

-- TPMM: Tiered Per Member Member (Employee)
select 
	'TPMM' As FeeTranType
	,#Accounts.HeadSecaId
	,#Accounts.HeadClAccountId 
	,#Accounts.SecaId
	,#Accounts.ClAccountId
	,SUM(FeeTPMM.Amount) AS TotalAmount
	,FeeTPMM.CurrencyId As CurrencyId
	,CurrencyFormat.IsoCode As CurrencyCode
FROM dbo.Fee_Accrual_TPMM As FeeTPMM
	INNER JOIN #Accounts 
		ON FeeTPMM.SecaId = #Accounts.SecaId
	INNER JOIN Res_Db.dbo.CurrencyFormat AS CurrencyFormat
		on CurrencyFormat.Id = FeeTPMM.CurrencyId
WHERE FeeTPMM.IsProcessed = 0
GROUP BY FeeTPMM.SecaId
		,FeeTPMM.CurrencyId
		,CurrencyFormat.IsoCode
		,#Accounts.ClAccountId
		,#Accounts.SecaId
		,#Accounts.HeadSecaId
		,#Accounts.HeadClAccountId

IF OBJECT_ID(N'tempdb.dbo.#Accounts', N'U') IS NOT NULL
BEGIN
	DROP TABLE #Accounts
END
