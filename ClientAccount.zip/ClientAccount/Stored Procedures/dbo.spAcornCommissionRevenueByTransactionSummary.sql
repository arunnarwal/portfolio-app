/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>4586E84BBD0C750860AB1711E653BE74</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE [dbo].[spAcornCommissionRevenueByTransactionSummary](@WrapProvider as VarChar(20), @advisorPostMethod as varchar(16), @glPosted as varchar(16), @pendingAdvisorPost as varchar(16), @clientID as int, @paymentTransactionID as int) As

SELECT	
		ARL.AsAt,
		ARL.TranType,
		SUM(ARL.TotalAmount) AS TotalAmount,
		PD.ProductType,
		CSD.Name AS SchemeName,
		CSD.ReferenceNumber AS SchemeNumber
FROM	Discovery.dbo.advisorrevenueledger ARL
		INNER JOIN ClientAccount..CorporateSchemeDetails CSD
			ON ARL.ADVCODE = CSD.AdvisorCode 
		INNER JOIN ClientAccount.dbo.vwAllowedClientAccounts ACA 
			ON ARL.ClAccountID = ACA.ClAccountID
		INNER JOIN Discovery..ProductDetails PD 
			ON PD.ClAccountID = ACA.ClAccountID
		INNER JOIN ClientAccount..AcornCommissionPayments PAY 
			ON (PAY.ID = ARL.CommissionPaymentID OR PAY.ID = ARL.CommissionPaymentIDReported)
		
WHERE ACA.ClientID = @clientID 
	AND ARL.GLPosted = @glPosted 
	AND ARL.PendingAdvisorPost = @pendingAdvisorPost 
	AND ACA.WrapProvider = @wrapProvider 
	AND ARL.AdvisorPostMethod = @advisorPostMethod
	AND PAY.PaymentTransactionID = @paymentTransactionID
GROUP BY ARL.AsAt, ARL.TranType, PD.ProductType, CSD.Name, CSD.ReferenceNumber



GO
