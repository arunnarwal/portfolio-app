/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>FDD718C87C81284285164CED9DFB7205</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[spCancelSchemeChargesZurich](@schemeID int, @userID int) AS

--declare @schemeID as int
--declare @userID as int
--set @schemeID = 1
--set @userID = 8245

update ClientAccount..SchemeLevelRemuneration 
set Status = 'Cancelled', UserCancelled = @userId, DateCancelled = getdate()
where Status = 'Active' and SchemeId = @schemeID

update ClientAccount..SchemeDistributorRenewalCommission 
set Status = 'Cancelled', UserCancelled = @userId, DateCancelled = getdate()
where Status = 'Active' and SchemeId = @schemeID

update ClientAccount..SchemeDrawdownCharges
set Status = 'Cancelled', UserCancelled = @userId, DateCancelled = getdate()
where Status = 'Active' and SchemeId = @schemeID
GO

