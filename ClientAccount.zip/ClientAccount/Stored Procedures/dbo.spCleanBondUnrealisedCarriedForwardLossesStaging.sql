/***
<StoredProcedure>
    <Description>Clean table after unrealised memo looses report is generated</Description>
    <Service>Transaction</Service>
</StoredProcedure>
***/
CREATE PROCEDURE [dbo].[spCleanBondUnrealisedCarriedForwardLossesStaging] AS
BEGIN
DELETE FROM dbo.BondUnrealisedCarriedForwardLossesStaging WHERE 1=1

END