/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>6608271FF6811DD248B1299142B6C674</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[spClearValidation](@SessionID int, @Page varchar(50)) AS 
DELETE FROM workflowwizardsessionvalidation 
WHERE page = @Page AND clientsessionid = @SessionID;
select 'x';
GO
