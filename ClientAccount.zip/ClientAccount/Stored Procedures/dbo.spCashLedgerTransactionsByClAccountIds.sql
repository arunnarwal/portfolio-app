
CREATE PROCEDURE [dbo].[spCashLedgerTransactionsByClAccountIds](
               @ClAccountIDs   VARCHAR(MAX), @AsAt DATE)
AS
  
 --DECLARE  @ClAccountIDs VARCHAR(MAX) ='OPCHQPAYMENTS,OMCHQPAYMENTS,OMCHQTRFPAYMENTS,OPCHQTRFPAYMENTS' 


;WITH ValidAccounts AS
 (
 SELECT
   se.ClAccountID,
   agp.DivisionCode
 FROM dbo.SEClientAccount se
   INNER JOIN dbo.AccountGladProperties agp
     ON agp.AccountId = se.Id
WHERE se.ClAccountID IN
      (Select TabValue FROM CSFBMaster.dbo.fn_convert_comma_to_table_char(@ClAccountIDs))
)
  

SELECT
 account.ClAccountID,
 account.DivisionCode,
 SUM(clt.Amount) AS Balance
FROM dbo.CashLedgerTransactions clt
   INNER JOIN ValidAccounts account
     ON account.ClAccountID = clt.ClAccountID
WHERE clt.LedgerDate <= @AsAt
GROUP BY account.ClAccountID, account.DivisionCode


