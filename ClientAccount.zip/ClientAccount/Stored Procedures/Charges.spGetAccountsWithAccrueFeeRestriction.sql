/***
<StoredProcedure>
    <Description>Get Get Accounts With AccrueFee Restriction</Description>
    <Service>Charges</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE [Charges].[spGetAccountsWithAccrueFeeRestriction] 
AS
BEGIN
	
	-- restricted by account restrictions
	SELECT
		seca.Id As AccountId,
		ar.IsActive As RestrictAccruals	 
	FROM 
		[dbo].[AccountRestrictions] ar 
		INNER JOIN [dbo].[RestrictionTypes] rt on ar.RestrictionType = rt.Id
		INNER JOIN [dbo].[SeClientAccount] seca on seca.ClAccountId = ar.ClAccountId
	WHERE rt.RestrictionName = 'AccrueFee'
	AND ar.IsActive = 1

	UNION

	-- restricted in Deauthorised firm
	SELECT 
		seca.Id As AccountId,
		1 As RestrictAccruals	 
	FROM dbo.SEClientAccount seca
	INNER JOIN dbo.vwHeadAccountIds ha on ha.HeadAccountId = seca.Id and ha.AccountId = seca.Id 
	INNER JOIN dbo.Advisor adv on adv.AdvCode = seca.PrimaryAdviser
	INNER JOIN dbo.Company co on co.Company = adv.Company
	AND co.FSAAuthorisationStatus = 'Deauthorised'

END