/***
<StoredProcedure>
   <Description>Moves an Adviser to a new Company and/or Branch.
   AFTER CALLING THIS PROCEDURE, RUN THE FOLLOWING:
	   RemoveEntityPermissionsForAllUsers to remove all existing direct permissions to the advisor
	   MaintSetCachedPermissionsByUpdatedEntity to maintain all existing users that have access to the advisor or the advisor's accounts
	   SetUserEntityPermissionsComplete to replace the existing advisor user's permissions with permission to the advisor only.
   </Description>
   <Parameters>
      <Parameter Name="@AdvCode">
         <Description>The advisor to move</Description>
      </Parameter>
      <Parameter Name="@Company">
         <Description>The company to move the advisor to</Description>
      </Parameter>
	  <Parameter Name="@BranchId" Nullable="true">
         <Description>The branch to move the advisor to</Description>
      </Parameter>
   </Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [dbo].[spChangeAdvisersCompany]
		@AdvCode	VARCHAR(20),
		@Company	VARCHAR(20),
		@BranchId	INT
AS
BEGIN

	IF @BranchId = 0 
	BEGIN
		SET @BranchId = NULL
	END


	SET NOCOUNT ON;
  
	BEGIN TRY;

		BEGIN TRANSACTION;

		DECLARE		@AdvisorId INT = (	SELECT		a.Id
										FROM		dbo.Advisor a 
										INNER JOIN	dbo.Company c ON c.Company = @Company 
										LEFT JOIN	dbo.Branches b ON b.Id = @BranchId AND b.Company = c.Company 
										WHERE		a.AdvCode = @AdvCode
										AND			(b.Id = @BranchId OR @BranchId IS NULL));

		IF @AdvisorId IS NULL
			THROW	50000, 'Invalid AdvCode/Company/BranchId', 1;

		UPDATE		dbo.Advisor
		SET			Company = @Company,
					SubCompanyId = NULL,
					SuperBranchId = NULL,
					BranchId = @BranchId,
					SubBranchId = NULL,
					FCAStatus = CASE WHEN a.FCAStatusInherited = 1 THEN c.FSAAuthorisationStatus ELSE a.FCAStatus END
		FROM		dbo.Advisor a
		INNER JOIN	dbo.Company c ON c.Company = @Company
		WHERE		a.AdvCode = @AdvCode;

		UPDATE		dbo.ClientDetails
		SET			Company = @Company
		WHERE		ClAccountId IN (SELECT ClAccountId FROM dbo.SEClientAccount WHERE PrimaryAdviser = @AdvCode);

		UPDATE dbo.FeeStanding
		SET Company = @Company
		WHERE Active = 1
			AND CLAccountID IN (SELECT CLAccountID FROM dbo.SEClientAccount WHERE PrimaryAdviser = @AdvCode)

		UPDATE		ClientDB3.dbo.TblClients
		SET			Company = @Company,
					BranchId = @BranchId
		WHERE		AdvCode = @AdvCode;


		DECLARE @DefaultPaymentPoint INT = (
			SELECT		ISNULL(cb.Id, nb.Id)
			FROM		dbo.Company c
			INNER JOIN	dbo.Network n ON n.Network = c.Network
			LEFT JOIN	dbo.Bankaccount cb ON cb.OwnerType = 'Company' AND cb.IsDefault = 1 AND cb.[Owner] = c.company AND cb.[Status] = 'Active' 
			LEFT JOIN	dbo.Bankaccount nb ON nb.OwnerType = 'Network' AND nb.IsDefault = 1 AND nb.[Owner] = n.Network AND nb.[Status] = 'Active' 
			WHERE		c.company = @Company);

		IF @DefaultPaymentPoint IS NOT NULL
		BEGIN
			UPDATE Discovery.dbo.AdvisorRevenueLedger
		    SET Company = @Company
		    WHERE AdvCode = @AdvCode 
		      AND TranType IN ('OA Charge', 'RIAC', 'IAC')
			  AND AdvisorPosted = 'NO'
			  AND AdvisorPostMethod = 'ACORN'
			  AND ClAccountId IN (SELECT ClAccountId FROM dbo.SEClientAccount WHERE PrimaryAdviser = @AdvCode);

			IF NOT EXISTS (SELECT 1 FROM dbo.AdvisorPaymentPoints WHERE AdvisorId = @AdvisorId)
				INSERT INTO dbo.AdvisorPaymentPoints (AdvisorId, BankAccountId) VALUES (@AdvisorId, @DefaultPaymentPoint)
			ELSE
				UPDATE		dbo.AdvisorPaymentPoints SET BankAccountId = @DefaultPaymentPoint WHERE AdvisorId = @AdvisorId;
		END

		COMMIT TRANSACTION;
		
		SELECT ClientId AS UserId FROM ClientDB3.dbo.TblClients WHERE AdvCode = @AdvCode AND OSTEnabled = 1; --Return all enabled moved users

	END TRY
	BEGIN CATCH;

		ROLLBACK TRANSACTION;
		THROW;

	END CATCH;

END;