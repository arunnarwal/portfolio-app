/***
<StoredProcedure>
    <Description>This will move Company under new Network</Description>
    <Feature>Adviser Servicing - Moving AR Netowrk</Feature>
</StoredProcedure>
***/

CREATE PROCEDURE [dbo].[spChangeCompanysNetwork] (@Company VARCHAR(20), @Network VARCHAR(50))
AS
DECLARE  @ErrorMessage VARCHAR(MAX)
SET nocount  ON
/*
DECLARE @Company VARCHAR(20)
DECLARE @Network VARCHAR(50)
SET @Company = 'AVAABQ'
SET @Network = 'AVNW00009'
*/
DECLARE @FCAStatus VARCHAR(50)

BEGIN TRANSACTION
  
BEGIN TRY

	EXEC spChangeAdviserPaymentPoints @Company, @Network
	
	UPDATE dbo.Company
	SET Network = @Network
	WHERE Company = @Company

	SET @FCAStatus = (SELECT FSAAuthorisationStatus FROM dbo.Network WHERE Network = @Network)
	EXEC dbo.spUpdateInheritedFcaAuthorisationStatusByNetwork @NetworkCode = @Network, @Status = @FCAStatus

	COMMIT TRANSACTION
END TRY
  
BEGIN CATCH

	ROLLBACK TRANSACTION
	SET @ErrorMessage = Error_message()

END CATCH
 
SELECT @ErrorMessage AS Errormessage

GO
