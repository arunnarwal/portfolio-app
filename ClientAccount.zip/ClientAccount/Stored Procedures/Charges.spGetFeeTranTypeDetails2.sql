/***
<StoredProcedure>
    <Description>Get the fields required for fees engine from FeeTranTypes table</Description>
    <Service>Charges</Service>
    <Feature>FeeTranTypes</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE Charges.spGetFeeTranTypeDetails2

AS

	SELECT TranType, WrapProvider, SystemToPostTo as AdvisorPostMethod, IsPaymentByDirectDebitAllowed, IsPaymentByDebitCardAllowed
	From dbo.FeeTranTypes Ftt
	
GO