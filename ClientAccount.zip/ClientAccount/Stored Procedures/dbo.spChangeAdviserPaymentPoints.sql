/***
<StoredProcedure>
    <Description>This will move Advisers Payment Point bank account under a target Networks bank account</Description>
    <Feature>Adviser Servicing - Moving AR Netowrk</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE dbo.spChangeAdviserPaymentPoints(
	@Company AS VARCHAR(20), 
	@TargetNetwork AS VARCHAR(50)
) 
AS

--DECLARE @Company AS VARCHAR(20) = 'AVAR06086'
--DECLARE @TargetNetwork AS VARCHAR(30) = 'AVNW00494'

	DECLARE @SourceNetworkBankAccountId AS INT 
	SELECT 
		@SourceNetworkBankAccountId = BA.Id 
	FROM
		dbo.BankAccount BA
		INNER JOIN dbo.Company C ON BA.OwnerType = 'Network' AND BA.[Owner] = C.Network
		INNER JOIN dbo.Network N ON C.Network = N.Network
	WHERE
		BA.[Status] = 'Active'
		AND C.Company = @Company
	
	IF @SourceNetworkBankAccountId IS NULL
		RETURN;

	DECLARE @TargetNetworkBankAccountId AS INT 
	SELECT 
		@TargetNetworkBankAccountId = BA.Id 
	FROM
		dbo.BankAccount BA
		INNER JOIN dbo.Network N ON BA.OwnerType = 'Network' AND BA.[Owner] = N.Network
	WHERE
		BA.[Status] = 'Active'
		AND N.Network = @TargetNetwork

	UPDATE
		APP
	SET
		APP.BankAccountId = @TargetNetworkBankAccountId
	FROM
		dbo.Advisor A
		INNER JOIN dbo.AdvisorPaymentPoints AS APP ON A.Id = APP.AdvisorId
	WHERE
		APP.BankAccountId = @SourceNetworkBankAccountId
		AND A.Company = @Company
