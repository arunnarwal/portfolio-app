/***
<StoredProcedure>
  <Description>Cash entries for auto match with swift transactions</Description>
    <Parameters>
        <Parameter Name="@AccountIdList">
            <Description>Account Id List</Description>
        </Parameter>
        <Parameter Name="@MaximumCashEntries">
            <Description>Maximum Cash Entries to be picked up for matching</Description>
        </Parameter>
        <Parameter Name="@MinCashEntryAge">
            <Description>Min Cash Entry Date For Cash entry Match</Description>
        </Parameter>
        <Parameter Name="@MaxCashEntryAge">
            <Description>Max Cash Entry Date For Cash entry Match</Description>
        </Parameter>
        <Parameter Name="@CashMethod">
            <Description>Cash Method - cheque or direct debit</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE Banking.spGetCashEntriesForReconciliationAutoMatching
(
	@AccountIdList VARCHAR(MAX),
	@MaximumCashEntries INT = 2147483647,
	@MinCashEntryAge DATETIME,
	@MaxCashEntryAge DATETIME,
	@CashMethod VARCHAR(25)
)
AS
    -- Last second of the day
    SET @MinCashEntryAge = DATEADD(s, -1,DATEADD(DAY,DATEDIFF(DAY, 0 , @MinCashEntryAge)  + 1,0))

    SELECT CAST(V.TabValue AS VARCHAR(20)) ClAccountId
    INTO #AccountIds
    FROM CSFBMaster.dbo.fn_convert_comma_to_table_char(@AccountIdList) V

    CREATE UNIQUE CLUSTERED INDEX CUIDX_ClAccountId ON #AccountIds (ClAccountId)

    DECLARE @CurrentTaxYear INT

    SELECT @CurrentTaxYear = Discovery.dbo.fnGetTaxYear(GETDATE())

    SELECT
        CE.Id AS CashEntryId,
        CE.Currency,
        CE.Amount,
        CE.ClAccountId,
        CE.DateCreated,
        CE.BatchId,
        CE.Method,
        CE.[Type],
        CE.SubType,
        CE.PaymentSubType,
        CE.PooledCashExpectationId,
        CE.[Source]
    INTO
        #CashEntries
    FROM
        Discovery.dbo.CashEntry CE
    WHERE
        CE.[Type] = 'Deposit'
        AND CE.[Status] IN('Confirmed', 'Authorised')
        AND CE.Amount > 0
        AND CE.InstructionType <> 'Standing'
        AND CE.DateJournalled IS NULL
        AND CE.DateCreated BETWEEN @MaxCashEntryAge AND @MinCashEntryAge

    SELECT
        CE.CashEntryId,
        CE.Currency,
        CE.Amount,
        CE.ClAccountId,
        CON.ClAccountId HeadClAccountId,
        PS.ProductSubscriptionLimit,
        SRAC.RecId,
        CE.DateCreated,
        SRAC.GladBankAccountId
    INTO
        #CashEntriesWithDetails
    FROM
        #CashEntries CE
        INNER JOIN dbo.SEClientAccount SE ON SE.ClAccountId = CE.ClAccountId
        LEFT JOIN dbo.AccountGladProperties PROP ON SE.Id = PROP.AccountId
        INNER JOIN dbo.Consolidate CON ON CON.SubClAccountId = CE.ClAccountId
        INNER JOIN #AccountIds A ON CE.ClAccountId = A.ClAccountId OR CON.ClAccountId = A.ClAccountId
        INNER JOIN dbo.ClientDetails CD ON CD.ClAccountId = CE.ClAccountId
        INNER JOIN Discovery.dbo.ClientAccount CA ON CA.ClAccountId = CE.ClAccountId
        INNER JOIN Discovery.dbo.ClientAccount AS HeadCA ON HeadCA.ClAccountId = CON.ClAccountId
        INNER JOIN dbo.SEClientAccount HeadSE ON HeadSE.ClAccountId = CON.ClAccountId
        INNER JOIN Platform.DBAAccount.CustomerRoles CR ON CR.AccountId = HeadSE.Id AND CR.IsPrimaryRole = 1
        LEFT JOIN Platform.DBACustomer.DeathDetails DD ON DD.CustomerId = CR.CustomerId
        LEFT JOIN Platform.DBACustomer.RegulatoryChecks RC ON RC.CustomerId = CR.CustomerId 
            AND RC.RegulatoryCheckTypeId = 1 -- AML 
            AND RC.RegulatoryCheckResultId = 1 -- Pass
        INNER JOIN dbo.Company CO ON CO.Company = CD.Company
        LEFT JOIN Discovery.dbo.ProductDetails PD ON PD.ClAccountId = CE.ClAccountId
        LEFT JOIN dbo.vwProductSettings PS
            ON PD.ProductType = PS.ProductType
            AND (PD.ProductSubTypeId = PS.ProductSubTypeId
                OR (PS.ProductSubTypeId IS NULL
                    AND CA.SubAccountType = PS.SubAccountType ))
            AND CO.WrapProvider = PS.WrapProvider
            AND CO.Company = PS.Company
            AND PS.ProductUsage = 'default'
        INNER JOIN  Discovery.dbo.Batch B ON B.BatchId = CE.BatchId
        INNER JOIN Banking.SwiftBankAccountReconciliationConfig SRAC
            ON CE.Method = SRAC.Method
            AND (SRAC.SubType IS NULL OR SRAC.SubType = COALESCE(CE.SubType, CE.[Type]))
            AND (SRAC.NullPaymentSubType IS NULL OR SRAC.NullPaymentSubType = CASE WHEN CE.PaymentSubType IS NULL THEN 1 ELSE 0 END)
            AND (SRAC.SubAccountType IS NULL OR SRAC.SubAccountType = CA.SubAccountType)
            AND (SRAC.RestrictActivity IS NULL OR SRAC.RestrictActivity = B.RestrictActivity)
            AND (SRAC.AllowPooledCashExpectation = 1 OR CE.PooledCashExpectationId IS NULL)
            AND (SRAC.DivisionCode1 = PROP.DivisionCode OR (SRAC.DivisionCode2 IS NOT NULL AND SRAC.DivisionCode2 = PROP.DivisionCode))
            AND (SRAC.MaxCashExpectationAmount IS NULL OR SRAC.MaxCashExpectationAmount > CE.Amount)
            AND (SRAC.RestrictEmployerContribution = 0 OR CE.Source <> 'Employer')
            AND (SRAC.Disaggregated IS NULL OR SRAC.Disaggregated = dbo.[fnIsTransferDissagregated](CE.BatchId))
            AND (SRAC.CheckAMLStatus = 0 OR RC.RegulatoryCheckResultId = 1)
            AND (SRAC.CheckCustomerIsNotDeceased = 0 OR DD.DateOfDeath IS NULL)
        INNER JOIN dbo.Reconciliations R ON SRAC.RecId = R.RecId
        LEFT JOIN dbo.ReconciledResultsRoot RRR ON RRR.RecId = R.RecId AND RRR.TableConstant = R.TableConstant2 AND CE.CashEntryId = RRR.IdFieldValue
    WHERE
        HeadCA.Status = 'Active'
        AND NOT EXISTS (SELECT Id FROM dbo.ReconciledResults RR WHERE RR.RecId = R.RecId AND RR.TableConstant = R.TableConstant2 AND RR.IDFieldValue = CE.CashEntryId AND RR.DateUnMatched IS NULL)
        AND NOT EXISTS (SELECT RootId FROM dbo.ReconciledResultsPending RRP WHERE RRP.RootId = RRR.ReconciledResultsRootId)
        AND HeadSE.InvestorType <> 'Consolidated'
        AND HeadCA.DPSAccountType <> 'Sub-Account'
        AND CD.RestrictActivities = 0
        AND (SRAC.ExcludeOrganizationClientsFromAutoMatching = 0 OR NOT EXISTS (SELECT 1 FROM PLatform.DBACustomer.Customers CT JOIN Platform.DBACustomer.CustomerTypes CTT ON CT.CustomerTypeId = CTT.CustomerTypeId WHERE CT.CustomerId = CR.CustomerId AND CTT.CustomerType = 'Organisation'))
        AND SRAC.Method = @CashMethod
    OPTION (RECOMPILE)

    CREATE CLUSTERED INDEX CIDX_CashEntryId ON #CashEntriesWithDetails (CashEntryId)
    CREATE NONCLUSTERED INDEX IDX_ClAccountId ON #CashEntriesWithDetails (ClAccountId)

    SELECT DISTINCT ClAccountId
    INTO #FilteredAccounts
    FROM #CashEntriesWithDetails

    CREATE UNIQUE CLUSTERED INDEX CUIDX_ClAccountId ON #FilteredAccounts (ClAccountId)

    SELECT
        SUM(ISAS.Amount) AS Amount,
        ISAS.ClAccountId,
        ISAS.TaxYear
    INTO
        #IsaSubscriptionsByTaxYear
    FROM
        #FilteredAccounts A
        INNER JOIN Discovery.dbo.vwIsaSubscriptions ISAS ON A.ClAccountId = ISAS.ClAccountId
    WHERE
        ISAS.[Status] = 'Completed'
    GROUP BY
        ISAS.ClAccountId,
        ISAS.TaxYear

    CREATE UNIQUE CLUSTERED INDEX CUIDX_ClAccountIdTaxYear ON #IsaSubscriptionsByTaxYear (ClAccountId, TaxYear)

    SELECT ITY.ClAccountId, ITY.Amount
    INTO #IsaSubscriptions
    FROM #IsaSubscriptionsByTaxYear ITY
    WHERE ITY.TaxYear = @CurrentTaxYear

    CREATE UNIQUE CLUSTERED INDEX CUIDX_ClAccountId ON #IsaSubscriptions (ClAccountId)

    ;WITH ClAccountIdToExclude AS
    (
        SELECT CE.ClAccountId
        FROM #CashEntriesWithDetails CE
        INNER JOIN #IsaSubscriptions ISAS ON ISAS.ClAccountId = CE.ClAccountId
        AND CE.ProductSubscriptionLimit <= ISAS.Amount

        UNION ALL

        SELECT AAR.ClAccountId
        FROM dbo.vwActiveAccountRestrictions AAR
        WHERE
            AAR.RestrictionName = 'Deposit'
            AND AAR.ClAccountId IN
            (
                SELECT CE.ClAccountId FROM #CashEntriesWithDetails CE
                UNION ALL
                SELECT CE2.HeadClAccountId FROM #CashEntriesWithDetails CE2
            )
    )

    SELECT TOP (@MaximumCashEntries)
        CE.CashEntryId,
        CE.Currency,
        CE.Amount,
        CE.ClAccountId,
        CE.HeadClAccountId,
        CE.RecId,
        CE.DateCreated,
        CE.GladBankAccountId
    FROM
        #CashEntriesWithDetails CE
    WHERE
        NOT EXISTS (SELECT 1 From ClAccountIdToExclude CTE WHERE CE.ClAccountId = CTE.ClAccountId)
    ORDER BY
        CE.CashEntryId

    DROP TABLE #AccountIds
    DROP TABLE #CashEntries
    DROP TABLE #CashEntriesWithDetails
    DROP TABLE #IsaSubscriptionsByTaxYear
    DROP TABLE #IsaSubscriptions
    DROP TABLE #FilteredAccounts
