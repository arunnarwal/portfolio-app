/***
<StoredProcedure>
    <Description>Get account glad properties</Description>
	<Parameters>
        <Parameter Name="@ClAccountId">
            <Description>Id of the client account</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [dbo].[spAccountGladProperties](@ClAccountId VARCHAR(20))
AS
SELECT
	AAP.AccountID,
	AAP.DivisionCode,
	AAP.InvestorType,
	SEA.ClAccountID,
	HA.HeadClAccountID
	FROM CashLedger.AccountGladProperties AAP
	INNER JOIN dbo.SEClientAccount SEA ON SEA.Id = AAP.AccountID
	INNER JOIN dbo.fnHeadAccounts() HA ON HA.ClAccountID = SEA.ClAccountID
	WHERE SEA.ClAccountID = @ClAccountId
GO




