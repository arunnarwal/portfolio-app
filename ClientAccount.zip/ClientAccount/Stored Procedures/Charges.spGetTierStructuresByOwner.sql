/***
<StoredProcedure>
    <Description>Gets tier structures by owner - for Quilters owner will be a network</Description>
	<Parameters>
		<Parameter Name="@OwnerHierarchyLevelNameId">
			<Description>The type of the owner</Description>
		</Parameter>
		<Parameter Name="@OwnerEntityid">
			<Description>The Id of the owner</Description>
		</Parameter>
	</Parameters>	
</StoredProcedure>
***/
CREATE PROCEDURE Charges.spGetTierStructuresByOwner
(
    @OwnerHierarchyLevelNameId INT,
    @OwnerEntityId INT
)
AS
--DECLARE     @OwnerHierarchyLevelNameId INT =4,
--    @OwnerEntityId INT=5479
SELECT ts.TierStructureId,
       ts.TierStructureName,
       ts.OwnerHierarchyLevelNameId,
       ts.OwnerEntityId
FROM Charges.TierStructures ts
WHERE ts.OwnerHierarchyLevelNameId = @OwnerHierarchyLevelNameId
      AND ts.OwnerEntityId = @OwnerEntityId
      AND NOT EXISTS
(
    SELECT 1
    FROM Charges.TierStructureNovationLogs Logs
    WHERE Logs.NovatedTierStructureId = ts.TierStructureId
);
