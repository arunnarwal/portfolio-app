/***
<StoredProcedure>
  <Description>Account Managers By Company. Used on EditUserDetails</Description>
  <Parameters>		
	<Parameter Name="@ClientId">
        <Description>Id of the Client</Description>
    </Parameter>
	<Parameter Name="@BranchId">
        <Description>Id of Branch</Description>
    </Parameter>	
   </Parameters>
</StoredProcedure>
***/

CREATE PROCEDURE [dbo].[spAccountManagersByCompany](@ClientId INT, @BranchId INT) AS
BEGIN

--DECLARE @ClientId AS INT = 8245 
--DECLARE @BranchID AS INT = 3163

SELECT 

DISTINCT C.AccountManagerId

FROM dbo.Branches B  
INNER JOIN dbo.Company C ON B.Company = C.Company
WHERE B.ID = @BranchId 
AND EXISTS (
                -- verify adviser permissions
                SELECT 1
                FROM dbo.ClientAccountSecurity CAS		
				INNER JOIN dbo.SEClientAccount SECA ON CAS.AdvisorCodes = SECA.PrimaryAdviser
				INNER JOIN dbo.ClientDetails CD ON CD.ClAccountID = SECA.ClAccountID				
                WHERE CD.Company = C.Company
				AND CAS.ClAccountId IS NULL 
				AND CAS.ClientId = @ClientId   

				UNION ALL

				-- verify direct permissions
				SELECT 1
				FROM dbo.ClientAccountSecurity CAS				
				INNER JOIN dbo.SEClientAccount SECA ON SECA.ClAccountID = CAS.CLAccountID
				INNER JOIN dbo.ClientDetails CD ON CD.ClAccountID = SECA.ClAccountID
				WHERE CD.Company = C.Company
				AND CAS.ClientId = @ClientID
				AND CAS.ClAccountID IS NOT NULL
 
				UNION ALL

				-- verify SystemUser
				SELECT 1
				WHERE @ClientID = 8245
            )
END