/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>2052491AD87E4F40A4E794D2D102269A</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/

/****** Object:  StoredProcedure [dbo].[spCancelFeeUnitCancellationWithActiveOptOut]    Script Date: 07/10/2013 11:16:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[spCancelFeeUnitCancellationWithActiveOptOut] AS

UPDATE FUC
SET FUC.IsCancelled = 1, UserCancelled = 8245, DateCancelled = GETDATE()
FROM ClientAccount..FeeUnitCancellation FUC
	INNER JOIN ClientAccount..fnAccountHasCancellationsOptOuts() OPT
		ON FUC.ClAccountID = OPT.ClAccountID
 where COALESCE(ARLID, 0) = 0 and COALESCE(IsCancelled, 0) = 0 AND COALESCE(IsResubmitted, 0 ) = 0

GO


