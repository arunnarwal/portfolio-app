/***
<StoredProcedure>
    <Description>Accrue the OMC Fee</Description>
	<Service>Charges</Service>
    <Feature>Tasks</Feature>
    <Parameters>
        <Parameter Name="@AsAt">
            <Description>The date of the fee run</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/

CREATE PROCEDURE [dbo].[spAccrueOMCFee] (@AsAt DATETIME)
AS

/*
DECLARE @AsAt SMALLDATETIME
SET @AsAt = '30 Jul 2013'
*/

BEGIN TRY
	BEGIN TRANSACTION T1

	IF OBJECT_ID(N'tempdb..#Accruals', N'U') IS NOT NULL
	BEGIN
		DROP TABLE #Accruals
	END

	DECLARE @vatRate AS DECIMAL(18, 4)

	SELECT TOP 1 @vatRate = Rate
	FROM Discovery.dbo.VATRate
	WHERE Status = 'Current'

	DECLARE @TranType VARCHAR(10)
	SET @TranType = 'OMC'

	CREATE TABLE #Accruals (
		ToBeAppliedFeesId INT
		,AsAt SMALLDATETIME
		,secaID INT
		,valuation MONEY
		,amount MONEY
		,rate NUMERIC(7, 4)
		,VatRate NUMERIC(7, 4)
		,VATAmount MONEY
		,chargeDate SMALLDATETIME
		,IsProcessed BIT
		,CurrencyId INT
		)

	INSERT INTO #Accruals (
		ToBeAppliedFeesId
		,AsAt
		,secaID
		,valuation
		,amount
		,rate
		,chargeDate
		,IsProcessed
		,VatRate
		,VATAmount
		,CurrencyId
		)
	SELECT ToBeApplied.Id AS ToBeAppliedFeesId
		,Fum.AsAt
		,Fum.SECAId
		,ROUND(COALESCE((Fum.CashAmount + Fum.NonCashAmount), 0), 4) AS Valuation
		,CASE 
			WHEN ToBeApplied.ApplyVAT = 1
				THEN ROUND(COALESCE(((Fum.CashAmount + Fum.NonCashAmount) * ToBeApplied.Rate / 100 / 365.25), 0), 4) + ROUND(COALESCE(((Fum.CashAmount + Fum.NonCashAmount) * ToBeApplied.Rate / 100 / 365.25), 0) * @vatRate / 100, 4)
			ELSE ROUND(COALESCE(((Fum.CashAmount + Fum.NonCashAmount) * ToBeApplied.Rate / 100 / 365.25), 0), 4)
			END AS Amount
		,COALESCE(ToBeApplied.Rate, 0) AS Rate
		,FrqRanged.ToDate
		,0 AS IsProcessed
		,CASE 
			WHEN ToBeApplied.ApplyVAT = 1
				THEN @vatRate
			ELSE NULL
			END AS VatRate
		,CASE 
			WHEN ToBeApplied.ApplyVAT = 1
				THEN ROUND(COALESCE(((Fum.CashAmount + Fum.NonCashAmount) * ToBeApplied.Rate / 100 / 365.25), 0) * @vatRate / 100, 4)
			ELSE NULL
			END AS VATAmount
		,Fum.CurrencyId
	FROM Cache.dbo.Fee_FUM_ByAccount AS Fum
	INNER JOIN dbo.[SEClientAccount] AS SecaId
		ON SecaId.Id = Fum.SECAId
	INNER JOIN Discovery.dbo.ClientAccount AS ClientAccount
		ON ClientAccount.ClAccountId = SecaId.ClAccountId
	INNER JOIN dbo.Advisor AS Advisor
		ON SecaId.PrimaryAdviser = Advisor.AdvCode
	INNER JOIN dbo.Company Company
		ON Company.Company = Advisor.Company
	INNER JOIN dbo.WrapProvider AS WrapProvider
		ON WrapProvider.Id = Fum.WrapProviderId
	INNER JOIN dbo.FeeTranTypes AS FeeTranTypes
		ON FeeTranTypes.TranType IN (@TranType)
			AND FeeTranTypes.WrapProvider = WrapProvider.WrapProvider
	INNER JOIN .dbo.ToBeAppliedFees_ByAccV2 AS ToBeApplied
		ON ToBeApplied.AsAt = Fum.AsAt
			AND Fum.SECAId = ToBeApplied.SecaId
			AND ToBeApplied.Applied = 0
			AND FeeTranTypes.Id = ToBeApplied.FeeTranTypesId
	INNER JOIN dbo.vwFeeConfigByCompany FeeConfig
		ON FeeConfig.CompanyId = Company.Id
	CROSS APPLY dbo.fnGetDateRangesForFrequencies(@AsAt,FeeConfig.SeedDate)  FrqRanged
	WHERE Fum.AsAt = @AsAt AND FeeConfig.Frequency = FrqRanged.Frequency

	INSERT INTO dbo.Fee_Accrual_OMC (
		AsAt
		,SecaId
		,Valuation
		,Amount
		,Rate
		,ChargeDate
		,IsProcessed
		,VatRate
		,VatAmount
		,CurrencyId
		)
	SELECT #Accruals.AsAt
		,#Accruals.SECAId
		,#Accruals.Valuation
		,#Accruals.Amount
		,#Accruals.Rate
		,#Accruals.ChargeDate
		,#Accruals.IsProcessed
		,#Accruals.VatRate
		,#Accruals.VATAmount
		,#Accruals.CurrencyId
	FROM #Accruals
END TRY

BEGIN CATCH
	ROLLBACK TRANSACTION T1

	DECLARE @ErrorMessage NVARCHAR(4000);
	DECLARE @ErrorSeverity INT;
	DECLARE @ErrorState INT;

	IF OBJECT_ID(N'tempdb..#Accruals', N'U') IS NOT NULL
	BEGIN
		DROP TABLE #Accruals
	END

	SELECT @ErrorMessage = ERROR_MESSAGE()
		,@ErrorSeverity = ERROR_SEVERITY()
		,@ErrorState = ERROR_STATE();

	RAISERROR (
			@ErrorMessage
			,@ErrorSeverity
			,@ErrorState
			);
END CATCH;

IF @@TRANCOUNT > 0
BEGIN
	SELECT 'Success' AS Result

	UPDATE dbo.ToBeAppliedFees_ByAccV2
	SET Applied = 1
		,ProcessedDate = GETDATE()
	WHERE Id IN (
			SELECT ToBeAppliedFeesId
			FROM #Accruals
			)

	INSERT INTO dbo.AppliedFees_ByAccV2 (
		FeeTranTypesId
		,SecaId
		,Rate
		,ProcessedDate
		,DateCreated
		,AsAt
		,ApplyVat
		)
	SELECT ToBeApplied.FeeTranTypesId
		,ToBeApplied.SECAId
		,ToBeApplied.Rate
		,ToBeApplied.ProcessedDate
		,ToBeApplied.DateCreated
		,ToBeApplied.AsAt
		,ToBeApplied.ApplyVAT
	FROM dbo.ToBeAppliedFees_ByAccV2 ToBeApplied
	WHERE Id IN (
			SELECT #Accruals.ToBeAppliedFeesId
			FROM #Accruals
			)

	DELETE dbo.ToBeAppliedFees_ByAccV2
	WHERE Id IN (
			SELECT ToBeAppliedFeesId
			FROM #Accruals
			)

	IF OBJECT_ID(N'tempdb..#Accruals', N'U') IS NOT NULL
	BEGIN
		DROP TABLE #Accruals
	END

	COMMIT TRANSACTION T1
END
GO