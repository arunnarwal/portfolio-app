/***
<StoredProcedure>
    <Description>This stored procedure is used to gather up all individual part fills that need to be converted into a contract note for a given order and sets them to processing.
 An additional check to ensure all part fills have arrived will be performed too before the trades are set to processing.</Description>
</StoredProcedure>
***/
CREATE PROCEDURE [dbo].[spBeginProcessingPartFillsByOrderIdWithCheck] (@orderId AS INT, @filledQuantity AS [decimal](18,6))
AS

DECLARE @ProcessingTradeBookingDetails TABLE
(
	TradeBookingDetailId INT
)

UPDATE dbo.TradeBookingDetails
SET TradeBookingDetailStatusId = 2 --Processing
OUTPUT INSERTED.TradeBookingDetailId INTO @ProcessingTradeBookingDetails
WHERE TradeBookingDetailStatusId = 1 --Created
AND OrderId = @orderId
AND @filledQuantity = (SELECT SUM(Quantity) FROM dbo.TradeBookingDetails WHERE OrderId = @orderId)

SELECT
TB.OrderId,
OC.OrderBuySell,
TB.Currency,
TB.TotalQuantity,
TB.TotalValue,
TB.TotalDiscretionValue,
TB.TradeDateTime,
TB.SettlementDate,
ISO.MIC,
TB.BrokerId,
TB.TraderId,
T.TraderName,
TB.AccruedInterestAmount,
CUS.CustodianClAccountID,
COM.WrapProvider,
TB.TradeReference,
CASE WHEN TB.MinPrice = TB.MaxPrice THEN TB.MinPrice ELSE NULL End as TradePrice
FROM
(
	SELECT
	TBD.OrderId,	
	TBD.Currency,
	SUM(TBD.Quantity) AS TotalQuantity,
	SUM(TBD.Quantity * TBD.Price) AS TotalValue,
	SUM(TBD.Quantity * TBD.DiscretionPrice) AS TotalDiscretionValue,
	MAX(TBD.TradeDateTime) AS TradeDateTime,
	TBD.SettlementDate,
	TBD.MarketId,
	TBD.BrokerId,
	TBD.TraderId,
	SUM(TBD.AccruedInterestAmount) AS AccruedInterestAmount,
	CASE WHEN MIN(TBD.TradeReference) = MAX(TBD.TradeReference) THEN MIN(TBD.TradeReference) ELSE NULL End as TradeReference,
	MIN(TBD.Price) as MinPrice,
	MAX(TBD.Price) as MaxPrice
	FROM
	@ProcessingTradeBookingDetails PTBD
	INNER JOIN dbo.TradeBookingDetails TBD ON TBD.TradeBookingDetailId = PTBD.TradeBookingDetailId
	GROUP BY TBD.OrderId, TBD.Currency, TBD.SettlementDate, TBD.MarketId, TBD.BrokerId, TBD.TraderId) TB
INNER JOIN Discovery.dbo.OrderCurrent OC ON OC.OrderID = TB.OrderId
INNER JOIN dbo.CustodianAccounts CUS ON CUS.CustodianAccountID = OC.CustodianAccountID
INNER JOIN dbo.Traders T ON T.TraderID = TB.TraderId
INNER JOIN dbo.ClientDetails AS CD on oc.ClAccountId = CD.ClAccountId
INNER JOIN dbo.Company AS COM on CD.Company = COM.Company
INNER JOIN Res_DB.dbo.MarketCodes_ISO10383 ISO ON ISO.ID = TB.MarketId
GO