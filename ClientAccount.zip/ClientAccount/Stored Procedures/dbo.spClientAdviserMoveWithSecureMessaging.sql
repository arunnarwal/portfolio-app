/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>83A2444B12A8B8192471BF901FAEFB2A</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[spClientAdviserMoveWithSecureMessaging] (@ClAccountID varchar(20), @AdviserCode varchar(20)) AS
DECLARE @ErrorMessage varchar(max)
SET NOCOUNT ON
BEGIN TRANSACTION
BEGIN TRY
--Update PrimaryAdviser in SEClientAccount
UPDATE SEClientAccount
SET PrimaryAdviser = @AdviserCode
WHERE ClAccountID IN (
SELECT ClAccountID FROM fnHeadAccounts() HA WHERE HA.Headclaccountid = @ClAccountID
)
END TRY
BEGIN CATCH
SET @ErrorMessage = error_message()
GOTO HANDLE_ERROR
END CATCH
BEGIN TRY
--Update AdvCode in advisorrevenueledger
UPDATE Discovery..advisorrevenueledger
SET AdvCode = @AdviserCode
WHERE ClAccountID IN (
SELECT ClAccountID FROM fnHeadAccounts() HA WHERE HA.Headclaccountid = @ClAccountID
) and glposted = 'NO'
END TRY
BEGIN CATCH
SET @ErrorMessage = error_message()
GOTO HANDLE_ERROR
END CATCH
BEGIN TRY
--Update advisorcodes in clientaccountsecurity
UPDATE clientaccountsecurity
SET advisorcodes = @AdviserCode
WHERE ClAccountID IN (
SELECT ClAccountID FROM fnHeadAccounts() HA WHERE HA.Headclaccountid = @ClAccountID
)
--Update secure message group to the new advisor 
declare @clientid as int
declare @groupid as int
set @clientid = (select clientid from clientaccount..accountholders where claccountid = @ClAccountID)
set @groupid = (select id from clientdb3..SecureMessageAdminGroups where groupname = @AdviserCode)
if @clientid > 0 and @groupid > 0
begin
update clientDB3.dbo.SecureMessageAdminGroupsToClients set groupid = @groupid where clientid = @clientid
end
END TRY
BEGIN CATCH
SET @ErrorMessage = error_message()
GOTO HANDLE_ERROR
END CATCH
COMMIT TRANSACTION
SELECT null as ErrorMessage
HANDLE_ERROR:
ROLLBACK TRANSACTION
SELECT @ErrorMessage as ErrorMessage

GO
