/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>9042D1249CF603DA9080AA02895D3472</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[spCmtAccruedInterestSumAsAt] 
	@AsAt datetime, 
	@ClAccountId VarChar(20)
AS
BEGIN
	SET NOCOUNT ON;
    
	SELECT Sum(NetAmount) as  NetAmount from ClientAccount.dbo.CmtAccruedInt where AsAtDate <= @AsAt and ClAccountId = @ClAccountId
END
GO
