/***
<StoredProcedure>
    <Description>Creates a tier structure</Description>
	<Parameters>
		<Parameter Name="@TierStructureName">
			<Description>The name of the tier structure</Description>
		</Parameter>
		<Parameter Name="@OwnerHierarchyLevelNameId">
			<Description>The hierarchy level of the owner</Description>
		</Parameter>
		<Parameter Name="@OwnerEntityId">
			<Description>The entity Id of the owner</Description>
		</Parameter>
		<Parameter Name="@CreatedBy">
			<Description>The user that created the tier structure</Description>
		</Parameter>
		<Parameter Name="@DateTimeCreated">
			<Description>the date the tier structure was created</Description>
		</Parameter>
		<Parameter Name="@TierStructureId">
			<Description>The Id of the tier structure created</Description>
		</Parameter>
	</Parameters>	
</StoredProcedure>
***/
CREATE PROCEDURE Charges.spCreateTierStructure (
	@TierStructureName VARCHAR(50),
	@OwnerHierarchyLevelNameId INT,
	@OwnerEntityId INT,
	@CreatedBy INT,
	@DateTimeCreated DATETIME2(2),
	@TierStructureId INT OUTPUT) AS

	INSERT INTO Charges.TierStructures
		(TierStructureName, OwnerHierarchyLevelNameId, OwnerEntityId, CreatedBy, DateTimeCreated)
	SELECT @TierStructureName, @OwnerHierarchyLevelNameId, @OwnerEntityId, @CreatedBy, @DateTimeCreated

	SET @TierStructureId = SCOPE_IDENTITY()
