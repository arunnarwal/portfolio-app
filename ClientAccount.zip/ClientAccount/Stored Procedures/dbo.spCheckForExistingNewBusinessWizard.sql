/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>5E5A965B658F6436FF8AF0AD9D4D4257</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO

create procedure [dbo].[spCheckForExistingNewBusinessWizard](@Claccountid varchar(20), @CompletedOnly bit)
as

select
	count(1) as SessionCount
from
	dbo.WorkflowWizardClientSession wwcs
inner join
	dbo.WorkflowWizard ww on ww.Id = wwcs.WizardId
where
	wwcs.ClAccountId = @claccountid and
	ww.Name in ('Product Purchase', 'Existing Client Product Purchase') and
	(
		(@completedOnly = 1 and wwcs.Status = 'COMPLETE') or
		
		-- all statuses, except for DELETED
		(@completedOnly = 0 and wwcs.Status IN ('InProgress','PENDINGAUTHORISATION','FailedAutomatedReview','SUBMITTED','COMPLETE','Cancelled','New'))	
	)
GO
