/***
<StoredProcedure>
    <Description>Delete Future Schedule from the live table. Audit will remain wihtin the unauthorised tables</Description>
	<Service>Charges</Service>
    <Feature>Tasks</Feature>
    <Parameters>
        <Parameter Name="@schemeId">
            <Description>The SchemeId</Description>
        </Parameter>
		<Parameter Name="@feeTranTypeId">
            <Description>The fee tran type id</Description>
        </Parameter>		
		<Parameter Name="@now">
            <Description>The time the schedules were authorised</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[DeleteFutureCorporateTieredAmcSchedule](@schemeId int, @feeTranTypeId int, @now DateTime) AS

	-- Delete Tiers
	DELETE dbo.CorporateTieredAMCTiers 
	WHERE CorporateTieredAMCId IN
	(
		SELECT Id FROM dbo.CorporateTieredAMC TierGroup
		WHERE SchemeId = @schemeId and FeeTranTypeId = @feeTranTypeId 
		AND ( 
				( FromDate > @now ) -- Future
				OR
				( FromDate <= @now And ( ToDate > @now Or ToDate IS NULL) ) -- Current
			)
	)

	-- Delete Tier Groups
	DELETE dbo.CorporateTieredAMC
	WHERE SchemeId = @schemeId and FeeTranTypeId = @feeTranTypeId 
	AND ( 
			( FromDate > @now ) -- Future
			OR
			( FromDate <= @now And ( ToDate > @now Or ToDate IS NULL) ) -- Current
		)
GO