/***
<StoredProcedure>
    <Description>dds Income Instructions for a newly created GIA</Description>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[spAddIncomeInstructionsForNewGIA] (	
	@UserID as integer,
	@GIAAccountID As Varchar(15))
AS

DECLARE @TransactionId INT

BEGIN TRY

	SET NOCOUNT ON
		
		IF NOT EXISTS (SELECT 1 FROM Discovery.dbo.IncomeInstructions WHERE ClAccountID = @GIAAccountID)
		BEGIN
			INSERT INTO discovery.dbo.Incomeinstructions
					   (bankaccountid,
						claccountid,
						enabled,
						frequency,
						minimumamount)
			VALUES     (0,@GIAAccountID,0,'MinimumAmount',0)
		END

		EXEC Discovery.dbo.spGetTransactionId  
				@UserId = @UserId,
				@ProcedureName = 'spAddIncomeInstructionsForNewGIA',
				@IssueLogId = 0,
				@TransactionId = @TransactionId OUTPUT; 

		EXEC ClientAccount.dbo.spChangeIncomePaymentInClientDetails	
			@UserID = @UserID,
			@SubAccountId = @GIAAccountID,
			@TransactionId = @TransactionId,
			@IncomePaymentExternal = 'ProductCash',
			@DRP = 0

	SET NOCOUNT OFF
	RETURN @@ROWCOUNT

END TRY
BEGIN CATCH
    	DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		RAISERROR (@ErrorMessage
			,@ErrorSeverity
			,@ErrorState
			);
END CATCH
