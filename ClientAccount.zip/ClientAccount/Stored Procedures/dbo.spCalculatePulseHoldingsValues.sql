/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>36BE45D9B7AF0C11652804368A281556</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[spCalculatePulseHoldingsValues]  as
BEGIN

;WITH MaxValueDate AS (
	SELECT Sedol,MAX(ValueDate) ValueDate, MAX(id) AS ID
	FROM ClientAccount..PulsePrices
	GROUP BY Sedol
	--makes lines unique
),
pricesWithDates AS (
	SELECT mvd.valuedate,pp.sedol,pp.priceingbp
	FROM clientaccount..pulseprices pp 
	INNER JOIN maxvaluedate mvd 
		ON pp.valuedate = mvd.valuedate AND pp.sedol = mvd.sedol AND pp.ID = mvd.ID
),
holdingValues AS (
	SELECT trans.sedol,
	trans.portfolioId,
	COALESCE(SUM(trans.Quantity*Cord), 0) Quantity,
	COALESCE(SUM(trans.Quantity*Cord) * 
		(CASE (SELECT AssetType FROM ClientAccount..PulseSecurities sec WHERE trans.sedol = sec.sedol) 
			WHEN 'Cash' THEN CONVERT(DECIMAL,1) 
			ELSE price.priceingbp 
		END),0) MarketValue

FROM ClientAccount..PulseTransactions trans
LEFT JOIN pricesWithDates price 
	ON trans.sedol = price.sedol 
GROUP BY trans.sedol, trans.portfolioid, price.priceingbp
)

UPDATE ClientAccount.dbo.PulseHoldings  
SET MarketValue = val.MarketValue, Quantity = val.Quantity 
FROM ClientAccount.dbo.PulseHoldings tab
LEFT JOIN holdingValues val 
	ON tab.portfolioid = val.portfolioid AND tab.sedol = val.sedol

END

GO
