/***
<StoredProcedure>
    <Description>Gets ongoing adviser charges for charge processing</Description>
</StoredProcedure>
***/
CREATE PROCEDURE ChargeProcessing.spGetOngoingAdviserCharges @AsAt DATE AS
	SELECT 
		seca.Id AS SubAccountId,
		cfs.FBRCRate AS Rate, 
		CASE
			WHEN cfs.FBRCRate = 0 THEN COALESCE(cfs.FBRCAmount, 0)
			ELSE 0
		END AS Amount,
		cfs.TierStructureId,
		Charges.fnConvertFrequencyCharToChargeFrequency(cd.FeeInvoicingFrequency) AS Frequency
	FROM dbo.ClientFBRCSettings cfs
	INNER JOIN dbo.SEClientAccount seca on seca.ClAccountId = cfs.ClAccountId
	INNER JOIN 
		(SELECT ClAccountId,MAX(AsAt) AS AsAt, MAX(Id) AS Id
		FROM dbo.ClientFBRCSettings
		WHERE AsAt <= @AsAt
		GROUP BY ClAccountId) LatestDate
		ON LatestDate.ClAccountId = cfs.ClAccountId
		AND LatestDate.AsAt = cfs.AsAt
		AND LatestDate.Id = cfs.Id
	INNER JOIN dbo.ClientDetails cd ON cd.ClAccountId = cfs.ClAccountId				
	WHERE cfs.Active = 1	
	AND (cfs.FBRCRate > 0
		OR COALESCE(cfs.FBRCAmount, 0) > 0
		OR cfs.TierStructureId IS NOT NULL)

