/***
<StoredProcedure>
    <Description>Gets tier structure tiers by TierStructureId</Description>
	<Parameters>
		<Parameter Name="@TierStructureId">
			<Description>The id of the tier structure</Description>
		</Parameter>
	</Parameters>	
</StoredProcedure>
***/
CREATE PROCEDURE Charges.spGetTierStructureTiers (@TierStructureId INT) AS

	SELECT tb.LowerLimit, tb.UpperLimit, tst.Rate
	FROM Charges.TierStructureTiers tst
	INNER JOIN Res_DB.Charges.TierBoundaries tb ON tb.TierBoundaryId = tst.TierBoundaryId
	WHERE tst.TierStructureId = @TierStructureId
	ORDER BY tb.LowerLimit
	