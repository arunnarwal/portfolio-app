
CREATE PROCEDURE [dbo].[spBackOfficeProviderBulkContractEnquiryRequests] @AsAt DATETIME AS
	
	/*
		DECLARE @AsAt datetime
		SET @AsAt = '2013-05-03'
	*/

	;WITH settings AS (
		
		SELECT * 
		FROM dbo.BackOfficeProviderWrapProviderSettings 
		WHERE (BulkContractEnquiryFrequencySun = 1 AND DATEPART(dw, @AsAt) = 1)
			OR (BulkContractEnquiryFrequencyMon = 1 AND DATEPART(dw, @AsAt) = 2)
			OR (BulkContractEnquiryFrequencyTues = 1 AND DATEPART(dw, @AsAt) = 3)
			OR (BulkContractEnquiryFrequencyWed = 1 AND DATEPART(dw, @AsAt) = 4)
			OR (BulkContractEnquiryFrequencyThurs = 1 AND DATEPART(dw, @AsAt) = 5)
			OR (BulkContractEnquiryFrequencyFri = 1 AND DATEPART(dw, @AsAt) = 6)
			OR (BulkContractEnquiryFrequencySat = 1 AND DATEPART(dw, @AsAt) = 7)
	)

	SELECT	BOP.[Provider],
			CO.Company,
			WP.WrapProvider,
			XGM.[Version] 
	FROM dbo.BackOfficeProviderCompanySettings BOS
		INNER JOIN dbo.Company CO ON BOS.CompanyId = CO.Id AND CO.FSAAuthorisationStatus = 'Authorised'
		INNER JOIN dbo.WrapProvider WP ON CO.WrapProvider = WP.WrapProvider
		INNER JOIN settings BOW ON BOS.BackOfficeProviderId = BOW.BackOfficeProviderId AND WP.Id = BOW.WrapProviderId AND BOW.IsEnabled = 1
		INNER JOIN dbo.BackOfficeProvider BOP ON BOS.BackOfficeProviderId = BOP.BackOfficeProviderId AND BOP.IsEnabled = 1
		LEFT JOIN Discovery.dbo.XMLGenericMessage XGM ON BOS.BulkContractEnquiryXMLGenericMessageId = XGM.Id
	WHERE BOS.BulkContractEnquiry = 1 AND BOS.BulkContractEnquiryStartOn < @AsAt
	ORDER BY CO.Company

GO
