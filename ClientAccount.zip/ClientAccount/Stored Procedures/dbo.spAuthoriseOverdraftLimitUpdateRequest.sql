create procedure dbo.spAuthoriseOverdraftLimitUpdateRequest(@id int, @userid int)
as

update dbo.OverdraftLimit set OverdraftAmount = OLC.OverdraftAmount
from dbo.OverdraftLimit OL 
inner join dbo.OverdraftLimitChanges OLC
	On OL.Id = OLC.OverdraftLimitID
where OLC.ID = @id and OLC.Status = 'Confirmed'




