/***
<StoredProcedure>
   <Description>Check if an individual customer is Paperless. Returns customer Id if yes. Applies read security based on @UserId.  Web Services API use only.</Description>
   <Parameters>
      <Parameter Name="@FromDateTime" Nullable="false">
         <Description>Date where the checking starts</Description>
      </Parameter>
	  <Parameter Name="@ToDateTime" Nullable="false">
         <Description>Date where the checking ends</Description>
      </Parameter>
	  <Parameter Name="@CustomerId" Nullable="false">
         <Description>Id of Customer</Description>
      </Parameter>
   </Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE dbo.spCheckIfCustomerIsPaperless(@FromDateTime DATETIME, @ToDateTime DATETIME, @CustomerId INT)
AS

BEGIN

SELECT Cust.CustomerId,
AudCP.AuditId,
ROW_NUMBER() OVER (PARTITION BY Cust.CustomerId order by AudCP.AuditDateTime) EntryNumber
INTO #AuditsForCustomer
FROM Platform.DBACustomer.Customers AS Cust
INNER JOIN Platform.DBACustomer_audit.ContactPreferences AS AudCP ON AudCP.CustomerId = Cust.CustomerId
WHERE Cust.CustomerId = @CustomerId

CREATE UNIQUE CLUSTERED INDEX CUIDX_AuditId ON #AuditsForCustomer (AuditId)

SELECT Customer.CustomerId
FROM(
SELECT AudCP.CustomerId
FROM Platform.DBACustomer_audit.ContactPreferences AudCP
INNER JOIN #AuditsForCustomer AS AFCN ON AFCN.AuditId = AudCP.AuditId
INNER JOIN Platform.DBACustomer_audit.ContactPreferences AS PrevAudCP ON AudCP.CustomerId = PrevAudCP.CustomerId
INNER JOIN #AuditsForCustomer AS AFCO ON AFCO.AuditId = PrevAudCP.AuditId
WHERE AudCP.IsPaperlessStatements = 1
	AND PrevAudCP.IsPaperlessStatements = 0
	AND AFCO.EntryNumber = AFCN.EntryNumber - 1
	AND AudCP.AuditDateTime BETWEEN @FromDateTime AND @ToDateTime

UNION ALL

SELECT AFCN.CustomerId
FROM #AuditsForCustomer AFCN 
INNER JOIN Platform.DBACustomer_audit.ContactPreferences As AudCP ON AudCp.AuditId = AFCN.AuditId
WHERE AFCN.EntryNumber = 1
	AND AudCP.AuditOperation = 'I'
	AND NOT EXISTS (SELECT 1 FROM #AuditsForCustomer AS AFC WHERE AFC.CustomerId = AFCN.CustomerId AND AFC.EntryNumber > 1)
	AND AudCP.AuditDateTime BETWEEN @FromDateTime AND @ToDateTime
	) AS Customer

DROP TABLE #AuditsForCustomer

END
GO