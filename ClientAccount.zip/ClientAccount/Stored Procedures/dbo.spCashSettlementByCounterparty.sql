/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>A7FDF564364A430B3F93EAEA8C7AB98B</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[spCashSettlementByCounterparty] (@ClAccountID varchar(25), @AsAt datetime) AS
Select TransID, LedgerDate, CLT.ClAccountID, LineNumber, MovementType, MovementSource, CCYCode, Amount, Balance, Reference, Narrative, DisplayToClient, Capital, UserID, CLT.DateCreated, LedgerSource, LedgerSourceID, FromCCYCode, ToCCYCode, BaseCCYCode, FXRate, UserNote, ContraID, JnlBatchID, RestrictSweepUntil, OriginatingCashEntryID, AccountName
From CashLedgerTransactions CLT With (NOLOCK)
		Inner Join SEClientAccount SECA With (NOLOCK) on CLT.ClAccountID = SECA.ClAccountID
Where CLT.ClAccountID = @ClAccountID and ((LedgerDate = @AsAt And RestrictSweepUntil Is Null) Or RestrictSweepUntil = @AsAt)
GO
