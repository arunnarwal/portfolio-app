/***
<StoredProcedure>
    <Description>Get CAScripFractionals</Description>
    <Service>Transaction</Service>
</StoredProcedure>
***/
CREATE PROCEDURE [dbo].[spCAScripFractionalByInstrumentCode]
(
	@InstrumentCode VARCHAR(20)
	,@CorpActType VARCHAR(20)
	,@Location VARCHAR(10)
	,@CorpActID INT
	,@CustodianAccountId VARCHAR(50)
)
AS
	SELECT CSF.CLAccountID
		,MP.CustodianAccountId
		,Sum(CSF.Fraction) AS Fraction
		,MP.IsFractionalSharePaymentEnabled
	FROM dbo.CAScripFractional CSF
		LEFT JOIN dbo.CustodianAccountProviderMappings MP
			ON MP.CustodianAccountId = CSF.CustodianAccountID
	WHERE CSF.InstrumentCode = @InstrumentCode
		AND CSF.CorpActType = @CorpActType
		--AND CSF.Location = @Location
		AND CSF.CorpActID = @CorpActID
		--AND MP.CustodianAccountId = @CustodianAccountId
	GROUP BY CSF.ClAccountID
		,MP.CustodianAccountId
		,MP.IsFractionalSharePaymentEnabled;
GO

EXEC sys.Sp_addextendedproperty @name = N'Legacy'
	,@value = N'true'
	,@level0type = N'SCHEMA'
	,@level0name = N'dbo'
	,@level1type = N'PROCEDURE'
	,@level1name = N'spCAScripFractionalByInstrumentCode';
GO