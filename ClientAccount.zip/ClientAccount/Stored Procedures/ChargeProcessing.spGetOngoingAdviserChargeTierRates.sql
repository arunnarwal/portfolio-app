/***
<StoredProcedure>
	<Description>Gets the onging adviser charge tier rates for the specified tier structure Ids</Description>
	<Parameters>
		<Parameter Name="@TierStructureIds">
			<Description>CSV list of tier structure Ids</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE ChargeProcessing.spGetOngoingAdviserChargeTierRates @TierStructureIds VARCHAR(MAX) AS

	SELECT
		ts.tabValue AS TierStructureId,
		tb.LowerLimit,
		tb.UpperLimit,
		tst.Rate
	FROM CSFBMaster.dbo.fn_convert_comma_to_table_int(@TierStructureIds) ts
	INNER JOIN Charges.TierStructureTiers tst ON tst.TierStructureId = ts.tabValue
	INNER JOIN Res_DB.Charges.TierBoundaries tb on tb.TierBoundaryId = tst.TierBoundaryId
	