/***
<StoredProcedure>
    <Description>Saves a request to save or update rebate rates for specified entity and instrument</Description>
    <Service>Charges</Service>
    <Feature>Charges</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE Charges.spSaveRebateRatesRequest (
	@EntityType VARCHAR(20),
	@EntityID INT,
	@InstrumentId INT, 
	@BundledRate NUMERIC(9,6), 
	@UnBundledRate NUMERIC(9,6), 
	@TrailRate NUMERIC(9,6), 
	@FromDate DATE,
	@ToDate DATE = NULL,
	@UserId INT, 
	@RequestId INT OUTPUT)
AS
BEGIN

	BEGIN TRY 
		
		DECLARE @Tomorrow DATE = DateAdd(day, 1, GetDate())		
		--SELECT @Tomorrow

		IF (@FromDate <> @Tomorrow)
		BEGIN
			RAISERROR('FromDate can only be set for tommorow', 16, 1)
		END

		IF (@EntityType = 'SystemProvider')
		BEGIN
			--check if pending update already exists 
			IF EXISTS (SELECT 1 FROM dbo.RebateBySystemProviderRequests WHERE ProviderID = @EntityId AND InstrumentsID = @InstrumentId AND [Status] = 'Pending')
			BEGIN
				RAISERROR('Pending request already exists', 16, 1)
			END
						
			ELSE
			BEGIN
				INSERT INTO dbo.RebateBySystemProviderRequests (
					ProviderId,
					InstrumentsID,
					BundledRate,
					UnBundledRate,
					TrailRate,
					FromDate,
					ToDate,
					[Status],
					UserRequested,
					DateRequested)
				VALUES (
					@EntityID,
					@InstrumentId,
					@BundledRate,
					@UnBundledRate,
					@TrailRate,
					@FromDate,
					@ToDate,
					'Pending',
					@UserId,
					GETDATE()
				)
			END
		END

		SET @RequestId = SCOPE_IDENTITY()
		
		--todo: if ever needed - wrapprovider and company level			

	END TRY
	BEGIN CATCH
		PRINT 'Saving rebate rate request failed';
		THROW;
	END CATCH
END
GO

