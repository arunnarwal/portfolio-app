/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>162AFBF372D6AAF8DCB55AEFEB447E95</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
* =============================================
* Author: SKasparo
* Create date: 07/05/12
* Description: Stored procedure for getting client AML Status for AWD
* =============================================
*/
CREATE PROCEDURE [dbo].[spClientAMLStatusForAWD] (@ClientID int, @FromDate datetime, @ToDate datetime, @AMLServiceProvider varchar(10) = '%', @WrapProvider varchar(20) = '%') 
AS
BEGIN
/*
Declare @ClientID As int
Declare @FromDate As datetime
Declare @ToDate As datetime
Declare @AMLServiceProvider As varchar(10)
Declare @WrapProvider as VarChar(20)
set @ClientID = 423455
set @FromDate = '4 Apr 2009'
set @ToDate = '4 May 2012'
set @AMLServiceProvider = '%'
set @WrapProvider = 'AWD'
*/
SELECT ACA.ClientID,
ACA.ClAccountID,
AH.Given as GivenName,
AH.Surname as Surname,
AH.AMLStatus,
AH.PEPStatus,
AH.OFACStatus, 
APP.Address1,
APP.Address2,
APP.Address3,
APP.Address4,
APP.Address5,
ACA.StartDate as AccountOpenDate,
AH.AMLServiceProvider,
CO.WrapProvider,
EIHDL.AuthenticationIndex,
EIHDL.HighRiskPolRule,
EIHDL.AuthenticationText
FROM dbo.vwAllowedClientAccountsV2 AS ACA 
inner join dbo.AccountHolders AH ON AH.ClAccountID = ACA.ClAccountID
left join Discovery.dbo.vwAddressPrimaryPostal APP ON ACA.CLAccountID = APP.ClAccountID
inner join dbo.Company CO ON ACA.Company = CO.Company
/* get junior account information (added by Vojtech Hubr) */
left join dbo.vwJuniorAccountClientDetails as JACD ON ACA.ClAccountID = JACD.ClAccountID
left join Discovery.dbo.ExperianIdHubDataLog AS EIHDL ON EIHDL.AccountNumber = ACA.ClAccountID AND EIHDL.Id = 
        (
           SELECT MAX(Id) 
           FROM Discovery.dbo.ExperianIdHubDataLog EIHDL2 
           WHERE EIHDL2.AccountNumber = EIHDL.AccountNumber AND IDHubTemplate in ('AML C','AML C Test')
        )
Where IsNull(AH.AMLServiceProvider,'') like @AMLServiceProvider
and ACA.StartDate between @FromDate and @ToDate
and ACA.ClientID = @ClientID
and CO.WrapProvider like @WrapProvider
/* eclude all junior accounts for now (added by Vojtech Hubr) */
and JACD.ClAccountID IS NULL
END
GO
