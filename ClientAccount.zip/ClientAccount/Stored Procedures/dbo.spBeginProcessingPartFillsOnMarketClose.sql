/***
<StoredProcedure>
    <Description>This stored procedure is used to gather up all individual part fills that need to be converted into a contract note and sets them to processing.
	This only applies to part fills after the market has closed.</Description>
</StoredProcedure>
***/
CREATE PROCEDURE [dbo].[spBeginProcessingPartFillsOnMarketClose] 
AS

-- Standardise the current time in UTC hours to check the market close times.
-- We will apply the UTC offset below
DECLARE @CurrentTimeUTCHours AS DECIMAL(6,2)
SET @CurrentTimeUTCHours = DATEPART(hh, GETUTCDATE()) + (DATEPART(mi, GETUTCDATE()) / 60.0)

DECLARE @ProcessingTradeBookingDetails TABLE
(
	TradeBookingDetailId INT
)

UPDATE TBD
SET TBD.TradeBookingDetailStatusId = 2 --Processing			
OUTPUT INSERTED.TradeBookingDetailId INTO @ProcessingTradeBookingDetails
FROM dbo.TradeBookingDetails TBD
	INNER JOIN LiveDB.dbo.MarketTradingHours MTH ON MTH.MarketId = TBD.MarketId
	INNER JOIN LiveDB.dbo.TimeZones TZ ON TZ.Id = MTH.TimeZoneID
WHERE TBD.TradeBookingDetailStatusId = 1 --Created
-- Check that the given market is closed (i.e outside of the Open or Close times)
-- Add on the offset to get it in local time and modulo the output. Check that it is both outside the open AND the close
AND ((@CurrentTimeUTCHours + TZ.UtcOffset / 60.0) % 24 < DATEPART(hh, MTH.MarketOpenLocalTime) + (DATEPART(mi, MTH.MarketOpenLocalTime) / 60.0)
	OR (@CurrentTimeUTCHours + TZ.UtcOffset / 60.0) % 24 > DATEPART(hh, MTH.MarketCloseLocalTime) + (DATEPART(mi, MTH.MarketCloseLocalTime) / 60.0))

SELECT
TB.OrderId,
OC.OrderBuySell,
TB.Currency,
TB.TotalQuantity,
TB.TotalValue,
TB.TotalDiscretionValue,
TB.TradeDateTime,
TB.SettlementDate,
ISO.MIC,
TB.BrokerId,
TB.TraderId,
T.TraderName,
TB.AccruedInterestAmount,
CUS.CustodianClAccountID,
COM.WrapProvider,
TB.TradeReference,
CASE WHEN TB.MinPrice = TB.MaxPrice THEN TB.MinPrice ELSE NULL End as TradePrice
FROM
(
	SELECT
	TBD.OrderId,	
	TBD.Currency,
	SUM(TBD.Quantity) AS TotalQuantity,
	SUM(TBD.Quantity * TBD.Price) AS TotalValue,
	SUM(TBD.Quantity * TBD.DiscretionPrice) AS TotalDiscretionValue,
	MAX(TBD.TradeDateTime) AS TradeDateTime,
	TBD.SettlementDate,
	TBD.MarketId,
	TBD.BrokerId,
	TBD.TraderId,
	SUM(TBD.AccruedInterestAmount) AS AccruedInterestAmount,
	CASE WHEN MIN(TBD.TradeReference) = MAX(TBD.TradeReference) THEN MIN(TBD.TradeReference) ELSE NULL End as TradeReference,
	MIN(TBD.Price) as MinPrice,
	MAX(TBD.Price) as MaxPrice
	FROM
	@ProcessingTradeBookingDetails PTBD
	INNER JOIN dbo.TradeBookingDetails TBD ON TBD.TradeBookingDetailId = PTBD.TradeBookingDetailId
	GROUP BY TBD.OrderId, TBD.Currency, TBD.SettlementDate, TBD.MarketId, TBD.BrokerId, TBD.TraderId) TB
INNER JOIN Discovery.dbo.OrderCurrent OC ON OC.OrderID = TB.OrderId
INNER JOIN dbo.CustodianAccounts CUS ON CUS.CustodianAccountID = OC.CustodianAccountID
INNER JOIN dbo.Traders T ON T.TraderID = TB.TraderId
INNER JOIN dbo.ClientDetails AS CD on oc.ClAccountId = CD.ClAccountId
INNER JOIN dbo.Company AS COM on CD.Company = COM.Company
INNER JOIN Res_DB.dbo.MarketCodes_ISO10383 ISO ON ISO.ID = TB.MarketId
GO