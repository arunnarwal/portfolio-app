CREATE PROCEDURE dbo.spCalculateCustomerAssumedHoldings
(
@CustomerId INT,
@UserId INT,
@SubAccountIdsToExclude VARCHAR(MAX) = ''
)

AS

--DECLARE @CustomerId INT = 5057,
--@UserId INT = 507405,
--@SubAccountIdsToExclude VARCHAR(MAX) = '149086';

CREATE TABLE #SubAccounts
(
SubAccountId INT,
ClAccountId VARCHAR(20)
)

CREATE INDEX UIDX_ClAccountId ON #SubAccounts(ClAccountId)

DECLARE @CurrentDate DATE = GETDATE()

INSERT INTO #SubAccounts (SubAccountId, ClAccountId)
SELECT SubSECA.Id AS SubAccountId, SubSECA.ClAccountId FROM Platform.DBAAccount.CustomerRoles CR
INNER JOIN Platform.DBAAccount.CustomerRoleTypes CRT ON CR.CustomerRoleTypeId = CRT.CustomerRoleTypeId
INNER JOIN Platform.Accounts.SEClientAccount SECA ON SECA.Id = CR.AccountId
INNER JOIN Platform.Accounts.Consolidate CON ON CON.ClAccountId = SECA.ClAccountId AND CON.ClAccountId <> CON.SubClAccountId
INNER JOIN Platform.Accounts.SEClientAccount SubSECA ON SubSECA.ClAccountId = CON.SubClAccountId
INNER JOIN dbo.ClientAccountSecurity CAS ON CAS.AdvisorCodes = SECA.PrimaryAdviser
WHERE CRT.IsPrimaryRoleApplicable = 1
AND CAS.ClientId = @UserId
AND CR.CustomerId = @CustomerId
AND SubSECA.Id not in (SELECT Tabvalue FROM CSFBMaster.dbo.fn_convert_comma_to_table_int(@SubAccountIdsToExclude))

SELECT
    B.InstrumentCode,
    SUM(B.Quantity) AS Quantity
    FROM (
		SELECT     
			A.SubAccountId,
			ST.CLAccountID,
			ST.InstrumentCode,
			ST.Location,
			SUM(ST.Quantity) AS Quantity
        FROM #SubAccounts A
        INNER JOIN dbo.ScripTransactions ST ON A.ClAccountId = ST.CLAccountId		
        WHERE      ST.AsAt < GETDATE() + 1
        AND        ST.TransStatus <> 'Cancelled'
        AND        ISNULL(ST.Cutover, 0) = 0
        GROUP BY   A.SubAccountId, ST.ClAccountId, ST.InstrumentCode, ST.[Location]

        UNION ALL

        SELECT
			A.SubAccountId,
            SA.ClAccountId,
            SA.InstrumentCode,
            'Custody',
            SUM(SA.Quantity) AS qty
        FROM       #SubAccounts A
        INNER JOIN dbo.ScripAdjustments SA ON A.ClAccountId = SA.CLAccountId		
        WHERE      SA.LedgerDate < GETDATE() + 1
        AND        SA.Reversed = 0
        GROUP BY   A.SubAccountId, SA.ClAccountId, SA.InstrumentCode
    ) B
    GROUP BY B.InstrumentCode
    HAVING   SUM(B.Quantity) > 0

UNION

SELECT 'GBPCash' AS InstrumentCode, COALESCE(SUM(CB.AvailableBalance),0) AS Quantity 
FROM dbo.fnAvailableCashBalanceForSwitchSubAccountsSearch (@CurrentDate) CB
INNER JOIN #SubAccounts SA ON SA.SubAccountId = CB.SubAccountId
WHERE CB.AvailableBalance > 0

DROP TABLE #SubAccounts