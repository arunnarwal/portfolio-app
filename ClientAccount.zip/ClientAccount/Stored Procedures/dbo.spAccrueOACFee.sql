/***
<StoredProcedure>
    <Description>Accrue the OAC Percent / Anmount </Description>
	<Service>Charges</Service>
    <Feature>Tasks</Feature>
    <Parameters>
        <Parameter Name="@AsAt">
            <Description>The date of the fee run</Description>
        </Parameter>
        <Parameter Name="@TranType">
            <Description>The tran type, OACPercent / OACAmount</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/

CREATE PROCEDURE [dbo].[spAccrueOACFee](@AsAt DATETIME, @TranType VARCHAR(10))
AS

-- DECLARE @AsAt SMALLDATETIME
-- SET @AsAt = '30 Jul 2013'
-- DECLARE @TranType VARCHAR(10)
-- SET @TranType = 'OACPercent'

BEGIN TRY
	BEGIN TRANSACTION T1

	IF OBJECT_ID(N'tempdb..#Accruals', N'U') IS NOT NULL
	BEGIN
		DROP TABLE #Accruals
	END
	
	DECLARE @PercentTranType VARCHAR(10)
	DECLARE @AmountTranType VARCHAR(10)

	SET @PercentTranType = 'OACPercent'
	SET @AmountTranType = 'OACAmount'

	SELECT 
		ToBeApplied.Id AS ToBeAppliedFeesId
		,Fum.AsAt
		,Fum.SECAId
		,ROUND(COALESCE((Fum.CashAmount + Fum.NonCashAmount), 0), 4) AS Valuation
		,CASE  
		WHEN @TranType = @PercentTranType
			THEN ROUND(COALESCE(((Fum.CashAmount + Fum.NonCashAmount) * ToBeApplied.Rate / 100 / 365.25), 0), 4)
		WHEN @TranType = @AmountTranType 
			THEN ROUND(ToBeApplied.Rate / 365.25, 4)
		ELSE 0
		END AS Amount
		,0 As VatAmount
		,COALESCE(ToBeApplied.Rate, 0) AS Rate
		,FrqRanged.ToDate As ChargeDate
		,0 AS IsProcessed
		,ToBeApplied.FeeTranTypesId
		,Fum.CurrencyId
	INTO #Accruals 
	FROM Cache.dbo.Fee_FUM_ByAccount AS Fum
	INNER JOIN dbo.SEClientAccount AS SecaId
		ON SecaId.Id = Fum.SECAId
	INNER JOIN dbo.WrapProvider AS WrapProvider
		ON WrapProvider.Id = Fum.WrapProviderId
	INNER JOIN dbo.FeeTranTypes AS FeeTranTypes
		ON FeeTranTypes.TranType = @TranType
			AND FeeTranTypes.WrapProvider = WrapProvider.WrapProvider
	INNER JOIN dbo.fnHeadAccounts() as HeadAccount
		ON HeadAccount.ClAccountId = SecaId.ClAccountId AND HeadAccount.Consolidated = 0
	INNER JOIN dbo.ClientDetails HeadClientDetails 
		ON HeadClientDetails.CLAccountId = HeadAccount.HeadClAccountId
	INNER JOIN dbo.ToBeAppliedFees_ByAccV2 AS ToBeApplied
		ON ToBeApplied.AsAt = Fum.AsAt
			AND Fum.SECAId = ToBeApplied.SECAId
			AND ToBeApplied.Applied = 0
			AND FeeTranTypes.Id = ToBeApplied.FeeTranTypesId
CROSS APPLY dbo.fnGetDateRangesForFrequencies(@AsAt,DATEADD(dd, 0, DATEDIFF(dd, 0, SecaId.DateCreated + 1))) FRQRanged -- FIX ME: Head Activation date but does not exist
	WHERE Fum.AsAt = @AsAt AND HeadClientDetails.Feeinvoicingfrequency = FrqRanged.Frequency

	INSERT INTO dbo.Fee_Accrual_OAC (
		FeeTranTypeId
		,AsAt
		,SecaId
		,Valuation
		,Amount
		,Rate
		,ChargeDate
		,IsProcessed
		,VatRate
		,VatAmount
		,CurrencyId
		)
	SELECT 
		#Accruals.FeeTranTypesId
		,#Accruals.AsAt
		,#Accruals.SECAId
		,#Accruals.Valuation
		,#Accruals.Amount
		,#Accruals.Rate
		,#Accruals.ChargeDate
		,#Accruals.IsProcessed
		,0 AS VatRate
		,#Accruals.VatAmount
		,#Accruals.CurrencyId		
	FROM #Accruals
END TRY

BEGIN CATCH
	ROLLBACK TRANSACTION T1

	DECLARE @ErrorMessage NVARCHAR(4000);
	DECLARE @ErrorSeverity INT;
	DECLARE @ErrorState INT;

	IF OBJECT_ID(N'tempdb..#Accruals', N'U') IS NOT NULL
	BEGIN
		DROP TABLE #Accruals
	END

	SELECT @ErrorMessage = ERROR_MESSAGE()
		,@ErrorSeverity = ERROR_SEVERITY()
		,@ErrorState = ERROR_STATE();

	RAISERROR (
			@ErrorMessage
			,@ErrorSeverity
			,@ErrorState
			);
END CATCH;

IF @@TRANCOUNT > 0
BEGIN
	SELECT 'Success' AS Result

	UPDATE dbo.ToBeAppliedFees_ByAccV2
	SET Applied = 1
		,ProcessedDate = GETDATE()
	WHERE Id IN (
			SELECT ToBeAppliedFeesId
			FROM #Accruals
			)

	INSERT INTO dbo.AppliedFees_ByAccV2 (
		FeeTranTypesId
		,SecaId
		,Rate
		,ProcessedDate
		,DateCreated
		,AsAt
		,ApplyVat
		)
	SELECT ToBeApplied.FeeTranTypesId
		,ToBeApplied.SECAId
		,ToBeApplied.Rate
		,ToBeApplied.ProcessedDate
		,ToBeApplied.DateCreated
		,ToBeApplied.AsAt
		,ToBeApplied.ApplyVAT
	FROM dbo.ToBeAppliedFees_ByAccV2 ToBeApplied
	WHERE Id IN (
			SELECT #Accruals.ToBeAppliedFeesId
			FROM #Accruals
			)

	DELETE dbo.ToBeAppliedFees_ByAccV2
	WHERE Id IN (
			SELECT ToBeAppliedFeesId
			FROM #Accruals
			)

	IF OBJECT_ID(N'tempdb..#Accruals', N'U') IS NOT NULL
	BEGIN
		DROP TABLE #Accruals
	END

	COMMIT TRANSACTION T1
END
GO