/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>4FFE9FAF01A331D5890E294F7EB27F0F</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS OFF
GO
CREATE PROCEDURE [dbo].[spAddThreeSixtyNBWConfiguration](@Company varchar(20))  AS

insert into webdb..companypagesectionmapping (Company, SectionIdentifier, URL, Active)
values (@Company, 'AccountDetails', '/clients/newbusiness/create.aspx', 1)
insert into webdb..companypagesectionmapping (company, sectionidentifier, url, active)
values (@Company,'AccountDetails2','/clients/newbusiness/create.aspx',1)

insert into webdb..companypagesectionmapping (Company, SectionIdentifier, URL, Active)
values (@Company, 'AnnuitiesAdvice', '/clients/newbusiness/Assets1.aspx', 1)
insert into webdb..companypagesectionmapping (Company, SectionIdentifier, URL, Active)
values (@Company, 'DefinedBenefitAdvice', '/clients/newbusiness/Assets1.aspx', 1)
insert into webdb..companypagesectionmapping (Company, SectionIdentifier, URL, Active)
values (@Company, 'DefinedContributionAdvice', '/clients/newbusiness/Assets1.aspx', 1)
insert into webdb..companypagesectionmapping (Company, SectionIdentifier, URL, Active)
values (@Company, 'LifeAdvice', '/clients/newbusiness/Assets1.aspx', 1)
insert into webdb..companypagesectionmapping (company, sectionidentifier, url, active)
values (@Company,'AnnuityDetails','/clients/newbusiness/Assets1.aspx',1)
insert into webdb..companypagesectionmapping (company, sectionidentifier, url, active)
values (@Company,'DefinedBenefitLegacy','/clients/newbusiness/Assets1.aspx',1)
insert into webdb..companypagesectionmapping (company, sectionidentifier, url, active)
values (@Company,'DefinedBenefitPortfolioPlanning','/clients/newbusiness/Assets1.aspx',1)
insert into webdb..companypagesectionmapping (company, sectionidentifier, url, active)
values (@Company,'DefinedContributionLegacy','/clients/newbusiness/Assets1.aspx',1)
insert into webdb..companypagesectionmapping (company, sectionidentifier, url, active)
values (@Company,'DefinedContributionPortfolioPlanning','/clients/newbusiness/Assets1.aspx',1)
insert into webdb..companypagesectionmapping (company, sectionidentifier, url, active)
values (@Company,'LifeLegacy','/clients/newbusiness/Assets1.aspx',1)
insert into webdb..companypagesectionmapping (company, sectionidentifier, url, active)
values (@Company,'LifePortfolioPlanning','/clients/newbusiness/Assets1.aspx',1)
insert into webdb..companypagesectionmapping (company, sectionidentifier, url, active)
values (@Company,'Lifeproviderdetails','/clients/newbusiness/Assets1.aspx',1)
insert into webdb..companypagesectionmapping (company, sectionidentifier, url, active)
values (@Company,'Pensionproviderdetails','/clients/newbusiness/Assets1.aspx',1)

insert into webdb..companypagesectionmapping (company,sectionidentifier,url,active)
values (@Company,'SavingsAndInvestmentsAdvice','/clients/newbusiness/Assets2.aspx',1)
insert into webdb..companypagesectionmapping (company,sectionidentifier,url,active)
values (@Company,'UnwrappedInvestmentsAdvice','/clients/newbusiness/Assets2.aspx',1)
insert into webdb..companypagesectionmapping (company,sectionidentifier,url,active)
values (@Company,'UnwrappedSavingsAdvice','/clients/newbusiness/Assets2.aspx',1)

insert into webdb..companypagesectionmapping (Company, SectionIdentifier, URL, Active)
values (@Company, 'Mortgages', '/clients/newbusiness/Assets3.aspx', 1)
insert into webdb..companypagesectionmapping (Company, SectionIdentifier, URL, Active)
values (@Company, 'Protection', '/clients/newbusiness/Assets3.aspx ', 1)
insert into webdb..companypagesectionmapping (company, sectionidentifier, url, active)
values (@Company,'ExpensesAdvice','/clients/newbusiness/Assets3.aspx',1)
insert into webdb..companypagesectionmapping (company, sectionidentifier, url, active)
values (@Company,'IncomeAdvice','/clients/newbusiness/Assets3.aspx',1)
insert into webdb..companypagesectionmapping (company, sectionidentifier, url, active)
values (@Company,'Liabilities','/clients/newbusiness/Assets3.aspx',1)
insert into webdb..companypagesectionmapping (company, sectionidentifier, url, active)
values (@Company,'LiabilitiesAdvice','/clients/newbusiness/Assets3.aspx',1)
insert into webdb..companypagesectionmapping (company, sectionidentifier, url, active)
values (@Company,'MortgagesAdvice','/clients/newbusiness/Assets3.aspx',1)
insert into webdb..companypagesectionmapping (company, sectionidentifier, url, active)
values (@Company,'NonInvestmentAssetsAdvice','/clients/newbusiness/Assets3.aspx',1)
insert into webdb..companypagesectionmapping (company, sectionidentifier, url, active)
values (@Company,'PropertyAdvice','/clients/newbusiness/Assets3.aspx',1)
insert into webdb..companypagesectionmapping (company, sectionidentifier, url, active)
values (@Company,'PropertyTable','/clients/newbusiness/Assets3.aspx',1)
insert into webdb..companypagesectionmapping (company, sectionidentifier, url, active)
values (@Company,'ProtectionAdvice','/clients/newbusiness/Assets3.aspx',1)

insert into webdb..companypagesectionmapping (Company, SectionIdentifier, URL, Active)
values (@Company, 'QuoteDetails', '/clients/wizards/CompleteWizard.aspx', 1)
insert into webdb..companypagesectionmapping (company, sectionidentifier, url, active)
values (@Company,'AdditionalDates','/clients/wizards/CompleteWizard.aspx',1)

insert into webdb..companypagecontent (company, pagename, fieldid, pagesection, include)
values (@Company,'/clients/newbusiness/RetirementGoals.aspx','ranking','CriticalIllness',1)
insert into webdb..companypagecontent (company, pagename, fieldid, pagesection, include)
values (@Company,'/clients/newbusiness/RetirementGoals.aspx','ranking','Estate',1)
insert into webdb..companypagecontent (company, pagename, fieldid, pagesection, include)
values (@Company,'/clients/newbusiness/RetirementGoals.aspx','ranking','LifeAssurance',1)
insert into webdb..companypagecontent (company, pagename, fieldid, pagesection, include)
values (@Company,'/clients/newbusiness/RetirementGoals.aspx','ranking','LongTerm',1)
insert into webdb..companypagecontent (company, pagename, fieldid, pagesection, include)
values (@Company,'/clients/newbusiness/RetirementGoals.aspx','ranking','Mortgage',1)
insert into webdb..companypagecontent (company, pagename, fieldid, pagesection, include)
values (@Company,'/clients/newbusiness/RetirementGoals.aspx','ranking','PermanentHealth',1)
insert into webdb..companypagecontent (company, pagename, fieldid, pagesection, include)
values (@Company,'/clients/newbusiness/RetirementGoals.aspx','ranking','PrivateMedical',1)
insert into webdb..companypagecontent (company, pagename, fieldid, pagesection, include)
values (@Company,'/clients/newbusiness/RetirementGoals.aspx','ranking','RetirementAdvice',1)
insert into webdb..companypagecontent (company, pagename, fieldid, pagesection, include)
values (@Company,'/clients/newbusiness/RetirementGoals.aspx','ranking','SavingsInvestment',1)

insert into webdb..companypagecontent (company,pagename,fieldid,pagesection,sortorder,include,fieldlabel)
select @Company, pagename, fieldid, pagesection, sortorder,include,fieldlabel
from webdb..companypagecontent
where company = 'thre' and pagename like '%assets3%'

insert into clientaccount..WorkflowWizardOutputItem (wizardid, description, type, taskid, sortorder, valuename, compulsory, specifictocompany, filename)
values (1, 'Non Advised Sales Form','Document',0,8,'NASF',0,@Company, 'THREESIXTY NASF.doc')
insert into clientaccount..WorkflowWizardOutputItem (wizardid, description, type, taskid, sortorder, valuename, compulsory, specifictocompany, filename)
values (4, 'Non Advised Sales Form','Document',0,8,'NASF',0,@Company, 'THREESIXTY NASF.doc')
insert into clientaccount..WorkflowWizardOutputItem (wizardid, description, type, taskid, sortorder, valuename, compulsory, specifictocompany, filename)
values (104, 'Non Advised Sales Form','Document',0,8,'NASF',0,@Company, 'THREESIXTY NASF.doc')
insert into clientaccount..WorkflowWizardOutputItem (wizardid, description, type, taskid, sortorder, valuename, compulsory, specifictocompany, filename)
values (41, 'Non Advised Sales Form','Document',0,8,'NASF',0,@Company, 'THREESIXTY NASF.doc')
insert into clientaccount..WorkflowWizardOutputItem (wizardid, description, type, taskid, sortorder, valuename, compulsory, specifictocompany, filename)
values (42, 'Non Advised Sales Form','Document',0,8,'NASF',0,@Company, 'THREESIXTY NASF.doc')
GO
