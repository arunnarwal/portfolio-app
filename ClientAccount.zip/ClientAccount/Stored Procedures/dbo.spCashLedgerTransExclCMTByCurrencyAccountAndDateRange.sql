/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>645392404FE48DA50C3ACEB724EE531A</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE Procedure [dbo].[spCashLedgerTransExclCMTByCurrencyAccountAndDateRange](@ClAccountId varchar(20), @FromDate datetime, @ToDate datetime, @CCYCode char(3)) AS

SELECT clt.transid,
       clt.ledgerdate,
       con.claccountid,
       clt.linenumber,
       clt.movementtype,
       clt.movementsource,
       clt.ccycode,
       -clt.amount AS amount,
       clt.narrative,
       clt.displaytoclient,
       clt.capital,
       clt.datecreated,
       clt.ledgersource,
       clt.ledgersourceid,
       clt.fromccycode,
       clt.toccycode,
       clt.baseccycode,
       clt.fxrate,
       con.subclaccountid,
       pd.producttype,
	   pd.arrangementtype,
       clt.reference,
       clt.narrativedetail,
       pd.productdisplayname,
       mcr.cltnarration,
	   clt.OrderID
FROM   clientaccount.dbo.cashledgertransactions AS clt
			inner join csfbmaster.dbo.fn_convert_comma_to_table_char(@claccountid) c on c.tabvalue = clt.claccountid
			INNER JOIN clientaccount.dbo.consolidate AS con ON con.subclaccountid = clt.claccountid
			LEFT OUTER JOIN discovery.dbo.productdetails AS pd ON con.subclaccountid = pd.claccountid
			LEFT JOIN clientaccount.dbo.manualcashadjustmentrequests mcr ON clt.MCAid = MCR.ID AND clt.movementsource = 'ManualCashAdj'
WHERE  clt.displaytoclient = 1
       AND clt.movementtype <> 'CALL_TRANSACTION'
       AND clt.amount <> 0
	   AND con.claccountid = @ClAccountID
	   And clt.ledgerDate > @FromDate
	   And clt.ledgerDate <= @ToDate
	   And clt.CCYCOde = @CCYCOde

order by clt.ledgerdate, clt.transid desc
GO
