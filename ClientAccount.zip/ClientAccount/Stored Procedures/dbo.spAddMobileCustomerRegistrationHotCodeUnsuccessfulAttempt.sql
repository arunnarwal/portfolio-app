/***
<StoredProcedure>
	<Description>Add unsuccessful attempt at using the registration code for mobile customer hot registration</Description>
	<Parameters>
		<Parameter Name="@CodeId">
			<Description>Code Identifier</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [dbo].[spAddMobileCustomerRegistrationHotCodeUnsuccessfulAttempt]
(
@CodeId VARCHAR(25),
@NumberOfAttempts INT OUTPUT
)

AS

SELECT @NumberOfAttempts = NumberOfAttempts FROM dbo.MobileCustomerRegistrationHotCodes WHERE CodeId = @CodeId

IF (@@ROWCOUNT > 0)
BEGIN 
	SET @NumberOfAttempts = @NumberOfAttempts + 1
	UPDATE dbo.MobileCustomerRegistrationHotCodes SET NumberOfAttempts = @NumberOfAttempts WHERE CodeId = @CodeId
END
ELSE
BEGIN
	SET @NumberOfAttempts = 1
	INSERT INTO dbo.MobileCustomerRegistrationHotCodes (CodeId, NumberOfAttempts) VALUES (@CodeId, @NumberOfAttempts)
END
