/***
<StoredProcedure>
   <Description>Gets head account information for specified customer and adviser id combination.</Description>
   <Parameters>
      <Parameter Name="@UserId">
         <Description>The callers UserId</Description>
      </Parameter>
      <Parameter Name="@CustomerId">
         <Description>The customers Id</Description>
      </Parameter>
      <Parameter Name="@AdvisorId">
         <Description>The adviser Id</Description>
      </Parameter>
	  <Parameter Name="@ClientAccountStatus" Nullable="true">
         <Description>The account status</Description>--
      </Parameter>
	  <Parameter Name="@IncludeDisqualifiedPensionCredits" Nullable="true">
         <Description>Include DPC headaccounts in results</Description>
      </Parameter>
   </Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE Accounts.spGetHeadAccountsByCustomerAndAdviserId
	   @UserId INT,
	   @CustomerId INT,
	   @AdvisorId INT,
	   @ClientAccountStatus VARCHAR(50) = NULL,
	   @IncludeDisqualifiedPensionCredits BIT = NULL
AS
	
SELECT		SE.ClAccountId,
			SE.AccountName,
			SE.Id AS SEClientAccountId,
			CA.[Status] AS AccountStatus,
			CD.InvestorType,
			PD.PolicyNumber,
			SE.DateCreated,
			CD.BaseCCY,
			CR.CustomerRoleTypeId
FROM		Platform.DBAAccount.CustomerRoles CR
INNER JOIN	dbo.SEClientAccount se ON cr.AccountId = SE.Id
INNER JOIN  dbo.Advisor AS ADV ON ADV.AdvCode = se.PrimaryAdviser
INNER JOIN	dbo.ClientDetails cd ON SE.ClAccountId = CD.ClAccountId
INNER JOIN	Discovery.dbo.ClientAccount ca ON SE.ClAccountId = CA.ClAccountId
INNER JOIN	Discovery.dbo.ProductDetails pd ON SE.ClAccountId = PD.ClAccountId
INNER JOIN  Platform.DBAAccount.CustomerRoleTypes CRT ON CR.CustomerRoleTypeId = CRT.CustomerRoleTypeId
LEFT JOIN	dbo.ClientAccountSecurity cad ON cad.AdvisorCodes = SE.PrimaryAdviser AND CAD.ClAccountId IS NULL AND CAD.ClientId = @UserId
LEFT JOIN	dbo.ClientAccountSecurity cac ON cac.ClAccountId = SE.ClAccountId AND CAC.ClientId = @UserId
WHERE		CR.CustomerId = @CustomerId
AND			ADV.Id = @AdvisorId 
AND			CRT.IsPrimaryRoleApplicable = 1
AND			(CAD.ClientId IS NOT NULL OR CAC.ClientId IS NOT NULL)
AND			(CA.[Status] = @ClientAccountStatus OR @ClientAccountStatus IS NULL)
AND			(pd.DisqualifyingPensionCredits IS NULL OR pd.DisqualifyingPensionCredits = 0 OR @IncludeDisqualifiedPensionCredits = 1)