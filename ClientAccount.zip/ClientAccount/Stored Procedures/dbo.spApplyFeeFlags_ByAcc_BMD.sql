/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>9C2B8FB6A740B11F9E4C74B0A4C3F2C2</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[spApplyFeeFlags_ByAcc_BMD](@AsAt datetime)
AS


---version that only inserts fees with applies = 1
/*
declare @AsAt datetime 
set @AsAt = '6-Mar-2013'
*/
/*
Declare @LastDayOfMonth as Datetime
Set @LastDayOfMonth = @AsAt
Set @LastDayOfMonth = DateAdd(day, -1, convert(varchar(6),DateAdd(month,1,@LastDayOfMonth),112) + '01')
*/

declare @seedDate as datetime
declare @wrapProvider as VARCHAR(MAX)

SET @wrapProvider = 'BMD'

SET @seedDate = (
		SELECT MIN(FeeChargeSeed)
		FROM ClientAccount..WrapProviderFeeConfig
		WHERE WrapProvider = @wrapProvider
		)
;

WITH DateRanges
AS (
	SELECT Frequency
		,FromDate
		,ToDate
		,DaysInThisPeriod
	FROM ClientAccount..fnGetDateRangesForFrequencies(@asAt,@seedDate)
	)

,FeeTranType 
AS (	
	SELECT 
		FTT.TranType,
		FTT.TermType,
		REPLACE(FTT.TranType, ' Charge', '') AS Category
	FROM ClientAccount.dbo.FeeTranTypes FTT
		WHERE WrapProvider = @wrapProvider 
			AND FTT.TranType IN  ( 'TOAC Charge', 'WOAC Charge', 'AOAC Charge')
	)


Insert into ClientAccount..AppliedFees_ByAcc (ClAccountID, Date, FeeType, Applies, Applied, Status_Note, Rate)

-------------BMD OAC----------------
Select
	U.ClAccountID,
	@AsAt As Date,
	OAC.Type As FeeType,
	1 As Applies,
	0 As Applied,
	null as Status_Note,
	OAC.Rate
from ClientAccount.dbo.UnprocessedFUMFees_ByAcc AS U
	INNER JOIN ClientAccount.dbo.WrapProvider AS WP
		ON U.WrapProvider = WP.WrapProvider
	INNER JOIN ClientAccount.dbo.SEClientAccount AS SECA
		ON U.ClAccountID = SECA.ClAccountID
	INNER JOIN Discovery.dbo.ClientAccount AS CA
		ON SECA.ClAccountID = CA.ClAccountID
	LEFT JOIN ClientAccount.dbo.ClientDetails AS CD
		ON SECA.ClAccountID = CD.ClAccountID	
	INNER JOIN ClientAccount..fnOngoingAccrualChargeSettings(@asAt) AS OAC 
		ON OAC.ClAccountId = U.ClAccountID
	INNER JOIN FeeTranType
		ON OAC.Type = FeeTranType.Category
--	INNER JOIN ClientAccount..vwCommissionSettingByClient CS
--		ON CS.ClAccountId = U.ClAccountID
	INNER JOIN DateRanges AS dr
		ON dr.Frequency =  'Q' -- CS.OACFrequencyUnbundled
where U.AsAt = @AsAt

	/*and (CD.FeeStructure is null OR CD.FeeStructure = 'Commission') --RDR changes, Trail only on Pre-RDR accounts*/
	and WP.FeeARLPostingEnabled = 1
	/*and WP.FeeProductFBRCEnabled = 1*/
	and U.SubAccountType NOT IN ('SIPP','Offshore Bond','Onshore Bond','Wrap Cash')
	and coalesce(OAC.Rate, 0) <> 0
	/*and (CA.SuppressFBRC is null or CA.SuppressFBRC = 0)*/
	and U.MVAfterFX >= 0
	and @asat = dr.ToDate

GO
