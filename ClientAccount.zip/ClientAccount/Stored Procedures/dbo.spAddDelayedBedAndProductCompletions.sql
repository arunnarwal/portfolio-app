/***
<StoredProcedure>
    <Description>Save Bed and product that due to complete but missed cutoff so need to be delayed</Description>
	<Parameters>
		<Parameter Name="@DelayToProcessIds">
			<Description>the completion id that need to be delayed to process</Description>
		</Parameter>
		<Parameter Name="@DateDelayed">
			<Description>the date that process has been delayed</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE dbo.spAddDelayedBedAndProductCompletions (@DelayToProcessIds AS VARCHAR(MAX), @DateDelayed AS Date) 
AS
/*
    USE ClientAccount
    GO
    DROP TABLE IF EXISTS #CompletionIdsToDelay
	DROP TABLE IF EXISTS #IdsToDelay
    DECLARE @DelayToProcessIds AS VARCHAR(MAX) = '1,2,3,4,5', @DateDelayed AS Date = '2024-01-26'
--*/
SELECT 
	T.Tabvalue AS CompletionId
INTO #CompletionIdsToDelay
FROM CSFBMaster.dbo.fn_convert_comma_to_table_int(@DelayToProcessIds) T

CREATE UNIQUE CLUSTERED INDEX CUIDX_CompletionId ON #CompletionIdsToDelay (CompletionId)

SELECT 
	BAI.BedAndIsaId
INTO #IdsToDelay
FROM dbo.BedAndProductCompletion BPC
INNER JOIN #CompletionIdsToDelay PCI ON BPC.BedAndProductCompletionId = PCI.CompletionId
INNER JOIN dbo.BedAndIsa BAI ON BPC.BedAndIsaId = BAI.BedAndIsaId

CREATE UNIQUE CLUSTERED INDEX CUIDX_BedAndIsaId ON #IdsToDelay (BedAndIsaId)

INSERT INTO dbo.BedAndProductDelayedTransfers 
(
    BedAndIsaId,
	DateDelayed
)
SELECT
	BedAndIsaId,
	@DateDelayed
FROM #IdsToDelay ITD
WHERE NOT EXISTS (SELECT 1 FROM dbo.BedAndProductDelayedTransfers WHERE BedAndIsaId = ITD.BedAndIsaId)