/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>6FA4A4DBB972E1F05731B406693F1BAD</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[spCancelSchemeChargesGS](@schemeID int, @userID int) AS

--declare @schemeID as int
--declare @userID as int
--set @schemeID = 1
--set @userID = 8245

update ClientAccount..SchemeCSIPPAllowCharges
set Status = 'Cancelled', UserCancelled = @userId, DateCancelled = getdate()
where Status = 'Active' and SchemeId = @schemeID

update ClientAccount..SchemeDistributorFBRC
set Status = 'Cancelled', DeletedUserId = @userId, DeletedDate = getdate()
where Status = 'Active' and SchemeId = @schemeID

update ClientAccount..SchemeDistributorFee
set Status = 'Cancelled', DeletedUserId = @userId, DeletedDate = getdate()
where Status = 'Active' and SchemeId = @schemeID

update ClientAccount..SchemeECR
set Status = 'Cancelled', UserCancelled = @userId, DateCancelled = getdate()
where Status = 'Active' and SchemeId = @schemeID

update ClientAccount..SchemeLFD
set Status = 'Cancelled', UserCancelled = @userId, DateCancelled = getdate()
where Status = 'Active' and SchemeId = @schemeID

update ClientAccount..SchemeAMC
set Status = 'Cancelled', UserCancelled = @userId, DateCancelled = getdate()
where Status = 'Active' and SchemeId = @schemeID
GO
