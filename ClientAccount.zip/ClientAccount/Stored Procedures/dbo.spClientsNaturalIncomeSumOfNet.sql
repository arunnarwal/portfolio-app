/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>CB7250C9132BD460CD904F76F44AA8BB</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[spClientsNaturalIncomeSumOfNet] (@ByValue bit = 1, @ProcessNextPaymentdateBegin DateTime = NULL, @ProcessNextPaymentdateEnd DateTime = NULL, @ClAccountId varchar(13) = '') AS

/*
DECLARE @ByValue AS BIT 

DECLARE @ProcessNextPaymentdateBegin AS DATETIME

DECLARE @ProcessNextPaymentdateEnd AS DATETIME

DECLARE @ClAccountId AS varchar(13)

SET @ClAccountId = '' 

SET @ByValue = 1

SET @ProcessNextPaymentdateBegin = GETDATE()

SET @ProcessNextPaymentdateEnd = DATEADD(DAY, 1, @ProcessNextPaymentdateBegin)
*/

--=============== TEMPORARY table Clients =================--
CREATE TABLE #Clients (GroupedAccountNumber char(13), AccountNumber char(13))

-- accounts paying externally
insert into #Clients(GroupedAccountNumber,AccountNumber)
select ca.claccountid,ca.claccountid from clientaccount..clientdetails ca 
inner join discovery..productdetails pd
	on pd.claccountid = ca.claccountid
inner join  Discovery.dbo.IncomeInstructions AS CD
	on CD.ClAccountID = ca.ClAccountID

where ca.IncomePaymentExternal = 'External'
and pd.isDfmManaged = 0

AND CD.Enabled = 1 AND 
	CD.BankAccountId > 0 AND 
	(
	(@ByValue = 1 and CD.Frequency = 'MinimumAmount')
	 or 
	(@ByValue = 0 and (CD.Frequency <> 'MinimumAmount' AND CD.NextPaymentdate >= @ProcessNextPaymentdateBegin AND CD.NextPaymentdate < @ProcessNextPaymentdateEnd ))
	)
and (@ClAccountId = '' or @ClAccountId = ca.claccountid)

-- models using parent settings
insert into #Clients(GroupedAccountNumber,AccountNumber)
select INS.Name,ca.claccountid from clientaccount..clientdetails ca 
inner join discovery..productdetails pd
	on pd.claccountid = ca.claccountid
inner JOIN res_db..AccountInstrumentMappings M on M.claccountid = ca.claccountid
inner join res_db..instrumentsettings INS on ins.InstrumentCode = M.InstrumentCode
inner join  Discovery.dbo.IncomeInstructions AS CD
	on CD.ClAccountID = INS.Name
inner join clientaccount..clientdetails caParent
	on caParent.ClAccountid = ins.name
where ca.IncomePaymentExternal = 'ModelParent'
and caParent.IncomePaymentExternal = 'External'
and INS.type = 'Account'
and pd.isDfmManaged = 0
AND CD.Enabled = 1 AND 
	CD.BankAccountId > 0 AND 
	(
	(@ByValue = 1 and CD.Frequency = 'MinimumAmount')
	 or 
	(@ByValue = 0 and (CD.Frequency <> 'MinimumAmount' AND CD.NextPaymentdate >= @ProcessNextPaymentdateBegin AND CD.NextPaymentdate < @ProcessNextPaymentdateEnd ))
	)
and (@ClAccountId = '' or @ClAccountId = ca.claccountid)


CREATE INDEX index_fundAccount ON #Clients(AccountNumber)

--=============== TEMPORARY table Net =================--

CREATE TABLE #Net (id integer, claccountid char(13), Net float, TypeOfInterest char(30))

--=============== InterestIncome - non Coupon =================--

INSERT INTO #Net

SELECT II.Id, C.GroupedAccountNumber, II.Net, 'InterestIncome'

FROM 

#Clients AS C 

INNER JOIN ClientAccount.dbo.InterestIncome AS II ON C.AccountNumber = II.claccountid AND II.InterestType = 'Call' AND II.ExternalPaymentBatchID IS NULL AND II.Currency = 'GBP'

--=============== InterestIncome - Coupon =================--

INSERT INTO #Net

SELECT IJ.Id,C.GroupedAccountNumber, IJ.Net + Coalesce(IJ.FeesCommitments, 0) As Net, 'InterestIncome'

FROM 

#Clients AS C

INNER JOIN ClientAccount.dbo.InterestIncome AS IJ ON C.AccountNumber = IJ.claccountid AND IJ.EODLogID IS NOT NULL AND IJ.InterestType <> 'Call' AND IJ.ExternalPaymentBatchID IS NULL AND IJ.Currency = 'GBP'

INNER JOIN ClientAccount.dbo.CustodyEODJournalLog AS EOD ON IJ.EODLogID = EOD.id

WHERE EXISTS(SELECT * FROM ClientAccount.dbo.CashLedgerTransactions CLT WHERE CLT.JnlBatchID = EOD.JnlBatchID 

AND CLT.ClAccountId = IJ.ClAccountId 

AND CLT.CorpActId = IJ.CorpActId 

AND CLT.Amount = IJ.Net * -1 )

--=============== IncomeSummary - with EODLogID =================--

INSERT INTO #Net

SELECT IJ.Id, C.GroupedAccountNumber, IJ.TargetNetAmount, 'IncomeSummary'

FROM 

#Clients AS C

INNER JOIN ClientAccount.dbo.IncomeSummary AS IJ ON C.AccountNumber = IJ.claccountid AND TaxReclaimID IS NULL AND IJ.EODLogID IS NOT NULL AND IJ.ExternalPaymentBatchID IS NULL AND IJ.TargetCncyCode = 'GBP'  AND IJ.FinalProcessType IN ('External','ModelParent')

INNER JOIN ClientAccount.dbo.CustodyEODJournalLog AS EOD ON IJ.EODLogID = EOD.id 

WHERE EXISTS(SELECT * FROM ClientAccount.dbo.CashLedgerTransactions CLT WHERE CLT.JnlBatchID = EOD.JnlBatchID 

AND CLT.ClAccountId = IJ.ClAccountId 

AND CLT.CorpActId = IJ.CorpActId )

--=============== IncomeSummary - with TaxReclaim =================--

INSERT INTO #Net

SELECT IJ.Id, C.GroupedAccountNumber, IJ.TargetNetAmount, 'IncomeSummary'

FROM 

#Clients AS C

INNER JOIN ClientAccount.dbo.IncomeSummary AS IJ ON C.AccountNumber = IJ.claccountid AND TaxReclaimID IS NOT NULL AND IJ.ExternalPaymentBatchID IS NULL AND IJ.TargetCncyCode = 'GBP'

--================= Getting out Sum of Net ================--

SELECT 

Id, 

ClAccountId, 

Net AS TargetNetAmount,

TypeOfInterest

FROM 

#Net 

ORDER BY 

ClAccountId

--================= Drop temp tables ================--

DROP TABLE #Net

DROP TABLE #Clients

/*

GO

exec CSFBMaster..spUpdateMetaDB @DBName='ClientAccount', @TableName='spClientsNaturalIncomeSumOfNet', @TableConstant='claSpClientsNaturalIncomeSumOfNet'

*/

GO
