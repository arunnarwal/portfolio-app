/***
<StoredProcedure>
    <Description>Get Data fro bond gain certificate generation</Description>
    <Service>Transaction</Service>
	<Parameters>
		<Parameter Name="@subAccountIds">
			<Description>asat date</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [dbo].[spBondManualChargeableEventsData] (@subAccountIds VARCHAR(MAX))
AS
BEGIN

--DECLARE @subAccountIds VARCHAR(MAX) ='1200'
SELECT 
 bond.SubAccountId,
 se.ClAccountId AS SubClAccountId,
 Coalesce(chEvents.ManualChargeableEvent, 0) AS ManualChargeableEvent
FROM CSFBMaster.dbo.Fn_convert_comma_to_table_int(@subAccountIds) ids
  INNER JOIN [dbo].[Bonds] bond
    ON bond.SubAccountId = ids.TabValue
  INNER JOIN [dbo].[SeClientAccount] se
   ON se.Id = bond.SubAccountId
  LEFT JOIN [dbo].[BondManualChargeableEvents] chEvents
    ON chEvents.SubAccountId = bond.SubAccountId
END