/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>36EEFBD12E0240F90F947504F9CD6CF5</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[spAcornCommissionRevenueByTransactionForSummary](@clientID as int, @paymentId as int, @wrapProvider as varchar(20), @advisorPostMethod as varchar(16), @glPosted as varchar(16), @pendingAdvisorPost as varchar(16))
AS

--declare @clientID as int
--declare @paymentId as int
--declare @wrapProvider varchar(16)
--declare @advisorPostMethod varchar(16)
--declare @glPosted varchar(16)
--declare @pendingAdvisorPost varchar(16)
--
--set @clientID = 8245
--set @paymentId = 131
--set @wrapProvider = 'AXA'
--set @advisorPostMethod = 'ACORN'
--set @glPosted = 'YES'
--set @pendingAdvisorPost = 'YES'

SELECT	
		ARL.TranType,
		SUM(ARL.TotalAmount) As TotalAmount,
		ACA.WrapProvider,
		PD.ProductType,
		CSD.Name As SchemeName,
		CSD.ReferenceNumber As SchemeNumber,
		ACA.Clientid,
		PAY.PaymentTransactionID
FROM	Discovery.dbo.advisorrevenueledger ARL
			LEFT OUTER JOIN ClientAccount..CorporateSchemeDetails CSD
				on ARL.ADVCODE = CSD.AdvisorCode 
			INNER JOIN ClientAccount.dbo.vwAllowedClientAccounts ACA 
				on ARL.ClAccountID = ACA.ClAccountID
			left outer join Discovery..ProductDetails PD ON PD.ClAccountID = ACA.ClAccountID
			left outer join ClientAccount..AcornCommissionPayments PAY ON (PAY.ID = ARL.CommissionPaymentID or PAY.ID = ARL.CommissionPaymentIDReported)
where ACA.ClientID = @clientID and PAY.PaymentTransactionID = @clientID and ACA.WrapPRovider = @wrapProvider AND ARL.AdvisorPostMethod = @advisorPostMethod And  ARL.GLPosted = @glPosted And ARL.PendingAdvisorPost = @pendingAdvisorPost

Group By ARL.TranType,ACA.WrapPRovider,PD.ProductType,CSD.Name,CSD.ReferenceNumber, ACA.Clientid, PAY.PaymentTransactionID
GO
