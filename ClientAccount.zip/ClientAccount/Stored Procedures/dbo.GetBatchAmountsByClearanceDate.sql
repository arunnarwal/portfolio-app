/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>1549BC3080C2109C8486C5134824A81A</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
Create procedure dbo.GetBatchAmountsByClearanceDate(@batchId int, @DefaultClearanceDate datetime)
as

select OC.batchid,coalesce(A.RestrictSweepUntil,CE.ChequeClearanceDate, @DefaultClearanceDate) ClearanceDate,-sum(a.Amount) Amount from clientaccount..cashledgertransactions A
inner join discovery..ordercurrent oc on A.OrderID = OC.OrderID and A.ClAccountiD = OC.CLAccountID
left outer join discovery..cashentry CE on CE.BatchID = OC.BatchID
where oc.batchid = @batchId
group by coalesce(A.RestrictSweepUntil,CE.ChequeClearanceDate, @DefaultClearanceDate),oc.claccountid,OC.batchid

