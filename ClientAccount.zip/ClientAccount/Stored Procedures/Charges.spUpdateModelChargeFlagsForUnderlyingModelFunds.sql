/***
<StoredProcedure>
    <Description>Updates the Old Mutual charging flags for model funds under a given model template</Description>    
</StoredProcedure>
--***/

CREATE PROCEDURE Charges.spUpdateModelChargeFlagsForUnderlyingModelFunds( @InstrumentCode VARCHAR(20), @OmgiFlag BIT, @IncludedInPlatformCharge BIT)
AS
BEGIN
--DECLARE @InstrumentCode VARCHAR(20)
--DECLARE @OmgiFlag BIT
--DECLARE @IncludedInPlatformCharge BIT
--SET @InstrumentCode = 'M_133268'
--SET @omgiFlag = 1
--SET @IncludedInPlatformCharge = 1

UPDATE MF 
SET 
	OmgiFlag = @OmgiFlag, 
	IncludedInPlatformCharge = @IncludedInplatformCharge, 
	DateModified = GETDATE(), 
	UserModified = 8245
FROM dbo.Modelaccountinstrumentmapping MAIM 
INNER JOIN Res_db.dbo.Instruments I ON MAIM.Modelfundinstrumentid = I.Id
INNER JOIN Res_db.dbo.ManagedFunds MF ON MF.InstrumentCode = I.Security  
INNER JOIN Res_db.dbo.Instruments MI ON MI.ExternalId = CAST(MAIM.ModelId AS VARCHAR(20)) AND MI.SecuritySubType IN ('Dfm Model Template', 'Lifestyle Template', 'Synthetic Fund Template', 'Advisor Model Template', 'MPS Model Template')
WHERE MI.Security = @InstrumentCode

END