/***
<StoredProcedure>
    <Description>Clean table before before new values are saved from calculation</Description>
    <Service>Transaction</Service>
</StoredProcedure>
***/
CREATE PROCEDURE [dbo].[spCleanBondPtcUnrealisedGainsStagingFromCacheCalculation](
	@BondUnrealisedGainCacheCalculationId AS INT
	) AS
BEGIN

DECLARE @FromDate AS DATE
DECLARE @ToDate AS DATE

SELECT @FromDate = FromDate, @ToDate = ToDate FROM dbo.BondUnrealisedGainCacheCalculation WHERE BondUnrealisedGainCacheCalculationId = @BondUnrealisedGainCacheCalculationId

IF @FromDate IS NULL 
BEGIN
  RETURN
END

; WITH SubAccountsToDelete AS
(
SELECT 
 SubAccountId
FROM dbo.BondUnrealisedGainCacheCalculationSubAccounts
WHERE BondUnrealisedGainCacheCalculationId = @BondUnrealisedGainCacheCalculationId
)


DELETE FROM dbo.BondPtcUnrealisedGainsStaging WHERE 
  SubAccountId IN (SELECT SubAccountId FROM SubAccountsToDelete )
  AND (AsAtDate >= @FromDate AND  AsAtDate <= @ToDate)

END