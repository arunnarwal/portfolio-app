/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>FD7A2147B1FD4745360EB112530E2808</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[spCheckIfAnyAuthenticationsCompleted](@listOfPersistIDs varchar(250)) 
AS
SELECT DISTINCT
dbo.WizardPersist.id, 
dbo.WizardPersist.ClAccountID, 
dbo.WizardPersist.ClientID, 
[Action].ClientID As ActionClientID, 
dbo.WizardPersist.DateCreated, 
dbo.WizardPersist.LastUpdated, 
dbo.WizardPersist.WizardSessionID, 
dbo.WizardPersist.WizardID, 
dbo.WizardPersist.Title, 
ISNULL([Action].ActionID, 0) as ActionID,
CL.FullName,
Wiz.DisplayName, 
A.Action,
SEC.AccountName,
UG.UserGroupID,
dbo.WizardPersist.Designation, 
dbo.WizardPersist.ExistingAccountNumber,
PD.ProductDisplayName,
dbo.WizardPersist.UserRejected,
dbo.WizardPersist.DateRejected,
dbo.WizardPersist.RejectedReason
FROM dbo.WizardPersist 
inner join ClientAccount..[fn_convert_comma_to_table_char](@listOfPersistIDs) as fun
	on dbo.WizardPersist.id = fun.tabvalue
INNER JOIN  clientdb3..tblclients CL on CL.clientid = dbo.WizardPersist.ClientID
INNER JOIN clientaccount..workflowwizard wiz on wiz.id = dbo.WizardPersist.wizardid
INNER JOIN clientaccount..seclientaccount SEC on SEC.claccountid = dbo.WizardPersist.ClAccountID 
INNER JOIN  webdb..usersToGroups UG on CL.clientid = UG.ClientID
LEFT JOIN  Discovery..ProductDetails PD on PD.claccountid = dbo.WizardPersist.ExistingAccountNumber
LEFT JOIN
(
Select * FROM WizardPersist_WizardPersistAction
WHERE id in
(SELECT MAX(id) as id FROM dbo.WizardPersist_WizardPersistAction
inner join ClientAccount..[fn_convert_comma_to_table_char](@listOfPersistIDs) as fun
	on dbo.WizardPersist_WizardPersistAction.WizardPersistID = fun.tabvalue
GROUP BY WizardPersistID)
) [Action]
ON dbo.WizardPersist.id = [Action].WizardPersistID
LEFT JOIN  dbo.WizardPersistAction A ON A.ID = [Action].ActionID
WHERE Action = 'Complete'
GO
