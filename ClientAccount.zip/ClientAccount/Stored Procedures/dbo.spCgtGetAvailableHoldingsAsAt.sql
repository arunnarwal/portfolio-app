/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>7A117EC315DFF1EFA4CAF3373E7CCCB5</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[spCgtGetAvailableHoldingsAsAt]    
@clAccountId VARCHAR(100),
@AsAt DATETIME
AS

BEGIN
SELECT SUM(Quantity) AS Quantity,
	   InstrumentCode
FROM cgtScripTransactions 
WHERE clAccountId = @clAccountId And AsAt < @AsAt And cgtExempt <> 1 And TransStatus = 'Settled'
GROUP BY InstrumentCode
END

/*
exec CSFBMaster..spUpdateMetaDB @DBName='ClientAccount', @TableName='spCgtGetAvailableHoldingsAsAt', @TableConstant='claspCgtGetAvailableHoldingsAsAt'
*/
GO
