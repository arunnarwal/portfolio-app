/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>EF0684C0BD11F3E82A32A329557060A5</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[spCacheUnclassifiedAssets] AS

DELETE FROM Cache..UnclassifiedAssetsCache

INSERT INTO Cache..UnclassifiedAssetsCache (Company, InstrumentCode, ClassMethod, CacheDate) 
	(Select Distinct CD.company, ST.instrumentcode, company.clientclassmethod2, CONVERT(CHAR(11),GETDATE(),106)

	From scriptransactions ST
		inner join clientdetails CD on ST.claccountid = CD.claccountid
		left join company on company.company = CD.company
		left join amaclass on amaclass.instrumentcode = ST.instrumentcode and amaclass.company = company.clientclassmethod2
	
	Where amaclass.classcode is null and transstatus='Settled')

Select 0 As ReturnValue
GO
