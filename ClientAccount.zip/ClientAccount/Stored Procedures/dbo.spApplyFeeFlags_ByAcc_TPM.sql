/***
<StoredProcedure>
    <Description>Permissions clients client fee FUM flags for Tiered Per Member (Member/Employer)</Description>
	<Service>Charges</Service>
    <Feature>Tasks</Feature>
    <Parameters>
        <Parameter Name="@AsAt">
            <Description>The date of the fee run</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [dbo].[spApplyFeeFlags_ByAcc_TPM] (@AsAt DATETIME,  @TranType VARCHAR(10))
AS
--DECLARE @AsAt DATETIME; SET @AsAt = '08 May 2014'
--DECLARE @TranType VARCHAR(10); SET @TranType = 'TPME'
--;
DECLARE @TPME VARCHAR(10); SET @TPME= 'TPME'
DECLARE @TPMM VARCHAR(10); SET @TPMM = 'TPMM'

IF OBJECT_ID(N'tempdb..#FeeAccrual', N'U') IS NOT NULL
BEGIN
	DROP TABLE #FeeAccrual
END

IF OBJECT_ID(N'tempdb..#MemberCounts', N'U') IS NOT NULL
BEGIN
	DROP TABLE #MemberCounts
END

CREATE TABLE #FeeAccrual (
	SecaID INT
	,SchemeID INT
	,AsAt SMALLDATETIME 
	,FeeTranTypesID INT
	,FeeTranType VARCHAR(50)
	,Rate NUMERIC(11, 3)
	,ApplyVAT BIT
	,FumTotal MONEY
	,EmployerChargeDate DATETIME
	,ClientChargeDate DATETIME
);

CREATE TABLE #MemberCounts (
	SchemeID INT
	,MemberCount INT
);

INSERT INTO #MemberCounts
SELECT 
	SchemeDetails.ID AS SchemeID
	,COUNT(*) AS MemberCount 
FROM
	dbo.CorporateSchemeDetails SchemeDetails
	INNER JOIN dbo.CorporateMemberSchemeDetails MemberDetails ON MemberDetails.SchemeID = SchemeDetails.ID
GROUP BY SchemeDetails.Id

INSERT INTO #FeeAccrual
SELECT 
	Fum.SecaID AS SecaID
	,SchemeDetails.ID AS SchemeID
	,Fum.AsAt AS AsAt 
	,FeeTranTypes.ID AS FeeTranTypesID
	,FeeTranTypes.TranType AS FeeTranType
	,CAmcTiers.TierRate AS Rate
	,0 AS ApplyVAT 
	,Fum.CashAmount + Fum.NonCashAmount FumTotal
	,EmployerFRQRanged.ToDate AS EmployerChargeDate
	,FRQRanged.ToDate AS ClientChargeDate
FROM
	Cache.dbo.Fee_FUM_ByAccount Fum
	INNER JOIN dbo.WrapProvider WrapProvider ON Fum.WrapProviderID = WrapProvider.ID
	INNER JOIN dbo.FeeTranTypes AS FeeTranTypes
		ON FeeTranTypes.TranType = @TranType AND FeeTranTypes.WrapProvider = WrapProvider.WrapProvider 
	INNER JOIN dbo.Advisor Advisor ON Fum.AdvisorID = Advisor.ID
	INNER JOIN dbo.CorporateSchemeDetails SchemeDetails ON SchemeDetails.AdvisorCode = Advisor.AdvCode
	INNER JOIN dbo.SEClientAccount SecaID ON SecaID.ID = Fum.SecaID
	INNER JOIN Discovery.dbo.ProductDetails ProductDetails ON ProductDetails.ClAccountID = SecaID.ClAccountID
	INNER JOIN #MemberCounts MemberCounts ON MemberCounts.SchemeID = SchemeDetails.ID
	INNER JOIN dbo.CorporateTieredAMC CAmc
		ON CAmc.SchemeID = SchemeDetails.ID AND CAmc.FeeTranTypeID = FeeTranTypes.ID
			AND CAmc.ProductType = ProductDetails.ProductType AND @AsAt >= CAmc.FromDate
			AND (CAmc.ToDate IS NULL OR @AsAt <= CAmc.ToDate)
	INNER JOIN  dbo.CorporateTieredAMCTiers CAmcTiers
		ON CAmcTiers.CorporateTieredAMCID = CAmc.ID AND MemberCounts.MemberCount >= CAmcTiers.FromRange
			AND (CAmcTiers.ToRange IS NULL OR MemberCounts.MemberCount <= CAmcTiers.ToRange)
	/** Employer Reserve Account **/
	INNER JOIN dbo.CorporateSchemeEmployerDetails EmployerDetails ON EmployerDetails.ID = SchemeDetails.EmployerdetailsID
	INNER JOIN dbo.CorporateEmployer Employer ON Employer.ID = EmployerDetails.EmployerID
	INNER JOIN dbo.Branches Branches ON Branches.ID = Employer.BranchID
	INNER JOIN dbo.Advisor EmployerAdvisor ON EmployerAdvisor.BranchID = Branches.ID
	INNER JOIN dbo.SEClientAccount EmployerSeca ON EmployerSeca.PrimaryAdviser = EmployerAdvisor.Advcode AND EmployerSeca.InvestorType = 'EmployerReserve'
	INNER JOIN dbo.fnHeadAccounts() Head
		ON EmployerSeca.ClAccountID = Head.ClAccountID AND Head.Consolidated = 0 AND Head.ClAccountID <> Head.HeadClAccountID
	/** END of Employer Reserve Account **/
	LEFT JOIN dbo.AppliedFees_ByAccV2 AS Applied
		ON Applied.AsAt = @AsAt AND Applied.SecaID = Fum.SecaID AND Applied.FeeTranTypesID = FeeTranTypes.ID
	CROSS APPLY dbo.fnGetDateRangesForFrequencies(@AsAt,DATEADD(dd, 0, DATEDIFF(dd, 0, SecaID.DateCreated + 1))) FRQRanged
	CROSS APPLY dbo.fnGetDateRangesForFrequencies(@AsAt,DATEADD(dd, 0, DATEDIFF(dd, 0, EmployerSeca.DateCreated + 1))) EmployerFRQRanged
WHERE 
	Fum.AsAt = @AsAt 
	AND Applied.ID IS NULL
	AND 'M' = FRQRanged.Frequency 
	AND 'M' = EmployerFRQRanged.Frequency
	AND NOT EXISTS (
		SELECT 1 FROM dbo.Fee_Fum_ExcludeAccountTypes EXAT 
		WHERE EXAT.WrapProviderID = Fum.WrapProviderID
			AND EXAT.FeeTranTypeID = FeeTranTypes.ID 
			AND EXAT.AccountType = SecaId.InvestorType)

INSERT INTO dbo.ToBeAppliedFees_ByAccV2 (
    SecaID
    ,[AsAt]
    ,FeeTranTypesID
    ,Applied
    ,Rate
    ,ApplyVAT
)
SELECT
	FeeAccrual.SecaID
	,FeeAccrual.[AsAt]
	,FeeAccrual.FeeTranTypesID
	,0 AS Applied/*Applied*/
	,FeeAccrual.Rate
	,FeeAccrual.ApplyVAT
FROM
	#FeeAccrual AS FeeAccrual
	LEFT JOIN dbo.ToBeAppliedFees_ByAccV2 AS ToBeApplied
		ON FeeAccrual.SecaID = ToBeApplied.SecaID AND FeeAccrual.AsAt = ToBeApplied.AsAt AND FeeAccrual.FeeTranTypesID = ToBeApplied.FeeTranTypesID
WHERE
	ToBeApplied.SecaID IS NULL
	AND FeeAccrual.Rate > 0
	AND FeeAccrual.FumTotal > 0
	AND ((FeeAccrual.FeeTranType = @TPMM AND FeeAccrual.ClientChargeDate = @asAt) OR FeeAccrual.FeeTranType = @TPME AND FeeAccrual.EmployerChargeDate = @asAt)

INSERT INTO dbo.NonAppliedFees_ByAccV2 (
	SecaID
	,[AsAt]
	,FeeTranTypesID
	,Status_NoteID
)
SELECT
FeeAccrual.SecaID
                ,FeeAccrual.[AsAt]
                ,FeeAccrual.FeeTranTypesID
                ,0 AS Status_NoteID
FROM
	#FeeAccrual AS FeeAccrual
	LEFT JOIN dbo.NonAppliedFees_ByAccV2 AS NotToBeApplied
		ON FeeAccrual.SecaID = NotToBeApplied.SecaID AND FeeAccrual.AsAt = NotToBeApplied.AsAt AND FeeAccrual.FeeTranTypesID = NotToBeApplied.FeeTranTypesID
WHERE
	NotToBeApplied.SecaID IS NULL
	AND FeeAccrual.Rate = 0
	AND FeeAccrual.FumTotal = 0
	AND ((FeeAccrual.FeeTranType = @TPMM AND FeeAccrual.ClientChargeDate <> @asAt) OR FeeAccrual.FeeTranType = @TPME AND FeeAccrual.EmployerChargeDate <> @asAt)

IF OBJECT_ID(N'tempdb..#FeeAccrual', N'U') IS NOT NULL
BEGIN
	DROP TABLE #FeeAccrual
END

IF OBJECT_ID(N'tempdb..#MemberCounts', N'U') IS NOT NULL
BEGIN
	DROP TABLE #MemberCounts
END
GO