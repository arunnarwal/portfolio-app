/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>CD470AEC58293FE7194A2201A3BBC9B2</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
create procedure [dbo].[spCloneChecklistItemStepBetweenSessions](@sourceSessionID int, @destSessionID int)
AS
update clientaccount..WorkflowWizardChecklistItem
set 
	clientaccount..WorkflowWizardChecklistItem.Optional = query.Optional,
	clientaccount..WorkflowWizardChecklistItem.Selected = query.Selected
from 
clientaccount..WorkflowWizardChecklistItem
inner join  (
select Dest.ID,Source.Optional,Source.Selected from 
(
	select a.ID,b.name from clientaccount..WorkflowWizardChecklistItem a 
	inner join clientaccount..WorkflowWizardChecklistItemType b on a.checklistitemtype = b.id where wizardsessionid =  @destSessionID
) dest
inner join 
(select a.optional,a.Selected,b.name from clientaccount..WorkflowWizardChecklistItem a 
inner join clientaccount..WorkflowWizardChecklistItemType b on a.checklistitemtype = b.id where wizardsessionid =  @sourceSessionID) source
on source.name = dest.name) query
on query.ID = clientaccount..WorkflowWizardChecklistItem.ID
GO
