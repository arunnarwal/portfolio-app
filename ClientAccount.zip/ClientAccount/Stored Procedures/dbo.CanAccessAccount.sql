/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<StoredProcedure>
    <Description>A9CD2CE626B40F5E2CF70958AC25BF2E</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</StoredProcedure>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[CanAccessAccount](@ClientID int, @ClAccountID varchar(20)) AS
select top 1 CAS.ReadWrite access from clientAccountSecurity CAS where clientid= @ClientID AND claccountid=@ClAccountID
union
select top 1 CAS.ReadWrite access from clientAccountSecurity CAS
INNER JOIN
     dbo.SEClientAccount SECA WITH (NOLOCK) ON (cas.AdvisorCodes = SECA.PrimaryAdviser AND (cas.clAccountID IS NULL))
 where SECA.claccountid=@ClAccountID and clientid= @ClientID
GO
