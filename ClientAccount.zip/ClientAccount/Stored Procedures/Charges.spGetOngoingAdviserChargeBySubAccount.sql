/***
<StoredProcedure>
    <Description>Gets ongoing adviser charge by sub account Id</Description>
	    <Parameters>
        <Parameter Name="@SubAccountId">
            <Description>the subaccount id</Description>
        </Parameter>        
    </Parameters>
</StoredProcedure>
***/
Create PROCEDURE Charges.spGetOngoingAdviserChargeBySubAccount @SubAccountId INT AS
	DECLARE @AsAt DATE = GETDATE()
	--DECLARE @SubAccountId INT =1864675
	SELECT 
		seca.Id AS SubAccountId,
		cfs.FBRCRate AS Rate, 
		CASE
			WHEN cfs.FBRCRate = 0 THEN COALESCE(cfs.FBRCAmount, 0)
			ELSE 0
		END AS Amount,
		cfs.TierStructureId,
		Charges.fnConvertFrequencyCharToChargeFrequency(cd.FeeInvoicingFrequency) AS Frequency
	FROM dbo.ClientFBRCSettings cfs
	INNER JOIN dbo.SEClientAccount seca on seca.ClAccountId = cfs.ClAccountId
	INNER JOIN dbo.ClientDetails cd ON cd.ClAccountId = cfs.ClAccountId		
	WHERE seca.Id = @SubAccountId And cfs.AsAt <= @AsAt
	ORDER BY cfs.AsAt desc


