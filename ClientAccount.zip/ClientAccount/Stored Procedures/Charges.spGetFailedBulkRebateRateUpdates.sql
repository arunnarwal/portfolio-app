/***
<StoredProcedure>
    <Description>Gets failed bulk rebate rate updates for specified bulk request</Description>
    <Service>Charges</Service>
    <Feature>Charges</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE Charges.spGetFailedBulkRebateRateUpdates (@BulkRequestId INT)
AS
BEGIN
	SELECT
		Frrur.FailReason,
		Rrur.InstrumentIsin
	FROM dbo.BulkRebateRateUpdateRequests Brrur
	INNER JOIN dbo.RebateRateUpdateRequests Rrur on rrur.BulkRebateRateUpdateRequestId = brrur.BulkRebateRateUpdateRequestId 
	INNER JOIN dbo.FailedRebateRateUpdateRequests Frrur on frrur.RebateRateUpdateRequestId = rrur.RebateRateUpdateRequestId
	WHERE Brrur.BulkRebateRateUpdateRequestId = @BulkRequestId
END
GO

