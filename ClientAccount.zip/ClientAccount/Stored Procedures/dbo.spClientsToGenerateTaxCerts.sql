/***
<StoredProcedure>
    <Description>Procedure to get list of clients to generate Tax Certificates</Description>
	<Parameters>
        <Parameter Name="@FromDate">
            <Description>The from date</Description>
        </Parameter>
		<Parameter Name="@ToDate">
            <Description>The to date</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/

--------------------------------------------------------------------------------------------------------------------------------------------  
-- This procedure retrieves all qualifying accounts for Tax certificates.  
--  
-- !!! Please REMEMBER that there is also "spClientsToGenerateTaxCertsSuppressed" which retreives all Tax Certificates that were suppressed  
-- with given reason.  
-- If you change some common logic here, you should take look at the other function to be sure it doesn't need to be changed as well !!!  
--------------------------------------------------------------------------------------------------------------------------------------------  
CREATE PROCEDURE [dbo].[spClientsToGenerateTaxCerts](
	 @FromDate datetime
	,@ToDate datetime) AS  

--DECLARE 
--	 @FromDate		DATETIME
--	,@ToDate		DATETIME

--SELECT
--	 @FromDate		= '2016-04-06 00:00:00.000'
--	,@ToDate		= '2017-04-05 00:00:00.000'

SELECT DISTINCT
				SECA.ClAccountId
INTO			#AccountsWithRebates
FROM			Discovery.dbo.XhubAdvisorRevenueLedger		XARL
INNER JOIN		dbo.ModelAccountInstrumentMapping			MAIA		ON MAIA.HubAccountId = XARL.HierarchyEntityId
INNER JOIN		dbo.SEClientAccount							SECA		ON SECA.Id = MAIA.SubAccountId
INNER JOIN		Discovery.dbo.ProductDetails				PD			ON PD.ClAccountId = SECA.ClAccountId
WHERE			XARL.LedgerDate >= @FromDate
				AND XARL.LedgerDate <= @ToDate
				AND PD.ProductType = 'Personal Portfolio'

UNION

SELECT DISTINCT 
				R.ClAccountID
FROM			Discovery.dbo.Rebate				R
INNER JOIN		Discovery.dbo.ProductDetails		PD	ON R.ClAccountId = PD.ClAccountId AND PD.ProductType = 'Personal Portfolio'
WHERE			R.AsAt <= @ToDate
				AND	R.AsAt >= @FromDate

CREATE UNIQUE CLUSTERED INDEX CUIDX_ClAccountId ON #AccountsWithRebates(ClAccountId)

SELECT DISTINCT 
				CO.WrapProvider, 
				C.ClAccountID						HeadClAccountId
FROM			#AccountsWithRebates				AWR
INNER JOIN		dbo.Consolidate						C	ON AWR.ClAccountID = C.SubClAccountID AND C.SubClAccountID <> C.ClAccountID
INNER JOIN		dbo.ClientDetails					CD	ON CD.CLAccountID = C.ClAccountID
INNER JOIN		dbo.Company							CO	ON CO.Company = CD.Company
WHERE CD.InvestorType <> 'Trading' 

UNION

SELECT DISTINCT
	 INC.WrapProvider
	,INC.HeadClAccountId
FROM		dbo.vwTaxableIncomeDataForUK		INC 
LEFT JOIN	dbo.SEClientAccount					SCA	 ON INC.HeadClAccountID = SCA.ClAccountID AND SCA.InvestorType = 'Trading'
WHERE	INC.SubAccountType IN ('Wrap Cash','Personal Portfolio')  
		AND	INC.LedgerDate BETWEEN @FromDate AND @ToDate  
		AND	INC.ClAccountId <> INC.HeadClAccountId
		AND	SCA.ClAccountID IS NULL

DROP TABLE #AccountsWithRebates
