/***
<StoredProcedure>
    <Description>CGT Tool Script Transactions
        Should be kept aligned with spCGTToolScripTransactionsExternal
    </Description>
    <Parameters>
        <Parameter Name="@ClAccountIds">
            <Description>Comma separated list of ClAccountIds</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/

CREATE PROCEDURE dbo.spCGTToolScripTransactionsInclInternalAndExternal
    @ClAccountIds VARCHAR(MAX), 
	@IncludePreMigrationTransactions BIT = 0
AS

 --DECLARE @ClAccountIds VARCHAR(MAX) = 'AC2022984-002'
 --DECLARE @IncludePreMigrationTransactions BIT = 0

DECLARE @BaseCCY VARCHAR(3)
SET @BaseCCY = 'GBP'

SELECT
    CAST(TabValue AS VARCHAR(20)) AS ClAccountId
INTO #ClAccountIds
FROM CSFBMaster.dbo.[fn_convert_comma_to_table_char](@ClAccountIds)

CREATE CLUSTERED INDEX IDX_ClAccountIds_ClAccountId ON #ClAccountIds (ClAccountId)

DECLARE @MigrationDateOffset int = (SELECT [Value] FROM SystemVariables.dbo.SystemVariables AS SV WHERE ID = 105549)

declare @MigrationDate DateTime

select @MigrationDate = tid.RequestDateTime from Discovery.Dbo.Clientaccount CA
inner join Discovery.Dbo.Transactionid TID on CA.TransactionID =TID.TransactionID
inner join #ClAccountIds Acc on Acc.ClAccountId = CA.ClAccountID
where TID.Callersource = 'MIG' 
order by tid.RequestDateTime desc

declare @MigrationDateMinusMigrationOffset DateTime = DateAdd(d, -1 * @MigrationDateOffset, @MigrationDate)

SELECT
    Acc.ClAccountId,
    Let.LegalEntityTypeId
INTO #Accounts
FROM #ClAccountIds Acc
INNER JOIN Discovery.dbo.ProductDetails AS PD
    ON PD.ClAccountID = Acc.ClAccountID
INNER JOIN [Platform].ProductWrappers.ProductWrapperTypes pwt
    ON pwt.ProductType=PD.ProductType
INNER JOIN Tax.CGT_TaxableProductWrapperTypes TPWT	
    ON TPWT.ProductWrapperTypeId = PWT.ProductWrapperTypeId
INNER JOIN dbo.ClientDetails AS CD
    ON CD.ClAccountID = Acc.ClAccountID
INNER JOIN dbo.Company CO
    ON CO.Company = CD.Company
INNER JOIN dbo.vwWrapProviderWithJurisdiction vww
    ON vww.WrapProvider=co.WrapProvider

LEFT JOIN One.Tax.LegalEntityType let
    ON (case when cd.InvestorType='individ' then 'individual' else cd.InvestorType end)=let.LegalEntityType
    AND let.IsSubType = 0

LEFT JOIN One.Tax.CGTProductWrapperException cgtE
    ON cgtE.JurisdictionID=vww.JurisdictionID
    AND (let.LegalEntityTypeId=cgtE.LegalEntityType or cgtE.LegalEntityType is null)
    AND (cd.LegalEntitySubType=cgtE.LegalEntitySubType or cgtE.LegalEntitySubType is null)
    AND (cd.LegalEntitySubSubType=cgtE.LegalEntitySubSubType or cgtE.LegalEntitySubSubType is null)
    AND (pwt.ProductWrapperTypeId=cgtE.ProductWrapperType or cgtE.ProductWrapperType is null)
    AND (pd.ProductSubTypeId=cgtE.ProductWrapperSubType  or cgtE.ProductWrapperSubType is null)

WHERE ( cgtE.JurisdictionID is null
    AND cgtE.LegalEntityType is null
    AND cgtE.LegalEntitySubType is null
    AND cgtE.LegalEntitySubSubType is null
    AND cgtE.ProductWrapperType is null
    AND cgtE.ProductWrapperSubType is null)

AND cd.IsCgtExempt <> 1

CREATE UNIQUE CLUSTERED INDEX uidx_ClAccountID ON #Accounts (CLAccountID)
-------

SELECT
    Scrip.ClAccountId,
	Scrip.InstrumentCode,
	SUM(Scrip.Quantity) AS 'Quantity',
	SUM(Scrip.Group1) AS 'Group1',
	SUM(Scrip.Group2) AS 'Group2'
INTO #HoldingsAsAtMigrationDateMinusMigrationOffset
FROM
(
	SELECT ST.ClAccountId,
	ST.InstrumentCode,
	ST.Quantity,
	ST.Group1,
	ST.Group2
	FROM dbo.ScripTransactions AS ST
	    INNER JOIN #Accounts
            ON #Accounts.ClAccountID = ST.CLAccountID
	WHERE ST.AsAt < @MigrationDateMinusMigrationOffset
		AND ST.TransStatus = 'Settled'
		AND ST.Cutover = 0

	UNION ALL

	SELECT EST.ClAccountId,
	EST.InstrumentCode,
	EST.Quantity,
	EST.Group1,
	EST.Group2
	FROM dbo.ExternallyReceivedScripTransactions AS EST
		INNER JOIN #Accounts
            ON #Accounts.ClAccountID = EST.CLAccountID
	WHERE EST.AsAt < @MigrationDateMinusMigrationOffset
		AND EST.TransStatus = 'Settled'
		AND EST.Cutover = 0
) Scrip

GROUP BY
	Scrip.ClAccountId,Scrip.InstrumentCode

	
CREATE UNIQUE CLUSTERED INDEX uidx_ClAccountIDInstrumentCode ON #HoldingsAsAtMigrationDateMinusMigrationOffset (CLAccountID, InstrumentCode)
-------

;WITH Registry AS (
    SELECT
        CASE WHEN CGT.cgtTotalValue IS NOT NULL
                    AND ST.Quantity IS NOT NULL
                    AND ST.Quantity <> 0 THEN CONVERT(DECIMAL(18, 8), ABS(CGT.CgtTotalValue) / ABS(ST.Quantity))

            ELSE ST.COST
        END AS Cost
	,   ST.COST As ScripCost
    ,   ST.TransId
    ,   ST.TransDate
    ,   COALESCE (CGT.cgtDate, ST.AsAt) AS AsAt
	,   CGT.cgtDate As CgtDate
	,   ST.AsAt As StAsAt
    ,   ST.CLAccountID
	,   ST.HubAccountId
    ,   #Accounts.LegalEntityTypeId
    ,   ST.Quantity
    ,   ST.InstrumentCode
    ,   ST.TransSource
    ,   ST.CorpActID
    ,   ST.TransType
    ,   ST.FXCost
    ,   ST.CncyCode
    ,   ST.AWOrderID
    ,   ST.AWScripTransferID
    ,   ST.Group1Group2
    ,   ST.TradeId
    ,   ST.Group1
    ,   ST.Group2
    ,   CGT.CgtExempt AS CgtExempt
    ,   CGT.CgtTotalValue
    ,   CGT.TaxBookStatus
    ,   CGT.ExcludeFrom30DayRule
    ,   ST.Location
    ,   ST.Note
    ,   1 AS IsExternal
    FROM dbo.ExternallyReceivedScripTransactions AS ST
    INNER JOIN #Accounts
        ON #Accounts.ClAccountID = St.CLAccountID

    LEFT JOIN dbo.ExternallyReceivedCgtTransactions AS CGT
        ON ST.TransId = CGT.scripTransactionID

    WHERE
        ST.CLAccountID IN (SELECT CLA.ClAccountId FROM #ClAccountIds AS CLA)
    AND ST.Cutover = 0
    AND ST.TransType <> 'MFRollFwd'
    AND ( (ST.TransStatus = 'Settled' AND ST.Location = 'Registry') OR (ST.TransStatus = 'Unsettled' AND ST.Location = 'BTA') )

), Bta AS (
    SELECT
    ST.AWOrderID
    ,   ST.TradeID
    ,   COALESCE(CGT.cgtDate, ST.AsAt) AS AsAt
    FROM dbo.ExternallyReceivedScripTransactions AS ST
    LEFT JOIN dbo.ExternallyReceivedCgtTransactions AS CGT ON ST.TransId = CGT.scripTransactionID

    WHERE
        ST.CLAccountID IN (SELECT CLA.ClAccountId FROM #ClAccountIds AS CLA)
    AND ST.TransStatus = 'Settled'
    AND ST.TransType <> 'MFRollFwd'
    AND ST.TransSource = 'Sell Trade'
    AND ST.Location = 'BTA'
    AND ST.Cutover = 0
)
SELECT
    C.Cost AS Cost
,	C.ScripCost
,   C.TransId
,   C.TransDate
,   COALESCE(B.AsAt, C.AsAt) AS AsAt
,   C.CgtDate
,   C.StAsAt
,   C.AsAt AS PriceAsAt
,   C.CLAccountID
,   C.HubAccountId
,   C.LegalEntityTypeId
,   C.Quantity
,   C.InstrumentCode
,   C.TransSource
,   C.CorpActID
,   C.TransType
,   C.FXCost
,   C.CncyCode
,   C.AWOrderID
,   C.AWScripTransferID
,   C.Group1Group2
,   C.TradeId
,   C.Group1
,   C.Group2
,   C.CGTExempt
,   C.CgtTotalValue
,   C.TaxBookStatus
,   C.ExcludeFrom30DayRule
,   C.Location
,   C.IsExternal
,   C.Note
INTO #ScripTransRegistry
FROM Registry C
LEFT JOIN Bta B
    ON C.AWOrderID = B.AWOrderID
    AND C.TradeID = B.TradeID
OPTION (RECOMPILE);

CREATE NONCLUSTERED INDEX idx_ClAccountID ON #ScripTransRegistry (ClAccountID)

-- update to the execution date for equities
;WITH X AS (
	SELECT    
		a.TransID ,
		ST.AsAt ,
		ST.TransDate
	FROM      #ScripTransRegistry a
	INNER JOIN dbo.ExternallyReceivedScripTransactions ST
		ON a.ClAccountID = ST.ClAccountID
		AND a.AWOrderID = ST.AWOrderID
		AND a.InstrumentCode = ST.InstrumentCode
		AND a.AsAt > ST.AsAt
		AND a.Location = 'Registry'
		AND ST.Location = 'BTA'
	WHERE st.ClAccountID IN (SELECT DISTINCT #ScripTransRegistry.CLAccountID FROM #ScripTransRegistry)
)

UPDATE  ST
SET     ST.AsAt = x.AsAt ,
        ST.TransDate = x.TransDate
FROM #ScripTransRegistry ST
INNER JOIN X ON X.TransID = ST.TransID


;WITH Custody AS (
    SELECT
        CASE WHEN CGT.cgtTotalValue IS NOT NULL
                    AND ST.Quantity IS NOT NULL
                    AND ST.Quantity <> 0 THEN CONVERT(DECIMAL(18, 8), ABS(CGT.CgtTotalValue) / ABS(ST.Quantity))

            ELSE ST.COST
        END AS Cost
	,   ST.COST As ScripCost
    ,   ST.TransId
    ,   ST.TransDate
    ,   COALESCE (CGT.cgtDate, ST.AsAt) AS AsAt
    ,   CGT.cgtDate As CgtDate
	,   ST.AsAt As StAsAt
    ,   ST.CLAccountID
    ,   #Accounts.LegalEntityTypeId
    ,   ST.Quantity
    ,   ST.InstrumentCode
    ,   ST.TransSource
    ,   ST.CorpActID
    ,   ST.TransType
    ,   ST.FXCost
    ,   ST.CncyCode
    ,   ST.AWOrderID
    ,   ST.AWScripTransferID
    ,   ST.Group1Group2
    ,   ST.TradeId
    ,   ST.Group1
    ,   ST.Group2
    ,   CGT.CgtExempt AS CgtExempt
    ,   CGT.CgtTotalValue
    ,   CGT.TaxBookStatus
    ,   ST.Note
    ,   CGT.ExcludeFrom30DayRule
    ,   0 AS IsExternal

    FROM dbo.ScripTransactions AS ST
    INNER JOIN #Accounts
        ON #Accounts.ClAccountID = St.CLAccountID

    LEFT JOIN dbo.CgtTransactions AS CGT
        ON ST.TransId = CGT.scripTransactionID

    WHERE
        ST.CLAccountID IN (SELECT CLA.ClAccountId FROM #ClAccountIds AS CLA)
    AND ST.Cutover = 0
    AND ST.TransType <> 'MFRollFwd'
    AND ( (ST.TransStatus = 'Settled' AND ST.Location = 'Custody') OR (ST.TransStatus = 'Unsettled' AND ST.Location = 'BTA') )

), Bta AS (
    SELECT
    ST.AWOrderID
    ,   ST.TradeID
    ,   COALESCE(CGT.cgtDate, ST.AsAt) AS AsAt
    FROM dbo.ScripTransactions AS ST
    LEFT JOIN dbo.CgtTransactions AS CGT ON ST.TransId = CGT.scripTransactionID

    WHERE
        ST.CLAccountID IN (SELECT CLA.ClAccountId FROM #ClAccountIds AS CLA)
    AND ST.TransStatus = 'Settled'
    AND ST.TransType <> 'MFRollFwd'
    AND ST.TransSource IN ('Sell Trade','Buy Trade')
    AND ST.Location = 'BTA'
    AND ST.Cutover = 0
)
SELECT
    C.Cost AS Cost
,   C.ScripCost
,   C.TransId
,   C.TransDate
,   COALESCE(B.AsAt, C.AsAt) AS AsAt
,   C.CgtDate
,   C.StAsAt
,   C.AsAt AS PriceAsAt
,   C.CLAccountID
,   C.LegalEntityTypeId
,   C.Quantity
,   C.InstrumentCode
,   C.TransSource
,   C.CorpActID
,   C.TransType
,   C.FXCost
,   C.CncyCode
,   C.AWOrderID
,   C.AWScripTransferID
,   C.Group1Group2
,   C.TradeId
,   C.Group1
,   C.Group2
,   C.CGTExempt
,   C.CgtTotalValue
,   C.TaxBookStatus
,   C.ExcludeFrom30DayRule
,   C.IsExternal
,   C.Note

INTO #ScripTransCustody
FROM Custody C
LEFT JOIN Bta B
    ON C.AWOrderID = B.AWOrderID
    AND C.TradeID = B.TradeID;



SELECT
    Cost
,   ScripCost
,   TransId
,   TransDate
,   AsAt
,   CgtDate
,   StAsAt
,   PriceAsAt
,   CLAccountID
,	NULL AS 'HubAccountId'
,   LegalEntityTypeId
,   Quantity
,   InstrumentCode
,   TransSource
,   CorpActID
,   TransType
,   FXCost
,   CncyCode
,   AWOrderID
,   AWScripTransferID
,   Group1Group2
,   TradeId
,   Group1
,   Group2
,   CGTExempt
,   CgtTotalValue
,   TaxBookStatus
,   ExcludeFrom30DayRule
,   IsExternal
,   Note
INTO #ScripTrans
FROM #ScripTransCustody
UNION ALL
SELECT
    Cost
,   ScripCost 
,   TransId
,   TransDate
,   AsAt
,   CgtDate
,   StAsAt
,   PriceAsAt
,   CLAccountID
,   HubAccountId
,   LegalEntityTypeId
,   Quantity
,   InstrumentCode
,   TransSource
,   CorpActID
,   TransType
,   FXCost
,   CncyCode
,   AWOrderID
,   AWScripTransferID
,   Group1Group2
,   TradeId
,   Group1
,   Group2
,   CGTExempt
,   CgtTotalValue
,   TaxBookStatus
,   ExcludeFrom30DayRule
,   IsExternal
,   Note
FROM #ScripTransRegistry
UNION ALL
SELECT
    Coalesce(STI.Cost, 0)
,   Coalesce(STI.Cost, 0)
,   0
,   Coalesce(STI.AcquisitionDate, @MigrationDateMinusMigrationOffset)
,   Coalesce(STI.AcquisitionDate, @MigrationDateMinusMigrationOffset)
,   Coalesce(STI.AcquisitionDate, @MigrationDateMinusMigrationOffset)
,   @MigrationDateMinusMigrationOffset
,   @MigrationDateMinusMigrationOffset
,   H.CLAccountID
,   NULL
,   let.LegalEntityTypeId
,   H.Quantity
,   H.InstrumentCode
,   'Impairment'
,   NULL
,   'Impairment'
,   1
,   'GBP'
,   0
,   NULL
,   NULL
,   NULL
,   H.Group1
,   H.Group2
,   0
,   Coalesce(STI.CgtTotalValue,0)
,   STI.TaxBookStatus
,   0
,   1
,   NULL
FROM #HoldingsAsAtMigrationDateMinusMigrationOffset AS H
INNER JOIN Dbo.ClientDetails CD ON H.ClAccountId = CD.CLAccountId
LEFT JOIN Tax.CGT_ScripTransactionsImpairment STI ON H.CLAccountID = STI.ClAccountID AND H.InstrumentCode = STI.InstrumentCode
LEFT JOIN One.Tax.LegalEntityType let
    ON (case when cd.InvestorType='individ' then 'individual' else cd.InvestorType end)=let.LegalEntityType
    AND let.IsSubType = 0
WHERE H.CLAccountID IN (SELECT CLA.ClAccountId FROM #ClAccountIds AS CLA) AND @IncludePreMigrationTransactions = 0
      AND H.Quantity <> 0

CREATE CLUSTERED INDEX #cuix_data ON #ScripTrans (TradeId, AWOrderID)

SELECT
    d.ClAccountID
,	d.HubAccountId
,   d.LegalEntityTypeId
,   d.Cost
,   d.ScripCost
,   d.TransDate
,   d.TransId
,   d.AsAt
,   d.CgtDate
,   d.StAsAt
,   d.PriceAsAt
,   d.Quantity
,   d.InstrumentCode
,   d.TransSource
,   d.CorpActID
,   d.TransType
,   d.FXCost
,   d.CncyCode
,   d.AWOrderID
,   d.AWScripTransferID
,   d.Group1Group2
,   d.TradeId
,   d.Group1
,   d.Group2
,   i.ID InstrumentId
,   i.SecurityType
,   i.SecuritySubType
,   i.DistributorReportingStatus
,   CASE
        WHEN d.IsExternal = 1 THEN eai.TradeDate
        ELSE t.TradeDate
    END AS TradeDate
,   CASE
        WHEN d.IsExternal = 1 THEN eai.Amount
        ELSE tfb.Amount
    END AS AccruedInterest
,   cst.ConversionId
,   d.CgtExempt
,   IsOffshoreFund =
        CAST(
            COALESCE(
                CASE
                    WHEN IP.FundType = 'OffshoreFund' AND IP.ReportingOffshoreFund = 1 AND RP.EffectiveFrom IS NULL THEN 1
                    WHEN IP.FundType = 'OffshoreFund' AND IP.ReportingOffshoreFund = 0 THEN 1
                    ELSE 0
                END
            , 0) AS BIT
        )
,   CAST(CASE WHEN S104.CorpActId IS NOT NULL THEN 1
                ELSE 0
    END AS BIT) AS IsS104CorporateAction
,   D.TaxBookStatus
,   CAST(CASE WHEN S104.CorpActId IS NOT NULL THEN S104.CheckSameDay
              WHEN d.TransSource = 'AccountTransfer' AND d.ExcludeFrom30DayRule = 1 THEN 1
              ELSE 0
    END AS BIT) AS CheckSameDay
,   D.CgtTotalValue
,   D.ExcludeFrom30DayRule
,   D.Note
,   D.IsExternal
,   ARL.NetAmount As IndividualTradingCharge
,   IC.ConversionFactor
INTO #ScripTransWithInsAndTrades
FROM #ScripTrans d
INNER JOIN Res_db.dbo.Instruments i ON i.[Security] = d.InstrumentCode
LEFT JOIN One.Tax.vwS104CorporateActionIds S104 ON S104.CorpActId = d.CorpActId
LEFT JOIN dbo.ConversionScripTransactions cst ON cst.ScripTransactionId = d.TransID
LEFT JOIN Platform.FundConversion.InstrumentConversions IC ON IC.ConversionId = CST.ConversionId
LEFT JOIN dbo.Trades t ON t.Id = d.TradeId AND d.IsExternal = 0
LEFT JOIN dbo.TradesFeesBreakdown tfb ON  t.Id = tfb.TradeId AND tfb.Description = 'AccruedInterest'
LEFT JOIN dbo.ExternallyReceivedAccruedInterest eai ON eai.TradeId = d.TradeId AND d.IsExternal = 1
LEFT JOIN One.Tax.HmrcFundReportingStatusEffectivePeriod RP ON RP.InstrumentId = I.ID AND d.AsAt BETWEEN ISNULL(RP.EffectiveFrom, '1900-01-01') AND ISNULL(RP.EffectiveTo, GETDATE())
LEFT JOIN Res_DB.dbo.InstrumentProperties IP ON IP.InstrumentCode = I.Security
LEFT JOIN Discovery.Dbo.AdvisorRevenueLedger ARL ON t.Orderid = ARL.Orderid AND ARL.TranType in ('BuyTransactionCharge','SellTransactionCharge','RegularBuyTransactionCharge','RegularSellTransactionCharge')
												 AND ARL.GLPosted = 'Yes' AND ARL.Reversed = 0 AND ARL.[Status] in (select FeeStatusId from Discovery.Dbo.FeeStatus where Status = 'Posted')
WHERE NOT EXISTS (
    SELECT 1
    FROM res_db.dbo.Bonds b
    WHERE b.bond_code = d.InstrumentCode
    AND BondType = 'Gilt')
	AND (IP.WrapProvider IS NULL OR IP.WrapProvider = 'UKW');

WITH TransactionFromTaxableAccount_CTE AS
(
	SELECT
		STWIAT.TransID,
		ROW_NUMBER() OVER (PARTITION BY STWIAT.TransId ORDER BY ContraST.TransId DESC) AS RowNo,
		CASE
			WHEN PWT.ProductWrapperTypeId = 3 THEN -- PersonalPortfolio
				0
			ELSE
				1
		END AS 'IsTransactionFromNonTaxableAccount'
	FROM #ScripTransWithInsAndTrades AS STWIAT
	INNER JOIN dbo.ScripTransactions AS ContraST
		ON ContraST.InstrumentCode = STWIAT.InstrumentCode AND
		ContraST.AWScripTransferID = STWIAT.AWScripTransferID AND
		- ContraST.Quantity = STWIAT.Quantity
	INNER JOIN Discovery.dbo.ProductDetails AS PD
		ON PD.ClAccountid = ContraST.CLAccountID
	INNER JOIN [Platform].ProductWrappers.ProductWrapperTypes AS PWT
		ON PWT.ProductType = PD.ProductType
	WHERE
		STWIAT.AWScripTransferID > 0 AND
		ContraST.TransStatus = 'Settled'
)


SELECT TFTAC.TransID, TFTAC.IsTransactionFromNonTaxableAccount
INTO #TransactionFromTaxableAccount
FROM TransactionFromTaxableAccount_CTE AS TFTAC
WHERE TFTAC.RowNo = 1

CREATE UNIQUE CLUSTERED INDEX cuidx_TransId ON #TransactionFromTaxableAccount (TransId)

SELECT
	STWIAT.TransID,
	1 AS 'IsTransactionFromJointToSole'
INTO #SameOwnerTransactionFromJointToSole
FROM #ScripTransWithInsAndTrades AS STWIAT
INNER JOIN dbo.SEClientAccount AS SECA
	ON SECA.ClAccountID = STWIAT.ClAccountID
INNER JOIN dbo.ScripTransactions AS ContraST
	ON ContraST.InstrumentCode = STWIAT.InstrumentCode AND
	ContraST.AWScripTransferID = STWIAT.AWScripTransferID 
INNER JOIN dbo.SEClientAccount AS ContraSECA
	ON ContraSECA.ClAccountID = ContraST.ClAccountID
WHERE
	ContraSECA.InvestorType IN ('JOINT_INDIVIDUAL','Joint') AND
	SECA.InvestorType IN ('INDIVIDUAL','INDIVID') AND
	STWIAT.TransType = 'Same Owner'

CREATE UNIQUE CLUSTERED INDEX cuidx_TransId ON #SameOwnerTransactionFromJointToSole (TransId)

SELECT  s.Security, s.O, s.Date
INTO #Prices
FROM Res_DB.dbo.Securities s
WHERE s.Security IN (
    SELECT DISTINCT d.CncyCode + 'USD'
    FROM #ScripTransWithInsAndTrades d
    UNION ALL
    SELECT @BaseCCY + 'USD'
)
AND s.Date IN (
    SELECT DISTINCT DATEADD(dd, 0 , (DATEDIFF( dd, 0, d.PriceAsAt)))
    FROM #ScripTransWithInsAndTrades d )

CREATE UNIQUE CLUSTERED INDEX cuidx_SecurityDate ON #Prices (Security, Date)


SELECT mf.InstrumentCode, IncomeAccumulation
INTO #MF
FROM Res_db.dbo.ManagedFunds mf
WHERE mf.InstrumentCode IN (
    SELECT DISTINCT d.InstrumentCode
    FROM #ScripTransWithInsAndTrades d
)

CREATE UNIQUE CLUSTERED INDEX cuidx_InstrumentCode ON #MF (InstrumentCode)

SELECT
	d.ClAccountID
,	d.HubAccountId
,   d.LegalEntityTypeId
,   COALESCE(META.UnitCost, d.Cost) AS Cost
,   COALESCE(d.ScripCost, 0) As ScripCost
,   d.TransDate
,   d.TransId
,   COALESCE(META.AcquisitionDate ,d.AsAt) AS AsAt
,   d.CgtDate
,   d.StAsAt
,   COALESCE(META.Quantity, d.Quantity) AS Quantity
,   d.InstrumentCode
,   d.TransSource
,   d.CorpActID
,   CASE	-- SELECT CgtCostToTransfereeReasonId FROM ClientAccount.Tax.CgtCostToTransfereeReasonTypes
		WHEN META.CostToTransfereeReasonId in (1,2) THEN
			'Different Owner'
		WHEN META.CostToTransfereeReasonId = 3 THEN
			'Deceased Inheritance'
		ELSE
			d.TransType
	END AS TransType
,   d.FXCost
,   CASE
        WHEN D.CgtTotalValue IS NOT NULL THEN 1
        WHEN D.CncyCode = 'USD' THEN IIF(d.FXCost IS NULL OR d.FxCost = 1, S2.o, d.FxCost)
        WHEN S1.o IS NULL THEN 1
    ELSE
        IIF(d.FXCost IS NULL OR d.FxCost = 1,Cast(S2.o AS FLOAT(53)) / Cast(S1.o AS FLOAT(53)), d.FxCost)
    END AS CgtFxRate
,   d.CncyCode
,   d.AWOrderID
,   d.AWScripTransferID
,   CAST(TFTAT.IsTransactionFromNonTaxableAccount AS BIT) AS 'IsTransactionFromNonTaxableAccount'
,	CAST(SOTFJTS.IsTransactionFromJointToSole AS BIT) AS 'IsTransactionFromJointToSole'
,   d.Group1Group2
,   d.TradeId
,   d.Group1
,   COALESCE(META.Quantity, d.Group2) AS Group2
,   d.InstrumentId
,   d.SecurityType
,   d.SecuritySubType
,   d.DistributorReportingStatus
,   mf.IncomeAccumulation
,   d.TradeDate
,   d.AccruedInterest
,   d.ConversionId
,   COALESCE(META.CgtExempt, d.CgtExempt) AS CgtExempt
,   D.IsOffshoreFund
,   IsRelevantSecurity =
        CAST(
            CASE
                WHEN TPT.TaxParcelTypeId IS NOT NULL AND TPT2.TaxParcelTypeId IS NULL THEN 1
                WHEN TPT2.TaxParcelTypeId IS NOT NULL AND RP.EffectiveFrom IS NULL THEN 1
                ELSE 0
            END AS BIT
        )
,   D.IsS104CorporateAction
,   D.TaxBookStatus
,   D.CheckSameDay
,   COALESCE(~META.S104Acquisition, D.ExcludeFrom30DayRule) AS ExcludeFrom30DayRule
,   D.IsExternal
,   D.Note
,   D.IndividualTradingCharge
,   D.ConversionFactor
FROM #ScripTransWithInsAndTrades d
	LEFT JOIN #MF mf ON mf.InstrumentCode = d.InstrumentCode
	LEFT JOIN #Prices S1 ON S1.Security = d.CncyCode + 'USD' AND S1.Date = DATEADD(dd, 0 , (DATEDIFF( dd, 0, d.PriceAsAt))) AND d.CncyCode <> @BaseCCY
	LEFT JOIN #Prices S2 ON S2.Security = @BaseCCY + 'USD' AND S2.Date = DATEADD(dd, 0 , (DATEDIFF( dd, 0, d.PriceAsAt)))
	LEFT JOIN One.Tax.ProductClassification PC ON PC.ProductClassification = d.SecuritySubType
	LEFT JOIN One.Tax.ProductClassificationTaxRule PCTR ON PCTR.ProductClassificationID = PC.ProductClassificationID AND PCTR.JurisdictionID = 61
	LEFT JOIN One.Tax.ProductTaxRulesUK PTR ON PTR.ProductTaxRuleID = PCTR.ProductTaxRuleID
	LEFT JOIN One.Tax.TaxParcelType TPT ON TPT.TaxParcelTypeId = PTR.TaxParcelTypeId AND TPT.TaxParcelType = 'RelevantSecurity'
	LEFT JOIN One.Tax.ProductTaxRuleException PTRE ON PTRE.InstrumentCode = d.InstrumentCode AND PTRE.JurisdictionID = 61
	LEFT JOIN One.Tax.ProductTaxRulesUK PTR2 ON PTR2.ProductTaxRuleID = PTRE.ProductTaxRuleID
	LEFT JOIN One.Tax.TaxParcelType TPT2 ON TPT2.TaxParcelTypeId = PTr2.TaxParcelTypeID AND TPT2.TaxParcelType = 'RelevantSecurity'
	LEFT JOIN One.Tax.HmrcFundReportingStatusEffectivePeriod RP ON RP.InstrumentId = d.InstrumentID AND d.AsAt BETWEEN ISNULL(RP.EffectiveFrom, '1900-01-01') AND ISNULL(RP.EffectiveTo, GETDATE())
	LEFT JOIN #TransactionFromTaxableAccount AS TFTAT ON TFTAT.TransId = d.TransId
	LEFT JOIN #SameOwnerTransactionFromJointToSole AS SOTFJTS ON SOTFJTS.TransId = d.TransId
	LEFT JOIN Tax.MoveEntitlementsTransactionApportionment AS META ON META.ScripTransactionId = d.TransId
	LEFT JOIN Tax.CGT_ScripTransactionsImpairment AS STI ON STI.CLAccountID = D.ClAccountID AND STI.InstrumentCode = d. InstrumentCode
WHERE
	(d.StAsAt >= @MigrationDateMinusMigrationOffset OR @MigrationDateMinusMigrationOffset IS NULL OR @IncludePreMigrationTransactions = 1)	 	
ORDER BY d.TransDate ASC;

DROP TABLE #TransactionFromTaxableAccount
DROP TABLE #SameOwnerTransactionFromJointToSole
DROP TABLE #MF
DROP TABLE #Prices
DROP TABLE #ScripTransWithInsAndTrades
DROP TABLE #ScripTrans;
DROP TABLE #Accounts
DROP TABLE #ClAccountIds;
DROP TABLE #ScripTransRegistry
DROP TABLE #ScripTransCustody
DROP TABLE #HoldingsAsAtMigrationDateMinusMigrationOffset

