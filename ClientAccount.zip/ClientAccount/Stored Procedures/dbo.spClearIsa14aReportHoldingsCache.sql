/*
<StoredProcedure>
    <Description>Clear staging table for ISA Statistical Report.</Description>
</StoredProcedure>
*/

CREATE PROCEDURE [dbo].[spClearIsa14aReportHoldingsCache]
AS

    DELETE FROM dbo.Isa14aReportHoldingsCache;

GO
