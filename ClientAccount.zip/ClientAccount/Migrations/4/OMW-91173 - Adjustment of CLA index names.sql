



EXEC ClientAccount.SchemaMigration.spRenameIndex @Schema = N'dbo', -- nvarchar(128)
    @Table = N'CashLedgerAdjustment', -- nvarchar(128)
    @OldIndexName = N'idx_Search', -- nvarchar(128)
    @NewIndexName = N'idx_ClAccountIDLedgerDatePortfolioAdjustAvailableAdjust' -- nvarchar(128)



EXEC ClientAccount.SchemaMigration.spRenameIndex @Schema = N'dbo', -- nvarchar(128)
    @Table = N'CashLedgerAdjustment', -- nvarchar(128)
    @OldIndexName = N'idx_LedgerDateClAccountId', -- nvarchar(128)
    @NewIndexName = N'idx_LedgerDateClAccountIdCcyCodePortfolioAdjustAdjustmentType' -- nvarchar(128)
