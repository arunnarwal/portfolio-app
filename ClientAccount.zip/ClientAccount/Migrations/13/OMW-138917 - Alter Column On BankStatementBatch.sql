/*
 * Author: Jerry Jiang
 * Date: 2023-9-22
 * Issue: OMW-138917
 * Description: Migration of table BankStatementBatch -- rebuild constraint
 */

DECLARE @SchemaName AS SYSNAME = 'dbo'
DECLARE @TableName AS SYSNAME = 'BankStatementBatch'
DECLARE @ColumnName_DateAdded AS SYSNAME = 'DateAdded'
DECLARE @ColumnName_TotalDebit AS SYSNAME = 'TotalDebit'
DECLARE @ColumnName_TotalCredit AS SYSNAME = 'TotalCredit'
DECLARE @ColumnName_OpenBal AS SYSNAME = 'OpenBal'
DECLARE @ColumnName_LedgerBal AS SYSNAME = 'LedgerBal'

-- 1. For column DateAdded
IF EXISTS (
    SELECT 1 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_SCHEMA = @SchemaName AND TABLE_NAME = @TableName AND COLUMN_NAME = @ColumnName_DateAdded
)
BEGIN    
    -- Drop any existing indexes
    EXEC SchemaMigration.spDropIndexesAndConstraintsContainingColumn 
        @Schema = @SchemaName,
        @Table = @TableName,
        @Column = @ColumnName_DateAdded
    
    -- Alter column
    -- No data change needed as changing from DATETIME to DATETIME2 (3) will not cause data loss
    ALTER TABLE dbo.BankStatementBatch ALTER COLUMN [DateAdded] DATETIME2 (3)
END

-- 2. For column TotalDebit
IF EXISTS (
    SELECT 1 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_SCHEMA = @SchemaName AND TABLE_NAME = @TableName AND COLUMN_NAME = @ColumnName_TotalDebit
)
BEGIN    
    -- Drop any existing indexes
    EXEC SchemaMigration.spDropIndexesAndConstraintsContainingColumn 
        @Schema = @SchemaName,
        @Table = @TableName,
        @Column = @ColumnName_TotalDebit
    
    -- Alter column
    -- No data change needed as changing from MONEY to DECIMAL (19,4) will not cause data loss
    ALTER TABLE dbo.BankStatementBatch ALTER COLUMN [TotalDebit] DECIMAL (19,4)
END

-- 3. For column TotalCredit
IF EXISTS (
    SELECT 1 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_SCHEMA = @SchemaName AND TABLE_NAME = @TableName AND COLUMN_NAME = @ColumnName_TotalCredit
)
BEGIN    
    -- Drop any existing indexes
    EXEC SchemaMigration.spDropIndexesAndConstraintsContainingColumn 
        @Schema = @SchemaName,
        @Table = @TableName,
        @Column = @ColumnName_TotalCredit
    
    -- Alter column
    -- No data change needed as changing from MONEY to DECIMAL (19,4) will not cause data loss
    ALTER TABLE dbo.BankStatementBatch ALTER COLUMN [TotalCredit] DECIMAL (19,4)
END

-- 4. For column OpenBal
IF EXISTS (
    SELECT 1 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_SCHEMA = @SchemaName AND TABLE_NAME = @TableName AND COLUMN_NAME = @ColumnName_OpenBal
)
BEGIN    
    -- Drop any existing indexes
    EXEC SchemaMigration.spDropIndexesAndConstraintsContainingColumn 
        @Schema = @SchemaName,
        @Table = @TableName,
        @Column = @ColumnName_OpenBal
    
    -- Alter column
    -- No data change needed as changing from MONEY to DECIMAL (19,4) will not cause data loss
    ALTER TABLE dbo.BankStatementBatch ALTER COLUMN [OpenBal] DECIMAL (19,4)
END

-- 5. For column LedgerBal
IF EXISTS (
    SELECT 1 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_SCHEMA = @SchemaName AND TABLE_NAME = @TableName AND COLUMN_NAME = @ColumnName_LedgerBal
)
BEGIN    
    -- Drop any existing indexes
    EXEC SchemaMigration.spDropIndexesAndConstraintsContainingColumn 
        @Schema = @SchemaName,
        @Table = @TableName,
        @Column = @ColumnName_LedgerBal
    
    -- Alter column
    -- No data change needed as changing from MONEY to DECIMAL (19,4) will not cause data loss
    ALTER TABLE dbo.BankStatementBatch ALTER COLUMN [LedgerBal] DECIMAL (19,4)
END

GO

