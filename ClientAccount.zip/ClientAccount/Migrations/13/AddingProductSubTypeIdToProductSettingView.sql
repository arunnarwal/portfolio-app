--Adding ProductSubTypeId to prevent x-db dependancy sync errors
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = object_id('ClientAccount.dbo.vwProductSettings') AND Name = 'ProductSubTypeId')
SET NOEXEC ON
	
GO

ALTER VIEW [dbo].[vwProductSettings] AS  
SELECT 
  p1.Product,   
  C.WrapProvider,  
  C.Company,
  p1.ProductUsage,  
  p1.ProductType As SystemLevelProductType,
  COALESCE (p3.DisplayName,net.displayname,p2.DisplayName,p1.DisplayName) AS DisplayName,  
  COALESCE (p3.ExtendedDisplayName,net.ExtendedDisplayName, p2.ExtendedDisplayName, p1.ExtendedDisplayName) AS ExtendedDisplayName,  
  COALESCE (p3.AllowTransfers,net.AllowTransfers,p2.AllowTransfers,p1.AllowTransfers) AS AllowTransfers,  
  COALESCE (p3.AllowContributions,net.AllowContributions,p2.AllowContributions,p1.AllowContributions) AS AllowContributions,  
  COALESCE (p3.Include,net.Include,p2.Include,p1.Include) AS Include,  
  COALESCE (p3.SortOrder,net.SortOrder,p2.SortOrder,p1.SortOrder) AS SortOrder,  
  COALESCE (p3.NewBusiness,net.NewBusiness,p2.NewBusiness,p1.NewBusiness) AS NewBusiness,  
  COALESCE (p3.WizardProductName,net.WizardProductName,p2.WizardProductName,p1.WizardProductName) AS WizardProductName,  
  COALESCE (p3.StyleClassSuffix,net.StyleClassSuffix,p2.StyleClassSuffix,p1.StyleClassSuffix) AS StyleClassSuffix,  
  COALESCE (p3.ClientType,net.ClientType,p2.ClientType,p1.ClientType) AS ClientType,    
  coalesce(p3.SubAccountType,net.SubAccountType,p2.SubAccountType,p1.SubAccountType) as SubAccountType,  
  coalesce(p3.ProductType,net.ProductType,p2.ProductType,p1.ProductType) as ProductType,  
  coalesce(p3.productHTML,net.productHTML,p2.productHTML,p1.productHTML) as productHTML,  
  coalesce(p3.isActive,net.isActive,p2.isActive,p1.isActive) as isActive,  
  coalesce(p3.ProductSubscriptionLimit,net.ProductSubscriptionLimit,p2.ProductSubscriptionLimit,p1.ProductSubscriptionLimit) as ProductSubscriptionLimit,  
  coalesce(p3.ProductSubcriptionLimitFor50AndOver,net.ProductSubcriptionLimitFor50AndOver,p2.ProductSubcriptionLimitFor50AndOver,p1.ProductSubcriptionLimitFor50AndOver) as ProductSubcriptionLimitFor50AndOver,  
  coalesce(p3.CombinedSubscriptionLimit,net.CombinedSubscriptionLimit,p2.CombinedSubscriptionLimit,p1.CombinedSubscriptionLimit) as CombinedSubscriptionLimit,  
  coalesce(p3.cancellationNoticeOn,net.cancellationNoticeOn,p2.cancellationNoticeOn,p1.cancellationNoticeOn) as cancellationNoticeOn,  
  coalesce(p3.ISANBDeclarationOn,net.ISANBDeclarationOn,p2.ISANBDeclarationOn,p1.ISANBDeclarationOn) as ISANBDeclarationOn,  
  coalesce(p3.AllowMultipleProductWrappers,net.AllowMultipleProductWrappers,p2.AllowMultipleProductWrappers,p1.AllowMultipleProductWrappers) As AllowMultipleProductWrappers,  
  COALESCE (p3.AllowQuoteAndDeal,net.AllowQuoteAndDeal,p2.AllowQuoteAndDeal,p1.AllowQuoteAndDeal) as  AllowQuoteAndDeal,
  COALESCE (p3.AllowTransfersOn,net.AllowTransfersOn,p2.AllowTransfersOn,p1.AllowTransfersOn) as  AllowTransfersOn,
  COALESCE (p3.RestrictPaymentsOut,net.RestrictPaymentsOut,p2.RestrictPaymentsOut,p1.RestrictPaymentsOut) as  RestrictPaymentsOut,
  COALESCE(p3.Id, p2.Id, p1.Id) As ProductSettingId,
  12 AS ProductSubTypeId, --COALESCE(p3.ProductSubTypeId,net.ProductSubTypeId,p2.ProductSubTypeId,p1.ProductSubTypeId) AS ProductSubTypeId,
  '' AS ProductWrapperSubTypeName
FROM    
   dbo.vwCompany C   
   LEFT OUTER JOIN dbo.ProductSettings AS p1 ON p1.Type = 'System' AND p1.Name = C.SystemProvider   
   LEFT OUTER JOIN dbo.ProductSettings AS p2 ON p2.Product = p1.Product AND p2.Type = 'WP' AND p2.Name = C.WrapProvider AND p2.ProductUsage = p1.ProductUsage   
   LEFT OUTER JOIN dbo.ProductSettings AS p3 ON p3.Product = p1.Product AND p3.Type = 'Company' AND p3.Name = C.Company AND p3.ProductUsage = p1.ProductUsage  
   LEFT OUTER JOIN dbo.ProductSettings AS net ON net.Product = p1.Product AND net.Type = 'Network' AND net.Name = C.Network AND net.ProductUsage = p1.ProductUsage
   --LEFT JOIN Platform.ProductWrappers.ProductWrapperSubTypes AS PWST ON PWST.ProductWrapperSubTypeId = COALESCE(p3.ProductSubTypeId,net.ProductSubTypeId,p2.ProductSubTypeId,p1.ProductSubTypeId)
WHERE   
   p1.Type = 'System' 
GO

SET NOEXEC OFF