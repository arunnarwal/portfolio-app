--Adding FCAStatus to prevent x-db dependancy sync errors
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = object_id('ClientAccount.dbo.vwAdvisor') AND Name = 'FCAStatus')
SET NOEXEC ON

GO
ALTER VIEW [dbo].[vwAdvisor] AS

SELECT
	SP.SystemProvider,
	WP.WrapProvider,
	WP.Id AS WrapProviderId,
	WP.ProviderName,
	CO.Id AS CompanyId,
	CO.Company,
	CO.CompanyName,
	CO.Network,
	CO.FSAAuthorisationNumber AS CompanyFSAAuthorisationNumber,
	CO.DefaultAdvisorCode,
	NET.ID AS NetworkID,
	NET.NetworkName,
	BR.SubCompanyName,
	BR.BranchName,
	BR.BranchID,
	ADV.AdvCode,
	ADV.Id AS AdvisorId,
	TBLC.ClientID,
	TBLC.FirstName,
	TBLC.Surname,
	ADV.Name,
	ADV.LastModified,
	ADV.Location,
	ADV.DateCreated,
	ADV.SyncSource,
	ADV.SyncStatus,
	ADV.LastSynchronised,
	ADV.Title,
	ADV.IsActive,
	ADV.Phone,
	ADV.CashValidation,
	ADV.ScripValidation,
	ADV.INGAdvCode,
	ADV.CompanyAdvCode,
	ADV.SSSUserID,
	ADV.SecuritySetupProcessed,
	ADV.BankAccountCCYCode,
	ADV.BankAccountNo,
	ADV.TaxID,
	ADV.FSAAuthorisationNumber,
	ADV.DateSync,
	ADV.EmailAddress,
	COALESCE(NULLIF(ADV.Address1,''), COADD.Address1, NA.StreetNumber) AS Address1,
	COALESCE(NULLIF(ADV.Address2,''), COADD.Address2, NA.BuildingName) AS Address2,
	COALESCE(NULLIF(ADV.Address3,''), COADD.Address3, NA.StreetName) AS Address3,
	COALESCE(NULLIF(ADV.Address4,''), COADD.Address4, NA.TownCity) AS Address4,
	COALESCE(NULLIF(ADV.PostCode,''), COADD.PostCode, NA.PostCode) AS PostCode,
	COALESCE(BR.WMCode, CO.WMCode) AS WMCode,
	UTG.UserGroupID,
	CASE
		WHEN CO.Company = WP.DefaultCompany AND ADV.AdvCode = CO.DefaultAdvisorCode THEN 1		
		ELSE 0	
	END AS IsDefault,
	'' AS FCAStatus
FROM dbo.SystemProvider SP
INNER JOIN dbo.WrapProvider WP 
	ON WP.SystemProvider = SP.SystemProvider
INNER JOIN dbo.Company CO 
	ON CO.WrapProvider = WP.WrapProvider
INNER JOIN dbo.Advisor ADV	
	ON ADV.Company = CO.Company
LEFT JOIN dbo.Address COADD 
	ON CO.Company = COADD.OwnerName 
	AND COADD.Context = 'Default' 
	AND COADD.OwnerType = 'Company' 
	AND AddressNumber = 1
LEFT JOIN dbo.Network NET	
	ON CO.Network = NET.Network 
LEFT JOIN dbo.vwBranch BR 
	ON ADV.BranchID = BR.BranchID
LEFT JOIN ClientDB3.dbo.TBLClients TBLC 
	ON ADV.AdvCode = TBLC.AdvCode
LEFT JOIN WebDB.dbo.UsersToGroups UTG
	ON UTG.ClientID = TBLC.ClientID
LEFT JOIN [Platform].[Communication].[Address] NA 
	ON NET.ID = NA.EntityValue AND NA.EntityTypeId = 4 /* ID from enum HierarchyLevelName */

GO

SET NOEXEC OFF
