/*
	author: lisa.wang
	desc: OMW-127400 - Bed & ISA - missing new columns for subaccounts (historical data migration)
*/

USE ClientAccount
GO

DECLARE @SchemaName SYSNAME = 'dbo'
DECLARE @TableName SYSNAME = 'BedAndIsa'
DECLARE @ColumnName SYSNAME = 'SourceSubClAccountID'

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = @SchemaName AND TABLE_NAME = @TableName AND COLUMN_NAME = @ColumnName)
BEGIN
    EXEC('ALTER TABLE dbo.BedAndIsa ADD SourceSubClAccountID VARCHAR (50) NULL')

    EXEC('UPDATE A SET A.SourceSubClAccountId = ISNULL(B.ClAccountId, '''')
		FROM ClientAccount..BedAndIsa A
		LEFT JOIN ClientAccount..BedAndProductDisinvestmentStrategy B ON A.BedAndIsaId = B.BedAndIsaId
		WHERE A.SourceSubClAccountId IS NULL')

    EXEC('ALTER TABLE dbo.BedAndIsa ALTER COLUMN SourceSubClAccountID VARCHAR (50) NOT NULL')
END


SET @ColumnName = 'TargetSubClAccountID'

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = @SchemaName AND TABLE_NAME = @TableName AND COLUMN_NAME = @ColumnName)
BEGIN
    EXEC('ALTER TABLE dbo.BedAndIsa ADD TargetSubClAccountID VARCHAR (50) NULL')

    EXEC('UPDATE A SET A.TargetSubClAccountId = ISNULL(B.ClAccountId, '''')
		FROM ClientAccount..BedAndIsa A
		LEFT JOIN ClientAccount..BedAndProductInvestmentStrategy B ON A.BedAndIsaId = B.BedAndIsaId
		WHERE A.TargetSubClAccountId IS NULL')

    EXEC('ALTER TABLE dbo.BedAndIsa ALTER COLUMN TargetSubClAccountID VARCHAR (50) NOT NULL')
END


SET @TableName = 'BedAndProductCompletion'
SET @ColumnName = 'SourceSubClAccountID'

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = @SchemaName AND TABLE_NAME = @TableName AND COLUMN_NAME = @ColumnName)
BEGIN
    EXEC('ALTER TABLE dbo.BedAndProductCompletion ADD SourceSubClAccountID VARCHAR (50) NULL')

    EXEC('UPDATE A SET A.SourceSubClAccountID = ISNULL(B.ClAccountId, '''')
		FROM ClientAccount..BedAndProductCompletion A
		LEFT JOIN ClientAccount..BedAndProductDisinvestmentStrategy B ON A.BedAndIsaId = B.BedAndIsaId
		WHERE A.SourceSubClAccountID IS NULL')

    EXEC('ALTER TABLE dbo.BedAndProductCompletion ALTER COLUMN SourceSubClAccountID VARCHAR (50) NOT NULL')
END


SET @ColumnName = 'TargetSubClAccountID'

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = @SchemaName AND TABLE_NAME = @TableName AND COLUMN_NAME = @ColumnName)
BEGIN
    EXEC('ALTER TABLE dbo.BedAndProductCompletion ADD TargetSubClAccountID VARCHAR (50) NULL')

    EXEC('UPDATE A SET A.TargetSubClAccountId = ISNULL(B.ClAccountId, '''')
		FROM ClientAccount..BedAndProductCompletion A
		LEFT JOIN ClientAccount..BedAndProductInvestmentStrategy B ON A.BedAndIsaId = B.BedAndIsaId
		WHERE A.TargetSubClAccountId IS NULL')

    EXEC('ALTER TABLE dbo.BedAndProductCompletion ALTER COLUMN TargetSubClAccountID VARCHAR (50) NOT NULL')
END