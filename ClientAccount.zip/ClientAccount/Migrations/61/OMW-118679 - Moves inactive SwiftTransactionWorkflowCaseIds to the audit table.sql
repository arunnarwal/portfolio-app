-- If the mapping table exists
IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'SwiftTransactionTransferWorkflowCaseMapping')
BEGIN
	-- If the audit table hasn't been created yet
	IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'SwiftTransactionTransferWorkflowCaseMappingAudit')
	BEGIN
		--Create the audit table
		EXEC('CREATE TABLE [dbo].[SwiftTransactionTransferWorkflowCaseMappingAudit] (	
		SwiftTransactionTransferWorkflowCaseMappingAuditId INT NOT NULL IDENTITY(1, 1),
		SwiftTransactionId INT NOT NULL,
		TransferWorkflowCaseId INT NOT NULL,
		DateTimeAdded DATETIME2(3) NOT NULL,
		DateTimeRemoved DATETIME2(3) NOT NULL);')
	END

	-- Keep record of all mapping entries to be moved to the audit table
	CREATE TABLE #ToBeAddedToAuditTable (
		TransferWorkflowCaseId INT NOT NULL,
		SwiftTransactionId INT NOT NULL,
		DateTimeAdded DATETIME2(3) NOT NULL);

	-- We will be searching on ids later so adding an index
	EXEC('CREATE NONCLUSTERED INDEX IDX_TransferWorkflowCaseIdSwiftTransactionId ON #ToBeAddedToAuditTable ([TransferWorkflowCaseId],[SwiftTransactionId]);')

	 -- Mark out duplicate mappings only keeping the latest
		EXEC('INSERT INTO #ToBeAddedToAuditTable
				SELECT M.TransferWorkflowCaseId , M.SwiftTransactionId, M.DateTimeAdded
				FROM [dbo].[SwiftTransactionTransferWorkflowCaseMapping] M
					WHERE M.DateTimeAdded <> 
						(SELECT MAX(MS.DateTimeAdded) FROM [dbo].[SwiftTransactionTransferWorkflowCaseMapping] MS WHERE MS.TransferWorkflowCaseId = M.TransferWorkflowCaseId);')

	-- Fill all of the values from the marking table
	EXEC('INSERT INTO [dbo].[SwiftTransactionTransferWorkflowCaseMappingAudit]
	(
		[SwiftTransactionId],
		[TransferWorkflowCaseId],
		[DateTimeAdded],
		[DateTimeRemoved]
	)
	SELECT M.SwiftTransactionId, M.TransferWorkflowCaseId, M.DateTimeAdded, GETDATE()
	FROM #ToBeAddedToAuditTable M;')
 
	--Delete all the marked mappings from the main mapping table
	EXEC('DELETE M FROM [dbo].[SwiftTransactionTransferWorkflowCaseMapping] M INNER JOIN #ToBeAddedToAuditTable AT ON AT.TransferWorkflowCaseId = M.TransferWorkflowCaseId AND AT.SwiftTransactionId = M.SwiftTransactionId;')
END