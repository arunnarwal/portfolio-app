/*
	author: lisa.wang
	desc: OMW-127400 - Bed & ISA - missing new columns for subaccounts (rename default constraints)
*/

USE ClientAccount
GO

IF EXISTS (SELECT 1 FROM sys.default_constraints WHERE parent_object_id = object_id('dbo.BedAndIsa'))
BEGIN
	EXEC SchemaMigration.spDropConstraintsContainingColumn 'dbo', 'BedAndIsa', 'IsFullSubscription'
	EXEC SchemaMigration.spDropConstraintsContainingColumn 'dbo', 'BedAndIsa', 'Amount'
	EXEC SchemaMigration.spDropConstraintsContainingColumn 'dbo', 'BedAndIsa', 'DisinvestmentStrategy'
	EXEC SchemaMigration.spDropConstraintsContainingColumn 'dbo', 'BedAndIsa', 'IsTaxYearEndCase'
END
GO

ALTER TABLE dbo.BedAndIsa ADD CONSTRAINT [DF_BedAndIsa_IsFullSubscription] DEFAULT(0) FOR IsFullSubscription
ALTER TABLE dbo.BedAndIsa ADD CONSTRAINT [DF_BedAndIsa_Amount] DEFAULT(0) FOR Amount
ALTER TABLE dbo.BedAndIsa ADD CONSTRAINT [DF_BedAndIsa_DisinvestmentStrategy] DEFAULT('Automated') FOR DisinvestmentStrategy
ALTER TABLE dbo.BedAndIsa ADD CONSTRAINT [DF_BedAndIsa_IsTaxYearEndCase] DEFAULT(0) FOR IsTaxYearEndCase
GO

IF EXISTS (SELECT 1 FROM sys.default_constraints WHERE parent_object_id = object_id('dbo.BedAndProductCompletion'))
BEGIN
	EXEC SchemaMigration.spDropConstraintsContainingColumn 'dbo', 'BedAndProductCompletion', 'DisinvestmentStrategy'
END
GO

ALTER TABLE dbo.BedAndProductCompletion ADD CONSTRAINT [DF_BedAndProductCompletion_DisinvestmentStrategy] DEFAULT('Automated') FOR DisinvestmentStrategy
GO