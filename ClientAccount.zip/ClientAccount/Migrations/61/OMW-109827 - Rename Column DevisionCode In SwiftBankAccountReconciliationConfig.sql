EXEC SchemaMigration.spRenameColumn @Schema = 'Banking',
                                    @Table = 'SwiftBankAccountReconciliationConfig',
                                    @OldColumnName = 'DivisionCode',
                                    @NewColumnName = 'DivisionCode1'