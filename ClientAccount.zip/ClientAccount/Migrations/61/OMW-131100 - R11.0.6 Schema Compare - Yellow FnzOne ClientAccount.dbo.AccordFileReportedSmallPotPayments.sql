/***
    Auther : Lungelo Nkosi
	Description: Added default constraints on dbo.AccordFileReportedSmallPotPayments for DateAdded Column
***/

USE ClientAccount
GO

IF EXISTS (SELECT 1 FROM sys.default_constraints WHERE parent_object_id = object_id('dbo.AccordFileReportedSmallPotPayments'))
BEGIN
	EXEC SchemaMigration.spDropConstraintsContainingColumn 'dbo', 'AccordFileReportedSmallPotPayments', 'DateAdded'

END
GO
ALTER TABLE dbo.AccordFileReportedSmallPotPayments ADD CONSTRAINT [DF_AccordFileReportedSmallPotPayments_DateAdded] DEFAULT GETDATE() FOR DateAdded
GO

