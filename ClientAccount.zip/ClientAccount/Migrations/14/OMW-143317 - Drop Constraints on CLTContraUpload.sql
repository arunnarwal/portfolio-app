/*
 * Author: Jerry Jiang
 * Date: 2023-9-27
 * Issue: OMW-143317
 * Description: Drop original constraints from ClientAccount.dbo.CashLedgerTransContraUpload
 */

DECLARE @SchemaName AS NVARCHAR(128) = 'dbo'
DECLARE @TableName AS NVARCHAR(128) = 'CashLedgerTransContraUpload'
DECLARE @DateAdded AS NVARCHAR(128) = 'DateAdded'

DECLARE @ColumnName AS NVARCHAR(128)

SET @ColumnName = @DateAdded
IF EXISTS (
    SELECT 1
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE 
        TABLE_SCHEMA = @SchemaName 
        AND TABLE_NAME = @TableName 
        AND COLUMN_NAME = @ColumnName
)
BEGIN
    EXEC SchemaMigration.spDropConstraintsContainingColumn
        @Schema = @SchemaName,
        @Table = @TableName,
        @Column = @ColumnName
END