USE ClientAccount
GO
 
DECLARE @SchemaName AS sysname
DECLARE @TableName AS sysname
DECLARE @ColumnName AS sysname
 
SET @SchemaName = 'dbo'
SET @TableName = 'XhubIncome'
SET @ColumnName = 'IncomeProcessTypeId'

IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = @SchemaName AND TABLE_NAME = @TableName)
BEGIN
    IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = @SchemaName AND TABLE_NAME = @TableName AND COLUMN_NAME = @ColumnName)
    BEGIN
       EXEC('ALTER TABLE dbo.XhubIncome ADD IncomeProcessTypeId TINYINT NULL;')
       EXEC('UPDATE dbo.XhubIncome SET IncomeProcessTypeId = 0 WHERE 1 = 1;') 
       EXEC('ALTER TABLE dbo.XhubIncome ALTER COLUMN IncomeProcessTypeId TINYINT NOT NULL;')
    END 
END

SET @TableName = 'IncomeProcessTypes'
IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = @SchemaName AND TABLE_NAME = @TableName)
BEGIN
CREATE TABLE ClientAccount.dbo.IncomeProcessTypes
(
	IncomeProcessTypeId TINYINT NOT NULL CONSTRAINT PK_IncomeProcessTypes PRIMARY KEY CLUSTERED,
	IncomeProcessType VARCHAR(20) NOT NULL
)
END;
GO

;WITH x (IncomeProcessTypeId, IncomeProcessType)AS
(
	SELECT 0, 'Unknown' UNION ALL
	SELECT 1, 'ProductCash' UNION ALL
	SELECT 2, 'Reinvest' UNION ALL
	SELECT 3, 'External'
)
INSERT INTO ClientAccount.dbo.IncomeProcessTypes (
	IncomeProcessTypeId, 
	IncomeProcessType)
SELECT 
	x.IncomeProcessTypeId, 
	x.IncomeProcessType
FROM x
WHERE NOT EXISTS (SELECT 1 FROM ClientAccount.dbo.IncomeProcessTypes s WHERE s.IncomeProcessTypeId = x.IncomeProcessTypeId)