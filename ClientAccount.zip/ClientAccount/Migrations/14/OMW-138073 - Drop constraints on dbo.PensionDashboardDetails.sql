/*
 * Author: Jerry Jiang
 * Date: 2023-9-27
 * Issue: OMW-138073
 * Description: Drop original constraints on dbo.PensionDashboardDetails
 */

DECLARE @SchemaName AS NVARCHAR(128) = 'dbo'
DECLARE @TableName AS NVARCHAR(128) = 'PensionDashboardDetails'
DECLARE @IncreasingAnnuity AS NVARCHAR(128) = 'IncreasingAnnuity'
DECLARE @SpouseBenefitIncluded AS NVARCHAR(128) = 'SpouseBenefitIncluded'

DECLARE @ColumnName AS NVARCHAR(128)

SET @ColumnName = @IncreasingAnnuity
IF EXISTS (
    SELECT 1
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE 
        TABLE_SCHEMA = @SchemaName 
        AND TABLE_NAME = @TableName 
        AND COLUMN_NAME = @ColumnName
)
BEGIN
    EXEC SchemaMigration.spDropConstraintsContainingColumn
        @Schema = @SchemaName,
        @Table = @TableName,
        @Column = @ColumnName
END

SET @ColumnName = @SpouseBenefitIncluded
IF EXISTS (
    SELECT 1
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE 
        TABLE_SCHEMA = @SchemaName 
        AND TABLE_NAME = @TableName 
        AND COLUMN_NAME = @ColumnName
)
BEGIN
    EXEC SchemaMigration.spDropConstraintsContainingColumn
        @Schema = @SchemaName,
        @Table = @TableName,
        @Column = @ColumnName
END
