--Migration script forrenaming indexes on ScripTrans
-- https://wiki.fnz.com/confluence/display/Architecture/Schema+Migration+Guidelines


EXEC SchemaMigration.spRenameIndex 
	@Schema = N'dbo', -- nvarchar(128)
    @Table = N'ScripTransactions', -- nvarchar(128)
    @OldIndexName = N'idx_AsAt3', -- nvarchar(128)
    @NewIndexName = N'idx_AsAtTransStatusLocationTransSource' -- nvarchar(128)


EXEC SchemaMigration.spRenameIndex 
	@Schema = N'dbo', -- nvarchar(128)
    @Table = N'ScripTransactions', -- nvarchar(128)
    @OldIndexName = N'idxTransStatus', -- nvarchar(128)
    @NewIndexName = N'idx_TransStatusClAccountID' -- nvarchar(128)


