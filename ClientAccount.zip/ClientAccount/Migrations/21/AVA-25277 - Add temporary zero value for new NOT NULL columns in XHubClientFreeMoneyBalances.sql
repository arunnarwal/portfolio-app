/* 
 * date: 16/02/2018
 * issue: AVA-25277
 * description: Add temporary zero value for new NOT NULL columns in XHubClientFreeMoneyBalances
 */

BEGIN TRANSACTION

USE ClientAccount;

-- The table XHubClientFreeMoneyBalances holds cache value for previous day only, so the zero values will be cached, as soon as the data copier task runs

IF NOT EXISTS (SELECT 1 FROM sys.columns where object_id = OBJECT_ID(N'[ClientMoney].[XHubClientFreeMoneyBalances]') AND name = 'BuyAdjustments')
BEGIN
	ALTER TABLE [ClientMoney].[XHubClientFreeMoneyBalances] ADD BuyAdjustments MONEY NULL;

	DECLARE @BuyAdjustments AS NVARCHAR(MAX) -- SQL statement, because simple UPDATE would fail compilation, if the columns were already renamed

	SET @BuyAdjustments = N'UPDATE [ClientMoney].[XHubClientFreeMoneyBalances] SET [BuyAdjustments] = 0 WHERE [BuyAdjustments] IS NULL'

	EXEC sp_executesql @BuyAdjustments
END

IF NOT EXISTS (SELECT 1 FROM sys.columns where object_id = OBJECT_ID(N'[ClientMoney].[XHubClientFreeMoneyBalances]') AND name = 'SellAdjustments')
BEGIN
	ALTER TABLE [ClientMoney].[XHubClientFreeMoneyBalances] ADD SellAdjustments MONEY NULL;

	DECLARE @SellAdjustments AS NVARCHAR(MAX) -- SQL statement, because simple UPDATE would fail compilation, if the columns were already renamed

	SET @SellAdjustments = N'UPDATE [ClientMoney].[XHubClientFreeMoneyBalances] SET [SellAdjustments] = 0 WHERE [SellAdjustments] IS NULL'

	EXEC sp_executesql @SellAdjustments
END

COMMIT TRANSACTION
