
--<Timeout>2000</Timeout>
IF EXISTS (
			SELECT *
			FROM INFORMATION_SCHEMA.COLUMNS
			WHERE TABLE_SCHEMA = 'dbo'
				AND TABLE_NAME = 'CgtTransactions'
				AND COLUMN_NAME = 'ScripTransactionId'
				AND DATA_TYPE = 'BIGINT'
		   )
BEGIN
	SET NOEXEC ON
END

EXEC SchemaMigration.spRenameTable @Schema = N'dbo',
                                   @OldTableName = N'CgtTransactions',
                                   @NewTableName = N'CgtTransactions_temp'
GO
EXEC SchemaMigration.spRenamePrimaryKey @Schema = N'dbo',
                                        @Table = N'CgtTransactions_temp',
                                        @NewPKName = N'PK_CgtTransactions_temp'

GO

CREATE TABLE [dbo].[CgtTransactions]
(
	[Id] [int] NOT NULL IDENTITY(1, 1) CONSTRAINT [PK_CgtTransactions] PRIMARY KEY CLUSTERED,
	[ScripTransactionId] BIGINT NOT NULL,
	[CgtDate] DATE NOT NULL,
	[CgtUnitCost] [numeric] (18, 8) NULL,
	[CgtTotalValue] [numeric] (18, 8) NULL,
	[CgtExempt] [bit] NOT NULL DEFAULT ((0)),
	[TaxBookStatus] [varchar] (50) NULL,
	[TreatAsBuy] [bit] NULL,
	[ExcludeFrom30DayRule] [bit] NOT NULL DEFAULT ((0)),
	[TransferOfEntitlementsReasonId] [tinyint] NULL
)
GO

SET IDENTITY_INSERT dbo.CgtTransactions ON
INSERT INTO dbo.CgtTransactions
(Id, ScripTransactionId, CgtDate, CgtUnitCost, CgtTotalValue, CgtExempt, TaxBookStatus, TreatAsBuy, ExcludeFrom30DayRule, TransferOfEntitlementsReasonId)
SELECT Id, ScripTransactionId, CgtDate, CgtUnitCost, CgtTotalValue, CgtExempt, TaxBookStatus, TreatAsBuy, ExcludeFrom30DayRule, TransferOfEntitlementsReasonId
FROM dbo.CgtTransactions_temp
SET IDENTITY_INSERT dbo.CgtTransactions OFF
GO

DROP TABLE dbo.CgtTransactions_temp
GO

SET NOEXEC OFF
