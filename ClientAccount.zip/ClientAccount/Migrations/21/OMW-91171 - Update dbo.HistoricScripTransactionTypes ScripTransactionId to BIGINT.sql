
--<Timeout>2000</Timeout>
IF EXISTS (
			SELECT 1
			FROM INFORMATION_SCHEMA.COLUMNS
			WHERE TABLE_SCHEMA = 'dbo'
				AND TABLE_NAME = 'HistoricScripTransactionTypes'
				AND COLUMN_NAME = 'ScripTransactionId'
				AND DATA_TYPE = 'BIGINT'
		   )
BEGIN
SET NOEXEC ON
END

EXEC SchemaMigration.spRenameTable @Schema = N'dbo',
                                   @OldTableName = N'HistoricScripTransactionTypes',
                                   @NewTableName = N'HistoricScripTransactionTypes_temp'
GO
EXEC SchemaMigration.spRenamePrimaryKey @Schema = N'dbo',
                                        @Table = N'HistoricScripTransactionTypes_temp',
                                        @NewPKName = N'PK_HistoricScripTransactionTypes_temp'
GO

CREATE TABLE [dbo].[HistoricScripTransactionTypes]
(
	[ScripTransactionId] BIGINT NOT NULL,
	[FETransactionType] [varchar](30) NOT NULL,
 CONSTRAINT [PK_HistoricScripTransactionTypes] PRIMARY KEY CLUSTERED ([ScripTransactionId] ASC) ON [PRIMARY]
)
GO


INSERT INTO dbo.HistoricScripTransactionTypes
([ScripTransactionId], [FETransactionType])
SELECT [ScripTransactionId], [FETransactionType]
FROM dbo.HistoricScripTransactionTypes_temp
GO

DROP TABLE dbo.HistoricScripTransactionTypes_temp
GO

SET NOEXEC OFF