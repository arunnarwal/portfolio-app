USE ClientAccount
GO

Update dbo.ClientDetails Set FeeInvoicingFrequency = 'M' Where FeeInvoicingFrequency is null
