USE ClientAccount
GO

IF EXISTS (
	SELECT 1
	FROM sys.tables 
	WHERE object_id = OBJECT_ID('dbo.Company'))

		
AND NOT EXISTS (
	SELECT 1 FROM sys.columns
	WHERE name = 'IsTaxExempt'
	AND object_id = OBJECT_ID('dbo.Company'))
			
BEGIN
	ALTER TABLE dbo.Company ADD IsTaxExempt BIT NULL CONSTRAINT [DF_Company_IsTaxExempt] DEFAULT ((0))
	EXEC ('UPDATE dbo.Company SET IsTaxExempt = 0 WHERE IsTaxExempt IS NULL');

	ALTER TABLE dbo.Company ALTER COLUMN IsTAXExempt BIT NOT NULL 	
END