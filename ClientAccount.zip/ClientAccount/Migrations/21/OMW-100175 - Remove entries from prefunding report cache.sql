--<Timeout>2000</Timeout>
IF EXISTS (
			SELECT *
			FROM INFORMATION_SCHEMA.COLUMNS
			WHERE TABLE_CATALOG = 'ClientAccount'
				AND TABLE_SCHEMA = 'dbo'
				AND TABLE_NAME = 'PrefundingReportClientFreeMoneyCache'
				AND COLUMN_NAME = 'ID'
		   )
BEGIN
	IF EXISTS (
				SELECT *
				FROM INFORMATION_SCHEMA.COLUMNS
				WHERE TABLE_CATALOG = 'ClientAccount'
					AND TABLE_SCHEMA = 'dbo'
					AND TABLE_NAME = 'PrefundingReportClientFreeMoneyCacheHistory'
					AND COLUMN_NAME = 'ID'
			   )
	BEGIN
		-- If it has the ID column, then we haven't yet updated the column names in these two tables.
		-- Since a) these tables weren't released to prod before this migration script was added and
		-- b) they're cache tables with a fallback when there's no entry, deleting everything from
		-- these tables is okay.
		DELETE FROM ClientAccount.dbo.PrefundingReportClientFreeMoneyCache WHERE 1 = 1
		DELETE FROM ClientAccount.dbo.PrefundingReportClientFreeMoneyCacheHistory WHERE 1 = 1
	END
END