/* Migrate existing objects over to the Permission_data schema */
SET NOCOUNT ON;
BEGIN TRY;

	BEGIN TRANSACTION;

	IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE [name] = 'Permission_data')
	BEGIN;
		PRINT 'Creating Permission_data schema';
		EXEC sp_executesql N'CREATE SCHEMA Permission_data AUTHORIZATION dbo;';
	END;

	IF EXISTS (SELECT 1 FROM information_schema.tables WHERE TABLE_TYPE = 'BASE TABLE' AND TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'ClientAccountSecurity')
	BEGIN;
		PRINT 'Moving dbo.ClientAccountSecurity to Permission_data.MigratedClientAccountSecurity';
		EXEC sp_executesql N'ALTER SCHEMA Permission_data TRANSFER dbo.ClientAccountSecurity;'
		EXEC sp_rename 'Permission_data.ClientAccountSecurity', 'MigratedClientAccountSecurity';
	END;

	IF EXISTS (SELECT 1 FROM information_schema.tables WHERE TABLE_TYPE = 'BASE TABLE' AND TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'WrapProviderSuperUsers')
	BEGIN;
		PRINT 'Moving dbo.WrapProviderSuperUsers to Permission_data.MigratedWrapProviderSuperUsers';
		EXEC sp_executesql N'ALTER SCHEMA Permission_data TRANSFER dbo.WrapProviderSuperUsers;'
		EXEC sp_rename 'Permission_data.WrapProviderSuperUsers', 'MigratedWrapProviderSuperUsers';
	END;

	IF EXISTS (SELECT 1 FROM information_schema.tables WHERE TABLE_TYPE = 'BASE TABLE' AND TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'NetworkSuperUsers')
	BEGIN;
		PRINT 'Moving dbo.NetworkSuperUsers to Permission_data.MigratedNetworkSuperUsers';
		EXEC sp_executesql N'ALTER SCHEMA Permission_data TRANSFER dbo.NetworkSuperUsers;'
		EXEC sp_rename 'Permission_data.NetworkSuperUsers', 'MigratedNetworkSuperUsers';
	END;

	IF EXISTS (SELECT 1 FROM information_schema.tables WHERE TABLE_TYPE = 'BASE TABLE' AND TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'CompanySuperUsers')
	BEGIN;
		PRINT 'Moving dbo.CompanySuperUsers to Permission_data.MigratedCompanySuperUsers';
		EXEC sp_executesql N'ALTER SCHEMA Permission_data TRANSFER dbo.CompanySuperUsers;'
		EXEC sp_rename 'Permission_data.CompanySuperUsers', 'MigratedCompanySuperUsers';
	END;

	IF EXISTS (SELECT 1 FROM information_schema.tables WHERE TABLE_TYPE = 'BASE TABLE' AND TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'BranchSuperUsers')
	BEGIN;
		PRINT 'Moving dbo.BranchSuperUsers to Permission_data.MigratedBranchSuperUsers';
		EXEC sp_executesql N'ALTER SCHEMA Permission_data TRANSFER dbo.BranchSuperUsers;'
		EXEC sp_rename 'Permission_data.BranchSuperUsers', 'MigratedBranchSuperUsers';
	END;

	IF EXISTS (SELECT 1 FROM information_schema.tables WHERE TABLE_TYPE = 'BASE TABLE' AND TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'EntitySuperUser')
	BEGIN;
		PRINT 'Moving dbo.EntitySuperUser to Permission_data.MigratedEntitySuperUser';
		EXEC sp_executesql N'ALTER SCHEMA Permission_data TRANSFER dbo.EntitySuperUser;'
		EXEC sp_rename 'Permission_data.EntitySuperUser', 'MigratedEntitySuperUser';
	END;
	
	DECLARE @SQL	NVARCHAR(MAX);
	DECLARE curIx CURSOR FOR  
	WITH 
	cteIndexes AS (
		SELECT		s.[name] As SchemaName,
					t.[name] AS TableName,
					i.[name] As IndexName,
					i.[is_primary_key] As IsPK,
					CASE WHEN i.[type_desc] = 'CLUSTERED' THEN '1' ELSE '0' END AS IsClustered,
					SUM(
					CASE	WHEN	t.[name] = 'MigratedClientAccountSecurity'
							AND		i.[type_desc] = 'CLUSTERED'
							AND		i.[is_primary_key] = 0
							AND		ic.[is_descending_key] = 0
							AND (  (ic.[key_ordinal] = 1 AND c.[name] = 'ClientId')
								OR (ic.[key_ordinal] = 2 AND c.[name] = 'ClAccountId')
								OR (ic.[key_ordinal] = 3 AND c.[name] = 'AdvisorCodes')
								OR (ic.[key_ordinal] = 4 AND c.[name] = 'ReadWrite')
								)
							THEN 1
							ELSE 999
					END) AS ColumnMatch
		FROM		sys.tables t 
		INNER JOIN	sys.schemas s ON s.schema_id = t.schema_id
		INNER JOIN	sys.indexes i ON i.object_id = t.object_id
		INNER JOIN	sys.index_columns ic ON ic.object_id = t.object_id AND ic.index_id = i.index_id
		INNER JOIN	sys.columns c ON c.object_id = t.object_id AND c.column_id = ic.column_id
		WHERE		s.[name] = 'Permission_data'
		AND			t.[name] IN (	'MigratedClientAccountSecurity',
									'MigratedWrapProviderSuperUsers',
									'MigratedNetworkSuperUsers',
									'MigratedCompanySuperUsers',
									'MigratedBranchSuperUsers',
									'MigratedEntitySuperUser')
		GROUP BY	s.[name], t.[name], i.[name], i.[is_primary_key], i.[type_desc]
	)
	SELECT			CASE
						WHEN ci.IsPK = 1 
							THEN ci.IsClustered + '_ALTER TABLE ' + ci.SchemaName + '.' + ci.TableName + ' DROP CONSTRAINT [' + IndexName + '];'
						WHEN ci.IsPK = 0 AND ci.ColumnMatch <> 4 
							THEN ci.IsClustered + '_DROP INDEX [' + ci.IndexName + N'] ON ' + ci.SchemaName + '.' + ci.TableName + ';'
						ELSE ci.IsClustered + '_'
					END + 
					CASE  
						WHEN ci.TableName = 'MigratedClientAccountSecurity' AND ci.IsClustered = 1 THEN
							CASE
								WHEN ci.ColumnMatch = 4 AND ci.IndexName <> 'cuidx_ClientIdClAccountIdAdvisorCodesReadWrite'
									THEN 'EXEC sp_rename @objname = ''' + DB_NAME() + '.' + ci.SchemaName + '.' + ci.TableName + '.' + IndexName + ''', @newname = ''cuidx_ClientIdClAccountIdAdvisorCodesReadWrite'', @objtype = ''INDEX'';'
								WHEN ci.ColumnMatch <> 4
									THEN 'CREATE UNIQUE CLUSTERED INDEX cuidx_ClientIdClAccountIdAdvisorCodesReadWrite ON ' + ci.SchemaName + '.' + ci.TableName + '(ClientId, ClAccountId, AdvisorCodes, [ReadWrite]) WITH(FILLFACTOR=100);'
								ELSE ''
							END
						ELSE ''
					END AS Cmd
	FROM			cteIndexes ci
	ORDER BY		ci.TableName, Cmd;

	OPEN curIx;  
	FETCH NEXT FROM curIx INTO @SQL;
	
	WHILE @@FETCH_STATUS = 0   
	BEGIN;  
		SET @SQL = SUBSTRING(@SQL, 3, LEN(@SQL) - 2);
		IF @SQL <> ''
		BEGIN;
			PRINT 'Running ' + @SQL;
			EXEC sp_executesql @SQL;
		END;
		FETCH NEXT FROM curIx INTO @SQL;
	END;  
	
	CLOSE curIx;   
	DEALLOCATE curIx;

	COMMIT TRANSACTION;

END TRY
BEGIN CATCH;

	ROLLBACK;
	THROW;

END CATCH;
GO