
DECLARE @SchemaName SYSNAME = 'Banking'
DECLARE @TableName SYSNAME = 'SwiftInterimTransactions'
DECLARE @ColumnName SYSNAME = 'EntryDate'

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = @SchemaName AND TABLE_NAME = @TableName AND COLUMN_NAME = @ColumnName)
BEGIN
    EXEC('ALTER TABLE Banking.SwiftInterimTransactions ADD EntryDate DATE NULL')

    EXEC('UPDATE Banking.SwiftInterimTransactions SET EntryDate = ValueDate')

    EXEC('ALTER TABLE Banking.SwiftInterimTransactions ALTER COLUMN EntryDate DATE NOT NULL')
END

SET @TableName = 'SwiftStatementTransactions'

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = @SchemaName AND TABLE_NAME = @TableName AND COLUMN_NAME = @ColumnName)
BEGIN
    EXEC('ALTER TABLE Banking.SwiftStatementTransactions ADD EntryDate DATE NULL')

    EXEC('UPDATE Banking.SwiftStatementTransactions SET EntryDate = ValueDate')

    EXEC('ALTER TABLE Banking.SwiftStatementTransactions ALTER COLUMN EntryDate DATE NOT NULL')
END
