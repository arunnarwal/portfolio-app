USE [ClientAccount]
GO
ALTER TABLE [dbo].[CustodianAccountDivisionCodeMappings] ADD [CustodianAccountIdV2] [int] NOT NULL DEFAULT(0)
GO
UPDATE [dbo].[CustodianAccountDivisionCodeMappings] SET [CustodianAccountIdV2] = CustodianAccountId WHERE 1 = 1
GO
ALTER TABLE [dbo].[CustodianAccountDivisionCodeMappings] DROP [PK_CustodianAccountDivisionCodeMappings] 
GO
ALTER TABLE [dbo].[CustodianAccountDivisionCodeMappings] DROP [FK_CustodianAccountDivisionCodeMappings_CustodianAccountId]
GO
ALTER TABLE [dbo].[CustodianAccountDivisionCodeMappings] DROP COLUMN [CustodianAccountId]
GO
EXEC sp_rename 'ClientAccount.dbo.CustodianAccountDivisionCodeMappings.CustodianAccountIdV2', 'CustodianAccountId', 'COLUMN'
GO
ALTER TABLE [dbo].[CustodianAccountDivisionCodeMappings] ADD CONSTRAINT [PK_CustodianAccountDivisionCodeMappings] PRIMARY KEY CLUSTERED  ([CustodianAccountId]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[CustodianAccountDivisionCodeMappings] ADD CONSTRAINT [FK_CustodianAccountDivisionCodeMappings_CustodianAccountId] FOREIGN KEY ([CustodianAccountId]) REFERENCES [dbo].[CustodianAccounts] ([ID])
GO