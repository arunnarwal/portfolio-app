IF OBJECT_ID(N'ClientAccount.dbo.ExternallyReceivedIncomeSummary_Staging', N'U') IS NOT NULL
	BEGIN
		DROP TABLE ClientAccount.dbo.ExternallyReceivedIncomeSummary_Staging
	END
