USE ClientAccount
GO

IF EXISTS (
	SELECT 1
	FROM sys.tables 
	WHERE object_id = OBJECT_ID('Glad.CounterpartyConfiguration'))

		
AND NOT EXISTS (
	SELECT 1 FROM sys.columns
	WHERE name = 'SettlementAlias'
	AND object_id = OBJECT_ID('Glad.CounterpartyConfiguration'))
			
BEGIN
	ALTER TABLE Glad.CounterpartyConfiguration ADD SettlementAlias VARCHAR(60) NOT NULL	DEFAULT ('')
END