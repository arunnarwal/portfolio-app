IF NOT EXISTS 
(
	SELECT * FROM Sys.Columns c
	INNER JOIN Sys.Tables t ON c.object_id = t.object_id
	WHERE c.[Name] = 'SwiftMessageChecksum'
		AND t.[Name] = 'SwiftMessages'
) 
BEGIN
	SET NOEXEC ON
END

;EXEC SchemaMigration.spDropIndexesAndConstraintsContainingColumn 'Banking', 'SwiftMessages', 'SwiftMessageChecksum'
;ALTER TABLE ClientAccount.Banking.SwiftMessages DROP COLUMN SwiftMessageChecksum
;ALTER TABLE ClientAccount.Banking.SwiftMessages ADD StatementNumber INT DEFAULT(0)
;ALTER TABLE ClientAccount.Banking.SwiftMessages ADD SequenceNumber INT DEFAULT(0)
GO

/**Insert Statement number and sequence number values into swift messages***/
UPDATE SM
SET SM.SequenceNumber = SSM.SequenceNumber,
SM.StatementNumber = SSM.StatementNumber
FROM ClientAccount.Banking.SwiftMessages SM
INNER JOIN ClientAccount.Banking.SwiftStatementMessages SSM
ON SM.SwiftMessageId = SSM.SwiftMessageId

UPDATE SM
SET SM.SequenceNumber = SITM.SequenceNumber,
SM.StatementNumber = SITM.StatementNumber
FROM ClientAccount.Banking.SwiftMessages SM
INNER JOIN ClientAccount.Banking.SwiftInterimTransactionMessages SITM
ON SM.SwiftMessageId = SITM.SwiftMessageId

/***Some messages have been sent through manually, so need to adjust the sequence number to have it increasing per statement number so that creating the index doesn't break***/

--First, get the SwiftMessages where the duplication would break the index
;WITH CTE_Ids AS
(
	SELECT SwiftMessageId, StatementNumber, SequenceNumber
	FROM ClientAccount.Banking.SwiftStatementMessages

	UNION ALL

	SELECT SwiftMessageId, StatementNumber, SequenceNumber
	FROM ClientAccount.Banking.SwiftInterimTransactionMessages
)
SELECT COUNT(ST.SwiftMessageReference) AS cnt, ST.SwiftMessageReference, IT.StatementNumber, IT.SequenceNumber
INTO #Duplicates
FROM CTE_Ids IT
INNER JOIN ClientAccount.Banking.SwiftMessages ST ON IT.SwiftMessageId = ST.SwiftMessageId
GROUP BY ST.SwiftMessageReference, IT.StatementNumber, IT.SequenceNumber
HAVING COUNT(ST.SwiftMessageReference) > 1

--Now that we know which are the offending SwiftMessageIds, Change SequenceNumber to an increasing sequence for each unique SwiftMessageReference/StatementNumber combination. Default, preexisting (populated at the top) sequence number values will be 1.
;WITH CTE_Duplicates AS
(
	SELECT SM.SwiftMessageId, SM.SwiftMessageReference, IDS.StatementNumber, IDS.SequenceNumber
	FROM #Duplicates IDS 
	INNER JOIN ClientAccount.Banking.SwiftMessages SM ON IDS.SwiftMessageReference = SM.SwiftMessageReference
)
SELECT SN.SwiftMessageId, SN.SequenceNumber
INTO #NewSequenceIds
FROM #Duplicates DU
OUTER APPLY
(
	SELECT D.SwiftMessageId, ROW_Number() OVER (ORDER BY (SELECT 1)) AS SequenceNumber
	FROM CTE_Duplicates D
	WHERE D.SwiftMessageReference = DU.SwiftMessageReference
) SN

--Now update them!
UPDATE SM
SET SM.SequenceNumber = NSI.SequenceNumber
FROM ClientAccount.Banking.SwiftMessages SM
INNER JOIN #NewSequenceIds NSI ON SM.SwiftMessageId = NSI.SwiftMessageId

DROP TABLE #Duplicates
DROP TABLE #NewSequenceIds

/***finally we're safe to create the new index***/
CREATE UNIQUE NONCLUSTERED INDEX UIDX_StatementNumberSequenceNumberSwiftMessageReference ON Banking.SwiftMessages (StatementNumber, SequenceNumber, SwiftMessageReference)

SET NOEXEC OFF