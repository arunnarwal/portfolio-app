
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'ScripLedger')
BEGIN
	EXEC('CREATE SCHEMA ScripLedger AUTHORISATION dbo');
END
GO

SELECT CONVERT(BIT, 0) CreatedTransactionsTable INTO #X

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'ScripLedger' AND TABLE_NAME = 'Transactions')
BEGIN
	EXEC('CREATE TABLE [ScripLedger].[Transactions]
		(
			[TransactionId] [bigint] NOT NULL IDENTITY(1, 1)
				CONSTRAINT [PK_Transactions] PRIMARY KEY CLUSTERED,
			[CreatedDateTime] [datetime2] NOT NULL DEFAULT (getdate()),
			[LastModifiedDateTime] [smalldatetime] NOT NULL DEFAULT (getdate()),
			[UserId] [int] NOT NULL
		)')

		UPDATE #X
		SET CreatedTransactionsTable = 1
		WHERE CreatedTransactionsTable = 0
END
GO

IF EXISTS (SELECT 1 FROM #X WHERE CreatedTransactionsTable = 1)
BEGIN
	SET IDENTITY_INSERT ScripLedger.Transactions ON

    INSERT INTO ScripLedger.Transactions
	(TransactionId, CreatedDateTime, LastModifiedDateTime, UserId)
    SELECT TransId, TransDate, LastModified, UserId
    FROM ScripLedger.OriginalScripTransactions

    SET IDENTITY_INSERT ScripLedger.Transactions OFF
END

DROP TABLE #X
