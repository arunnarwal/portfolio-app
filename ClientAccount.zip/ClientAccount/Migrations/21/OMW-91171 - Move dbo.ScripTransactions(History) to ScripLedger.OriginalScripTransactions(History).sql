
--1 hour timeout, expected run time = 30 mins
--<Timeout>3600</Timeout>

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'ScripLedger')
BEGIN
	EXEC('CREATE SCHEMA ScripLedger AUTHORISATION dbo');
END

--Fix data before rebuilding with 100% fill factor
UPDATE dbo.ScripTransactions
SET TransType = 'AccountTransfer'
WHERE TransType = ''

--Drop indexes to save space
EXEC SchemaMigration.spDropIndexesAndConstraintsContainingColumn @Schema = N'dbo', @Table = N'ScripTransactions', @Column = N'ClAccountId'
EXEC SchemaMigration.spDropIndexesAndConstraintsContainingColumn @Schema = N'dbo', @Table = N'ScripTransactions', @Column = N'InstrumentCode'
EXEC SchemaMigration.spDropIndexesAndConstraintsContainingColumn @Schema = N'dbo', @Table = N'ScripTransactions', @Column = N'OrderId'
EXEC SchemaMigration.spDropIndexesAndConstraintsContainingColumn @Schema = N'dbo', @Table = N'ScripTransactions', @Column = N'TradeId'
EXEC SchemaMigration.spDropIndexesAndConstraintsContainingColumn @Schema = N'dbo', @Table = N'ScripTransactions', @Column = N'AWScripTransferId'
EXEC SchemaMigration.spDropIndexesAndConstraintsContainingColumn @Schema = N'dbo', @Table = N'ScripTransactions', @Column = N'CorpActId'

--Compress the table to save space
--for 100M rows: 47GB clustered index (86GB all indexes) -> 8GB
ALTER TABLE dbo.ScripTransactions REBUILD PARTITION = ALL WITH (FILLFACTOR = 100, DATA_COMPRESSION = PAGE);   
GO
ALTER TABLE dbo.ScripTransactionsHistory REBUILD PARTITION = ALL WITH (FILLFACTOR = 100, DATA_COMPRESSION = PAGE);   
GO

ALTER SCHEMA ScripLedger TRANSFER dbo.ScripTransactions
GO
ALTER SCHEMA ScripLedger TRANSFER dbo.ScripTransactionsHistory
GO

EXEC SchemaMigration.spRenameTable @Schema = N'ScripLedger', @OldTableName = N'ScripTransactions', @NewTableName = N'OriginalScripTransactions'
EXEC SchemaMigration.spRenameTable @Schema = N'ScripLedger', @OldTableName = N'ScripTransactionsHistory', @NewTableName = N'OriginalScripTransactionsHistory'

EXEC SchemaMigration.spRenamePrimaryKey @Schema = N'ScripLedger', @Table = N'OriginalScripTransactions', @NewPKName = N'PK_OriginalScripTransactions'
EXEC SchemaMigration.spRenamePrimaryKey @Schema = N'ScripLedger', @Table = N'OriginalScripTransactionsHistory', @NewPKName = N'PK_OriginalScripTransactionsHistory'
GO

DECLARE @HistoryId INT = 1
SELECT @HistoryId = IDENT_CURRENT('ScripLedger.OriginalScripTransactionsHistory')

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'ScripLedger' AND TABLE_NAME = 'TransactionChangeLog')
BEGIN
	CREATE TABLE ScripLedger.TransactionChangeLog
	(
		TransactionChangeLogId	INT IDENTITY(1,1) NOT NULL
				CONSTRAINT [PK_TransactionChangeLog] PRIMARY KEY CLUSTERED,
		TransactionId			BIGINT NOT NULL,
		ChangeDateTime			SMALLDATETIME NOT NULL DEFAULT (GETDATE())
	)
END

DBCC CHECKIDENT('ScripLedger.TransactionChangeLog', RESEED, @HistoryId)

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'ScripLedger' AND TABLE_NAME = 'TransactionHistory')
BEGIN

	CREATE TABLE ScripLedger.TransactionHistory
	(
		TransactionHistoryId			INT				NOT NULL IDENTITY(1, 1) CONSTRAINT PK_TransactionHistory PRIMARY KEY CLUSTERED,
		ChangeOperation					CHAR(1)			NOT	NULL,
		ChangeDateTime					DATETIME		NOT	NULL,
		TransactionId					BIGINT          NOT NULL,
		AccountId						INT             NOT NULL,
		InstrumentId					INT				NOT NULL,
		CustodianAccountId				INT					NULL,
		AsAt							DATE		    NOT NULL,
		Quantity						DECIMAL(23, 8)  NOT NULL,
		LocationId						TINYINT			NOT NULL,
		TransactionTypeId				TINYINT			NOT NULL,
		TransactionSourceId				TINYINT			NOT NULL,
		Reference						VARCHAR(50)			NULL,
		Cost							NUMERIC(18, 8)		NULL,
		Group1							DECIMAL(23, 8)	    NULL,
		Group2							DECIMAL(23, 8)      NULL,
		DisplayToClient					BIT             NOT NULL,
		ExcludeFromPerformanceCalc		BIT                 NULL,
		OrderId							INT					NULL,
		SettlementDate					DATE				NULL,
		TradeId							INT					NULL,
		ExternalTransactionTypeId		TINYINT				NULL,
		ContextInfo                     VARCHAR(128)        NULL
	)
END

DBCC CHECKIDENT('ScripLedger.TransactionHistory', RESEED, @HistoryId)