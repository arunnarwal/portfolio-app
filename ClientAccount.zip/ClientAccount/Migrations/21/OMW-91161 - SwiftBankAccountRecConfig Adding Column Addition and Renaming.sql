USE ClientAccount
GO
 
DECLARE @SchemaName AS sysname
DECLARE @TableName AS sysname
DECLARE @ColumnName1 AS sysname
DECLARE @ColumnName2 AS sysname

SET @SchemaName = 'Banking'
SET @TableName = 'SwiftBankAccountReconciliationConfig'

SET @ColumnName1 = 'Method'
SET @ColumnName2 = 'DivisionCode'
 
--Check the table exists
--If it doesn't then the sync will add it, no need for a migration
IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = @SchemaName AND TABLE_NAME = @TableName)
BEGIN
 
    --Check the column doesn't exist already. It shouldn't as are only just adding it, but best to be defensive...
    IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = @SchemaName AND TABLE_NAME = @TableName AND COLUMN_NAME = @ColumnName1)
    BEGIN
 
       EXEC('ALTER TABLE Banking.SwiftBankAccountReconciliationConfig ADD Method VARCHAR(20) NULL')

       EXEC('UPDATE Banking.SwiftBankAccountReconciliationConfig SET Method = '''+'DummyMethod'+'''')

       EXEC('ALTER TABLE Banking.SwiftBankAccountReconciliationConfig ALTER COLUMN Method VARCHAR(20) NOT NULL;')
    END

	IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = @SchemaName AND TABLE_NAME = @TableName AND COLUMN_NAME = @ColumnName2)
    BEGIN
 
       EXEC('ALTER TABLE Banking.SwiftBankAccountReconciliationConfig ADD DivisionCode VARCHAR(5) NULL')
 
       EXEC('UPDATE Banking.SwiftBankAccountReconciliationConfig SET DivisionCode = '''+'OP'+'''')
 
       EXEC('ALTER TABLE Banking.SwiftBankAccountReconciliationConfig ALTER COLUMN DivisionCode VARCHAR(5) NOT NULL;')
    END
 
END

EXEC SchemaMigration.spRenameColumn @Schema = 'Banking',
                                    @Table = 'SwiftBankAccountReconciliationConfig',
                                    @OldColumnName = 'RestrictActivities',
                                    @NewColumnName = 'RestrictActivity'