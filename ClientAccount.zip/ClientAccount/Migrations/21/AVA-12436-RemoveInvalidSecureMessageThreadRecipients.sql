/*
 * Author:      Stuart Connolly
 * Date:        August 11, 2017
 * Build Item:  Aviva Advised R1 / AVA-12436
 * Description: Remove invalid secure messages thread recipients to allow for FK deployment.
 */

-- Remove entries against invalid threads
DELETE R FROM ClientDb3.dbo.SecureMessagePendingBroadcastThreadRecipients R
WHERE NOT EXISTS (SELECT 1 FROM ClientDb3.dbo.SecureMessagePendingBroadcastThreads T WHERE T.Id = R.ThreadId)

-- Remove invalid clients
DELETE R FROM ClientDb3.dbo.SecureMessagePendingBroadcastThreadRecipients R
WHERE NOT EXISTS (SELECT 1 FROM ClientDb3.dbo.TblClients C WHERE c.ClientId = r.ClientId)

-- Remove duplicate rows
SELECT ThreadId, ClientId, COUNT(1) AS [Count]
INTO #DuplicateRows
FROM ClientDB3.dbo.SecureMessagePendingBroadcastThreadRecipients
WHERE ThreadId > 0
GROUP BY ThreadId, ClientId
HAVING COUNT(1) > 1

INSERT INTO ClientDB3.dbo.SecureMessagePendingBroadcastThreadRecipients (ThreadId, ClientId)
SELECT DR.ThreadId, DR.ClientId
FROM #DuplicateRows DR
WHERE NOT EXISTS (SELECT 1 FROM ClientDB3.dbo.SecureMessagePendingBroadcastThreadRecipients R WHERE R.ThreadId = DR.ThreadId AND R.ClientId = DR.ClientId)

DROP TABLE #DuplicateRows
