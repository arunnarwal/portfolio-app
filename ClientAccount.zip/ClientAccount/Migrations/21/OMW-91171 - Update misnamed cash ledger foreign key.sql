IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = 'CashLedger' AND CONSTRAINT_NAME = 'FK_TransactionNarratives_New_Transactions_TransactionId')
BEGIN
	EXEC sp_rename 'CashLedger.FK_TransactionNarratives_New_Transactions_TransactionId', 'FK_TransactionNarratives_Transactions_TransactionId';
END
