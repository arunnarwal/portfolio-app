use ClientAccount
go

CREATE TABLE dbo.BondAssignment_New (
       [AssignmentId] [int] IDENTITY(1,1) NOT NULL,
       [SourceSubAccountId] [int] NOT NULL,
       [DestinationSubAccountId] [int] NOT NULL,
       [SegmentsAssigned] [int] NOT NULL,
       [EffectiveTime] [datetime] NOT NULL,
       [TimeAuthorised] [datetime] NULL,
       [UserAuthorised] [int] NULL,
CONSTRAINT [PK_BondAssignment_New] PRIMARY KEY CLUSTERED 
(
       [AssignmentId] ASC
))

ALTER TABLE dbo.BondAssignment_New  WITH CHECK ADD  CONSTRAINT [FK_BondAssignment_New_Bonds_SourceSubAccountId] FOREIGN KEY([SourceSubAccountId])
REFERENCES [dbo].[Bonds] ([SubAccountId])
GO

ALTER TABLE dbo.BondAssignment_New CHECK CONSTRAINT [FK_BondAssignment_New_Bonds_SourceSubAccountId]
GO

ALTER TABLE dbo.BondAssignment_New  WITH CHECK ADD  CONSTRAINT [FK_BondAssignment_New_SEClientAccount_DestinationSubAccountId] FOREIGN KEY([DestinationSubAccountId])
REFERENCES [dbo].[SEClientAccount] ([ID])
GO

ALTER TABLE dbo.BondAssignment_New CHECK CONSTRAINT [FK_BondAssignment_New_SEClientAccount_DestinationSubAccountId]
GO

set identity_insert dbo.BondAssignment_New on
insert into dbo.BondAssignment_New (AssignmentId, SourceSubAccountId, DestinationSubAccountId, SegmentsAssigned, EffectiveTime, TimeAuthorised, UserAuthorised)
select AssignmentId, SourceSubAccountId, DestinationSubAccountId, SegmentsAssigned, EffectiveTime, TimeAuthorised, cast(userAuthorised as int)
from dbo.BondAssignment
set identity_insert dbo.BondAssignment_New off

drop table dbo.BondAssignment

EXEC SchemaMigration.spRenameTable @Schema = 'dbo', @OldTableName = 'BondAssignment_New', @NewTableName = 'BondAssignment'
EXEC SchemaMigration.spRenamePrimaryKey @Schema = 'dbo', @Table = 'BondAssignment', @NewPKName = 'PK_BondAssignment'
EXEC sp_rename @objname = 'dbo.FK_BondAssignment_New_Bonds_SourceSubAccountId', @newname = 'FK_BondAssignment_Bonds_SourceSubAccountId';
EXEC sp_rename @objname = 'dbo.FK_BondAssignment_New_SEClientAccount_DestinationSubAccountId', @newname = 'FK_BondAssignment_SEClientAccount_DestinationSubAccountId';
