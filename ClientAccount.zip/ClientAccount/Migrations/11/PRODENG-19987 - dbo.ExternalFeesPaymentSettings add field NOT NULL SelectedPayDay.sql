USE ClientAccount
GO
 
DECLARE @SchemaName AS sysname
DECLARE @TableName AS sysname
DECLARE @ColumnName AS sysname
 
SET @SchemaName = 'dbo'
SET @TableName = 'ExternalFeesPaymentSettings'
SET @ColumnName = 'SelectedPayDay'
 
--Check the table exists
--If it doesn't then the sync will add it, no need for a migration
IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = @SchemaName AND TABLE_NAME = @TableName)
BEGIN
 
    --Check the column doesn't exist already. It shouldn't as are only just adding it, but best to be defensive...
    IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = @SchemaName AND TABLE_NAME = @TableName AND COLUMN_NAME = @ColumnName)
    BEGIN
 
       --Add the column as NULLABLE
       EXEC('ALTER TABLE dbo.ExternalFeesPaymentSettings ADD SelectedPayDay tinyint NULL;')
 
       --Fill all of the values
       EXEC('UPDATE dbo.ExternalFeesPaymentSettings SET dbo.ExternalFeesPaymentSettings.SelectedPayDay = (SELECT DAY(CONVERT(date, (SELECT f.feespaydate FROM clientaccount.dbo.ExternalFeesPaymentSettings f WHERE f.ClAccountID = dbo.ExternalFeesPaymentSettings.ClAccountID))))')
 
       --Now make it non-nullable
       --n.b we could leave this to the sync,
       --but it's better to do it here so if something goes wrong with filling the values then the migration will fail rather than the sync
       EXEC('ALTER TABLE dbo.ExternalFeesPaymentSettings ALTER COLUMN SelectedPayDay tinyint NOT NULL;')
    END
 
END
