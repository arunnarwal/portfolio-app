/*
    Author: Matej Lobodas
    Description: Adding tables for Flexi Isa and populating with new data              
*/


DECLARE @SchemaName AS sysname
DECLARE @TableName AS sysname
DECLARE @ColumnName AS sysname

SET @SchemaName = 'ProductWrapper'
SET @TableName = 'IsaProductSettings'

IF NOT EXISTS (SELECT 1 FROM SYS.SCHEMAS WHERE Name = @SchemaName)
BEGIN
    EXEC('CREATE SCHEMA [ProductWrapper] AUTHORIZATION [dbo]')
END

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = @SchemaName AND TABLE_NAME = @TableName)
BEGIN
    CREATE TABLE ProductWrapper.IsaProductSettings(
        IsaProductSettingId int NOT NULL,
        CONSTRAINT PK_IsaSettings PRIMARY KEY CLUSTERED(IsaProductSettingId),
        CONSTRAINT FK_IsaSettings_ProductSettings_IsaProductSettingId FOREIGN KEY (IsaProductSettingId) REFERENCES dbo.ProductSettings(Id),
        IsFlexiIsaAllowed bit NOT NULL DEFAULT(0)
    )	
END

--Allowed by default for all ISA products, but Junior ISA
INSERT INTO ProductWrapper.IsaProductSettings(IsaProductSettingId,IsFlexiIsaAllowed)
SELECT Id,1 FROM dbo.ProductSettings WHERE Product LIKE '%ISA%' AND Product NOT LIKE '%JISA%'
INSERT INTO ProductWrapper.IsaProductSettings(IsaProductSettingId,IsFlexiIsaAllowed)
SELECT Id,0 FROM dbo.ProductSettings WHERE Product LIKE '%JISA%'