
EXEC SchemaMigration.spRenameIndex
    @Schema = N'dbo',
    @Table = N'CashLedgerAdjustments',
    @OldIndexName = N'IDX_Search',
    @NewIndexName = N'IDX_ClAccountIDLedgerDatePortfolioAdjustAvailableAdjust'
