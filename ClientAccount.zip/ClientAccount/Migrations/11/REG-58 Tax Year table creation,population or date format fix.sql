/*
    Author: Matej Lobodas
    Description: Adding tables for Tax Years
*/


DECLARE @SchemaName AS sysname
DECLARE @TableName AS sysname
DECLARE @ColumnName AS sysname

SET @SchemaName = 'Tax'
SET @TableName = 'Years'

IF NOT EXISTS (SELECT 1 FROM SYS.SCHEMAS WHERE Name = @SchemaName)
BEGIN
    EXEC('CREATE SCHEMA [Tax] AUTHORIZATION [dbo]')
END

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = @SchemaName AND TABLE_NAME = @TableName)
BEGIN
    CREATE TABLE Tax.Years
    (
        TaxYearId tinyint NOT NULL,
        CONSTRAINT PK_Years_TaxYearId PRIMARY KEY CLUSTERED(TaxYearId),
        TaxYear varchar(9) NOT NULL,
        FirstDate smalldatetime NOT NULL,
        FirstDateOfNext smalldatetime NOT NULL,
    )
END

IF EXISTS(SELECT DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Years' AND COLUMN_NAME = 'FirstDateOfNext'AND DATA_TYPE = 'datetime')
BEGIN 
    DELETE FROM Tax.Years WHERE FirstDateOfNext > '2080-01-01'
    ALTER TABLE Tax.Years ADD TempDateColumn smalldatetime         
    EXECUTE('UPDATE Tax.Years SET TempDateColumn = CONVERT(smalldatetime,FirstDateOfNext)')        
    ALTER TABLE Tax.Years DROP COLUMN FirstDateOfNext
    ALTER TABLE Tax.Years ADD FirstDateOfNext smalldatetime         
    EXECUTE('UPDATE Tax.Years SET FirstDateOfNext = TempDateColumn')
    ALTER TABLE Tax.Years ALTER COLUMN FirstDate smalldatetime NOT NULL

    EXECUTE('ALTER TABLE Tax.Years DROP COLUMN TempDateColumn')
END

IF EXISTS(SELECT DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Years' AND COLUMN_NAME = 'FirstDate'AND DATA_TYPE = 'datetime')
BEGIN        
    DELETE FROM Tax.Years WHERE FirstDate > '2079-01-01'
    ALTER TABLE Tax.Years ADD TempDateColumn smalldatetime 

    EXECUTE('UPDATE Tax.Years SET TempDateColumn = CONVERT(smalldatetime,FirstDate)')
    ALTER TABLE Tax.Years DROP COLUMN FirstDate
    ALTER TABLE Tax.Years ADD FirstDate smalldatetime
    EXECUTE('UPDATE Tax.Years SET FirstDate = TempDateColumn')
    ALTER TABLE Tax.Years ALTER COLUMN FirstDate smalldatetime NOT NULL

    EXECUTE('ALTER TABLE Tax.Years DROP COLUMN TempDateColumn')
END

IF NOT EXISTS (SELECT 1 FROM Tax.Years)
BEGIN
    DECLARE @TaxYearId INT;
    SET  @TaxYearId=1;
    WHILE  @TaxYearId < 89
    BEGIN 
        INSERT Tax.Years (TaxYearId, TaxYear, FirstDate,FirstDateOfNext) 
        VALUES(@TaxYearId,
            CONVERT(varchar(4),1990 + @TaxYearId) + '/' + CONVERT(varchar(4),1991+@TaxYearId),
            CONVERT(varchar(4),1990 + @TaxYearId) + '-04-06',
            CONVERT(varchar(4),1991 + @TaxYearId) + '-04-06' ); 
        SET @TaxYearId = @TaxYearId + 1;
    END
END