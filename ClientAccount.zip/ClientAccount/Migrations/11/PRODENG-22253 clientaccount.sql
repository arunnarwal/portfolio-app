
SELECT COLUMN_NAME 
INTO #ExistedAtTheStartOfThisMigration 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'gladProductSweepMovementTypes' 
AND column_name ='WrapProvider'
AND TABLE_SCHEMA = 'dbo'
GO


IF EXISTS (SELECT 1 FROM #ExistedAtTheStartOfThisMigration)
BEGIN
ALTER TABLE dbo.GladProductSweepMovementTypes ADD DivisionId INT NULL
END
GO

IF EXISTS (SELECT 1 FROM #ExistedAtTheStartOfThisMigration)
BEGIN
   DECLARE @Divisionid INT
   SELECT @Divisionid = Id from clientaccount.dbo.gladGLDivision WHERE GLDivisionCode = 'CUS'

   DECLARE @Sql AS NVARCHAR(400)
   SET @Sql = N'UPDATE [dbo].GladProductSweepMovementTypes SET Divisionid = ' + CONVERT(varchar, @Divisionid) +' WHERE WrapProvider = ''CUS'''

   EXEC(@Sql)

   ALTER TABLE dbo.GladProductSweepMovementTypes ALTER COLUMN DivisionId INT NOT NULL
END

DROP TABLE #ExistedAtTheStartOfThisMigration

GO