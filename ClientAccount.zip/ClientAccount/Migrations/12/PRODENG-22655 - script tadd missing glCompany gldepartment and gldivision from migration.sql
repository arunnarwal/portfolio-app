
INSERT INTO ClientAccount.dbo.GladCompany (GLCompany, CompanyName)
SELECT 'UKW', 'First NZ Wrap (UK) Limited'
WHERE not exists (SELECT 1 FROM ClientAccount.dbo.GladCompany where GLCompany = 'UKW');

insert into clientaccount.dbo.gladgldepartment (GLDepartmentCode, DepartmentName)
select '00', 'General'
where not exists (select 1 from clientaccount.dbo.gladgldepartment where GLDepartmentCode = '00');

insert into clientaccount.dbo.gladglDivision (GLDivisionCode, DivisionName)
select '00', 'General'
where not exists (select 1 from clientaccount.dbo.gladglDivision where GLDivisionCode = '00') 

