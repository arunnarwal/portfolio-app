/*
 * Author: Richard Kubny
 * Date: 2024-01-31
 * Issue: OMW-144542
 * Description: Table CustodianAccountInstrumentMappings should not contain any data (does not on prod, this is just in case for dev envs)
 */
 
EXEC('TRUNCATE TABLE ClientAccount.dbo.CustodianAccountInstrumentMappings')