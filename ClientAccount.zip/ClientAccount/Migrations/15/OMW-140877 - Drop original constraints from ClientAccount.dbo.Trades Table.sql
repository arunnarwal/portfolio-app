/*
 * Author: Arun Narwal
 * Date: 2023-12-27
 * Issue: OMW-140877
 * Description: Drop original constraints from ClientAccount.dbo.Trades
 */

DECLARE @SchemaName AS NVARCHAR(128) = 'dbo'
DECLARE @TableName AS NVARCHAR(128) = 'Trades'
DECLARE @LastModified AS NVARCHAR(128) = 'LastModified'
DECLARE @ColumnName AS NVARCHAR(128)

SET @ColumnName = @LastModified
IF EXISTS (
    SELECT 1
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE 
        TABLE_SCHEMA = @SchemaName 
        AND TABLE_NAME = @TableName 
        AND COLUMN_NAME = @ColumnName
)
BEGIN
    EXEC SchemaMigration.spDropConstraintsContainingColumn
        @Schema = @SchemaName,
        @Table = @TableName,
        @Column = @ColumnName
END