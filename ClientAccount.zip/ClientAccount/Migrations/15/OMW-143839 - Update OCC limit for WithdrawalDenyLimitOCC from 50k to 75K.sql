/*
 * Author: Arun Narwal
 * Date: 2024-01-11
 * Issue: OMW-143839
 * Description: Update OCC limit for WithdrawalDenyLimitOCC from 50k to 75K
 */
DECLARE @OptionName VARCHAR(200) = 'WithdrawalDenyLimitOCC'

DECLARE @OptionValue VARCHAR(150) = '75000'

DECLARE @WrapProvider VARCHAR(5) = 'OM'

UPDATE ClientAccount.dbo.GenericOptions SET OptionValue=@OptionValue WHERE [OptionName] = @OptionName AND [Type] = 'WP' AND [Name] = @WrapProvider
