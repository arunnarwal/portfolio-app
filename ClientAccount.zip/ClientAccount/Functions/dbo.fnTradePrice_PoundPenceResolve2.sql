SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- =============================================
-- Author: Romil
-- Create date: 10/June/12
-- Description: bond price fron pence to pound
--declare @ans numeric(19,5)
--select price from fnTradePrice_PoundPenceResolve2 ('2435.12','bond','UK' ) 
--print @ans
-- =============================================
CREATE FUNCTION [dbo].[fnTradePrice_PoundPenceResolve2] 
( 
-- Add the parameters for the function here
@price numeric (19,5),
@security varchar(10),
@country varchar(5)
)
RETURNS TABLE AS 
Return
SELECT
case when (@security IN ('BOND','bond') AND @country = 'GB')
then @price/100.000
else @price
end as Price
GO
