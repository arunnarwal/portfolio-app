SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
create function [dbo].[fnGetExternalCashBalances](@AsAt datetime)  RETURNS TABLE AS return select 
	CT.claccountid,
	CT.cncycode,
	sum(CT.amount) as Amount,
	cd.investortype
from clientaccount..cashtransactions CT
inner join clientaccount..seclientaccount CD
	 on CD.ClAccountID = CT.ClAccountID
where ct.asat <= @AsAt
group by 
	CT.claccountid,
	CT.cncycode,
	cd.investortype
GO
