SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION  [dbo].[fnCorporateActionClientHoldings](@ClientID int) Returns Table AS

RETURN
SELECT	c.ID as CorpActID, st.InstrumentCode, CON.ClAccountID, ST.custodianaccountid, CO.CountryCode AS CompanyCountryCode, 
		CO.WrapProvider, ST.Group1Group2, C.InstrumentType, C.ExDate, max(asat) as MaxAsAt,
		sum(ST.Quantity) AS Quantity,
		case when ST.location = 'BTA' and C.IncludeBTA = 1 then 'Custody' 
			else ST.Location 
		end as Location, 0 as DRPDefault,
		C.PostStatus

FROM	ClientAccount.dbo.scriptransactions ST
			Inner join corporateactions.dbo.fnCorporateActionsWithQualifyingLocation() C on C.instrumentcode = st.instrumentcode and st.asat < c.exdate
			inner join ClientAccount.dbo.vwBaseAllowedClAccountID CAQL on CAQL.CLAccountiD = ST.ClAccountID and CAQL.ClientID = @ClientID	
			inner join ClientAccount.dbo.Consolidate Con on Con.SubclAccountID = ST.ClAccountid			
			inner join ClientAccount.dbo.ClientDetails CD on CD.ClAccountID = CON.ClAccountID
			inner join ClientAccount.dbo.Company CO on CO.Company = CD.Company
			
WHERE	ST.transstatus in ('Settled','UnSettled') and CD.InvestorType != 'Consolidated'

GROUP by c.ID, st.InstrumentCode, CON.ClAccountID, ST.custodianaccountid, ST.Group1Group2, 
		CO.CountryCode, CO.WrapProvider, C.ExDate, C.InstrumentType, 
		case when ST.location = 'BTA' and C.IncludeBTA = 1 then 'Custody' else ST.Location end,
		C.PostStatus
		
HAVING sum(ST.quantity) <> 0
GO
