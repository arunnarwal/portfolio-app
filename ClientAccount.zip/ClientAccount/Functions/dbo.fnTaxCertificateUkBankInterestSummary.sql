CREATE FUNCTION [dbo].[fnTaxCertificateUkBankInterestSummary](@FromDate datetime, @ToDate datetime)
RETURNS TABLE
AS
RETURN

/*
USE ClientAccount

DECLARE @FromDate DATETIME;
DECLARE @ToDate DATETIME;

SET @FromDate = '2020-04-06 00:00:00';
SET @ToDate = '2021-04-05 00:00:00';
*/

WITH WithholdingTaxData AS
(
	SELECT 
		ClAccountID, 
		SUM(Amount) AS Tax
	FROM dbo.CashLedgerTransactions
	WHERE MovementType = 'WITHHOLDING_TAX'
		AND MovementSource = 'ClientInterest'
		AND LedgerDate BETWEEN @FromDate AND @ToDate
	GROUP BY ClAccountID
),

TaxableIncomeData AS 
(
	SELECT
		TIDFU.ClAccountID, 
		SUM(TIDFU.Gross) - SUM(TIDFU.WT) AS Net,
		Sum(TIDFU.WT) AS Tax,
		Sum(TIDFU.Gross) AS Gross
	FROM
		dbo.vwTaxableIncomeDataForUK AS TIDFU
	WHERE 
		TIDFU.LedgerDate >= @FromDate 
		AND TIDFU.LedgerDate <= @ToDate
		AND TIDFU.Reversal IS NULL 
		AND (
			(TIDFU.[Type] = 'Interest' AND (TIDFU.InstrumentCode = 'GBPCash' Or TIDFU.Domicile = 'UK')) 
			OR (TIDFU.MFIncomeType = 'Interest' AND TIDFU.SecuritySubType = 'ManagedFund' And TIDFU.Domicile = 'UK')
			OR (TIDFU.Type = 'Interest' AND TIDFU.SecuritySubType = 'Term Deposit' And TIDFU.Domicile = 'UK')
		)
		AND TIDFU.SubAccountType IS NOT NULL AND TIDFU.SubAccountType <> ''
		AND TIDFU.[Type] = 'Interest'
		AND (TIDFU.InstrumentCode = 'GBPCash' OR TIDFU.SecuritySubType = 'Term Deposit') 
	GROUP BY
		TIDFU.ClAccountID
)

SELECT
	TI.ClAccountID,
	TI.Net,
	TI.Tax + WT.Tax AS Tax,
	TI.Gross + WT.Tax AS Gross
FROM TaxableIncomeData TI
	INNER JOIN WithholdingTaxData WT ON WT.ClAccountID = TI.ClAccountID
