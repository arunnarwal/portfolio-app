SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[fnGetLinkedAccounts](@subclaccountid varchar(20)) RETURNS TABLE AS

RETURN

SELECT 

 SubClAccountID as ClAccountID,CLAccountID as LinkAccount

FROM 

ClientAccount.dbo.Consolidate c

INNER JOIN

(SELECT headClAccountID FROM ClientAccount.dbo.fnheadaccounts() WHERE claccountid = @subclaccountid and consolidated = 1) AS linked 

ON c.ClAccountID = linked.headClAccountID

AND

c.SubClAccountID not like '%-%'
AND c.Status = 'Authorised'
GO
