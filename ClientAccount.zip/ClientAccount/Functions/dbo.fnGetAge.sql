SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE function [dbo].[fnGetAge]
(@in_DOB AS datetime,@now as datetime)

returns int

as

begin
	DECLARE @age int
	IF cast(datepart(m,@now) as int) > cast(datepart(m,@in_DOB) as int)
		SET @age = cast(datediff(yyyy,@in_DOB,@now) as int)
	else
		IF cast(datepart(m,@now) as int) = cast(datepart(m,@in_DOB) as int)
			IF datepart(d,@now) >= datepart(d,@in_DOB)
				SET @age = cast(datediff(yyyy,@in_DOB,@now) as int)
			ELSE
				SET @age = cast(datediff(yyyy,@in_DOB,@now) as int) -1
			ELSE
				SET @age = cast(datediff(yyyy,@in_DOB,@now) as int) - 1
	RETURN @age

end
GO
