SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE function [dbo].[latestFeeRebateSchedule]() Returns TABLE AS

return

SELECT	maxfrs.instrumentcode,
				maxfrs.WrapProvider,
				frs.rate, 
				adminrate
		FROM	(
				SELECT	instrumentcode,
						WrapProvider,
						max(id) as maxID
				FROM	ClientAccount..FeeRebateSchedule
				WHERE	Type = 'MFR' and
						instrumentcode is not null and
						WrapProvider is not null 
				group by instrumentcode,
						WrapProvider
				) maxfrs
		INNER JOIN	ClientAccount..FeeRebateSchedule as frs
		ON		maxfrs.instrumentcode = frs.instrumentcode and
				maxfrs.WrapProvider = frs.WrapProvider and
				maxfrs.maxID = frs.id
		WHERE	frs.Type = 'MFR' and
				frs.instrumentcode is not null and
				frs.WrapProvider is not null
GO
