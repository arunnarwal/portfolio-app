SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE Function [dbo].[fnAvailableCashBalanceForClAccountIdbyCCY](@AsAt datetime, @BatchID int = 0, @ClAccountID AS VarChar(20)) RETURNS TABLE AS

RETURN
SELECT	CLIENTSANDCCY.claccountid,
		CLIENTSANDCCY.ccycode,
		coalesce(CLT.CLTbalance,0)as CLTbalance,
		coalesce(CMT.CMTbalance,0)as CMTbalance,
		coalesce(CLA.CLAbalance,0)as CLAbalance,
 		coalesce(CLAAvailable.CLAAvailableAdjustBalance,0)as CLAAvailableAdjustBalance,
		coalesce(CLAPortfolio.CLAPortfolioAdjustBalance,0)as CLAPortfolioAdjustBalance,
		coalesce(WD.Withdrawals,0)as Withdrawals,
		coalesce(BUYORD.BuyOrders,0)as BuyOrders,
		coalesce(SELLORD.SellOrders,0)as SellOrders,
		coalesce(SELLORDSAMEBATCH.SellOrdersSameBatch,0) as SellOrdersSameBatch,
		coalesce(CLT.CLTbalance,0)+	coalesce(CMT.CMTbalance,0)+	coalesce(CLA.CLAbalance,0)-	coalesce(WD.Withdrawals,0)- coalesce(BUYORD.BuyOrders,0)+	coalesce(SELLORD.SellOrders,0) as AvailableBalance,
		coalesce(UCL.UnclearedCheques,0)as UnclearedCheques,
		coalesce(DEAL.DealsInProgress,0)as DealsInProgress,
		coalesce(FEE.FeeExpectations,0) as FeeExpectations
FROM 
			
				( select Q1.claccountid,Q2.ccycode from 
					(select subclaccountid as claccountid from clientaccount..consolidate
						where claccountid = @ClAccountId 
					) Q1
					cross join 
					(	--select ISOCode from res_db..currencyFormat where wrapenabled=1
						select distinct ccycode as ccycode from clientaccount.CashLedger.gladbankaccounts
					)Q2
				) CLIENTSANDCCY
			left Join  
                    	(Select	ClAccountID, CCYCode, -Sum(Amount) as CLTBalance
						From	ClientAccount.dbo.CashLedgerTransactions
						Where	LedgerDate <= @AsAt
						Group By ClAccountID, CCYCode) CLT on CLIENTSANDCCY.claccountid=CLT.claccountid and CLIENTSANDCCY.ccycode=CLT.ccycode 

			Left Join	(Select CLAccountID, Currency, Sum(Amount) as CMTBalance
						From	ClientAccount.dbo.CMTTrans 
						Where	TranDate <= @AsAt
						Group By CLAccountID, Currency) CMT On CMT.CLAccountID = CLIENTSANDCCY.CLAccountID And CMT.Currency = CLIENTSANDCCY.CCYCODE 

			Left Join	(Select ClAccountID, CcyCode, -Sum(Amount) as CLABalance
						From	ClientAccount.dbo.CashLedgerAdjustments
						Where LedgerDate <= @AsAt
						Group By ClAccountID, CcyCode) CLA On CLA.ClAccountID = CLIENTSANDCCY.ClAccountID And CLA.CcyCode = CLIENTSANDCCY.CCYCODE 

			Left Join	(Select ClAccountID, CcyCode, -Sum(Amount) as CLAAvailableAdjustBalance
						From	ClientAccount.dbo.CashLedgerAdjustments
						Where LedgerDate <= @AsAt and availableadjust = 1
						Group By ClAccountID, CcyCode) CLAAvailable On CLAAvailable.ClAccountID = CLIENTSANDCCY.ClAccountID And CLAAvailable.CcyCode = CLIENTSANDCCY.CCYCODE 

			Left Join	(Select ClAccountID, CcyCode, -Sum(Amount) as CLAPortfolioAdjustBalance
						From	ClientAccount.dbo.CashLedgerAdjustments
						Where LedgerDate <= @AsAt and portfolioadjust = 1
						Group By ClAccountID, CcyCode) CLAPortfolio On CLAPortfolio.ClAccountID = CLIENTSANDCCY.ClAccountID And CLAPortfolio.CcyCode = CLIENTSANDCCY.CCYCODE 

			Left Join	(Select CE.ClAccountID, CE.Currency, sum(CE.Amount) as Withdrawals
						From	Discovery.dbo.CashEntry CE
									inner join Discovery.dbo.Batch B on B.BatchID = CE.BatchID
									inner join Discovery.dbo.CashEntryStatus S on S.Status = CE.Status
						Where	Type = 'Withdrawal' and B.BatchType IN ('Auto','One-Off') and S.[Open] = 1 and 
								((B.StandingNextCashDate <= @AsAt) or B.StandingNextCashDate Is Null) 
						Group By CE.ClAccountID, CE.Currency) WD on WD.ClAccountID = CLIENTSANDCCY.ClAccountID And WD.Currency = CLIENTSANDCCY.CCYCode 


			Left Join	(Select OC.ClAccountID, OC.OrderSettCurrency, sum(OC.DisplayValue) as BuyOrders
						From	Discovery.dbo.OrderCurrent OC
									inner join Discovery.dbo.Batch B on B.BatchID = OC.BatchID
									inner join Discovery.dbo.OrderStatus S on S.Status = OC.Status
									left join Discovery..CashEntry CE ON OC.BatchID=CE.batchID
									left join res_db.dbo.ManagedFunds M on M.Instrumentcode = OC.InstrumentCode
						Where	OC.OrderBuySell = 'Buy' and B.BatchType IN ('Auto','One-Off') and S.[Open] = 1 and B.BatchID != @BatchID
								-- but ignore switches, conversionsa and insured fund
								and coalesce(M.insuredfund,0) <> 1 and OC.SwitchID Is Null and OC.ConversionID Is NULL
								and CE.batchid IS null
and		(coalesce(SwitchID,ConversionID) Is Null 
						or OC.PoolOrderID is not null or S.InProgress = 1)
						Group By OC.ClAccountID, OC.OrderSettCurrency
						Having	round(sum(OC.DisplayValue),2) <> 0) BUYORD on BUYORD.ClAccountID = CLIENTSANDCCY.ClAccountID And BUYORD.OrderSettCurrency  = CLIENTSANDCCY.CCYCODE 
			
			Left Join	(Select OC.ClAccountID, OC.OrderSettCurrency, sum(abs(OC.DisplayValue)) as SellOrders
						From	Discovery.dbo.OrderCurrent OC
									inner join Discovery.dbo.Batch B on B.BatchID = OC.BatchID
									inner join Discovery.dbo.OrderStatus S on S.Status = OC.Status
									left join res_db.dbo.ManagedFunds M on M.Instrumentcode = OC.InstrumentCode
						Where	OC.OrderBuySell = 'Sell' and B.BatchType IN ('Auto','One-Off') and S.[Open] = 1 and B.BatchID != @BatchID
								-- but ignore switches, conversionsa and insured fund
								and coalesce(M.insuredfund,0) <> 1 and OC.SwitchID Is Null and OC.ConversionID Is Null
						Group By OC.ClAccountID, OC.OrderSettCurrency
						Having	round(sum(OC.DisplayValue),2) <> 0) SELLORD on SELLORD.ClAccountID = CLIENTSANDCCY.ClAccountID And SELLORD.OrderSettCurrency  = CLIENTSANDCCY.CCYCODE 
			
			Left Join	(Select OC.ClAccountID, OC.OrderSettCurrency, sum(abs(OC.DisplayValue)) as SellOrdersSameBatch
						From	Discovery.dbo.OrderCurrent OC
									inner join Discovery.dbo.Batch B on B.BatchID = OC.BatchID
									inner join Discovery.dbo.OrderStatus S on S.Status = OC.Status
									left join res_db.dbo.ManagedFunds M on M.Instrumentcode = OC.InstrumentCode
						Where OC.OrderBuySell = 'Sell' and B.BatchType IN ('Auto','One-Off') and OC.Status  IN ('Created','Confirmed','Authorised','Pooled','Placed') and  OC.ClAccountID = @ClAccountID and B.BatchID = @BatchID 
						Group By OC.ClAccountID, OC.OrderSettCurrency
						Having	round(sum(OC.DisplayValue),2) <> 0) SELLORDSAMEBATCH on SELLORDSAMEBATCH.ClAccountID = CLIENTSANDCCY.ClAccountID And SELLORDSAMEBATCH.OrderSettCurrency  = CLIENTSANDCCY.CCYCODE

			Left Join	(Select ClAccountID, CcyCode, -Sum(Amount) as UnclearedCheques
						From	ClientAccount.dbo.CashLedgerAdjustments
						Where LedgerDate <= @AsAt And AdjustmentType = 'UNCLEARED_CHEQUE'
						Group By ClAccountID, CcyCode) UCL On UCL.ClAccountID = CLIENTSANDCCY.ClAccountID And UCL.CcyCode = CLIENTSANDCCY.CCYCODE 
			
			Left Join	(Select OC.ClAccountID, OC.OrderSettCurrency, sum(OC.DisplayValue) as DealsInProgress
						From	Discovery.dbo.OrderCurrent OC
									inner join Discovery.dbo.Batch B on B.BatchID = OC.BatchID
									inner join Discovery.dbo.OrderStatus S on S.Status = OC.Status
									left join res_db.dbo.ManagedFunds M on M.Instrumentcode = OC.InstrumentCode
						Where	B.BatchType IN ('Auto','One-Off') and B.BatchID != @BatchID
								and (S.[InProgress] = 1 or OC.Status = 'Authorised' and OC.PoolOrderID is not null)
								-- but ignore switches, conversionsa and insured fund
								and coalesce(M.insuredfund,0) <> 1 and OC.SwitchID Is Null and OC.ConversionID Is Null
						Group By OC.ClAccountID, OC.OrderSettCurrency
						Having	round(sum(OC.DisplayValue),2) <> 0) DEAL on DEAL.ClAccountID = CLIENTSANDCCY.ClAccountID And DEAL.OrderSettCurrency  = CLIENTSANDCCY.CCYCODE 
			
			Left Join	(Select ARL.ClAccountID, 'GBP' as CcyCode, Sum(ARL.NetAmount) as FeeExpectations
						From	Discovery.dbo.AdvisorRevenueLedger ARL INNER JOIN
								ClientDetails CD ON ARL.ClAccountID = CD.ClAccountID INNER JOIN
								Company CO ON CD.Company = CO.Company LEFT JOIN
								FeeTranTypes FTT ON ARL.TranType = FTT.TranType AND FTT.WrapProvider = CO.WrapProvider
						Where coalesce(ARL.Reversed,0)<>1 and 
							  ARL.TranType <> 'Advisor FBRC Charge' and
							  ARL.AsAt <= @AsAt AND ARL.GLPosted = 'NO' and 
							  (ARL.PendingAdvisorPost = 'YES' OR FTT.IncludeUnauthorisedFeesInAvailCash = 1)
						Group By ARL.ClAccountID) FEE On FEE.ClAccountID = CLIENTSANDCCY.ClAccountID
GO
