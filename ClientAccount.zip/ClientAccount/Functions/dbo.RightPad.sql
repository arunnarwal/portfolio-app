SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[RightPad]

(@string varchar(100), @length int,@character char)

RETURNS varchar(max)

AS

BEGIN

DECLARE @result varchar(max)

SELECT @result =

CASE WHEN len(@String) < @length 

THEN @string + replicate(@character, @length - len(@string)) 

ELSE

RIGHT(@string,@length)

END

RETURN @result

END
GO
