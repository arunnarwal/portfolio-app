﻿create function dbo.fnGetFeeScheduleIdOfModelAccount(@ClAccountId VarChar(20)) 
Returns @outputTable Table (FeeScheduleID int) 
AS

Begin
--declare @ClAccountId VarChar(20); set @claccountid = 'DM1003002'
declare @portfolioId int; set @portfolioId = (select portfolioid from discovery..clientaccount where claccountid = @claccountid)
declare @EntityOwnerId int; set @EntityOwnerId = (select externalHierarchyEntityId from clientaccount..ExternalHierarchyEntityAccountMapping
where claccountid = @claccountid)

declare @FeeScheduleID int;
declare @Level int; set @Level = (select  HierarchyLevel
from clientaccount..ExternalHierarchyEntity where id = @EntityOwnerId)

if @Level = 1
	begin
		set @FeeScheduleID = (select FeeScheduleID
		from clientaccount..ModelPortfolioExternalEntityScheduleMapping Map
			where Map.ExternalEntityID = @EntityOwnerId
			and map.Modelportfolioid = @portfolioId)
	end
else if @Level = 2
	begin
		set @FeeScheduleID = (
		select coalesce(Map2.FeeScheduleID,Map1.FeeScheduleID) as FeeScheduleID from clientaccount..vwExternalHierarchyEntityLevel2 L2 
		left outer join clientaccount..ModelPortfolioExternalEntityScheduleMapping Map2
			on Map2.ExternalEntityID = L2.IdLevel2
			and map2.Modelportfolioid = @portfolioId
		left outer join clientaccount..ModelPortfolioExternalEntityScheduleMapping Map1
			on Map1.ExternalEntityID = L2.IdLevel1
			and map1.Modelportfolioid = @portfolioId
		where L2.IdLevel2 = @EntityOwnerId)
	end
else if @Level = 3 
	begin
		set @FeeScheduleID = (
		select coalesce(map3.FeeScheduleID,Map2.FeeScheduleID,Map1.FeeScheduleID) as FeeScheduleID from clientaccount..vwExternalHierarchyEntityLevel3 L3 
		left outer join clientaccount..ModelPortfolioExternalEntityScheduleMapping Map3
			on Map3.ExternalEntityID = L3.IdLevel3
			and map3.Modelportfolioid = @portfolioId
		left outer join clientaccount..ModelPortfolioExternalEntityScheduleMapping Map2
			on Map2.ExternalEntityID = L3.IdLevel2
			and map2.Modelportfolioid = @portfolioId
		left outer join clientaccount..ModelPortfolioExternalEntityScheduleMapping Map1
			on Map1.ExternalEntityID = L3.IdLevel1
			and map1.Modelportfolioid = @portfolioId
		where L3.IdLevel3 = @EntityOwnerId	)
			
	end
else if @Level = 4 
	begin
	set @FeeScheduleID = (
		select coalesce(map4.FeeScheduleID,map3.FeeScheduleID,Map2.FeeScheduleID,Map1.FeeScheduleID) as FeeScheduleID from clientaccount..vwExternalHierarchyEntityLevel4 L4
		left outer join clientaccount..ModelPortfolioExternalEntityScheduleMapping Map4
			on Map4.ExternalEntityID = L4.IdLevel3		
			and map4.Modelportfolioid = @portfolioId
		left outer join clientaccount..ModelPortfolioExternalEntityScheduleMapping Map3
			on Map3.ExternalEntityID = L4.IdLevel3
			and map3.Modelportfolioid = @portfolioId
		left outer join clientaccount..ModelPortfolioExternalEntityScheduleMapping Map2
			on Map2.ExternalEntityID = L4.IdLevel2
			and map2.Modelportfolioid = @portfolioId
		left outer join clientaccount..ModelPortfolioExternalEntityScheduleMapping Map1
			on Map1.ExternalEntityID = L4.IdLevel1
			and map1.Modelportfolioid = @portfolioId
		where L4.IdLevel4 = @EntityOwnerId
		)

	end
	else
		set @FeeScheduleID = 0

insert into @outputTable(feeScheduleID) select @FeeScheduleID
return
end
	


