SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- =============================================
-- Author:  Ben Arnold
-- Create date: 2007-01-16
-- Description: Returns 1 if Date is within
--              the range FromDate..ToDate,
--              inclusive, otherwise returns 0.
--              The time portion of all three
--              dates is ignored.
-- =============================================
CREATE FUNCTION [dbo].[IsDateBetween] 
(
 @Date DATETIME,
 @FromDate DATETIME,
 @ToDate DATETIME
)
RETURNS TINYINT
AS
BEGIN
 DECLARE @Result TINYINT
 SELECT @Result = 
  CASE WHEN @Date >= dbo.TruncateDate(@FromDate)
   AND @Date < dbo.TruncateDate(@ToDate + 1)
  THEN 1
  ELSE 0
  END
 RETURN @Result
END
GO
