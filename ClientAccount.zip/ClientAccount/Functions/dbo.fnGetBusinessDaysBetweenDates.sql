/*
<Function>
    <Description>
		Get the number of business days in the given date range [@startDate ... @endDate).
	</Description>
    <Parameters>
        <Parameter Name="@startDate">
            <Description>The start date (inclusive).</Description>
        </Parameter>
		<Parameter Name="@endDate">
            <Description>The start date (exclusive).</Description>
        </Parameter>
		<Parameter Name="@countryCode">
            <Description>The country code of the holiday calendar.</Description>
        </Parameter>
    </Parameters>
</Function>
*/
CREATE FUNCTION dbo.fnGetBusinessDaysBetweenDates(
	@startDate AS DATE,
	@endDate AS DATE,
	@countryCode AS VARCHAR(6) = 'GB') 
RETURNS
	INT
AS
BEGIN
	DECLARE @holidayCount INT
	SELECT 
		@holidayCount = COUNT(1)
	FROM LiveDB.dbo.vwHolidaySchedule H
	WHERE H.HolDate >= @StartDate
	AND H.HolDate < @endDate
	-- Exclude weekends
	AND DATEPART(dw, HolDate) NOT IN (1,7)
	AND CountryCode = @countryCode

	DECLARE @days AS INT = DATEDIFF(dd, @startDate, @endDate)
	-- DATEDIFF(wk) counts all transitions from Saturday to Sunday, even partial weeks. See DATEDIFF(wk,'2019-06-15','2019-06-16').
	DECLARE @weekendDays AS INT = DATEDIFF(wk, @startDate, @endDate) * 2
		-- Need to count the starting Sunday since there is no Saturday to Sunday transition.
		+ (CASE WHEN DATEPART(dw, @startDate) = 1 THEN 1 ELSE 0 END)
		-- Need to uncount ending Sunday since we are exclusive of end date.
		+ (CASE WHEN DATEPART(dw, @endDate) = 1 THEN -1 ELSE 0 END)

	RETURN @days - @weekendDays - @holidayCount
END
