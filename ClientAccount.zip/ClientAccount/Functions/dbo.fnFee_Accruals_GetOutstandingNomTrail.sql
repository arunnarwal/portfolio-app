CREATE FUNCTION [dbo].[fnFee_Accruals_GetOutstandingNomTrail](@ChargeDate datetime, @WrapProvider varchar(20)) Returns TABLE AS


--declare @ChargeDate datetime
--declare @WrapProvider varchar(20)

--SET @WrapProvider = 'OM'
--SET @ChargeDate = '01 may 2018'
-- ;

RETURN

WITH FADTOTALS AS (
	SELECT	FAD.SubAccountId,
			SECA.CLAccountID,
			SECA.PrimaryAdviser,
			FAD.ChargeDate,
			C.Company,
			C.WrapProvider,
			ROUND(SUM(FAD.Amount), 2) AS TotalAmount,
			DATEADD(MONTH, DATEDIFF(MONTH, 0, FAD.ChargeDate)-1, 0) AS FromDate, --First day of previous month based on ChargeDate
			DATEADD(MONTH, DATEDIFF(MONTH, -1, FAD.ChargeDate)-1, -1) As ToDate, --Last Day of previous month based on ChargeDate
			AVG(FAD.Valuation) as Valuation,
			AVG(FAD.Rate) as Rate,
			FAD.CurrencyId			
	FROM dbo.Fee_Accrual_NominatedTrail AS FAD
	INNER JOIN dbo.SEClientAccount AS SECA 
		ON SECA.Id = FAD.SubAccountId
	INNER JOIN dbo.ClientDetails AS CD 
		ON SECA.ClAccountId = CD.ClAccountId
	INNER JOIN dbo.Company AS C 
		ON C.Company = CD.Company

	WHERE FAD.ChargeDate <= @ChargeDate 
			AND FAD.ISProcessed = 0
			AND C.WrapProvider = @WrapProvider 
	GROUP BY FAD.SubAccountId,
			SECA.CLAccountID,
			SECA.PrimaryAdviser,
			FAD.ChargeDate,
			C.WrapProvider,
			C.Company,
			FAD.CurrencyId
	HAVING ROUND(SUM(FAD.Amount), 2) <> 0
)

SELECT	FADTOTALS.ClAccountId,
		FADTOTALS.ClAccountId As DestinationClAccountID,
		FADTOTALS.PrimaryAdviser,
		FADTOTALS.Company, 
		FADTOTALS.WrapProvider, 
		CA.SubAccountType, 
		'NomTrail' AS [Type], --probably remove
		'NomTrail' AS Category, 
		FADTOTALS.ChargeDate,
		FADTOTALS.FromDate,
		FADTOTALS.ToDate,
		PD.ProductType,
		FADTOTALS.TotalAmount,
		FADTOTALS.Valuation,
		FADTOTALS.Rate,
		FADTOTALS.CurrencyId
FROM FADTOTALS 
	INNER JOIN Discovery.dbo.ProductDetails AS PD 
		ON FADTOTALS.ClAccountId = PD.ClAccountId 
	INNER JOIN Discovery.dbo.ClientAccount AS CA 
		ON FADTOTALS.ClAccountId = CA.ClAccountId
	WHERE CA.Status = 'Active'
GO