SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE FUNCTION [dbo].[fnAccountValueForDim](@AsAt datetime, @Location varchar(10), @Currency char(3), @PriceAsAt datetime) RETURNS TABLE AS

RETURN

SELECT C.CLAccountID,sum(Amount * coalesce(fx2.a, 1) / coalesce(fx1.a,1)) as ProductValue 

FROM (SELECT ST.ClAccountID,

I.InstrumentCCY as CCYCode,

sum(ST.quantity * S.O) as Amount

FROM dbo.ScripTransactions ST 

INNER JOIN res_db.dbo.instruments I ON ST.InstrumentCode = I.security 

INNER JOIN res_db.dbo.securities S on I.security = S.security AND S.Date = @PriceAsAt

WHERE ST.AsAt < dateadd(d,1,@AsAt) AND ST.TransStatus = 'Settled' 

and (replace(ST.Location,'BTA','Custody') = @Location 
	or @Location = 'ALL'
	or (ST.Location = 'Registry' AND I.SecurityType = 'Model' AND I.SecuritySubType = 'Platform Fund'))

GROUP BY ST.ClAccountID, I.InstrumentCCY

HAVING sum(ST.quantity) <> 0

UNION ALL

SELECT CLT.CLAccountID, rtrim(CLT.CCYcode) CCYCode, -round(sum(CLT.Amount),2) Amount

FROM CashLedgerTransactions CLT 

WHERE CLT.LedgerDate < dateadd(d,1,@AsAt)

GROUP BY CLT.CLAccountID, CLT.CCYCode

UNION ALL

SELECT CLA.ClAccountID, rtrim(CLA.CCYcode) CCYCode, -round(sum(CLA.Amount),2) Amount

FROM dbo.CashLedgerAdjustments CLA

WHERE CLA.LedgerDate < dateadd(d,1,@AsAt)

GROUP BY CLA.ClAccountID, CLA.CCYCode

UNION ALL

SELECT CMT.ClAccountID, rtrim(CMT.currency) CCYCode, round(sum(CMT.amount),2) Amount

FROM dbo.CMTTrans CMT

WHERE CMT.trandate < dateadd(d,1,@AsAt)

GROUP BY CMT.ClAccountID, CMT.currency

UNION ALL

SELECT CT.ClAccountID, rtrim(CT.cncycode) CCYCode, round(sum(CT.amount),2) Amount

FROM dbo.cashtransactions CT

WHERE asat < dateadd(d,1,@AsAt) and transstatus <> 'cancelled' and CT.location = 'external'

and @Location in ('External','All')

GROUP BY CT.ClAccountID, CT.cncycode) Amounts

inner join clientaccount..consolidate c

on c.subclaccountid = amounts.claccountid

and c.subclaccountid <> c.claccountid

LEFT JOIN res_db.dbo.securities Fx1 on Fx1.Security = Amounts.CCYCode + 'USD' and Fx1.date = @PriceAsAt

LEFT JOIN res_db.dbo.securities Fx2 on Fx2.Security = @Currency + 'USD' and Fx2.date = @PriceAsAt

GROUP BY c.ClAccountID
GO
