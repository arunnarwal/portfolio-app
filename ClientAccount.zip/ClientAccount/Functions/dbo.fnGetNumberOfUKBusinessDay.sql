CREATE FUNCTION [dbo].[fnGetNumberOfUKBusinessDay](@DateFrom as dateTime = NULL, @DateTo as datetime = NULL) 
RETURNS
	int
AS
BEGIN
	
SET @DateFrom =   DATEDIFF(dd, 0, @DateFrom)
SET @DateTo =   DATEDIFF(dd, 0, @DateTo)
DECLARE @Date DateTime
--exlude dateFrom
SET @Date = @DateFrom + 1

DECLARE @Counter int
SET @Counter = 0

DECLARE @WeekDay int

while @Date <= @DateTo
BEGIN
	SET @WeekDay = datepart(dw,@Date)
	IF @WeekDay <> 1
		AND @WeekDay <> 7
		AND NOT EXISTS (SELECT * FROM LiveDB.dbo.HolidaySchedule WHERE HolDate = @Date AND CountryCode = 'GB')
	BEGIN
		SET @Counter = @Counter + 1
	END
	
	SET @Date = @Date + 1
END
	RETURN @Counter
END

GO