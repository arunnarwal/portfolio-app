CREATE FUNCTION [dbo].fnIsAnniversaryByMonthInterval
               (@actualDate    AS DATETIME,
                @comparedDate  AS DATETIME,
                @monthInterval AS TINYINT)
RETURNS BIT
AS
  BEGIN
/*
 USE ClientAccount

 DECLARE @actualDate    AS DATETIME
 DECLARE @comparedDate  AS DATETIME
 DECLARE @monthInterval AS TINYINT

 SET @actualDate    = '2014-08-14'
 SET @comparedDate  = '2014-02-14 13:34:56.093'
 SET @monthInterval = 6
-- */

    -- strip off the time
    SET @actualDate = DATEADD(DAY, DATEDIFF(DAY, 0, @actualDate), 0)
    SET @comparedDate = DATEADD(DAY, DATEDIFF(DAY, 0, @comparedDate), 0)

    DECLARE @result AS BIT
    SET @result = 0

    IF @actualDate != @comparedDate -- not created today
    BEGIN
      DECLARE @deltaMonth AS TINYINT
      SET @deltaMonth = DATEDIFF(MONTH, @comparedDate, @actualDate)

      DECLARE @modulo AS TINYINT
      SET @modulo = @deltaMonth % @monthInterval

      IF @modulo = 0 AND DAY(@actualDate) = DAY(@comparedDate) -- anniversary
      BEGIN
        SET @result = 1
      END
    END

    RETURN @result
  END
