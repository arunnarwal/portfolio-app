SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE FUNCTION [dbo].[fnPSDRptJPMBatchHasInvestmentTrust]() RETURNS TABLE AS

RETURN

SELECT OC.BatchID, 1 AS HASInvestTrust, SUM(OrderValue) AS InvestTrustBatchTotal
FROM Discovery..OrderCurrent OC
	INNER JOIN Res_Db..Instruments INS
		ON OC.Instrumentcode = INS.Security 
WHERE SecuritySubType = 'Invest Trust' 
GROUP BY OC.BatchID
GO
