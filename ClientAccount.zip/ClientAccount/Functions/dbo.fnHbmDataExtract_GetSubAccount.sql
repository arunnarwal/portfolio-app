CREATE FUNCTION [dbo].[fnHbmDataExtract_GetSubAccount] ()
RETURNS @OutputTable TABLE (
	ClAccountId VARCHAR(20),
	HeadClAccountId VARCHAR(20),
	ProductDisplayName VARCHAR(100),
	DateCreated DATETIME,
	Status VARCHAR(20),
	CrystallisationDate DATETIME,
	CrystallisationStatus VARCHAR(20),
	CrystallisationPercentSplit DECIMAL(18,2),
	PSTRNumber VARCHAR(20),
	ProductType VARCHAR(50),
	LedgerBalance MONEY,
	DrawdownType VARCHAR(50),
	IsIncomeTakenFromSubAccount BIT,
	IncomeCommencementDate DATETIME,
	IsCappedToFlexiSwap BIT,
	CappedDrawdownReferencePeriodStartDate DATETIME,
	CappedDrawdownReferencePeriodEndDate DATETIME,
	LastBenefitCrystallisationReviewDate DATETIME,
	LastBenefitCrystallisationReviewStatus VARCHAR(30)) 
AS
BEGIN

DECLARE @Accounts TABLE (SubAccount VARCHAR(20));
DECLARE @WrapProviderTemp VARCHAR(3);

SELECT @WrapProviderTemp = 'HBM';

INSERT INTO @Accounts(SubAccount)
SELECT SubAccount
FROM dbo.vwSuperiorHierarchyEntitiesForSubAccounts
WHERE WrapProvider = @WrapProviderTemp;



DECLARE @FirstWithdrawals TABLE (ClAccountId VARCHAR(20), FirstDate DATETIME);

INSERT INTO @FirstWithdrawals(ClAccountId, FirstDate)
SELECT A.SubAccount, MIN(CE.DateCompleted) AS FirstDate
FROM @Accounts A
INNER JOIN Discovery.dbo.CashEntry CE 
ON CE.ClAccountId = A.SubAccount AND CE.Type = 'Withdrawal' AND CE.Status = 'Completed'
GROUP BY A.SubAccount;



DECLARE @AccountsBalances TABLE (ClAccountId VARCHAR(20), Balance MONEY);

INSERT INTO @AccountsBalances(ClAccountId, Balance)
SELECT SECA.ClAccountId, Cash.Balance
FROM Cache.dbo.Trans_CMTTrans_ByAccount Cash
INNER JOIN dbo.SEClientAccount SECA ON SECA.Id = Cash.SECAId
WHERE Cash.ToDate = 0xFFFFFF;



DECLARE @LastPensionDrawdownEvents TABLE (SubClAccountId VARCHAR(20), Description VARCHAR(50), DateCompleted DATETIME);

INSERT INTO @LastPensionDrawdownEvents (SubClAccountId, Description, DateCompleted)
SELECT PDE.SubClAccountId, PDE.Description, PDE.DateCompleted 
FROM dbo.PensionDrawdownEvents PDE
INNER JOIN (
	SELECT SubClAccountId, MAX(DateCompleted) AS LastDateCompleted, MAX(Id) AS Id  
	FROM dbo.PensionDrawdownEvents
	GROUP BY SubClAccountId
) AS LastPDE ON PDE.Id = LastPDE.Id;



DECLARE @LastScripTransferRequests TABLE (ClAccountId VARCHAR(20), ArrangementType VARCHAR(50), FlexibleDrawdown BIT);

INSERT INTO @LastScripTransferRequests
SELECT LastSTRE.ClAccountId, LastSTRE.ArrangementType, LastSTRE.FlexibleDrawdown FROM Discovery.dbo.ScripTransferRequest LastSTRE
INNER JOIN (
	SELECT ClAccountId, MAX(Id) AS Id
	FROM Discovery.dbo.ScripTransferRequest 
	GROUP BY ClAccountId
) AS STRE ON LastSTRE.Id = STRE.Id;

DECLARE @LastBenefitCrystallisationReviewStatuses TABLE (ClAccountId VARCHAR(20), Status VARCHAR(30), LastUpdated DATETIME, SubClAccountId varchar(50));

INSERT INTO @LastBenefitCrystallisationReviewStatuses
SELECT WWCS.ClAccountId, WWCS.Status, WWCS.LastUpdated, WWCSLAST.SubClAccountId
FROM dbo.WorkflowWizardClientSession WWCS
INNER JOIN (
	SELECT MAX(LastUpdated) AS MaxLastUpdated, REPLACE(SessionParameters, 'SubClAccountID=', '') As SubClAccountId	
	FROM dbo.WorkflowWizardClientSession
	WHERE WizardID = 269 and Status <> 'New' 
	GROUP BY SessionParameters
) AS WWCSLAST ON WWCS.LastUpdated = WWCSLAST.MaxLastUpdated

DECLARE @LastBenefitCrystallisationReviewCompleted TABLE (ClAccountId VARCHAR(20), Status VARCHAR(30), LastUpdated DATETIME, SubClAccountId varchar(50));

INSERT INTO @LastBenefitCrystallisationReviewCompleted
SELECT WWCS.ClAccountId, WWCS.Status, WWCS.LastUpdated, WWCSLAST.SubClAccountId
FROM dbo.WorkflowWizardClientSession WWCS
INNER JOIN (
	SELECT MAX(LastUpdated) AS MaxLastUpdated, REPLACE(SessionParameters, 'SubClAccountID=', '') As SubClAccountId	
	FROM dbo.WorkflowWizardClientSession
	WHERE WizardID = 269 and Status = 'COMPLETE' 
	GROUP BY SessionParameters
) AS WWCSLAST ON WWCS.LastUpdated = WWCSLAST.MaxLastUpdated


INSERT INTO @OutputTable(
	ClAccountId,
	HeadClAccountId,
	ProductDisplayName,
	DateCreated,
	Status,
	CrystallisationDate,
	CrystallisationStatus,
	CrystallisationPercentSplit,
	PSTRNumber,
	ProductType,
	LedgerBalance,
	Drawdowntype,
	IsIncomeTakenFromSubAccount,
	IncomeCommencementDate,
	IsCappedToFlexiSwap,
	CappedDrawdownReferencePeriodStartDate,
	CappedDrawdownReferencePeriodEndDate, 
	LastBenefitCrystallisationReviewDate, 
	LastBenefitCrystallisationReviewStatus) 
SELECT 
	PD.ClAccountId,
	PD.HeadClAccountId,
	PD.ProductDisplayName,
	PD.DateCreated,
	PD.Status,
	CASE WHEN PD.ArrangementType = 'Crystallised'
		THEN ISNULL(PDE.DateCompleted, PD.DateCreated)
		ELSE NULL
	END AS CrystallisationDate,
	PD.ArrangementType AS CrystallisationStatus,
	0 AS CrystallisationPercentSplit,
	'<new build>' AS PSTRNumber,
	APS.SchemeName AS ProductType,
	ISNULL(AB.Balance, 0) AS LedgerBalance,
	CASE WHEN STRE.ArrangementType = 'Crystallised' AND STRE.FlexibleDrawdown = 1 
		THEN 'Flexi-Access' 
		ELSE 'Capped'
	END AS DrawdownType,
	CASE WHEN RW.Id IS NOT NULL 
		THEN 1
		ELSE 0
	END AS IsIncomeTakenFromSubAccount,
	F.FirstDate AS IncomeCommencementDate,
	PD.FlexibleDrawdown AS IsCappedToFlexiSwap,+
	CASE WHEN NOT STRE.ArrangementType = 'Crystallised' AND STRE.FlexibleDrawdown = 1
		THEN SD.PensionYearStart
		ELSE NULL
	END AS CappedDrawdownReferencePeriodStartDate,
		CASE WHEN NOT STRE.ArrangementType = 'Crystallised' AND STRE.FlexibleDrawdown = 1
		THEN SD.ReferencePeriodEndDate
		ELSE NULL
	END AS CappedDrawdownReferencePeriodEndDate,
	LBCC.LastUpdated AS LastBenefitCrystallisationReviewDate, 
	LBC.Status As LastBenefitCrystallisationReviewStatus
FROM @Accounts A
INNER JOIN Discovery.dbo.vwProductDetails PD ON A.SubAccount = PD.ClAccountId
LEFT JOIN @AccountsBalances AB ON AB.ClAccountId = A.SubAccount
LEFT JOIN @LastPensionDrawdownEvents PDE ON A.SubAccount = PDE.SubClAccountId
LEFT JOIN @FirstWithdrawals F ON F.ClAccountId = A.SubAccount
LEFT JOIN dbo.vwAccountPensionScheme APS ON PD.HeadClAccountId = APS.AccountId
LEFT JOIN dbo.SippDetails SD ON PD.ClAccountId = SD.ClAccountId
LEFT JOIN @LastScripTransferRequests STRE ON PD.ClAccountId = STRE.ClAccountId
LEFT JOIN @LastBenefitCrystallisationReviewCompleted LBCC ON PD.ClAccountID = LBCC.SubClAccountId
LEFT JOIN @LastBenefitCrystallisationReviewStatuses LBC ON PD.ClAccountID = LBC.SubClAccountId
OUTER APPLY (
	SELECT MAX(Id) AS Id
	FROM Discovery.dbo.RegularWithdrawals 
	WHERE ClAccountId = A.SubAccount AND Status != 'Cancelled'
) RW

RETURN END
