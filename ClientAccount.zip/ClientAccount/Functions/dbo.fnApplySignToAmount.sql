/***
<Function>
	<Description>Applies sign to amount. Returns amount when sign is '+' and amount * -1 when sign is '-'.</Description>
	<Parameters>
		<Parameter Name="@Sign">
			<Description>Sign which should be applied.</Description>
		</Parameter>
		<Parameter Name="@Amount">
			<Description>Amount to which sign should be applied.</Description>
		</Parameter>
	</Parameters>
</Function>
***/

CREATE FUNCTION [dbo].[fnApplySignToAmount] (@Sign AS CHAR(1), @Amount AS MONEY) RETURNS MONEY
AS
BEGIN
	RETURN CASE
			   WHEN @Sign = '+' THEN @Amount
			   WHEN @Sign = '-' THEN @Amount * -1
		   END
END