/*
<Function>
    <Description>Function to determine whether the instruction with specified ID and type exists</Description>
    <Parameters>
        <Parameter Name="@InstructionId">
            <Description>Id of the instruction</Description>
        </Parameter>
		<Parameter Name="@InstructionTypeId">
            <Description>Id of the instruction type</Description>
        </Parameter>		
    </Parameters>
</Function>
*/
CREATE FUNCTION [dbo].[fnCheckBusinessInstruction](
	@InstructionId AS INT , @InstructionTypeId AS INT
)
RETURNS INT
AS
	BEGIN
	DECLARE  @Counts INT
	SELECT @Counts=count(1)
	FROM
		Platform.Instructions.fnGetTopLevelInstruction(@InstructionId) ti
	CROSS APPLY
		Platform.Instructions.fnGetInstructionsByTopLevelInstruction(ti.InstructionId) i
	WHERE i.InstructionTypeId = @InstructionTypeId
	RETURN @Counts
	END
GO
