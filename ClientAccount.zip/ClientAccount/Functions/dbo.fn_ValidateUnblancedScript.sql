

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[fn_ValidateUnblancedScript]()
RETURNS @valTable TABLE(tabvalue Integer)
AS
BEGIN
	
IF (
SELECT COUNT(*) FROM (
SELECT CLAccountId
FROM dbo.ScripTransactions
WHERE Transstatus = 'Settled' AND Cutover = 1
AND (claccountid like 'ax%' OR claccountid like 'el%')
AND Location = 'Custody'
GROUP BY CLAccountId, InstrumentCode
having abs(sum(quantity * cost * COALESCE(fxcost,1))) > 0) x) > 0
BEGIN
	BEGIN
		INSERT INTO @valTable(tabvalue) 
		VALUES(1)
	END
 END

return 

END
GO
