SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE Function [dbo].[fn_FeeAssetSummariesWithUnclearedCash](@AsAt datetime) RETURNS TABLE AS

RETURN

--declare @asat as datetime
--set @asat='25 feb 2010'
SELECT  fas.AsAt, fas.Company, fas.ClAccountID, fas.HeaderClAccountID, 
SUM(fas.TotalHolding) TotalHolding,
fas.TotalCash fasTotalCash, 
COALESCE(sum(unclearedCash.TotalUnclearedCash), 0) unclearedCash,
COALESCE(sum(unclearedCheques.TotalUnclearedCash), 0) unclearedCheque, 
fas.TotalCash  + COALESCE(sum(unclearedCash.TotalUnclearedCash), 0)  + COALESCE(sum(unclearedCheques.TotalUnclearedCash), 0) as TotalCash
FROM ClientAccount..FeeAssetSummaries fas
			LEFT JOIN (
					SELECT ClAccountID, SUM(Amount) As TotalUnclearedCash
					FROM CashLedgerTransactions
					WHERE RestrictSweepUntil IS NOT NULL 
						AND MovementType IN ('FUND_APPLICATION', 'FUND_REDEMPTION', 'BUY_TRADE','SELL_TRADE')
						And (@AsAt >= RestrictSweepUntil or RestrictSweepUntil is null)
					GROUP BY ClAccountID
			) unclearedCash on unclearedCash.ClAccountID=FAS.ClAccountID and FAS.AsAt=@asat
			LEFT JOIN (
					SELECT CLAccountID, SUM(Amount) as TotalUnclearedCash
					FROM CashLedgerAdjustments
					WHERE AdjustmentType = 'UNCLEARED_CHEQUE'
					and  Ledgerdate <=@AsAt
					GROUP BY CLAccountID
			) unclearedCheques on unclearedCheques.ClAccountID=FAS.ClAccountID and FAS.AsAt = @asat
Where FAS.AsAt = @asat 
GROUP BY fas.AsAt, fas.Company, fas.ClAccountID, fas.HeaderClAccountID, fas.TotalCash
GO
