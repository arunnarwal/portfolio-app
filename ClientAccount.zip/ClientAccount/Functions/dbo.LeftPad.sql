SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[LeftPad]

(@string varchar(100), @length int,@character char)

RETURNS varchar(max)

AS

BEGIN

DECLARE @result varchar(max)

SELECT @result =

CASE WHEN len(@String) < @length 

THEN replicate(@character, @length - len(@string)) + @string 

ELSE

LEFT(@string,@length)

END

RETURN @result

END
GO
