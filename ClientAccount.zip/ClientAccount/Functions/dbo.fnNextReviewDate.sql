SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[fnNextReviewDate] (@StartDate datetime, @ReviewDate datetime, @YearsBetweenReview int)
	RETURNS datetime
AS
BEGIN
	DECLARE @Temp datetime
	SET @Temp = dateadd(year, @YearsBetweenReview, @StartDate)
	WHILE (@Temp < @ReviewDate)
	BEGIN
		SET @Temp = dateadd(year, @YearsBetweenReview, @Temp)
	END
	RETURN @Temp
END
GO
