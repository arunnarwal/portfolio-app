SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[fnGroup1Group2Split] (@claccountid varchar(14), @instrumentcode varchar(20)) RETURNS TABLE AS

RETURN
SELECT CLAccountID, InstrumentCode, sum(quantity) as Quantity,

SUM(case when group1group2 = 1 then quantity else 0 end) as Group1Holding,

SUM(case when group1group2 = 2 then quantity else 0 end) as Group2Holding

FROM ClientAccount..ScripTransactions

WHERE CLAccountID = @claccountid 
and InstrumentCode =@instrumentcode
and transstatus = 'Settled'

GROUP BY CLAccountID, InstrumentCode

HAVING SUM(Quantity) <> 0
GO
