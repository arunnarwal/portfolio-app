/*USE ClientAccount;
GO
DROP FUNCTION dbo.GetLinkedValuation
GO*/
CREATE FUNCTION dbo.GetLinkedValuation(@AsAt datetime)
RETURNS TABLE
AS
/*declare @CLAccountID varchar(20)
set @CLAccountID = 'CL1001182' 
declare @AsAt Datetime
set @AsAt = '1 April 2013'*/
return select ACC.LinkAccount,SUM(CASE 
					WHEN COALESCE(FUM.Cash_MVAfterFX, 0) > 0
						THEN COALESCE(FUM.Cash_MVAfterFX, 0) * INC.IncludeCash
					ELSE 0
					END + CASE 
					WHEN COALESCE(FUM.FTD_MVAfterFX, 0) > 0
						THEN COALESCE(FUM.FTD_MVAfterFX, 0) * INC.IncludeFTD
					ELSE 0
					END + CASE 
					WHEN COALESCE(FUM.MF_MVAfterFX, 0) > 0
						THEN COALESCE(FUM.MF_MVAfterFX, 0) * INC.IncludeManagedFunds
					ELSE 0
					END + CASE 
					WHEN COALESCE(FUM.PF_MVAfterFX, 0) > 0
						THEN COALESCE(FUM.PF_MVAfterFX, 0) * INC.IncludePlatformFunds
					ELSE 0
					END + CASE 
					WHEN COALESCE(FUM.EqBnd_MVAfterFX, 0) > 0
						THEN COALESCE(FUM.EqBnd_MVAfterFX, 0) * INC.IncludeEquity
					ELSE 0
					END + CASE 
					WHEN COALESCE(FUM.ExtCash_MVAfterFX, 0) > 0 * CD.Discretionary
						THEN COALESCE(FUM.ExtCash_MVAfterFX, 0)
					ELSE 0
					END + CASE 
					WHEN COALESCE(FUM.PH_MVAfterFX, 0) > 0
						THEN COALESCE(FUM.PH_MVAfterFX, 0) * CONVERT(INT, COALESCE(CLA.ExternalSystemIdentifier5, 0))
					ELSE 0
					END)  AS  LinkedValuation from ClientAccount..UnprocessedFUMFees_ByAcc as FUM --this will have to be changed to UNPROCESSED
CROSS APPLY [ClientAccount].dbo.[fnGetLinkedAccounts](FUM.HeadAccount) AS ACC
JOIN clientaccount..ClientDetails CD ON CD.ClaccountID = FUM.CLAccountID
LEFT JOIN Discovery..ClientAccount CLA ON CLA.CLAccountID = FUM.HeadAccount
INNER JOIN ClientAccount..vwPeriodicFeeDetailsByClient_ForFees TIER ON FUM.ClAccountID = TIER.ClAccountID
				AND TIER.STATUS = 'Current'
				AND TIER.tiernumber = 1
			INNER JOIN ClientAccount..FeeAccrualsFUMIncludes INC ON TIER.FUMIncludesID = INC.ID
				AND FUM.AsAt = @asat
				AND FUM.SimpleTieredCharge_status = 'Applicable' -- has to be changed to Applicable
				AND (CD.Discretionary = 1 )
INNER JOIN discovery..clientaccount CA   
   ON CA.claccountid = ACC.LinkAccount
    AND CA.islinkedaccountforfees = 1 
where FUM.HeadAccount = ACC.CLAccountID

GROUP BY LinkAccount
;
GO
