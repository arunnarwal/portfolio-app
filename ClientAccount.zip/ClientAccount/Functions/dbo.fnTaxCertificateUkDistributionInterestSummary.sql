CREATE FUNCTION [dbo].[fnTaxCertificateUkDistributionInterestSummary](@FromDate datetime, @ToDate datetime)
RETURNS TABLE
AS
RETURN

/*
USE ClientAccount

DECLARE @FromDate DATETIME;
DECLARE @ToDate DATETIME;

SET @FromDate = '2016-04-06 00:00:00';
SET @ToDate = '2017-04-05 00:00:00';
*/

SELECT
	TIFU.ClAccountID,
	SUM(TIFU.Gross) - SUM(TIFU.WT) AS Net,
	SUM(TIFU.WT) AS Tax,
	SUM(TIFU.Gross) AS Gross
FROM
	dbo.vwTaxableIncomeDataForUK AS TIFU
WHERE
	TIFU.LedgerDate >= @FromDate AND TIFU.LedgerDate <= @ToDate
	AND TIFU.Reversal IS NULL
	AND (
		(TIFU.[Type] = 'Interest' AND (TIFU.InstrumentCode = 'GBPCash' Or TIFU.Domicile = 'UK') AND (TIFU.SecuritySubType <> 'Term Deposit'))
		OR (TIFU.MFIncomeType = 'Interest' AND TIFU.SecuritySubType = 'ManagedFund' AND TIFU.Domicile = 'UK')
	)
	AND TIFU.IsBond = 0
    AND TIFU.SubAccountType IS NOT NULL AND TIFU.SubAccountType <> ''
	AND TIFU.InstrumentCode <> 'GBPCash'
GROUP BY
	TIFU.ClAccountID;
