SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE FUNCTION [dbo].[fnGetNextBusinessDay](@Date as datetime = NULL) 
RETURNS
	datetime
AS
BEGIN
	
	set @Date = coalesce(@Date, CURRENT_TIMESTAMP);
	set @Date = convert(datetime, convert(char, @Date, 106)) 
	declare @counter int

	set @counter = 0
	while @counter < 10
	begin
		set @counter = @counter + 1
		if exists 
		(	select D.Date 
			from res_db.dbo.Dates D
				left join livedb.dbo.vwHolidayschedule S 
			on D.Date = S.HolDate 
			where HolDate is NULL
			and D.Date = @Date
		)
		begin
			break
		end	
		set @Date = dateAdd(dd,1,@Date)
	end

	RETURN @Date
END
GO
