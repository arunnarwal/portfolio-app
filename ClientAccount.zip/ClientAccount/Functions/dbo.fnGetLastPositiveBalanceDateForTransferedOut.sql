SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE Function [dbo].[fnGetLastPositiveBalanceDateForTransferedOut](@subAccountNumber [varchar](255)) RETURNS TABLE AS

RETURN

SELECT DATEADD(Day, -1, max([lastDate])) AS [lastDate]
FROM 
(
	(
		SELECT MAX([AsAt]) AS lastDate
		FROM ClientAccount..ScripTransactions
		WHERE [clAccountId] = @subAccountNumber AND [Quantity] < 0
	) UNION
	(
		SELECT max([AsAt]) as [lastDate]
		FROM [ClientAccount]..[ScripTransactions]
		WHERE [clAccountId] = @subAccountNumber  AND [Location] = 'Custody' AND [Quantity] < 0
	)
) AS [ScripAndLedger]
GO
