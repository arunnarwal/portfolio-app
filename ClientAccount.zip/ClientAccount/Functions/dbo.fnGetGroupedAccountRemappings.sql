SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE function [dbo].[fnGetGroupedAccountRemappings]
	(@ClAccountId VarChar(20),@GroupType varchar(50))
RETURNS @Result table
(
	originalClAccountID varchar(20) PRIMARY KEY CLUSTERED,
	TopClAccountID varchar(20) not null,
	NewClAccountID varchar(20) not null	
)

AS
begin


insert into @Result(originalClAccountID,TopClAccountID,NewClAccountID)
select a.groupedclaccountid,b.claccountid,b.subclaccountid from vwGroupReportingDetail A inner join
clientaccount..consolidate b
ON a.ClAccountID = b.subClAccountID
where grouptype = @GroupType and b.claccountid = @ClAccountID 



insert into @Result(originalClAccountID,TopClAccountID,NewClAccountID)
select subclaccountid,claccountid,subclaccountid from dbo.consolidate
where claccountid = @claccountid and not exists 
	(select * from @Result RA where RA.originalClAccountID = consolidate.subclaccountid)

return 
end
GO
