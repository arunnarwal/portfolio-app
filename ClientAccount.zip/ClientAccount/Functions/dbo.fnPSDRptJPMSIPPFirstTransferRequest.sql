SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE FUNCTION [dbo].[fnPSDRptJPMSIPPFirstTransferRequest]( @fromDate datetime, @toDate datetime  ) RETURNS TABLE AS

RETURN 

WITH FirstTransaction AS 
( 
	SELECT	STRQ.ClAccountID,
			STRQ.TransferCompleted  AS DateCompleted
	FROM Discovery..ScripTransferRequest AS STRQ
	INNER JOIN Discovery..ProductDetails PD 
		ON  PD.CLAccountID =  STRQ.ClAccountID AND PD.ArrangementType = 'Accumulation'
	WHERE	STRQ.ProductType In ('NPR', 'PR') AND STRQ.TransferMode = 'IN SPECIE' AND STRQ.[Status] = 'Completed' AND STRQ.TransferCompleted  IS NOT NULL AND STRQ.TransferCompleted >= @fromDate AND STRQ.TransferCompleted <= @toDate AND PD.ArrangementType = 'Accumulation'


)


SELECT ClAccountID, MIN(DateCompleted) AS DateCompleted FROM FirstTransaction 
GROUP BY ClAccountID;
GO
