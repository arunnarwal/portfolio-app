/***
<Function>
    <Description>Maps an investor type to the associated legay entity type.</Description>
    <Parameters>
        <Parameter Name="@InvestorType">
            <Description>Investor type to map.</Description>
        </Parameter>
    </Parameters>
</Function>
***/
CREATE FUNCTION dbo.fnMapInvestorTypeToLegalEntityType
(
    @InvestorType VARCHAR(20)
)
RETURNS VARCHAR(20)
AS
    BEGIN
        /*
            Treat off-platform pensions as individuals.
            This is currently only used for ETI custodian account look ups.
        */
        IF (@InvestorType IN ('INDIVID', 'PENSION'))
        BEGIN
            RETURN 'INDIVIDUAL'
        END

        RETURN @InvestorType
    END
