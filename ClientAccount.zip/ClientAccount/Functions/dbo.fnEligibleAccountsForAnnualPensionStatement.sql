/***
<Function>
	<Description>Returns eligible accounts for annual pension statement.</Description>
	<Parameters>
		<Parameter Name="@RunId">
			<Description>Id of a specific run to return.</Description>
		</Parameter>
	</Parameters>
</Function>
***/
CREATE FUNCTION [dbo].[fnEligibleAccountsForAnnualPensionStatement] (@RunId INT)
RETURNS TABLE
AS
RETURN (
        --declare @run int = 1
        SELECT CCD.CLAccountId
            ,CCD.[Status]
            ,CCD.Clienttype
            ,CONVERT(DATETIME, CONVERT(VARCHAR, CCD.InceptionDate, 106)) AS InceptionDate
            ,Year(CCD.InceptionDate) AS YearOfInception
            ,Month(CCD.InceptionDate) AS MonthOfInception
            ,Day(CCD.InceptionDate) AS DayOfInception
            ,CCD.CloseDate
            ,REGLOG.Id
            ,REGLOG.RunId
            ,REGLOG.TaskRequestId
            ,REGLOG.STATUS AS RunStatus
            ,REGLOG.ErrorDescription
            ,REGLOG.DateCreated
        FROM dbo.vwCombinedClientDetails CCD
        INNER JOIN (
            SELECT FHA.HeadClAccountID AS ClAccountID
            FROM dbo.vwCombinedClientDetails C2
            INNER JOIN ClientAccount.dbo.fnHeadAccounts() FHA ON C2.ClAccountID = FHA.ClAccountID
                AND FHA.Consolidated = 0
            WHERE SubAccountType IN (
                    'SIPP'
                    ,'CRA'
                    )
                AND C2.STATUS IN ('Active')
            GROUP BY FHA.HeadClAccountID
            ) CCD2 ON CCD.ClAccountID = CCD2.ClAccountID
        LEFT JOIN dbo.RegularStatementRunLog REGLOG ON CCD.ClAccountId = REGLOG.CLAccountId
            AND REGLOG.RunId = @RunId
            AND REGLOG.STATUS = 'Complete'
        WHERE REGLOG.Id IS NULL
        )
GO
