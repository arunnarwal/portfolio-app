
CREATE FUNCTION [dbo].[fnHbmDataExtract_GetManualCashAdjustment]
(
	@WrapProvider as VarChar(20)
)

RETURNS TABLE 
AS 
RETURN
(
	SELECT 
	MCA.Id, 
	MCA.Claccountid, 
	MCA.Datecreated, 
	MCA.Adjustmenttype, 
	MCA.Amount, 
	MCA.Status
	FROM dbo.vwManualCashAdjustmentRequestsAccountDetails MCA
	WHERE (MCA.Datecreated > DATEADD(DAY, DATEDIFF(DAY, 0, GETDATE()), -3) or MCA.Status = 'Pending')
	and MCA.WrapProvider = @WrapProvider
)
