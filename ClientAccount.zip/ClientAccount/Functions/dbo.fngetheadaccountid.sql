SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[fngetheadaccountid]
               (@ClAccountId VARCHAR(20))
RETURNS VARCHAR(20)
AS
  BEGIN
    DECLARE  @SUFFIX_CHAR_POSITION INT
    
    SET @SUFFIX_CHAR_POSITION = Charindex('-',@ClAccountID)
    
    RETURN CASE 
             WHEN (@SUFFIX_CHAR_POSITION > 0) THEN Substring(@ClAccountID,0,@SUFFIX_CHAR_POSITION)
             ELSE @ClAccountId
           END
  END

GO
