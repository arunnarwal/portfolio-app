SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE Function [dbo].[fn_FeeAssetSummariesWithUnclearedCashV2](@AsAt datetime) RETURNS TABLE AS

RETURN
--v2 sfield 2011/02/15 for new fum tables


--declare @asat as datetime
--set @asat='09 may 2011'

SELECT sq.asat, sq.company, sq.claccountid, sq.HeaderCLAccountID, 
--hack to make it same as old report... 
CASE 
	WHEN sq.TotalHolding < 0 THEN 0
	ELSE sq.TotalHolding
END AS TotalHolding, 
sq.fasTotalCash, 
COALESCE((unclearedCash.TotalUnclearedCash), 0) unclearedCash,
COALESCE((unclearedCheques.TotalUnclearedCheque), 0) unclearedCheque,
sq.FasTotalCash + COALESCE((unclearedCash.TotalUnclearedCash), 0)  + COALESCE((unclearedCheques.TotalUnclearedCheque), 0) as TotalCash
FROM
	(SELECT   fas.AsAt, fas.Company, fas.ClAccountID, fas.HeadAccount as HeaderClAccountID, 
	sum(COALESCE(fas.TotalHolding,0)) TotalHolding,
	sum(COALESCE(fas.TotalCash,0)) fasTotalCash

	FROM Cache..FumByInstAccByDate fas--ClientAccount..processedfumfees_byinstacc fas 
	Where FAS.AsAt = @AsAt --and fas.claccountid like 'EL1021269%'
	GROUP BY fas.AsAt, fas.Company, fas.ClAccountID, fas.HeadAccount
	HAVING not (sum(TotalHolding) < 0 and sum(TotalCash) = 0) --this excludes the zero'd out negative rows which were in te20 and not te19

	) as sq
		left JOIN (
					SELECT ClAccountID, sum(Amount) As TotalUnclearedCash
					FROM CashLedgerTransactions
					WHERE RestrictSweepUntil IS NOT NULL 
						AND MovementType IN ('FUND_APPLICATION', 'FUND_REDEMPTION', 'BUY_TRADE','SELL_TRADE')
						And (@AsAt >= RestrictSweepUntil or RestrictSweepUntil is null)
					GROUP BY ClAccountID
		) unclearedCash on unclearedCash.ClAccountID=sq.ClAccountID and sq.AsAt=@asat
		left JOIN (
					SELECT CLAccountID, SUM(Amount) as TotalUnclearedCheque
					FROM CashLedgerAdjustments
					WHERE AdjustmentType = 'UNCLEARED_CHEQUE'
					and  Ledgerdate <=@AsAt
					GROUP BY CLAccountID
		) unclearedCheques on unclearedCheques.ClAccountID=sq.ClAccountID and sq.AsAt = @asat





--SELECT  fas.AsAt, fas.Company, fas.ClAccountID, fas.HeadAccount as HeaderClAccountID, 
--SUM(fas.NonCashValue) TotalHolding,
--fas.CashValue fasTotalCash, 
--COALESCE(sum(unclearedCash.TotalUnclearedCash), 0) unclearedCash,
--COALESCE(sum(unclearedCheques.TotalUnclearedCash), 0) unclearedCheque, 
--fas.CashValue  + COALESCE(sum(unclearedCash.TotalUnclearedCash), 0)  + COALESCE(sum(unclearedCheques.TotalUnclearedCash), 0) as TotalCash
--FROM Cache..FumByAccByDate fas --ClientAccount..FeeAssetSummaries fas
--			LEFT JOIN (
--					SELECT ClAccountID, SUM(Amount) As TotalUnclearedCash
--					FROM CashLedgerTransactions
--					WHERE RestrictSweepUntil IS NOT NULL 
--						AND MovementType IN ('FUND_APPLICATION', 'FUND_REDEMPTION', 'BUY_TRADE','SELL_TRADE')
--						And (@AsAt >= RestrictSweepUntil or RestrictSweepUntil is null)
--					GROUP BY ClAccountID
--			) unclearedCash on unclearedCash.ClAccountID=FAS.ClAccountID and FAS.AsAt=@asat
--			LEFT JOIN (
--					SELECT CLAccountID, SUM(Amount) as TotalUnclearedCash
--					FROM CashLedgerAdjustments
--					WHERE AdjustmentType = 'UNCLEARED_CHEQUE'
--					and  Ledgerdate <=@AsAt
--					GROUP BY CLAccountID
--			) unclearedCheques on unclearedCheques.ClAccountID=FAS.ClAccountID and FAS.AsAt = @asat
--Where FAS.AsAt = @asat 
--GROUP BY fas.AsAt, fas.Company, fas.ClAccountID, fas.HeadAccount, fas.CashValue
GO
