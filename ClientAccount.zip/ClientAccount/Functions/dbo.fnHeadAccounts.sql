CREATE FUNCTION [dbo].[fnHeadAccounts]() RETURNS TABLE AS

RETURN

SELECT	CON.SubClAccountID as ClAccountID, 
		CON.CLAccountID as HeadClAccountID, 
		case when CD.InvestorType = 'Consolidated' then 1 else 0 end as [Consolidated]
FROM	ClientAccount.dbo.Consolidate CON 
			inner join Discovery.dbo.ClientAccount CA on CA.ClAccountID = CON.ClAccountID
			inner join ClientAccount.dbo.ClientDetails CD on CD.ClAccountID = CON.ClAccountID
WHERE	CA.DPSAccountType != 'Sub-Account'
GO
