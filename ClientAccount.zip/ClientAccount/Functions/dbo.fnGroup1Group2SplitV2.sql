CREATE FUNCTION [dbo].[fnGroup1Group2SplitV2] (@claccountid varchar(14), @instrumentcode varchar(20)) RETURNS TABLE AS

RETURN
SELECT	CLAccountID, 
		InstrumentCode, 
		sum(quantity) as Quantity,
		SUM(group1) as Group1Holding, 
		SUM(group2) as Group2Holding
		
FROM	ClientAccount..ScripTransactions

WHERE	CLAccountID = @claccountid 
	AND InstrumentCode = @instrumentcode
	AND transstatus != 'Cancelled'
	
GROUP BY CLAccountID, InstrumentCode
HAVING SUM(Quantity) >= 0
GO
