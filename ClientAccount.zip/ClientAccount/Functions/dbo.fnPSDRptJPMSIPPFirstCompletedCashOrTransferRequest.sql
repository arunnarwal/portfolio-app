SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE FUNCTION [dbo].[fnPSDRptJPMSIPPFirstCompletedCashOrTransferRequest]( @fromDate datetime, @toDate datetime  ) RETURNS TABLE AS

RETURN 

WITH FirstTransaction AS 
( 
	SELECT	STRQ.ClAccountID,
			STRQ.TransferCompleted  AS DateCompleted
	FROM Discovery..ScripTransferRequest AS STRQ
	INNER JOIN Discovery..ProductDetails PD 
		ON  PD.CLAccountID =  STRQ.ClAccountID AND PD.ArrangementType = 'Accumulation'
	INNER JOIN 	ClientAccount..fnPSDRptJPMBatchHasOEICOrInvestTrust() OOIT
		ON STRQ.BatchID = OOIT.BatchID
	WHERE	STRQ.ProductType In ('NPR', 'PR', 'BOP') AND STRQ.TransferMode = 'IN SPECIE' AND STRQ.[Status] = 'Completed' AND STRQ.TransferCompleted  IS NOT NULL AND STRQ.TransferCompleted >= @fromDate AND STRQ.TransferCompleted <= @toDate AND PD.ArrangementType = 'Accumulation'

	UNION 

	SELECT	CE.ClAccountID, 
			DateCompleted 
	FROM Discovery..CashEntry CE
	INNER JOIN Discovery..ProductDetails PD 
		ON  PD.CLAccountID =  CE.ClAccountID AND PD.ArrangementType = 'Accumulation'
	WHERE PD.ProductType in ('NPR', 'PR', 'BOP') and CE.DateCompleted >= @fromDate and CE.DateCompleted <= @toDate AND CE.DateCompleted IS NOT NULL AND PD.ArrangementType = 'Accumulation'
	--tpastirc: CAM issue 1314 - Standing batch is not to be used - it is Complete on creation, e.g. is complete for inactive accounts as well.
	and CE.InstructionType <> 'Standing'
)


SELECT ClAccountID, MIN(DateCompleted) AS DateCompleted FROM FirstTransaction 
GROUP BY ClAccountID;
GO
