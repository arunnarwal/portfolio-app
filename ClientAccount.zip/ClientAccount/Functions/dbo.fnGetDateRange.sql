

CREATE FUNCTION [dbo].[fnGetDateRange]
(     
      @StartDate              DATE,
      @EndDate                DATE
)
RETURNS  
@SelectedRange    TABLE 
(IndividualDate SMALLDATETIME)
AS 
BEGIN
      ;WITH cteRange (DateRange) AS (
            SELECT @StartDate
            UNION ALL
            SELECT DATEADD(dd, 1, DateRange)
            FROM cteRange
            WHERE DateRange <= DATEADD(dd, -1, @EndDate)
			)
          
      INSERT INTO @SelectedRange (IndividualDate)
      SELECT DateRange
      FROM cteRange
      RETURN
END
GO