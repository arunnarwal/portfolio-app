CREATE FUNCTION [dbo].[fnCustodyEODToProcess] (@CorpActID int = 0)

RETURNS @Actions TABLE (TargetCncyCode CHAR(3), GLSystem CHAR(4), NumToProcess INT) 
AS
BEGIN

IF @CorpActID <= 0
	Begin
	INSERT INTO @Actions
	Select TargetCncyCode, 'GLAD' as GLSystem, Sum(NumToProcess) As NumToProcess
	From	(Select INC.TargetCncyCode, Count(*) AS NumToProcess
			From dbo.IncomeSummary INC
			Where INC.Location IN ('Custody','Registry') And (INC.JnlGenerated IS NULL OR inc.PostedToBalanceSheet = 0)
			Group By INC.TargetCncyCode

			UNION ALL

			Select INT.TargetCurrency As TargetCncyCode, Count(*)
			From dbo.InterestIncome INT
			Where INT.Location IN ('Custody','Registry') And INT.JnlGenerated IS NULL 
			Group By INT.TargetCurrency

			UNION ALL

			Select CAN.TargetCcy As TargetCncyCode, Count(*)
			From dbo.CANonIncomeJnl CAN
			Where CAN.Location IN ('Custody','Registry') And CAN.JnlGenerated IS NULL
			Group By CAN.TargetCcy) DTBL

	Group By TargetCncyCode
End
Else 
	Begin
	INSERT INTO @Actions
	Select TargetCncyCode, 'GLAD' as GLSystem, Sum(NumToProcess) As NumToProcess
	From
			(Select INC.TargetCncyCode, Count(*) AS NumToProcess
			From dbo.IncomeSummary INC
			Where INC.Location IN ('Custody','Registry') And (INC.JnlGenerated IS NULL OR inc.PostedToBalanceSheet = 0) and INC.CorpActID = @CorpActID
			Group By INC.TargetCncyCode

			UNION ALL

			Select INT.TargetCurrency As TargetCncyCode, Count(*)
			From dbo.InterestIncome INT
			Where INT.Location IN ('Custody','Registry') And INT.JnlGenerated IS NULL and INT.CorpActID = @CorpActID
			Group By INT.TargetCurrency

			UNION ALL

			Select CAN.TargetCcy As TargetCncyCode, Count(*)
			From dbo.CANonIncomeJnl CAN
			Where CAN.Location IN ('Custody','Registry') And  CAN.JnlGenerated IS NULL and CAN.CorpActID = @CorpActID
			Group By CAN.TargetCcy) DTBL

	Group By TargetCncyCode
	
	End

RETURN

END

GO