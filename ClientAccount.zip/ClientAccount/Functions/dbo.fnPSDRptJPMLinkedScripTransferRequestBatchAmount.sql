SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE FUNCTION [dbo].[fnPSDRptJPMLinkedScripTransferRequestBatchAmount](@ArrangementType as VarChar(20)) RETURNS TABLE AS

RETURN 

SELECT STRQL.RequestID, SUM(Amount) As Amount 
	FROM Discovery..ScripTransferRequestLink STRQL
	INNER JOIN Discovery..ScripTransferRequest STRQ
		ON STRQ.RequestID = STRQL.LinkedRequestID And ( @ArrangementType  = '' Or (ArrangementType = @ArrangementType ))
	GROUP BY STRQL.RequestID
GO
