SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE FUNCTION [dbo].[fnPSDRptJPMBatchHasOEIC]() RETURNS TABLE AS

RETURN 

SELECT 
OC.BatchID, 1 AS HasOEIC, SUM(COALESCE(DisplayValueExComm, DisplayValue)) AS OEICBatchTotal 
FROM Discovery..OrderCurrent OC
	INNER JOIN Res_Db..ManagedFunds MF
		ON OC.InstrumentCode = MF.InstrumentCode  AND MF.UnitTrustOEIC = 'OEIC'
WHERE MF.UnitTrustOEIC = 'OEIC'
GROUP BY OC.BatchID
GO
