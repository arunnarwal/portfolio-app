

CREATE FUNCTION [dbo].[fnLatestFBRCSettingsForAsat] (@asat datetime)
	RETURNS TABLE
AS
RETURN
(
	SELECT 
	CSetting.Id,
	CSetting.ClAccountId,
	CSetting.FBRCRate, 
	CSetting.UseFundFBRCRate,
	CSetting.AsAt,
	CSetting.DateAdded,
	CSetting.UserAddedBy,
	CSetting.CallerSource,
	CSetting.SessionId,
	CSetting.Note,
	CSetting.FBRCAmount,
	CSetting.Active,
	CSetting.ActivationDate,
	CSetting.DateAuthorised,
	CSetting.UserAuthorised,
	CSetting.DateRejected,
	CSetting.UserRejected,
	CSetting.AdviceGiven
FROM dbo.ClientFBRCSettings CSetting
INNER JOIN 
(SELECT ClAccountId,max(AsAt) as AsAt, max(Id) As ID
FROM dbo.ClientFBRCSettings
WHERE AsAt <= @asat
GROUP BY ClAccountId) LatestDate
ON LatestDate.ClAccountId = CSetting.ClAccountId
AND LatestDate.AsAt = CSetting.AsAt
AND LatestDate.Id = CSetting.Id

UNION
/*sub accounts are not restricted by their activation date*/
SELECT 
	CSetting.Id,
	Fun.FundAccount as ClAccountID,
	CSetting.FBRCRate, 
	CSetting.UseFundFBRCRate,
	CSetting.AsAt,
	CSetting.DateAdded,
	CSetting.UserAddedBy,
	CSetting.CallerSource,
	CSetting.SessionId,
	CSetting.Note,
	CSetting.FBRCAmount,
	1 As Active,
	CSetting.ActivationDate,
	CSetting.DateAuthorised,
	CSetting.UserAuthorised,
	CSetting.DateRejected,
	CSetting.UserRejected,
	CSetting.AdviceGiven
FROM dbo.ClientFBRCSettings CSetting
INNER JOIN 
(SELECT ClAccountId,max(AsAt) as AsAt, max(Id) As ID
FROM dbo.ClientFBRCSettings
/*where Activationdate is not null*/
WHERE AsAt <= @asat
GROUP BY ClAccountId) LatestDate
ON LatestDate.ClAccountId = CSetting.ClAccountId
AND LatestDate.AsAt = CSetting.AsAt
AND LatestDate.Id = CSetting.Id
INNER JOIN dbo.vwFundAccountsByHolder AS FUN ON fun.HolderAccount = CSetting.ClAccountId

UNION

SELECT 
	CSetting.Id,
	Fun2.FundAccount as ClAccountID,
	CSetting.FBRCRate, 
	CSetting.UseFundFBRCRate,
	CSetting.AsAt,
	CSetting.DateAdded,
	CSetting.UserAddedBy,
	CSetting.CallerSource,
	CSetting.SessionId,
	CSetting.Note,
	CSetting.FBRCAmount,
	1 As active,
	CSetting.ActivationDate,
	CSetting.DateAuthorised,
	CSetting.UserAuthorised,
	CSetting.DateRejected,
	CSetting.UserRejected,
	CSetting.AdviceGiven	
FROM dbo.ClientFBRCSettings CSetting
INNER JOIN 
(SELECT ClAccountId,max(AsAt) as AsAt, max(Id) As ID
FROM dbo.ClientFBRCSettings
WHERE AsAt <= @asat
/*where Activationdate is not null*/
GROUP BY ClAccountId) LatestDate
ON LatestDate.ClAccountId = CSetting.ClAccountId
AND LatestDate.AsAt = CSetting.AsAt
AND LatestDate.Id = CSetting.Id
INNER JOIN dbo.vwFundAccountsByHolder AS FUN ON fun.HolderAccount = CSetting.ClAccountId
INNER JOIN dbo.vwFundAccountsByHolder AS FUN2 ON FUN2.HolderAccount = fun.FundAccount
)

GO
