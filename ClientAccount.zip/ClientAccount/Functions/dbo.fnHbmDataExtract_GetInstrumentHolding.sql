SET QUOTED_IDENTIFIER OFF
GO

CREATE FUNCTION [dbo].[fnHbmDataExtract_GetInstrumentHolding]() RETURNS TABLE AS

RETURN

WITH Transactions AS (
    SELECT ST.ClAccountId, ST.InstrumentCode, SUM(ST.Quantity) AS SumQuantity, MIN(COALESCE(STRCD2.AcquisitionDate, STRCD.AcquisitionDate)) AS AcquisitionDate
    FROM dbo.ScripTransactions ST
		LEFT JOIN Discovery.dbo.ScripTransferRequest STR ON STR.RequestID = ST.AWScripTransferID AND STR.CLAccountID = ST.CLAccountID AND STR.InstrumentCode = ST.InstrumentCode
		LEFT JOIN Discovery.dbo.ScripTransferRequestCgtData STRCD ON STRCD.ScripTransferRequestID = STR.ID
		LEFT JOIN Discovery.dbo.ScripTransferRequestLink STRL ON STRL.LinkedRequestID = STR.RequestID
		LEFT JOIN Discovery.dbo.ScripTransferRequest STR2 ON STR2.RequestID = STRL.RequestID AND STR2.CLAccountID = ST.CLAccountID AND STR2.InstrumentCode = ST.InstrumentCode
		LEFT JOIN Discovery.dbo.ScripTransferRequestCgtData STRCD2 ON STRCD2.ScripTransferRequestID = STR2.ID
    WHERE ST.TransStatus = 'Settled' AND ST.Location IN ('Custody')
    GROUP BY ST.ClAccountId, ST.InstrumentCode
    HAVING SUM(ST.Quantity) <> 0)   

SELECT TR.InstrumentCode AS InstrumentHoldingCode, 
       TR.ClAccountId AS SubAccountID, 
       INS2.Security AS InstrumentCode,
       INS.ExternalId AS PartnerReference, 
       TR.SumQuantity * SEC2.O AS Valuation, 
       SEC2.Date AS ValuationDate, 
       TR.SumQuantity AS Quantity, 
       SEC2.O AS Price,
	   CASE
			WHEN OC.MinDatePlaced IS NULL OR OC.MinDatePlaced > TR.AcquisitionDate THEN TR.AcquisitionDate
			ELSE OC.MinDatePlaced
	   END AS InitialPurchaseDate,
       INS.DisplayName AS HoldingName,
	   NULL AS OrderID
FROM Transactions AS TR 
      INNER JOIN 
     Res_DB.dbo.Instruments AS INS ON INS.Security = TR.InstrumentCode
      INNER JOIN 
     (SELECT Security, MAX(Date) As MaxDate FROM Res_DB.dbo.Securities GROUP BY Security) AS SEC1 ON SEC1.Security = TR.InstrumentCode 
      INNER JOIN
     Res_DB.dbo.Securities AS SEC2 ON SEC2.Security = SEC1.Security AND SEC2.Date = SEC1.MaxDate
      LEFT JOIN 
     (SELECT ClAccountId, InstrumentCode, MIN(DatePlaced) AS MinDatePlaced FROM Discovery.dbo.OrderCurrent GROUP BY ClAccountId, InstrumentCode) AS OC ON OC.ClAccountId = TR.ClAccountId AND OC.InstrumentCode = TR.InstrumentCode
      LEFT JOIN
     Res_DB.dbo.LinkedInstruments AS LI ON LI.LinkedInstrumentCode = INS.Security
      LEFT JOIN
     Res_DB.dbo.Instruments AS INS2 ON INS2.Security = LI.InstrumentCode

UNION ALL

SELECT OC.InstrumentCode AS InstrumentHoldingCode, 
       OC.ClAccountId AS SubAccountID, 
       INS2.Security AS InstrumentCode,
       NULL PartnerReference, 
       0 AS Valuation, 
       GETDATE() AS ValuationDate, 
       0 AS Quantity, 
       0 AS Price,   
	   OC.DateCreated AS InitialPurchaseDate,
       INS.DisplayName AS HoldingName,
	   OC.OrderID
FROM Discovery.dbo.OrderCurrent AS OC
	  INNER JOIN 
     Res_DB.dbo.Instruments AS INS ON INS.Security = OC.InstrumentCode
      LEFT JOIN
     Res_DB.dbo.LinkedInstruments AS LI ON LI.LinkedInstrumentCode = INS.Security
      LEFT JOIN
     Res_DB.dbo.Instruments AS INS2 ON INS2.Security = LI.InstrumentCode
	  LEFT JOIN
	 Transactions AS TR ON OC.ClAccountId = TR.ClAccountId AND OC.InstrumentCode = TR.InstrumentCode
WHERE OC.Status IN ('Authorised','Placed') AND TR.CLAccountID IS NULL
