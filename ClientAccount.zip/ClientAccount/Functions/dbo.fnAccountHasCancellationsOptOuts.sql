SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO

CREATE FUNCTION [dbo].[fnAccountHasCancellationsOptOuts]() RETURNS TABLE AS

RETURN

WITH HeadAndProducts
AS
(
		SELECT FH.HeadClAccountID, PD.ClAccountID, PD.ProductType 
		FROM Discovery..ProductDetails PD 
		INNER JOIN ClientAccount..fnHeadAccounts() FH 
			ON PD.ClAccountID = FH.ClAccountID AND FH.Consolidated = 0
		WHERE PD.ProductType IS NOT NULL

), OptCounts as
(

SELECT HeadAndProducts.ClAccountID, count(*) Counts
	FROM ClientAccount..SEClientAccount SECA
		INNER JOIN ClientAccount..fnHeadAccounts() FH 
			ON SECA.ClAccountID = FH.ClAccountID  AND FH.Consolidated = 0
		INNER JOIN ClientAccount..AccountCancellationsOptOuts ACOO 
			ON SECA.ID = ACOO.SEClientAccountId
		INNER JOIN Discovery..ProductDetails PD 
			ON SECA.ClAccountID = PD.ClAccountID
		INNER JOIN HeadAndProducts
			on HeadAndProducts.HeadClAccountID = FH.HeadClAccountID AND HeadAndProducts.ProductType = PD.ProductType
	Where ACOO.Status NOT IN ( 'Complete' ) and ACOO.ManualProcessing = 0
	GROUP BY HeadAndProducts.ClAccountID
)

SELECT ClAccountID,
CASE Counts
	When 0 Then 0
	Else 1 
End As HasOpenAutoOptOut 
FROM OptCounts

