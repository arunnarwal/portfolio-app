CREATE FUNCTION [dbo].[fnGetTaxExemptAccountsForMFR]() Returns TABLE AS
	RETURN

	-- account where primary role is tax exempt
	WITH PrimaryRoleTaxExemptAccounts AS (
		SELECT sub.ClAccountId, head.Id HeadAccountId, sub.Id SubAccountId, cr.CustomerRoleTypeId
		FROM Platform.DBAAccount.CustomerRoles cr
		INNER JOIN platform.DBACustomer_UK.TaxDetails td ON td.CustomerId = cr.CustomerId AND td.TaxExemptionReasonId IS NOT NULL
		INNER JOIN Platform.DBAAccount.CustomerRoleStatuses crs on crs.CustomerRoleStatusId = cr.CustomerRoleStatusId
		INNER JOIN dbo.SEClientAccount head ON head.Id = cr.AccountId
		INNER JOIN dbo.vwHeadAccountIds ha ON ha.HeadAccountId = cr.AccountId AND ha.Consolidated = 0
		INNER JOIN dbo.SEClientAccount sub ON sub.ClAccountID = ha.AccountNumber
		INNER JOIN Discovery.dbo.ProductDetails pd on pd.ClAccountid = sub.ClAccountId
		WHERE crs.CustomerRoleStatus = 'Active'
		AND cr.IsPrimaryRole = 1
		AND pd.ProductType = 'Personal Portfolio'
	)
	
	-- if individual accout holder then exempt
	SELECT prtea.ClAccountId, prtea.SubAccountId from PrimaryRoleTaxExemptAccounts prtea
	INNER JOIN Platform.DBAAccount.CustomerRoleTypes crt on crt.CustomerRoleTypeId = prtea.CustomerRoleTypeId
	WHERE crt.CustomerRoleType = 'IndividualAccountHolder'

	UNION ALL

	-- if joint accout holder then exempt if all joint account holders are exempt
	SELECT prtea.ClAccountId, prtea.SubAccountId from PrimaryRoleTaxExemptAccounts prtea
	INNER JOIN Platform.DBAAccount.CustomerRoleTypes crt on crt.CustomerRoleTypeId = prtea.CustomerRoleTypeId
	WHERE crt.CustomerRoleType = 'JointAccountHolder'
	AND NOT EXISTS (
		SELECT 1  FROM Platform.DBAAccount.CustomerRoles cr
		LEFT JOIN platform.DBACustomer_UK.TaxDetails td ON td.CustomerId = cr.CustomerId AND td.TaxExemptionReasonId IS NOT NULL
		INNER JOIN Platform.DBAAccount.CustomerRoleStatuses crs on crs.CustomerRoleStatusId = cr.CustomerRoleStatusId
		WHERE cr.AccountId = prtea.HeadAccountId
		AND crs.CustomerRoleStatus = 'Active'
		AND td.CustomerId IS NULL)

	UNION ALL 

	-- if organisation accout holder then exempt
	SELECT prtea.ClAccountId, prtea.SubAccountId
	from PrimaryRoleTaxExemptAccounts prtea
	INNER JOIN Platform.DBAAccount.CustomerRoleTypes crt on crt.CustomerRoleTypeId = prtea.CustomerRoleTypeId
	WHERE crt.CustomerRoleType = 'OrganisationAccountHolder'

GO
