/***
<Function>
    <Description>Exposes available cash balances by currency</Description>
    <Parameters>
        <Parameter Name="@AsAt">
            <Description>The date as at the balances should be fo</Description>
        </Parameter>        
    </Parameters>
</Function>
***/
create FUNCTION [dbo].[fnExternalCashBalancebyCCY]
(
    @AsAt DATETIME
) 
RETURNS TABLE AS
RETURN

--declare @AsAt DATETIME = '26 jan 2020'

    SELECT
        GT.AccountId,
		CD.ClAccountId,
        GC.CurrencyCode CcyCode,
        C.WrapProvider,        
		GT.CurrencyId,
		-SUM(GT.Amount) AS ExternalBalance                       
        FROM     CashLedger.ExternalTransactions GT
		INNER JOIN CashLedger.Currencies GC
			on GC.CurrencyId = GT.CurrencyId
		INNER JOIN dbo.SEClientAccount SCA ON GT.AccountId = SCA.ID
		INNER JOIN dbo.ClientDetails CD ON Cd.CLAccountID = SCA.ClAccountID
            LEFT JOIN  dbo.Company C ON CD.Company = C.Company
        WHERE    GT.LedgerDate <= @AsAt
		GROUP BY GT.AccountId, GT.CurrencyId,CD.CLAccountID,GC.CurrencyCode,C.WrapProvider
