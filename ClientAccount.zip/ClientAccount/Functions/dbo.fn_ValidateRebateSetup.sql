

CREATE FUNCTION [dbo].[fn_ValidateRebateSetup](@WrapProvider as VarChar(20))
RETURNS @valTable TABLE
([Type] varchar(10),[Message] varchar(100),DBName varchar(100),DBTable varchar(100), [Owner] varchar(100), SiteOwner varchar(100))
AS
BEGIN
IF
(
 SELECT COUNT(*) FROM Res_DB.dbo.InstrumentSettings S
INNER JOIN [dbo].Instruments I
	ON I.Security = S.Instrumentcode
LEFT JOIN dbo.FeeRebateSchedule R
	ON I.Security = R.Instrumentcode
WHERE I.SecurityType = 'Managed Fund'
AND S.NAME = @WrapProvider AND S.Type = 'WP'
AND S.AssetWatchStatus = 'tradeable'
AND R.InstrumentCode IS NULL) > 0
 BEGIN
	BEGIN
		INSERT INTO @valTable(type, message, DBName, DBTable, owner, SiteOwner)
		VALUES ('Warning', 'Some tradeable funds have no applicable rebate setup','Clientaccount', 'feerebateschedule','Jono', @WrapProvider)
	END
END

return 

END
GO
