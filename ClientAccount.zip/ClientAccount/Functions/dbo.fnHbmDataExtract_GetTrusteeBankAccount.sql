CREATE FUNCTION [dbo].[fnHbmDataExtract_GetTrusteeBankAccount] ()
Returns @outputTable Table (
	AccountNumber varchar(20),
	SortCode varchar(20),
	HeadAccountId varchar(20),
	UnmatchedAmount MONEY,
	Balance MONEY) 
AS
BEGIN

DECLARE @WrapProvider Varchar(20)
SET @WrapProvider = 'HBM'

DECLARE @Accounts TABLE (
	AccountNumber VARCHAR(20),
	SortCode VARCHAR(20),
	ClAccountId VARCHAR(20),
	CustomerAccountNumber VARCHAR(20)
)

INSERT INTO @Accounts (AccountNumber, SortCode, ClAccountId, CustomerAccountNumber)
SELECT 
	GCBA.AccountNumber,
	GCBA.SortCode,
	GCBA.ClAccountID,
	GCBA.SortCode + '-' + GCBA.AccountNumber
FROM dbo.vwGladClientBankAccount GCBA 
INNER JOIN Discovery.dbo.ClientAccount CA ON CA.ClAccountID = GCBA.ClAccountID
WHERE CA.Status NOT IN ('Inactive', 'Closed')
AND GCBA.WrapProvider = @WrapProvider

DECLARE @UnmatchedTransactions TABLE (
	CustomerAccountNumber VARCHAR(20),
	UnmatchedAmount MONEY
)

INSERT INTO @UnmatchedTransactions (CustomerAccountNumber, UnmatchedAmount)
SELECT
	CustomerAccountNumber, 
	-SUM(Amount)
FROM dbo.vwBankTransactionsToMatch
WHERE DateProcessed IS NULL
GROUP BY CustomerAccountNumber

INSERT INTO @outputTable (AccountNumber, SortCode, HeadAccountId, UnmatchedAmount, Balance)
SELECT 
	A.AccountNumber,
	A.SortCode,
	A.ClAccountId,
	COALESCE(UT.UnmatchedAmount, 0),
	COALESCE(HBS.CurrentBalance, 0)
FROM @Accounts A
LEFT JOIN @UnmatchedTransactions UT ON A.CustomerAccountNumber = UT.CustomerAccountNumber
LEFT JOIN dbo.HbosBalanceSummary HBS ON HBS.Id = 
	(
		SELECT TOP(1) Id
		FROM dbo.HbosBalanceSummary
		WHERE SortCode = A.SortCode 
		AND AccountNumber = A.AccountNumber
		ORDER BY [Date] DESC
	) 

RETURN END

