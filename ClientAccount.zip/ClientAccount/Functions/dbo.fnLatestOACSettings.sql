SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[fnLatestOACSettings](@AsAt datetime = NULL)
RETURNS @resultTable TABLE
(
ID int,
[Type] varchar(50),
ClAccountID varchar(20),
Rate money,
AsAt datetime,
DateAdded datetime,
UserAddedBy int,
CallerSource varchar(max),
SessionID int,
Note varchar(max),
Amount money,
Active bit,
ActivationDate datetime, 
DateAuthorised datetime,
UserAuthorised int,
DateRejected datetime,
UserRejected int,
AdviceGiven bit
)
AS
BEGIN
SET @AsAt = COALESCE(@AsAt,GetDate())

INSERT INTO @resultTable
(ID,
[Type],
ClAccountID,
Rate, 
AsAt,
DateAdded,
UserAddedBy,
CallerSource,
SessionID,
Note,
Amount,
Active,
ActivationDate, 
DateAuthorised,
UserAuthorised,
DateRejected,
UserRejected,
AdviceGiven)

select 
	CSetting.ID,
	CSetting.[Type],
	CSetting.ClAccountID,
	CSetting.Rate, 
	CSetting.AsAt,
	CSetting.DateAdded,
	CSetting.UserAddedBy,
	CSetting.CallerSource,
	CSetting.SessionID,
	CSetting.Note,
	CSetting.Amount,
	CSetting.Active,
	CSetting.ActivationDate, 
	CSetting.DateAuthorised,
	CSetting.UserAuthorised,
	CSetting.DateRejected,
	CSetting.UserRejected,
	CSetting.AdviceGiven
from clientaccount..OACsettings CSetting
inner join 
(select claccountid,max(asat) as AsAt, max(id) As ID
from clientaccount..OACsettings
where Activationdate is not null
and asAt <= @AsAt
group by [Type],claccountid) LatestDate
ON LatestDate.ClAccountID = CSetting.ClAccountID
and LatestDate.AsAt = CSetting.AsAt
and LatestDate.Id = CSetting.ID

union
/*sub accounts are not restricted by their activation date*/
select 
	CSetting.ID,
	CSetting.[Type],
	Fun.FundAccount as ClAccountID,
	CSetting.Rate,
	CSetting.AsAt,
	CSetting.DateAdded,
	CSetting.UserAddedBy,
	CSetting.CallerSource,
	CSetting.SessionID,
	CSetting.Note,
	CSetting.Amount,
	1 As Active,
	CSetting.ActivationDate,
	CSetting.DateAuthorised,
	CSetting.UserAuthorised,
	CSetting.DateRejected,
	CSetting.UserRejected,
	CSetting.AdviceGiven
from clientaccount..OACsettings CSetting
inner join 
(select claccountid,max(asat) as AsAt, max(id) As ID
from clientaccount..OACsettings
/*where Activationdate is not null*/
where asAt <= @AsAt
group by [Type],claccountid) LatestDate
ON LatestDate.ClAccountID = CSetting.ClAccountID
and LatestDate.AsAt = CSetting.AsAt
and LatestDate.Id = CSetting.ID
inner join ClientAccount..vwFundAccountsByHolder AS FUN on fun.HolderAccount = CSetting.ClAccountID



union

select 
	CSetting.ID,
	CSetting.[Type],
	Fun2.FundAccount as ClAccountID,
	CSetting.Rate, 
	CSetting.AsAt,
	CSetting.DateAdded,
	CSetting.UserAddedBy,
	CSetting.CallerSource,
	CSetting.SessionID,
	CSetting.Note,
	CSetting.Amount,
	1 As active,
	CSetting.ActivationDate,
	CSetting.DateAuthorised,
	CSetting.UserAuthorised,
	CSetting.DateRejected,
	CSetting.UserRejected,
	CSetting.AdviceGiven	
from clientaccount..OACsettings CSetting
inner join 
(select claccountid,max(asat) as AsAt, max(id) As ID
from clientaccount..OACsettings
/*where Activationdate is not null*/
where asAt <= @AsAt
group by [Type],claccountid) LatestDate
ON LatestDate.ClAccountID = CSetting.ClAccountID
and LatestDate.AsAt = CSetting.AsAt
and LatestDate.Id = CSetting.ID
inner join ClientAccount..vwFundAccountsByHolder AS FUN on fun.HolderAccount = CSetting.ClAccountID
inner join ClientAccount..vwFundAccountsByHolder AS FUN2 on FUN2.HolderAccount = fun.FundAccount
RETURN
END
GO
