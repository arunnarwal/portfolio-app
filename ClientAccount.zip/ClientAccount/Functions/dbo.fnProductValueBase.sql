SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE FUNCTION [dbo].[fnProductValueBase](@AsAt datetime, @Location varchar(10), @Currency char(3), @PriceAsAt datetime, @PortfolioAdjust as bit = 0, @IncludeRegistry as bit = 0) 

RETURNS TABLE AS

RETURN

--Declare @AsAt datetime
--
--Declare @Location varchar(10)
--
--Declare @Currency char(3)
--
--Declare @PriceAsAt datetime
--
--Declare @PortfolioAdjust as bit
--
--Declare @IncludeRegistry as bit
--
--
--
--SET @AsAt = '2012-07-12'
--
--SET @Location = 'Custody'
--
--SET @Currency = 'GBP'
--
--SET @PriceAsAt = '2012-07-12'
--
--SET @PortfolioAdjust = 0
--
--SET @IncludeRegistry = 1


SELECT CLAccountID,

sum(Amount * coalesce(fx2.a, 1) / coalesce(fx1.a,1)) as ProductValue, 

sum(AmountChecksUncleared * coalesce(fx2.a, 1) / coalesce(fx1.a,1)) As ProductValueOfUnclearedCheques

FROM (

SELECT ST.ClAccountID,

I.InstrumentCCY as CCYCode,

sum(ST.quantity * S.O) as Amount, 0 as AmountChecksUncleared

FROM dbo.ScripTransactions ST 

INNER JOIN res_db.dbo.instruments I ON ST.InstrumentCode = I.security 

INNER JOIN res_db.dbo.securities S on I.security = S.security AND S.Date = @PriceAsAt

WHERE ST.AsAt < dateadd(d,1,@AsAt) AND ST.TransStatus = 'Settled' 

and (replace(ST.Location,'BTA','Custody') = @Location or @Location = 'ALL' or (@IncludeRegistry = 1 AND ST.Location='Registry'))

GROUP BY ST.ClAccountID, I.InstrumentCCY

HAVING sum(ST.quantity) <> 0

UNION ALL

SELECT CLT.CLAccountID, rtrim(CLT.CCYcode) CCYCode, -round(sum(CLT.Amount),2) Amount, 0 as AmountChecksUncleared

FROM CashLedgerTransactions CLT 

WHERE CLT.LedgerDate < dateadd(d,1,@AsAt)

GROUP BY CLT.CLAccountID, CLT.CCYCode

UNION ALL

SELECT CLA.ClAccountID, rtrim(CLA.CCYcode) CCYCode, -round(sum(CLA.Amount),2) Amount, 0 as AmountChecksUncleared

FROM dbo.CashLedgerAdjustments CLA

WHERE CLA.LedgerDate < dateadd(d,1,@AsAt)

AND PortfolioAdjust = CASE WHEN @PortfolioAdjust = 1 THEN 1 ELSE 0 END

GROUP BY CLA.ClAccountID, CLA.CCYCode

UNION ALL

SELECT CLA.ClAccountID, rtrim(CLA.CCYcode) CCYCode, 0 as Amount, -round(sum(CLA.Amount),2) as AmountChecksUncleared

FROM dbo.CashLedgerAdjustments CLA

WHERE CLA.LedgerDate > @AsAt and CLA.adjustmenttype = 'UNCLEARED_CHEQUE'

AND PortfolioAdjust = CASE WHEN @PortfolioAdjust = 1 THEN 1 ELSE 0 END

GROUP BY CLA.ClAccountID, CLA.CCYCode

UNION ALL

SELECT CMT.ClAccountID, rtrim(CMT.currency) CCYCode, round(sum(CMT.amount),2) Amount, 0 as AmountChecksUncleared

FROM dbo.CMTTrans CMT

WHERE CMT.trandate < dateadd(d,1,@AsAt)

GROUP BY CMT.ClAccountID, CMT.currency

UNION ALL

SELECT CT.ClAccountID, rtrim(CT.cncycode) CCYCode, round(sum(CT.amount),2) Amount, 0 as AmountChecksUncleared

FROM dbo.cashtransactions CT

WHERE asat < dateadd(d,1,@AsAt) and transstatus <> 'cancelled' and CT.location = 'external'

and @Location in ('External','All')

GROUP BY CT.ClAccountID, CT.cncycode

) Amounts

LEFT JOIN res_db.dbo.securities Fx1 on Fx1.Security = Amounts.CCYCode + 'USD' and Fx1.date = @PriceAsAt

LEFT JOIN res_db.dbo.securities Fx2 on Fx2.Security = @Currency + 'USD' and Fx2.date = @PriceAsAt

GROUP BY ClAccountID
GO
