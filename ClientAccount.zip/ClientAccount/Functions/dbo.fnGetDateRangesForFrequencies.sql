SET QUOTED_IDENTIFIER ON
GO

SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[fnGetDateRangesForFrequencies] (
	@asAt DATETIME
	,@seed DATETIME
	)
RETURNS TABLE
AS
--	DECLARE @asAt AS DATETIME
--	DECLARE @seed AS DATETIME
--	SET @asAt = GETDATE()
--	SET @seed = '01/01/2001';
RETURN
WITH FrqAndSeed_Months AS (
		SELECT 'M' Frequency
			,1.0 MULTIPLIER
			,@seed Seed
		
		UNION ALL
		
		SELECT 'Q' Frequency
			,3.0 MULTIPLIER
			,@seed Seed
		
		UNION ALL
		
		SELECT 'H' Frequency
			,6.0 MULTIPLIER
			,@seed Seed
		
		UNION ALL
		
		SELECT 'A' Frequency
			,12.0 MULTIPLIER
			,@seed Seed

		UNION ALL
		
		SELECT 'Y' Frequency
			,12.0 MULTIPLIER
			,@seed Seed
		)
	,NextSeedDate_Months AS (
		SELECT Frequency
			,multiplier
			,Seed
			,CASE 
				--WHEN Frequency = 'M'
				--	THEN DATEADD(D, CASE 
				--				WHEN DATEPART(D, Seed) > DATEPART(D, DATEADD(D, - 1, DATEADD(M, DATEDIFF(M, 0, @asAt) + 1, 0)))
				--					THEN DATEPART(D, DATEADD(D, - 1, DATEADD(M, DATEDIFF(M, 0, @asAt) + 1, 0)))
				--				ELSE DATEPART(D, Seed)
				--				END - 1, DATEADD(M, CASE 
				--					WHEN DATEPART(D, Seed) < DATEPART(D, @asAt)
				--						THEN 1
				--					ELSE 0
				--					END + DATEDIFF(M, 0, @asAt), 0))
				--ELSE CASE 
						WHEN DATEADD(M, CEILING(DATEDIFF(M, Seed, @asAt) / MULTIPLIER) * multiplier, Seed) <= @AsAt
							THEN DATEADD(M, CEILING(DATEDIFF(M, Seed, @asAt) / MULTIPLIER) * multiplier + multiplier, Seed)
						ELSE DATEADD(M, CEILING(DATEDIFF(M, Seed, @asAt) / MULTIPLIER) * multiplier, Seed)
						--END
				END AS NextSeedDate
		FROM FrqAndSeed_Months
		),
		FrqAndSeed_Days AS (
		SELECT 'D' Frequency
			,1.0 MULTIPLIER
			,@seed Seed
		UNION ALL
		SELECT 'W' Frequency
			,7.0 MULTIPLIER
			,@seed Seed
		UNION ALL
		SELECT 'F' Frequency
			,14.0 MULTIPLIER
			,@seed Seed
		)
	,NextSeedDate_Days AS (
		SELECT Frequency
			,multiplier
			,Seed
			,CASE 
				WHEN Frequency = 'D'
					THEN DATEADD(D, 1, @AsAt)
				ELSE CASE 
						WHEN DATEADD(D, CEILING(DATEDIFF(D, Seed, @asAt) / MULTIPLIER) * multiplier, Seed) <= @AsAt
							THEN DATEADD(D, CEILING(DATEDIFF(D, Seed, @asAt) / MULTIPLIER) * multiplier + multiplier, Seed)
						ELSE DATEADD(D, CEILING(DATEDIFF(D, Seed, @asAt) / MULTIPLIER) * multiplier, Seed)
						END
				END AS NextSeedDate
		FROM FrqAndSeed_Days
		)
SELECT Frequency
	,DATEADD(M, - 1 * multiplier, NextSeedDate) AS FromDate
	,DATEADD(D, - 1, NextSeedDate) AS ToDate
	,DATEDIFF(D, DATEADD(M, - 1 * multiplier, NextSeedDate), NextSeedDate) DaysInThisPeriod
	,NextSeedDate NextFromDate
	,DATEADD(D, - 1, DATEADD(M, 1 * multiplier, NextSeedDate)) AS NextToDate
	,DATEDIFF(D, NextSeedDate, DATEADD(M, 1 * multiplier, NextSeedDate)) DaysInNextPeriod
FROM NextSeedDate_Months

UNION ALL

SELECT Frequency
	,DATEADD(D, - 1 * multiplier, NextSeedDate) AS FromDate
	,DATEADD(D, - 1, NextSeedDate) AS ToDate
	,DATEDIFF(D, DATEADD(D, - 1 * multiplier, NextSeedDate), NextSeedDate) DaysInThisPeriod
	,NextSeedDate NextFromDate
	,DATEADD(D, - 1, DATEADD(D, 1 * multiplier, NextSeedDate)) AS NextToDate
	,DATEDIFF(D, NextSeedDate, DATEADD(D, 1 * multiplier, NextSeedDate)) DaysInNextPeriod
FROM NextSeedDate_Days
GO


