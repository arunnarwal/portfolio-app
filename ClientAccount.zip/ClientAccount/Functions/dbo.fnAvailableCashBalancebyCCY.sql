/***
<Function>
    <Description>Exposes available cash balances by currency</Description>
    <Parameters>
        <Parameter Name="@AsAt">
            <Description>The date as at the balances should be fo</Description>
        </Parameter>
        <Parameter Name="@BatchId">
            <Description>Specific order batch ID to exclude</Description>
        </Parameter>
    </Parameters>
</Function>
***/
CREATE FUNCTION [dbo].[fnAvailableCashBalancebyCCY]
(
    @AsAt DATETIME,
    @BatchId INT = 0
)
RETURNS TABLE AS
RETURN
    SELECT
        ClAccountId,
        CCYCode,
        WrapProvider,
        CLTbalance,
        CMTbalance,
        CLAbalance,
        CLAAvailableAdjustBalance,
        CLAPortfolioAdjustBalance,
        CLAFeeAdjustBalance,
        Withdrawals,
        BuyOrders,
        BuyOrdersWithSettledCash,
        BuyOrdersExComm,
        InsuredFundsBuyOrders,
        SellOrders,
        SellOrdersSameBatch,
        AvailableBalance,
        UnclearedCheques,
        DealsInProgress,
        SellDealsInProgress,
        BuyDealsInProgress,
        BuyDealsInProgressExcludingSwitches, 
        FeeExpectations,
        FutureDatedFeeExpectations,
        UnsettledCash,
        UnsettledCashDebits,
        UnsettledCashPostedFees,
        UnclearedDeposits,
        SettlingToday,
        SwitchSellOrders,
        SwitchSellsWithUnsettledBuys,
        SellOrdersFundingWithdrawals,
        ETBalance	
    FROM
        dbo.FnAvailableCashBalancebyCCY_Base(@AsAt, @BatchId, DEFAULT, DEFAULT)
