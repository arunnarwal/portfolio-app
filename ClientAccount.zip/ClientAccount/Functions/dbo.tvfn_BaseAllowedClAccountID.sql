SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE function [dbo].[tvfn_BaseAllowedClAccountID] (@claccountid varchar(20)) returns @allowed_clients table
(
	ClAccountid varchar(20),
	Clientid int,
	Companies varchar(255),
	AdvisorCodes varchar(255),
	ReadWrite tinyint,
	SuperUser varchar(2))
AS
begin
insert into @allowed_clients
SELECT seca.claccountid, ClientID, Companies, AdvisorCodes, ReadWrite, Superuser 
FROM ClientAccountSecurity cas
inner join SEClientAccount seca on cas.advisorcodes = seca.primaryadviser and cas.claccountid is null
and  seca.claccountid = @claccountid;

insert into @allowed_clients
SELECT CON.subclaccountid as claccountid, clientid, companies, advisorcodes, readwrite, superuser 
FROM clientaccountsecurity cas
inner join dbo.Consolidate CON on CON.ClAccountID = CAS.ClAccountID
where cas.claccountid is not null
and cas.claccountid = @claccountid;

return ;
end;
GO
