

CREATE FUNCTION [dbo].[fn_ValidateChequeClearanceDays]()
RETURNS @valTable TABLE
([Type] varchar(10),[Message] varchar(100),DBName varchar(100),DBTable varchar(100), [Owner] varchar(100), SiteOwner varchar(100))
AS
BEGIN
	
IF (SELECT COUNT(*) FROM dbo.CashLedgerAdjustments clt1
		INNER JOIN dbo.CashLedgerAdjustments clt2 ON clt1.Reference = clt2.Reference AND clt2.Amount < 0
	WHERE clt1.AdjustmentType = 'UNCLEARED_CHEQUE' AND clt1.Amount > 0 AND clt2.LedgerDate = clientaccount.dbo.fnGetNextBusinessDay(clientaccount.dbo.fnGetNextBusinessDay(clientaccount.dbo.fnGetNextBusinessDay(clt1.LedgerDate)))) > 0 
BEGIN 
	BEGIN
		INSERT INTO @valTable(type, message, DBName, DBTable, owner, SiteOwner)
		VALUES ('Warning', 'Cheques with incorrect clearance days (3 business days).','ClientAccount', 'CashLedgerAdjustments','Audrey Wan', 'All')
	END
END

return 

END
GO
