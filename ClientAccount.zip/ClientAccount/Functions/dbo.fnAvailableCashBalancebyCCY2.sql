/***
<Function>
    <Description>Exposes available cash balances by currency</Description>
    <Parameters>
        <Parameter Name="@AsAt">
            <Description>The date as at the balances should be fo</Description>
        </Parameter>
        <Parameter Name="@BatchId">
            <Description>Specific order batch ID to exclude</Description>
        </Parameter>
    </Parameters>
</Function>
***/
CREATE FUNCTION [dbo].[fnAvailableCashBalancebyCCY2]
(
	@AsAt DATETIME,
	@BatchId INT = 0
)
RETURNS TABLE AS
RETURN
	SELECT
        ClAccountId,
		CCYCode,
		CLTbalance,
		CMTbalance,
		CLAbalance,
		CLAAvailableAdjustBalance,
		CLAPortfolioAdjustBalance,
		CLAFeeAdjustBalance,
		Withdrawals,
		BuyOrders,
		InsuredFundsBuyOrders,
		SellOrders,
		SellOrdersSameBatch,
		AvailableBalance,
		UnclearedCheques,
		DealsInProgress,
		SellDealsInProgress,
		BuyDealsInProgress,
		FeeExpectations
	FROM
        dbo.FnAvailableCashBalancebyCCY_Base(@AsAt, @BatchId, DEFAULT, DEFAULT)
