

CREATE FUNCTION [dbo].[fnOngoingAccrualChargeSettings] (@AsAt DATETIME)
RETURNS TABLE
AS
RETURN (
		SELECT CSETTING.Id
			,CSetting.[Type]
			,CSetting.HeadClAccountId
			,CSetting.ProductType
			,FH.ClAccountId
			,CSetting.Rate
			,CSetting.AsAt
			,CSetting.DateAdded
			,CSetting.UserAdded
			,CSetting.CallerSource
			,CSetting.SessionId
			,CSetting.Note
			,CSetting.DateCancelled
			,CSetting.UserCancelled
	FROM Discovery.dbo.ProductDetails PD
		INNER JOIN dbo.fnHeadAccounts() FH ON PD.ClAccountId = FH.ClAccountId AND FH.Consolidated = 0
		INNER JOIN dbo.OngoingAccrualChargeSettings CSETTING ON CSETTING.HeadClAccountId = FH.HeadClAccountId AND CSETTING.ProductType = PD.ProductType
		INNER JOIN (
			SELECT HeadClAccountId, MAX(Id) AS MaxID
			FROM dbo.OngoingAccrualChargeSettings
			WHERE DateCancelled IS NULL
				AND AsAt <= @AsAt
			GROUP BY [Type]
				,HeadClAccountId
				,ProductType
				,Type	
			) LatestDate ON LatestDate.MaxId = CSETTING.Id AND LatestDate.HeadClAccountId = CSETTING.HeadClAccountId
		) 
GO
