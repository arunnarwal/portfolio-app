SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- =============================================
-- Author:		jmachala
-- Create date: 01-Dec-2011
-- Description:	
-- =============================================
--DROP FUNCTION [dbo].[fnGetDisplayProductName_SL]
CREATE FUNCTION [dbo].[fnGetDisplayProductName_SL] 
(
	-- Add the parameters for the function here
	@oldProductName varchar(150)
)
RETURNS varchar(150)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result varchar(150)

	-- Add the T-SQL statements to compute the return value here
	SELECT @Result = 
		CASE 
			WHEN @oldProductName = 'ISA Cash' THEN 'Cash ISA'
			WHEN @oldProductName = 'ISA Stocks' OR @oldProductName = 'ISA Stocks & Shares' OR @oldProductName = 'ISA Stocks/Shares' THEN 'Stocks & Shares ISA'
			WHEN @oldProductName = 'SIPP' THEN 'Self Invested Personal Pension'
			WHEN @oldProductName = 'Offshore Bond' THEN 'International Portfolio Bond'
			WHEN @oldProductName = 'Onshore Bond' THEN 'Onshore Bond'
			WHEN @oldProductName = 'Personal Portfolio' THEN 'Personal Portfolio'
			WHEN @oldProductName = 'Wrap Cash' THEN 'Wrap Cash'
			WHEN @oldProductName = 'Other' THEN 'Other (Legacy Products)' 
			WHEN @oldProductName = '' THEN 'Other (Legacy Products)'
			ELSE
				@oldProductName
		END

	-- Return the result of the function
	RETURN @Result

END
GO
