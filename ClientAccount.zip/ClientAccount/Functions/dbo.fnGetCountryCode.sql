CREATE FUNCTION [dbo].[fnGetCountryCode](@WrapProvider varchar(20)) RETURNS VARCHAR(3)
AS
BEGIN

--DECLARE @WrapProvider as VarChar(20);
--SET @WrapProvider = 'DIS'
 
	DECLARE @CountryCode VARCHAR(3)

	SET @CountryCode =
		(SELECT 
			TOP 1 Country_code AS CountryCode
		FROM
			dbo.WrapProvider WP
			INNER JOIN WebDB.dbo.WrapProviderJurisdiction WPJUR ON WP.Id = WPJUR.WrapProviderId
			INNER JOIN Res_Db.dbo.Country JUR ON WPJUR.JurisdictionId = JUR.Id
		WHERE
			WP.WrapProvider = @WrapProvider)

	RETURN @CountryCode

END

GO