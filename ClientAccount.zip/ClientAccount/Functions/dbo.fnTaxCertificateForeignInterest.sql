/***
<Function>
	<Description>Function to get foreign interest details for tax certificate</Description>
	<Parameters>
		<Parameter Name="@FromDate">
			<Description>From date. For example, '2016-04-06 00:00:00'</Description>
		</Parameter>
		<Parameter Name="@ToDate">
			<Description>To date. For example, '2017-04-05 00:00:00'</Description>
		</Parameter>
		<Parameter Name="@SubAccounts">
			<Description>List of sub-accounts. For example, 'ID1005150-001,ID1005177-001'</Description>
		</Parameter>
	</Parameters>
</Function>
***/

CREATE FUNCTION [dbo].[fnTaxCertificateForeignInterest](@FromDate datetime, @ToDate datetime, @SubAccounts VARCHAR(MAX))
RETURNS TABLE
AS
RETURN

/*
USE ClientAccount

DECLARE @FromDate DATETIME;
DECLARE @ToDate DATETIME;
DECLARE @SubAccounts VARCHAR(MAX);

SET @FromDate = '2016-04-06 00:00:00';
SET @ToDate = '2017-04-05 00:00:00';
SET @SubAccounts = 'ID1005150-001,ID1005177-001';
*/

WITH SubAccount AS(
	SELECT TabValue FROM CSFBMaster.dbo.fn_convert_comma_to_table_char(@SubAccounts)
)
SELECT
	TI.ID,
	TI.CorpActID,
	TI.LedgerDate,
	TI.DisplayName,
	CRY.ISOCountryCode as Domicile,
	TI.QualifyingHolding,
	TI.Gross,
	TI.WT,
	TI.Gross - TI.WT + TI.Equalisation AS AmtPaid,
	TI.SecuritySubType,
	TI.MFIncomeType,
	TI.[Type]
FROM
	dbo.vwTaxableIncomeDataForUK TI
	INNER JOIN SubAccount SA
		ON SA.TabValue = TI.ClAccountID
	LEFT JOIN res_db.dbo.Country CRY
		ON TI.Domicile = CRY.Country
WHERE
	TI.LedgerDate >= @FromDate
	AND TI.LedgerDate <= @ToDate
	AND TI.Reversal IS NULL
	AND TI. Domicile <> 'UK'
	AND TI.SubAccountType IS NOT NULL AND TI.SubAccountType <> ''
