/***
<View>
	<Description>Cash Ledger transactions and pending Cash entries that are used by services to display on UI, all transaction types are included</Description>
</View>
***/

CREATE FUNCTION dbo.fnMergedCashTransactionsViaApi(@SubAccountIdsCsv AS VARCHAR(MAX), @ExcludeManualCashAdjustments AS BIT) RETURNS TABLE
AS

RETURN

--Declare @SubAccountIdsCsv AS VARCHAR(MAX) = '125076'
--declare @ExcludeManualCashAdjustments AS BIT = 0;


WITH Accounts AS (
SELECT Csv.TabValue AS SubAccountId, SECA.ClAccountID	
FROM CSFBMaster.dbo.Fn_convert_comma_to_table_int(@SubAccountIdsCsv) Csv
INNER JOIN dbo.SEClientAccount AS SECA ON SECA.Id = Csv.TabValue
)
,Trans AS (
	SELECT 
		GT.AccountId,
		GT.TransactionId,
		GT.LedgerDate,
		GT.MovementTypeId,
		GT.CurrencyId,
		GT.Amount,
		GT.MovementSourceId,
	    GT.RestrictSweepUntil
	FROM  CashLedger.GladTransactions AS GT		
	WHERE  
		GT.DisplayToClient = 1		
		AND GT.Amount <> 0
		AND GT.AccountId IN (select S.SubAccountId FROM Accounts S)		
		AND (@ExcludeManualCashAdjustments = 0 OR NOT EXISTS (SELECT 1 FROM CashLedger.ManualCashAdjustmentTransactions MCAT WHERE MCAT.TransactionId = GT.TransactionId))

  UNION ALL

	SELECT 
		GT.AccountId,
		GT.TransactionId,
		GT.LedgerDate,
		GT.MovementTypeId,
		GT.CurrencyId,
		GT.Amount,
		GT.MovementSourceId,
		CONVERT(SMALLDATETIME, NULL) RestrictSweepUntil
	FROM  CashLedger.ExternalTransactions AS GT		
	WHERE  
		GT.DisplayToClient = 1		
		AND GT.Amount <> 0
		AND GT.AccountId IN (select S.SubAccountId FROM Accounts S)	
),
Clt AS (
	SELECT
		GT.AccountId AS SubAccountId,
		GT.TransactionId,
		GT.LedgerDate,
		MT.MovementType,
		C.CurrencyCode AS CcyCode,
		-GT.Amount           AS Amount,
		tn.Narrative,
	    T.CreatedDateTime AS DateCreated,
		TOD.OrderID,
		TCED.CashEntryId AS OriginatingCashEntryID,
		TCD.ArlId,
		GT.RestrictSweepUntil,
		TCAD.CorporateActionId AS CorpActId,
		MS.MovementSource
	FROM Trans AS GT
		INNER JOIN CashLedger.Transactions AS T ON GT.TransactionId = T.TransactionId
		INNER JOIN CashLedger.MovementTypes AS MT ON MT.MovementTypeId = GT.MovementTypeId
		INNER JOIN CashLedger.Currencies AS C ON C.CurrencyId = GT.CurrencyId
		INNER JOIN CashLedger.MovementSources AS MS ON MS.MovementSourceId = GT.MovementSourceId
		LEFT JOIN CashLedger.TransactionNarratives AS TN ON TN.TransactionId = GT.TransactionId
		LEFT JOIN CashLedger.OrderTransactions AS TOD ON TOD.TransactionId = T.TransactionId
		LEFT JOIN CashLedger.ChargeTransactions AS TCD ON TCD.TransactionId = T.TransactionId
		LEFT JOIN CashLedger.CashEntryTransactions AS TCED ON TCED.TransactionId = T.TransactionId
		LEFT JOIN CashLedger.CorporateActionTransactions AS TCAD ON TCAD.TransactionId = t.TransactionId
	WHERE MT.MovementType <> 'CALL_TRANSACTION'
),
Transactions AS (
SELECT  DISTINCT
		CLT.TransactionId,
		A.SubAccountId,
	    CLT.LedgerDate AS TransactionDate,
		COALESCE(CLT.RestrictSweepUntil, CLT.LedgerDate) AS SettlementDate,
		CLT.Amount,
		CLT.CCYCode AS Currency,
		CLT.Narrative,
	    CLT.DateCreated,		
	    CLT.MovementType,		
		ARL.Trantype AS ChargeType,	
		CE.AWScripTransferID AS TransferId,
		COALESCE(CLT.OrderId, CLT.OriginatingCashEntryId, CLT.CorpActId, CLT.ArlId) AS SourceActionId
FROM Clt AS CLT      
INNER JOIN Accounts A ON A.SubAccountId = CLT.SubAccountId				 
LEFT JOIN Discovery.dbo.AdvisorRevenueLedger ARL ON ARL.Id = CLT.ArlId
LEFT JOIN Discovery.dbo.CashEntry CE ON CE.Id = CLT.OriginatingCashEntryId
WHERE (@ExcludeManualCashAdjustments = 0 OR CE.Id IS NULL OR NOT EXISTS(SELECT 1 FROM ClientAccount.dbo.ManualCashAdjustmentRequests MCAT WHERE MCAT.OriginalContributionTransId = CLT.TransactionId AND MCAT.Status = 'Completed'))

UNION ALL

SELECT  DISTINCT
		R.TransID AS TransactionId,
		ACC.SubAccountId,
	    R.LedgerDate AS TransactionDate,
		R.LedgerDate AS SettlementDate,
		R.Amount,
		R.CCYCode AS Currency,
		R.Narrative,
	    R.DateCreated,		
	    R.MovementType,		
		ARL.Trantype AS ChargeType,
		CE.AWScripTransferID AS TransferId,
		COALESCE(R.OrderId, R.OriginatingCashEntryId, R.CorpActId, R.ArlId) AS SourceActionId
FROM Accounts ACC
INNER JOIN dbo.RegistryCashLedgerTransactions R ON R.ClAccountId = ACC.ClAccountId			 
LEFT JOIN Discovery.dbo.AdvisorRevenueLedger ARL ON ARL.Id = R.ArlId
LEFT JOIN Discovery.dbo.CashEntry CE ON CE.Id = R.OriginatingCashEntryId

UNION ALL

SELECT 	DISTINCT
		CMT.Id AS TransactionId,
		ACC.SubAccountId,
	    CMT.TransactionDate,
		CMT.TransactionDate AS SettlementDate,
		CMT.Amount,
		CMT.Currency,
		NULL AS Narrative,
	    CMT.TransactionDate AS DateCreated,		
	    CMT.TransType AS MovementType,		
		NULL AS ChargeType,	
		NULL AS TransferId,
		NULL AS SourceActionId
FROM Accounts ACC
INNER JOIN dbo.CmtTrans CMT ON CMT.ClAccountId = ACC.ClAccountId
WHERE	
		CMT.TransType IN ('Interest','AIL','RWT','NRWT') 
		AND CMT.DisplayToClient = 1 
		AND CMT.Amount <> 0 
)

SELECT 
	T.TransactionId AS ReferenceNumber, 
	'Completed' AS Status,
	T.SubAccountId,
	T.Amount AS Value,
	T.Currency,
	T.TransactionDate,		
	PD.ProductType,	
	PD.ProductSubTypeId,
	T.Narrative,		
	T.MovementType,
	T.ChargeType,	
	T.TransferId,
	SUM(T.Amount) OVER (PARTITION BY T.SubAccountId ORDER BY T.TransactionDate, T.TransactionId ROWS UNBOUNDED PRECEDING) AS Balance
FROM
	Transactions T	
INNER JOIN Accounts A ON A.SubAccountId = T.SubAccountId	
INNER JOIN Discovery.dbo.ProductDetails AS PD ON A.ClAccountID = PD.ClAccountId	

UNION ALL

SELECT
	CE.Id AS ReferenceNumber,
	'Pending' AS [Status],	
	SE.Id as SubAccountId,
	CASE
	WHEN CE.MovementType IN ('Capital In', 'CAPITAL_IN', 'Deposit') THEN CE.Amount
	WHEN CE.MovementType IN ('Capital Out', 'CAPITAL_OUT', 'Withdrawal') THEN -CE.Amount
	ELSE 0
	END AS Value,	
	CE.Currency,
	CE.DateCreated AS TransactionDate,	
	PD.ProductType,
	PD.ProductSubTypeId,
	CE.Narration AS Narrative,
	CASE
		WHEN CE.Method = 'internal transfer' THEN 'Internal Transfer'
		WHEN CE.Method = 'transferred subscription' THEN 'Transferred Subscription'
		ELSE CE.Type 
	END AS Method,
	NULL AS ChargeType,
	CE.AWScripTransferID AS TransferId,
	NULL AS Balance
FROM
	Discovery.dbo.CashEntry AS CE
INNER JOIN dbo.SeClientaccount AS SE on SE.Claccountid = CE.Claccountid
INNER JOIN Discovery.dbo.ProductDetails AS PD on PD.Claccountid = CE.Claccountid
INNER JOIN Accounts ACC ON ACC.SubAccountId = SE.Id
WHERE	
	CE.[Status] IN ('Authorised', 'Confirmed', 'Placed')
	AND CE.InstructionType != 'Standing'

