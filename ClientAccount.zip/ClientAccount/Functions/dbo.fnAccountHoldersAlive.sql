SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[fnAccountHoldersAlive] (@HeadAccountID varchar(20) = 'ALL') RETURNS TABLE AS 
--	DECLARE @HeadAccountID varchar(20)
--	SET @HeadAccountID = 'GS2003130'
	RETURN
	select CLAccountID,Count(ID) as Total,0 as Deceased from clientaccount..accountholders WHERE CLAccountID = @HeadAccountID OR @HeadAccountID = 'ALL' Group By CLAccountID
	UNION ALL
	select CLAccountID,0 as Total,Count(ID) as Deceased from clientaccount..accountholders WHERE (CLAccountID = @HeadAccountID OR @HeadAccountID = 'ALL') AND Deceased = 1 Group By CLAccountID
GO
