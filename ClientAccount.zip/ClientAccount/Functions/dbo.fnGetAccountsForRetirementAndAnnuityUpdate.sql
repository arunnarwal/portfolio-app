SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/* 
=============================================  
 Author:  skasparo  
 Create date: 17 February 2012
 Description: selects accounts for update of retirement date and annuity purchase age
 ============================================= 
*/ 
CREATE FUNCTION [dbo].[fnGetAccountsForRetirementAndAnnuityUpdate] (@AsAt DateTime)  
RETURNS TABLE AS 
RETURN ( 
/*
declare @AsAt As DateTime
set @AsAt = '2012-02-17 00:00:00'
;
*/
with valuedAccounts as
(
select HA.HeadClAccountID,ATV.ArrangementType,sum(FUM.TotalValue) As TotalValue from
(
select acc.ClAccountID,acc.ArrangementType from
(
select PD.ClAccountID,PD.ArrangementType from Discovery..ProductDetails PD inner join Discovery..ClientAccount CA on PD.ClAccountID = CA.ClAccountID
where PD.ArrangementType in ('Accumulation','Crystallised') and CA.Status = 'Active' and PD.IsPlatformFund = 0 
) acc
UNION ALL
select vfa.fundaccount as ClAccountID,acc1.ArrangementType from
(
select PD.ClAccountID,PD.ArrangementType from Discovery..ProductDetails PD inner join Discovery..ClientAccount CA on PD.ClAccountID = CA.ClAccountID
where PD.ArrangementType in ('Accumulation','Crystallised') and CA.Status = 'Active' and PD.IsPlatformFund = 0 
) acc1
inner join ClientAccount..vwFundAccountsByHolder vfa on acc1.claccountid = vfa.holderaccount and vfa.holderaccount is not null
UNION ALL
select vfa2.fundaccount as ClAccountID,acc2.ArrangementType from
(
select PD.ClAccountID,PD.ArrangementType from Discovery..ProductDetails PD inner join Discovery..ClientAccount CA on PD.ClAccountID = CA.ClAccountID
where PD.ArrangementType in ('Accumulation','Crystallised') and CA.Status = 'Active' and PD.IsPlatformFund = 0 
) acc2
inner join ClientAccount..vwFundAccountsByHolder vfa1 on acc2.claccountid = vfa1.holderaccount and vfa1.holderaccount is not null
inner join ClientAccount..vwFundAccountsByHolder vfa2 on vfa1.fundaccount = vfa2.holderaccount and vfa2.holderaccount is not null
) ATV
inner join ClientAccount..vwHeadAccounts HA on HA.ClAccountID = ATV.ClAccountID
inner join cache..fumbyaccbydate FUM on ATV.ClAccountID = FUM.ClAccountID and FUM.AsAt = @AsAt and FUM.TotalValue > 0
group by HA.HeadClAccountID,ATV.ArrangementType 
having sum(FUM.TotalValue) > 0
),
accountsToRoll as
(
select distinct 
HA.HeadClAccountID,
PD.ArrangementType, 
CA.DateOfBirth, 
CD.RetirementDate, 
CD.AnnuityPurchaseAge 
from 
Discovery..ProductDetails PD 
inner join ClientAccount..vwHeadAccounts HA on HA.ClAccountID = PD.ClAccountID
inner join Discovery..ClientAccount CA on HA.HeadClAccountID = CA.ClAccountID
inner join ClientAccount..ClientDetails CD on HA.HeadClAccountID = CD.ClAccountID
where
PD.ArrangementType = 'Accumulation' and CD.RetirementDate <= getdate() and dateadd(yy,75,CA.DateOfBirth) > dateadd(dd,1,CD.RetirementDate) and PD.IsPlatformFund = 0 and CA.Status = 'Active'
UNION ALL
select distinct 
HA.HeadClAccountID,
PD.ArrangementType, 
CA.DateOfBirth, 
CD.RetirementDate, 
CD.AnnuityPurchaseAge 
from 
Discovery..ProductDetails PD 
inner join ClientAccount..vwHeadAccounts HA on HA.ClAccountID = PD.ClAccountID
inner join Discovery..ClientAccount CA on HA.HeadClAccountID = CA.ClAccountID
inner join ClientAccount..ClientDetails CD on HA.HeadClAccountID = CD.ClAccountID
where
PD.ArrangementType = 'Crystallised' and dateadd(yy,(CD.AnnuityPurchaseAge-10),CA.DateOfBirth) <= getdate() and CD.AnnuityPurchaseAge < 99 and PD.IsPlatformFund = 0 and CA.Status = 'Active'
) 

select
ATR.HeadClAccountID,
ATR.ArrangementType, 
ATR.DateOfBirth, 
ATR.RetirementDate, 
ATR.AnnuityPurchaseAge 
from 
accountsToRoll ATR
inner join valuedAccounts VA on ATR.HeadClAccountID = VA.HeadClAccountID and ATR.ArrangementType = VA.ArrangementType

/* order by ATR.HeadClAccountID,ATR.ArrangementType */ 
)
GO
