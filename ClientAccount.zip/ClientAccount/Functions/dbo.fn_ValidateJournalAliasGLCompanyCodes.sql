

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[fn_ValidateJournalAliasGLCompanyCodes]()
RETURNS @valTable TABLE
([Type] varchar(10),[Message] varchar(100),DBName varchar(100),DBTable varchar(100), [Owner] varchar(100), SiteOwner varchar(100))
AS
BEGIN
	
IF (SELECT COUNT(*) FROM dbo.GladJournalActionAlias
WHERE GLCompanyCode NOT IN (SELECT GLCompany FROM dbo.GladCompany)) > 0 
BEGIN 
	BEGIN
		INSERT INTO @valTable(type, message, DBName, DBTable, owner, SiteOwner)
		VALUES ('Warning', 'Journal Alias GL Company Codes not set up.','ClientAccount', 'GladJournalActionAlias','Audrey Wan', 'All')
	END
END

return 

END
GO
