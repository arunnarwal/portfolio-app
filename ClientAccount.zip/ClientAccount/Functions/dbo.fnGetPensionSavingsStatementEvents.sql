/***
<Function>
    <Description>Get events for pension savings statements</Description>
</Function>
***/

SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[fnGetPensionSavingsStatementEvents] ( @FromDate DATETIME, @ToDate DATETIME )
RETURNS @EventsTab TABLE
	(
		ClAccountID		VARCHAR (20),
		Title			VARCHAR (25),
		FirstName		VARCHAR (50),
		Surname			VARCHAR (50),
		DateOfBirth		datetime,
		NINO			VARCHAR (20),
		Amount			MONEY,
		TaxYear			INT
	)
AS
BEGIN
	--DECLARE @FromDate DATETIME
	--DECLARE @ToDate DATETIME
	--SET @FromDate = '2015-10-06 00:00:00.000'
	--SET @ToDate = '2016-01-06 00:00:00.000'

	INSERT @EventsTab
		SELECT  
			PSI.ClAccountId,
			AH.Title,
			AH.Given AS FirstName,
			AH.Surname,
			AH.DateOfBirth,
			AH.IRDNo AS NINO,
			AMN.Amount,
			AMN.TaxYear
		FROM
			(SELECT DISTINCT 
				SD.ClAccountID
				FROM dbo.SippDetails SD
				INNER JOIN Discovery.dbo.CashEntry CE 
					ON SD.ClAccountID = CE.ClAccountID
				INNER JOIN Discovery.dbo.ProductDetails PD 
					ON PD.ClAccountId = SD.ClAccountId
			WHERE 
				SD.InputPeriodStart IS NULL 
				AND PD.ArrangementType = 'Accumulation'
				AND CE.Type = 'Deposit' 
				AND CE.Status = 'Completed' 
				AND (CE.SubType IS NULL 
					OR CE.SubType <> 'Transfer')
			) AS PSI
			INNER JOIN dbo.fnHeadAccounts() HA 
				ON HA.ClAccountID = PSI.ClAccountID
			INNER JOIN dbo.AccountHolders AH 
				ON HA.HeadClAccountID = AH.ClAccountID
			INNER JOIN dbo.fnGetTotalPensionInputAmountByAccount(@FromDate, @ToDate) AMN
				ON HA.HeadClAccountID = AMN.ClAccountID
	RETURN
END

GO