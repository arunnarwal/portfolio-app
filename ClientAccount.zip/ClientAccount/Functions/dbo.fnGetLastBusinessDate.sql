-- =============================================
-- Author:		Petr Pavlicek
-- Create date: 2014-04-01
-- Description:	Returns the last business day
-- =============================================
CREATE FUNCTION [dbo].[fnGetLastBusinessDate] 
(
	@asAt DATETIME
)
RETURNS DATETIME
AS
BEGIN
	DECLARE  @retValue DATETIME

	SELECT @retValue = Max(D.DATE)
	FROM   res_db.dbo.dates D
		   LEFT JOIN LiveDB.dbo.holidays H
			 ON D.DATE = H.HolidayDate
	WHERE  D.DATE <= @asAt
		   AND H.id IS NULL

    RETURN @retValue
END

GO

