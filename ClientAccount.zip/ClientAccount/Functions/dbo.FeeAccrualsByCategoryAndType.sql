SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE function [dbo].[FeeAccrualsByCategoryAndType](@ChargeDate datetime, @WrapProvider varchar(20), @RestrictByChargeDate tinyint = 1) Returns TABLE AS

Return
Select	FAD.ClAccountId,
		coalesce(ADVMP.AdvisorAccount, FAD.ClAccountID) As DestinationClAccountID,
		SE.PrimaryAdviser,
		C.Company, 
		C.WrapProvider, 
		CA.SubAccountType, 
		FAD.Type,
		FAD.Category, 
		FAD.ChargeDate,
		FAD.InstrumentCode,
		I.SecurityType,
		DPD.ProductType,
		coalesce(MF.InsuredFund,0) as InsuredFund,	
		sum(FAD.TotalAmount) as TotalAmount,
		sum(FAD.ClientAmount) as ClientAmount, 
		Sum(FAD.AdvisorAmount) as AdvisorAmount, 
		sum(FAD.CorporateAmount) as CorporateAmount

From ClientAccount..FeeAccrualDetail2 as FAD
		inner join ClientAccount..SEClientAccount as SE on SE.claccountid = FAD.claccountid
		inner join discovery..ProductDetails  as DPD on FAD.ClAccountID = DPD.ClAccountID 
		inner join discovery..clientaccount as CA on SE.claccountid = CA.claccountid
		inner join clientaccount..clientdetails as CD on SE.claccountid = CD.claccountid
		inner join clientaccount..company as C on C.Company = CD.company
		left join res_db..instruments I on I.security = FAD.InstrumentCode
		left join res_db..managedfunds MF on MF.InstrumentCode = FAD.InstrumentCode
		left join ClientAccount..vwFundAccountToAdvisorAccount ADVMP on ADVMP.FundAccount = CD.claccountid AND @WrapProvider = 'GS'
		LEFT OUTER JOIN ClientAccount..fnAccountHasCancellationsOptOuts() HasOptOuts ON FAD.ClAccountID = HasOptOuts.ClAccountID

Where C.WrapProvider = @WrapProvider and FAD.ChargeDate <= @ChargeDate and FAD.RestrictByChargeDate = @RestrictByChargeDate and processeddatetime is null and COALESCE(HasOptOuts.HasOpenAutoOptOut, 0 ) = 0

GROUP BY FAD.ClAccountId, ADVMP.AdvisorAccount, SE.PrimaryAdviser, C.Company, C.WrapProvider, CA.SubAccountType, 
		FAD.Type, FAD.Category, FAD.ChargeDate, FAD.InstrumentCode, I.SecurityType, MF.InsuredFund, DPD.ProductType
HAVING sum(FAD.totalAmount) <> 0

-- exec CSFBMaster..spUpdateMetaDB 'FeeAccrualsByCategoryAndType', 'clafFeeAccrualsByCategoryAndType', 'ClientAccount'
GO
