SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[fnGLADClientTransactionsForCallSweep] (@AsAt DateTime, @GLADCashSweepType varchar(20)) RETURNS TABLE AS

RETURN
select CLT.TransID, CLT.CLAccountID, CLT.CCYCode, CLT.Amount, WP.WrapProvider, CCD.Company
From ClientAccount.dbo.CashLedgerTransactions CLT 
	INNER JOIN ClientAccount.dbo.GladCashEntriesToSweep E on E.TransID = CLT.TransID
	Inner Join ClientAccount.dbo.ClientDetails CCD ON CCD.ClAccountID = CLT.ClAccountID 
	Inner Join Discovery.dbo.ClientAccount CA ON CA.ClAccountID = CCD.ClAccountID 
	Inner Join ClientAccount.dbo.Company CO on CO.Company = CCD.Company
	Inner Join ClientAccount.dbo.WrapProvider WP ON CO.WrapProvider = WP.WrapProvider
	Left Join gladProductCashSweeps PCS ON PCS.SubAccountType = CA.SubAccountType And PCS.WrapProvider = WP.WrapProvider
	
Where	E.Destination = @GLADCashSweepType And PCS.DestinationClAccountID Is Null 
		And CCD.InvestorType not in ('CONTROL','FundManager') And WP.SweepFundsToCall = 1
		and CLT.LedgerSource = 'GLAD' And CLT.LedgerDate <= @AsAt And (CLT.RestrictSweepUntil <= @AsAt Or CLT.RestrictSweepUntil Is Null)
GO
