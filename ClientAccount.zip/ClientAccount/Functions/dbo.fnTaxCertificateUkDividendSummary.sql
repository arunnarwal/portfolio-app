CREATE FUNCTION [dbo].[fnTaxCertificateUkDividendSummary](@FromDate datetime, @ToDate datetime)
RETURNS TABLE
AS
RETURN

/*
USE ClientAccount

DECLARE @FromDate DATETIME;
DECLARE @ToDate DATETIME;

SET @FromDate = '2016-04-06 00:00:00';
SET @ToDate = '2017-04-05 00:00:00';
*/

SELECT
	TIDFU.ClAccountID,
	TIDFU.Gross,
	TIDFU.WT,
	TIDFU.SecuritySubType,
	TIDFU.MFIncomeType,
	TIDFU.Gross - TIDFU.WT + TIDFU.Equalisation AS AmtPaid
FROM
	dbo.vwTaxableIncomeDataForUK AS TIDFU
WHERE
	TIDFU.LedgerDate >= @FromDate
	AND TIDFU.LedgerDate <= @ToDate
	AND TIDFU.Reversal IS NULL
	AND TIDFU.[Type] = 'Dividend'
	AND TIDFU.Domicile = 'UK'
    AND TIDFU.SubAccountType IS NOT NULL AND TIDFU.SubAccountType <> ''
	AND TIDFU.PID = 0
