

CREATE FUNCTION [dbo].[fn_ValidateMatchedCashHaveCashLedgerTransactions]()
RETURNS @valTable TABLE
([Type] varchar(10),[Message] varchar(100),DBName varchar(100),DBTable varchar(100), [Owner] varchar(100), SiteOwner varchar(100))
AS
BEGIN
	
IF (SELECT COUNT(*) FROM dbo.ReconciledResults 
		WHERE RecID IN (SELECT RecID FROM ClientAccount..Reconciliations WHERE Type = 'Cash Expectation' AND TableConstant LIKE '%CashEntry%')
			AND IDFieldValue NOT IN (SELECT OriginatingCashEntryID FROM ClientAccount..CashLedgerTransactions WHERE Reference Like 'Cash%')) > 0 
BEGIN 
	BEGIN
		INSERT INTO @valTable(type, message, DBName, DBTable, owner, SiteOwner)
		VALUES ('Warning', 'Matched cash with missing CashLedgerTransactions.','ClientAccount', 'ReconciledResults','Audrey Wan', 'All')
	END
END

return 

END
GO
