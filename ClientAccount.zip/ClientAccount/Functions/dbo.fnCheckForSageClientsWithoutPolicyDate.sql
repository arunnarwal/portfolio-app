

CREATE FUNCTION [dbo].[fnCheckForSageClientsWithoutPolicyDate](@WrapProvider as VarChar(20)) 
RETURNS @valTable TABLE
([Type] varchar(10),[Message] varchar(100),DBName varchar(100),DBTable varchar(100), [Owner] varchar(100), SiteOwner varchar(100))
AS
BEGIN
IF
(SELECT 
	COUNT(HA.HeadClAccountId)
	FROM Discovery.dbo.ProductDetails PD
		INNER JOIN Discovery.dbo.ClientAccount CA
			ON CA.ClAccountId = PD.ClAccountId
		INNER JOIN dbo.fnHeadAccounts() HA 
			ON PD.ClAccountId = HA.ClAccountId AND HA.Consolidated = 0
		INNER JOIN dbo.ClientDetails CD
			ON CD.CLAccountId = HA.HeadClAccountId
	WHERE 
		PD.ArrangementType = 'Crystallised' 
		AND PD.producttype IN ('NPR','PR')
		AND CD.SAGEPolicyStartDate IS NULL 
		AND CA.Status = 'active'
		AND CONVERT(datetime, CONVERT(char, getDate(), 106)) > (SELECT clientaccount.dbo.fnGetNextBusinessDay(dateAdd(dd,1,PD.datecreated)))
	) > 0
 BEGIN
	BEGIN
		INSERT INTO @valTable(type, message, DBName, DBTable, owner, SiteOwner)
		VALUES ('Warning', 'Sage policy clients found with no SagePolicyStartDate','ClientAccount', 'ClientDetails','Jono', @WrapProvider)
	END
END

return 

END
GO
