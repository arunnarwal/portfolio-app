CREATE FUNCTION [dbo].[fnGetTaxExemptAccountsFromTaxExemptCompaniesForMFR]() Returns TABLE AS
	RETURN

	SELECT seca.ClAccountID, seca.Id SubAccountId FROM dbo.SEClientAccount seca
	INNER JOIN Discovery.dbo.ProductDetails pd on pd.ClAccountid = seca.ClAccountID
	INNER JOIN dbo.Advisor adv on adv.AdvCode = seca.PrimaryAdviser
	INNER JOIN dbo.Company c on c.Company = adv.Company
	WHERE PD.ProductType = 'Personal Portfolio'
	AND C.CompanyType = 'thirdparty'
	AND C.IsTaxExempt = 1

GO
