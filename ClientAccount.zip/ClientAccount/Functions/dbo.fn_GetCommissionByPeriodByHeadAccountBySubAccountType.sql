

-- =============================================

-- Author: imcghee

-- Create date: 21 feb 2009

-- Description:

-- =============================================

CREATE FUNCTION [dbo].[fn_GetCommissionByPeriodByHeadAccountBySubAccountType]

(

-- Add the parameters for the function here

@periodStart datetime,

@periodEnd datetime

)

RETURNS TABLE

AS

RETURN

(

--Declare @PeriodStart as datetime

--Declare @PeriodEnd as datetime

--set @PeriodStart='01 Aug 2009'

--set @PeriodEnd='31 Aug 2009'

SELECT HEAD.HeadClAccountId,

CA.SubAccountType,

SUM(CPMP.TPCCharge)as TPCCharge,

SUM(CPMP.Ic) as Ic,

SUM(CPMP.Wic) as Wic,

SUM(CPMP.AdvisorFBRCCharge)as AdvisorFBRCCharge ,

SUM(CPMP.FBRCCharge)as FBRCCharge,

SUM(CPMP.AdHocCommission)as AdHocCommission,

SUM(CPMP.Bceic)as Bceic,

SUM(CPMP.Popc)as Popc,

SUM(CPMP.Dopc)as Dopc,

SUM(CPMP.Donc)as Donc,

SUM(CPMP.Ponc)as Ponc,

SUM(CPMP.Sic)as Sic,

SUM(CPMP.Switch)as Switch,

SUM(CPMP.NewCash)as NewCash,

SUM(CPMP.ReregAmount)as ReregAmount,

SUM(CPMP.AverageFundsUnderManagement)as AverageFundsUnderManagement,

SUM(CPMP.TotalDailyFundsUnderManagement)as TotalDailyFundsUnderManagement,

SUM(CPMP.SwitchAmounts)as SwitchAmounts,

SUM(CPMP.CrystalisedAmount)as CrystalisedAmount,

SUM(CPMP.DFMFixedCharge) as DFMFixedCharge,

SUM(CPMP.Dfmic) as Dfmic,

SUM(CPMP.DFMTieredCharge) as DFMTieredCharge

FROM dbo.CommissionPerMonthlyPeriod CPMP

INNER JOIN Discovery.dbo.ClientAccount CA

ON CPMP.ClaccountId =CA.ClAccountId

INNER JOIN dbo.fnHeadAccounts() HEAD

ON CPMP.ClaccountId =HEAD.ClAccountId AND HEAD.Consolidated=0

WHERE CPMP.PeriodStart >= @PeriodStart AND CPMP.PeriodEnd < dateadd(day,1,@PeriodEnd)

GROUP BY HEAD.HeadClAccountId,CA.SubAccountType

)
GO
