SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
Create FUNCTION [dbo].[fnGetLinkedAccountsCommaSeparatedList](@ClAccountId VarChar(20))
Returns varchar(1000)
As
BEGIN
DECLARE @LinkedAccounts varchar(1000)

SELECT @LinkedAccounts = COALESCE(@LinkedAccounts + ', ', '') +  SubClAccountID 
FROM clientaccount..consolidate WHERE ClAccountID = @CLAccountID AND SubClAccountID NOT like @CLAccountID + '%' 

Return @LinkedAccounts
END
GO
