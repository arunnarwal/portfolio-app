
/***
<Function>
	<Description>Gets corp act preferences for a list of accounts</Description>
	<Parameters>
		<Parameter Name="@ClAccountId">
			<Description>CLAccountid for which to get active CAP</Description>
		</Parameter>
		<Parameter Name="@AsAt">
			<Description>Date for which CAP was active</Description>
		</Parameter>
	</Parameters>
</Function>
***/
CREATE FUNCTION [dbo].[fnCorporateActionAccountPreferences] (
	@ClAccountId VARCHAR(max)
	,@AsAt DATETIME
	)
RETURNS @Result TABLE(   
    Id int
    , AccountId int
    , ClAccountId Varchar(20)
    , DRP bit
    , AsAt DateTime
)
AS 
BEGIN

DECLARE @clientAccountTable AS TABLE(ClAccountId Varchar(20) PRIMARY KEY)
INSERT INTO @clientAccountTable
SELECT RTRIM(LTRIM( t.Tabvalue )) FROM Csfbmaster.dbo.[fn_convert_comma_to_table_char](@ClAccountId) t


DECLARE @temId varchar(20)
while EXISTS(SELECT TOP 1 * FROM @clientAccountTable)
    BEGIN
        SELECT TOP 1 @temId = ClAccountId FROM @clientAccountTable

		INSERT INTO @Result
		SELECT TOP 1 CAP.Id,CAP.AccountId,Seca.ClAccountId,CAP.Drp,CAP.AsAt
		FROM dbo.CorporateActionPreferences CAP
		INNER JOIN dbo.SEClientAccount seca ON seca.Id = CAP.AccountId
		WHERE CAP.AsAt < @AsAt 
		AND seca.ClAccountID = @temId
		ORDER BY CAP.AsAt DESC

		DELETE FROM @clientAccountTable WHERE ClAccountId = @temId 
    END

RETURN 
END

