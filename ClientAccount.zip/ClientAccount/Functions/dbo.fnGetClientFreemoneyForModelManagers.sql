GO
/****** Object:  UserDefinedFunction [dbo].[fnGetClientFreemoneyForModelManagers]    Script Date: 10/01/2014 09:59:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[fnGetClientFreemoneyForModelManagers] (@AsAt DATETIME)
	
RETURNS @result TABLE(ClAccountID                   VARCHAR(50),
					  ModelManagerName				VARCHAR(100),
                      currency                      VARCHAR(20),
                      callbalance                   NUMERIC(18,4),
                      ledgerbalance                 NUMERIC(18,4),
                      buyadjustments                NUMERIC(18,4),
                      selladjustments               NUMERIC(18,4),
                      feeadjustments                NUMERIC(18,4),
                      adjustments                   NUMERIC(18,4),
                      combinedbalance               NUMERIC(18,4),
                      portfoliobalance              NUMERIC(18,4))
AS

BEGIN
 
DECLARE  @ModelManagerAcounts  AS  TABLE(claccountid VARCHAR(30) PRIMARY KEY CLUSTERED, ModelManagerName VARCHAR(100))  
       
INSERT INTO @ModelManagerAcounts(ClAccountID, ModelManagerName)
SELECT HA.ClAccountID, MM.Name as ModelManagerName
FROM Res_db..ModelManager MM 
	INNER JOIN clientaccount..seClientAccount CA ON MM.PooledAccountId = CA.ID
	INNER JOIN ClientAccount..vwHeadAccounts HA ON HA.HeadClAccountID = CA.ClAccountID

INSERT @result
SELECT	ccd.ClAccountID,
		MMA.ModelManagerName,
		dtbl.currency,
		SUM(dtbl.callbalance) AS callbalance,
		SUM(dtbl.cltbalance) as ledgerbalance,
		SUM(dtbl.buyadjustments) as buyadjustments,
		SUM(dtbl.selladjustments) as selladjustments,
		SUM(dtbl.feeadjustments) as feeadjustments,
		SUM(Coalesce(dtbl.selladjustments,0) + Coalesce(dtbl.buyadjustments,0) + Coalesce(dtbl.feeadjustments,0))  AS adjustments,
		SUM(dtbl.callbalance + dtbl.cltbalance + dtbl.buyadjustments + dtbl.selladjustments + dtbl.feeadjustments) AS combinedbalance,
		SUM(dtbl.callbalance + dtbl.cltbalance) AS portfoliobalance								
FROM	(
			SELECT   x.claccountid,
                    x.currency,
                    Sum(x.callbalance)     AS callbalance,
                    Sum(x.cltbalance)      AS cltbalance,
                    Sum(x.buyadjustments)  AS buyadjustments,
                    Sum(x.selladjustments) AS selladjustments,
                    Sum(x.feeadjustments)  AS feeadjustments
            FROM    (
					/*CMT Balance*/
					SELECT   cmt.claccountid,
                                cmt.currency,
                                Round(Sum(cmt.amount),2) AS callbalance,
                                0                        AS cltbalance,
                                0                        AS buyadjustments,
                                0                        AS selladjustments,
                                0                        AS feeadjustments
                    FROM     cmttrans cmt
                    WHERE    cmt.trandate <= @AsAt
                    GROUP BY cmt.claccountid,
                                cmt.currency
                    UNION ALL
                    /*CLT Balance*/
                    SELECT clt.claccountid,
                            clt.ccycode,
                            0                         callbalance,
                            Round(Sum(-clt.amount),2) AS cltbalance,
                            0                         AS buyadjustments,
                            0                         AS selladjustments,
                            0                         AS feeadjustments
                    FROM     cashledgertransactions clt
                    WHERE    clt.ledgerdate <= @AsAt
                                AND clt.ledgersource = 'GLAD'
                    GROUP BY clt.claccountid,
                                clt.ccycode
                    UNION ALL
                    /*Adjustments*/
                    SELECT clt.claccountid,
                            clt.ccycode,
                            0               callbalance,
                            0               cltbalance,
                            Sum(CASE 
                                    WHEN oc.orderbuysell = 'BUY' THEN Round(clt.amount,2)
                                    ELSE 0
                                END),
                            Sum(CASE 
                                    WHEN oc.orderbuysell = 'SELL'
                                        AND (parentoc.orderid IS NOT NULL 
                                            OR ordrel.TYPE IS NULL) THEN Round(clt.amount,2)
                                    ELSE 0
                                END) selladjustments,
                            Sum(CASE 
                                    WHEN clt.arlid IS NOT NULL THEN Round(clt.amount,2)
                                    ELSE 0
                                END) feeadjustments
                    FROM     cashledgertransactions clt
                                LEFT JOIN discovery..ordercurrent oc
                                ON oc.orderid = clt.orderid
                                LEFT JOIN discovery..orderrelationship ordrel
                                ON oc.orderid = ordrel.toorderid
                                LEFT JOIN discovery..ordercurrent parentoc
                                ON parentoc.orderid = ordrel.fromorderid
                                    AND (parentoc.status NOT IN ('Completed','Cancelled')
                                        OR (parentoc.status IN ('Completed','Cancelled')
                                            AND (parentoc.datecompleted > @asat + 1
                                                    OR parentoc.datecancelled > @asat + 1)))
                    WHERE    Dateadd(dd,0,clt.ledgerdate) <= @AsAt
                                AND clt.ledgersource = 'GLAD'
                                /* unsettled trades, but ignore uncleared cheques*/
                                AND (clt.restrictsweepuntil > @AsAt
                                    AND clt.movementtype NOT LIKE 'CAPITAL_IN%')
                                AND clt.movementsource NOT IN ('Pending','PostPending') /*LIKE '%Pending'*/
                    GROUP BY clt.claccountid,
                                clt.ccycode
                    UNION ALL
                    /*Parent Adjustments*/
                    SELECT parentoc.claccountid,
                            clt.ccycode,
                            0                        callbalance,
                            0                        cltbalance,
                            0                        buyadjustments,
                            Sum(Round(clt.amount,2)) selladjustments,
                            0                        feeadjustments
                    FROM     cashledgertransactions clt
                                INNER JOIN discovery..ordercurrent oc
                                ON oc.orderid = clt.orderid
                                INNER JOIN discovery..orderrelationship ordrel
                                ON oc.orderid = ordrel.toorderid
                                INNER JOIN discovery..ordercurrent parentoc
                                ON parentoc.orderid = ordrel.fromorderid
                                    AND (parentoc.status = 'Completed'
                                        AND parentoc.datecompleted <= @AsAt + 1)
                                INNER JOIN res_db..accountinstrumentmappings m
                                ON m.instrumentcode = parentoc.instrumentcode
                                    AND m.claccountid = clt.claccountid
                    WHERE    Dateadd(dd,0,clt.ledgerdate) <= @AsAt
                                AND clt.ledgersource = 'GLAD'
                                AND oc.orderbuysell = 'Sell'
                                /* unsettled trades, but ignore uncleared cheques*/
                                AND (clt.restrictsweepuntil > @AsAt
                                    AND clt.movementtype NOT LIKE 'CAPITAL_IN%')
                                AND clt.movementsource NOT IN ('Pending','PostPending') /*LIKE '%Pending'*/
                    GROUP BY parentoc.claccountid,
                                clt.ccycode) x
            GROUP BY x.claccountid,
                    x.currency
            HAVING   Sum(x.callbalance) <> 0
                    OR Sum(x.cltbalance) <> 0
                    OR Sum(x.buyadjustments) <> 0
                    OR Sum(x.selladjustments) <> 0
					OR Sum(x.FeeAdjustments) <> 0
		    ) dtbl
            INNER JOIN clientaccount..clientdetails ccd 
            ON ccd.claccountid = dtbl.claccountid
            INNER JOIN clientaccount..seclientaccount sca ON ccd.claccountid = sca.claccountid
            INNER JOIN clientaccount..company com ON ccd.company = com.company
            INNER JOIN @ModelManagerAcounts MMA ON MMA.claccountid = dtbl.claccountid            			             
WHERE    ccd.investortype <> 'CONTROL'
         AND ccd.investortype <> 'FundManager'
GROUP BY MMA.ModelManagerName, 
		ccd.ClAccountID,
		dtbl.currency

RETURN
END
    







GO


