SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[fnHistoricalAllowedAccountsOverDateRange](@ClientID int, @FromDate datetime, @ToDate datetime) 
RETURNS @Table Table (ClAccountID varchar(20) not null, FromDate datetime not null, ToDate datetime not null) AS

begin
INSERT INTO @Table
SELECT	ClAccountID,
		@FromDate as FromDate,
		@ToDate as ToDate
FROM	ClientAccount.dbo.vwBaseAllowedClAccountID Per
			left join ClientAccount.dbo.NetworkSuperUsers N on N.ClientID = Per.ClientID
WHERE	Per.clientid = @ClientID and N.ID is null
UNION ALL
SELECT	ClAccountID,
		Coalesce(mins.MinDate, @FromDate) as FromDate,
		Coalesce(max.MaxDate, @ToDate) as ToDate
FROM	ClientAccount.dbo.vwBaseAllowedClAccountID Per
			inner join ClientAccount.dbo.NetworkSuperUsers N on N.ClientID = Per.ClientID
			inner join ClientAccount.dbo.Advisor A on A.AdvCode = Per.AdvisorCodes
			left join
				(SELECT min(HM.DateAdded) as MinDate,
						HM.MappingItemName,
						HM.MapTo
						
					from ClientAccount.dbo.HierarchyMappings HM 
					where HM.MappingItemType = 'Company' and HM.MappingType = 'Network' and HM.DateAdded > @FromDate
					group by HM.MappingItemName, HM.MapTo
					) mins on mins.MappingItemName = A.Company and mins.MapTo = N.Network
			left join
				(SELECT max(HM.DateRemoved) as MaxDate,
						HM.MappingItemName,
						HM.MapTo
						
					from ClientAccount.dbo.HierarchyMappings HM 
					where HM.MappingItemType = 'Company' and HM.MappingType = 'Network' and HM.DateAdded < @FromDate
					group by HM.MappingItemName, HM.MapTo
					) max on max.MappingItemName = A.Company and max.MapTo = N.Network
			
WHERE	Per.clientid = @ClientID

RETURN
end
GO
