CREATE FUNCTION [dbo].[fnFee_Accruals_GetOutsandingTAMFR]
    (
      @ChargeDate DATETIME ,
      @WrapProvider VARCHAR(20)
    )
RETURNS TABLE
AS


--declare @ChargeDate datetime
--declare @WrapProvider varchar(20)
--
--SET @WrapProvider = 'DIM'
--SET @ChargeDate = '01 Jan 2014'
-- ;

RETURN
    WITH    FADTOTALS
              AS ( SELECT   FAD.SECAId ,
                            SECA.CLAccountID ,
                            SECA.PrimaryAdviser ,
                            FAD.ChargeDate ,
                            C.Company ,
                            C.WrapProvider ,
                            SUM(FAD.TotalAmount) AS TotalAmount ,
                            SUM(FAD.TAXAmount) AS TAXAmount ,
                            DATEADD(MONTH, DATEDIFF(MONTH, 0, FAD.ChargeDate) - 1, 0) AS FromDate , --First day of previous month based on ChargeDate
                            DATEADD(MONTH, DATEDIFF(MONTH, -1, FAD.ChargeDate) - 1, -1) AS ToDate , --Last Day of previous month based on ChargeDate
                            I.[Security] ,
                            AVG(FAD.Rate) AS Rate ,
                            FAD.CurrencyId
                   FROM     dbo.Fee_Accrual_TAMFR AS FAD
                            INNER JOIN      dbo.SEClientAccount AS SECA ON SECA.Id = FAD.SECAId
                            INNER JOIN      dbo.ClientDetails AS CD ON SECA.ClAccountId = CD.ClAccountId
                            INNER JOIN      dbo.Company AS C ON C.Company = CD.Company
                            INNER JOIN Res_db.dbo.Instruments AS I ON I.ID = FAD.InstrumentID
                   WHERE    FAD.ChargeDate <= @ChargeDate
                            AND FAD.ISProcessed = 0
                            AND C.WrapProvider = @WrapProvider
                   GROUP BY FAD.SECAId ,
                            SECA.CLAccountID ,
                            SECA.PrimaryAdviser ,
                            FAD.ChargeDate ,
                            C.WrapProvider ,
                            C.Company ,
                            I.[Security] ,
                            FAD.CurrencyId
                   HAVING   SUM(FAD.TotalAmount) <> 0
                 )
    SELECT  FADTOTALS.ClAccountId ,
            FADTOTALS.ClAccountId AS DestinationClAccountID ,
            FADTOTALS.PrimaryAdviser ,
            FADTOTALS.Company ,
            FADTOTALS.WrapProvider ,
            CA.SubAccountType ,
            'TAMFR' AS [Type] ,
            'TAMFR' AS Category ,
            FADTOTALS.ChargeDate ,
            FADTOTALS.FromDate ,
            FADTOTALS.ToDate ,
            PD.ProductType ,
            FADTOTALS.TotalAmount ,
            FADTOTALS.TAXAmount ,
            0 AS ClientAmount ,
            0 AS AdvisorAmount ,
            FADTOTALS.TotalAmount AS CorporateAmount ,
            FADTOTALS.[Security] AS InstrumentCode ,
            FADTOTALS.Rate ,
            FADTOTALS.CurrencyId
    FROM    FADTOTALS
            INNER JOIN Discovery.dbo.ProductDetails AS PD ON FADTOTALS.ClAccountId = PD.ClAccountId
            INNER JOIN Discovery.dbo.ClientAccount AS CA ON FADTOTALS.ClAccountId = CA.ClAccountId
GO