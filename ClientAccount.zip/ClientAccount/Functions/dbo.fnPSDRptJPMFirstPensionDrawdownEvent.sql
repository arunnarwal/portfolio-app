SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE FUNCTION [dbo].[fnPSDRptJPMFirstPensionDrawdownEvent]() RETURNS TABLE AS

RETURN 

SELECT SubclAccountID, MIN(ID) AS ID
FROM ClientAccount..PensionDrawdownEvents
GROUP BY SubClaccountID
GO
