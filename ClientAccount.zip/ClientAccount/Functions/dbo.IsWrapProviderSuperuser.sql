SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[IsWrapProviderSuperuser] (@ClientID Int, @WrapProvider varchar(20)) RETURNS bit AS

BEGIN
	DECLARE @Result TINYINT
	SELECT @Result = 
		CASE WHEN exists (select 1 from dbo.WrapProviderSuperUsers where ClientID = @ClientID and WrapProvider = @WrapProvider)
		THEN 1
		ELSE 0
		END
	RETURN @Result
END
GO
