SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[fn_getclientisaallowancereportdata]
              (@taxyearstartdate DATETIME,
               @tye              DATETIME)
RETURNS TABLE
AS
  RETURN
    /*
    declare @taxyearstartdate datetime, @company char(6), @adviser char(13),@tye datetime
    set @taxyearstartdate = '2009-04-06 00:00:00.000' 
    set @tye = '2010-04-06 00:00:00.000'
    set @company = 'AXAAAA'
    set @adviser = 'AXAAAA0000002'
    */
    SELECT ACCOUNT.claccountid,
           ACCOUNT.accountname,
           dob.dateofbirth,
           ACCOUNT.network,
           ACCOUNT.company,
           ACCOUNT.advcode,
           ACCOUNT.advname,
           ACCOUNT.baseccy,
           Coalesce(isacontributions.currenttaxcontribution,0) AS currenttaxcontribution,
           Coalesce(duecontributions.totalamount,0)            AS duetaxcontribution,
           Coalesce(nexttycontribution.totalamount,0)          AS nexttycontributions,
           producttype, 
		   ACCOUNT.investortype
    FROM   (SELECT ccd.claccountid,
                   ccd.status,
                   ccd.company,
                   com.network,
                   ccd.accountname,
                   ccd.advcode,
                   ccd.advname,
                   ccd.termsandconditionsagreed,
                   ccd.headclaccountid,
                   ccd.baseccy,
                   ccd.producttype,
				   ccd.investortype
            FROM   clientaccount..vwcombinedclientdetails AS ccd
                   LEFT JOIN clientaccount..company AS com
                     ON com.company = ccd.company
            WHERE  ccd.status IN ('active','submitted')
                   AND ccd.subaccounttype = 'ISA'
                   AND ccd.claccountid IN (SELECT claccountid
                                           FROM   discovery..productdetails
                                           WHERE  producttype IN ('Stocks/Shares','Cash')
                                                  AND coalesce(isdfmmanaged,0) = 0
                                                  AND coalesce(isplatformfund,0) = 0)) AS ACCOUNT
           LEFT JOIN clientaccount..accountholders AS dob
             ON ACCOUNT.headclaccountid = dob.claccountid
                AND dob.holdernumber = 1
           LEFT JOIN (SELECT   claccountid,
                               Sum(currenttaxcontribution) AS currenttaxcontribution
                      FROM     (SELECT   claccountid,
                                         Sum(amount) AS currenttaxcontribution
                                FROM     discovery..cashentry
                                WHERE    movementtype IN ('Capital In','CAPITAL_IN') /*Issue 337325: unfortunately we have to have both of these variants here (and all other movementtype conditions below)*/
                                         AND status = 'Completed'
                                         AND excludefromsublimit = 0
                                         AND datecompleted >= @taxyearstartdate
                                         AND datecompleted < @tye
                                         AND claccountid IN (SELECT claccountid
                                                             FROM   discovery..productdetails
                                                             WHERE  producttype IN ('Stocks/Shares','Cash')
                                                                    AND coalesce(isdfmmanaged,0) = 0
                                                                    AND coalesce(isplatformfund,0) = 0)
                                GROUP BY claccountid
                                UNION ALL
                                SELECT   pd.claccountid,
                                         Sum(amount)    AS currenttaxcontribution
                                FROM     discovery..cashentry ce
                                         INNER JOIN discovery..productdetails pd
                                           ON ce.accountnumber = pd.claccountid  /*Issue 337325: this had join on ce.claccountid, which is incorrect for internal transfers*/
                                WHERE    movementtype IN ('Capital In','CAPITAL_IN')
                                         AND status = 'Completed'
                                         AND TYPE = 'Withdrawal'
                                         AND excludefromsublimit = 0
                                         AND datecompleted >= @taxyearstartdate
                                         AND datecompleted < @tye
                                         AND method = 'Internal Transfer'
                                         AND producttype IN ('Stocks/Shares','Cash')
                                         AND coalesce(isdfmmanaged,0) = 0
                                         AND coalesce(isplatformfund,0) = 0
                                GROUP BY pd.claccountid) x
                      GROUP BY x.claccountid) AS isacontributions
             ON ACCOUNT.claccountid = isacontributions.claccountid
           LEFT JOIN (SELECT   claccountid,
                               Sum(VALUE)  AS totalamount
                      FROM     (SELECT   claccountid,
                                         Sum(CASE 
                                               WHEN datecompleted >= @taxyearstartdate
                                                    AND datecompleted < @tye THEN 1
                                               ELSE 0
                                             END + CASE 
                                                     WHEN frequency = 'Monthly' THEN CASE 
                                                                                       WHEN Datepart(d,nextpaydate) < Datepart(d,@tye) THEN 1
                                                                                       ELSE 0
                                                                                     END + CASE 
                                                                                             WHEN instructiontype = 'standing' THEN Datediff(m,nextpaydate,Dateadd(m,Datediff(m,0,@tye),0))
                                                                                             ELSE 1
                                                                                           END
                                                     WHEN frequency = 'Quarterly' THEN CASE 
                                                                                         WHEN Datepart(d,nextpaydate) < Datepart(d,@tye) THEN 1
                                                                                         ELSE 0
                                                                                       END + CASE 
                                                                                               WHEN instructiontype = 'standing' THEN Datediff(q,nextpaydate,Dateadd(q,Datediff(q,0,@tye),0))
                                                                                               ELSE 1
                                                                                             END
                                                     WHEN frequency = 'Yearly' THEN CASE 
                                                                                      WHEN Datepart(d,nextpaydate) < Datepart(d,@tye) THEN 1
                                                                                      ELSE 0
                                                                                    END + CASE 
                                                                                            WHEN instructiontype = 'standing' THEN Datediff(yy,nextpaydate,Dateadd(m,Datediff(m,0,@tye),0))
                                                                                            ELSE 1
                                                                                          END
                                                     ELSE 1
                                                   END * amount) AS VALUE
                                FROM     discovery..cashentry
                                WHERE    instructiontype IN ('Standing')
                                         AND movementtype IN ('Capital In','CAPITAL_IN')
                                         AND status IN ('Authorised','Placed')
                                         AND excludefromsublimit = 0
                                         AND nextpaydate <= @tye
                                GROUP BY claccountid
                                UNION ALL
                                SELECT   claccountid,
                                         Sum(amount) AS VALUE
                                FROM     discovery..cashentry
                                WHERE    instructiontype IN ('Auto','One-off')
                                         AND movementtype IN ('Capital In','CAPITAL_IN')
                                         AND status IN ('Authorised','Placed')
                                         AND excludefromsublimit = 0
                                         AND nextpaydate <= @tye
                                GROUP BY claccountid) tab1
                      GROUP BY claccountid) AS duecontributions
             ON ACCOUNT.claccountid = duecontributions.claccountid
           LEFT JOIN (SELECT   claccountid,
                               Sum(VALUE)  AS totalamount
                      FROM     (SELECT   claccountid,
                                         Sum(amount * CASE 
                                                        WHEN frequency = 'Monthly' THEN 12
                                                        WHEN frequency = 'Quarterly' THEN 4
                                                        WHEN frequency = 'Yearly' THEN 1
                                                        ELSE 0
                                                      END) AS VALUE
                                FROM     discovery..cashentry
                                WHERE    instructiontype IN ('Standing')
                                         AND movementtype IN ('Capital In','CAPITAL_IN')
                                         AND status IN ('Authorised','Placed')
                                         AND excludefromsublimit = 0
                                GROUP BY claccountid
                                UNION ALL
                                SELECT   accountnumber AS claccountid,
                                         Sum(amount)   AS VALUE
                                FROM     discovery..cashentry
                                WHERE    instructiontype IN ('Auto','One-off')
                                         AND method = 'Internal Transfer'
                                         AND movementtype IN ('Capital In','CAPITAL_IN')
                                         AND status IN ('Authorised','Placed')
                                         AND excludefromsublimit = 0
                                         AND firstdate >= @tye
                                GROUP BY accountnumber) tab2
                      GROUP BY claccountid) AS nexttycontribution
             ON ACCOUNT.claccountid = nexttycontribution.claccountid

GO
