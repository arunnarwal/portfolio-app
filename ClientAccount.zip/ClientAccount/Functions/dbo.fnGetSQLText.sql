SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
create function [dbo].[fnGetSQLText](@sql_handle binary(20))
returns varchar(8000)
as 
begin
            return (select cast ([text] as varchar(8000)) from ::fn_get_sql(@sql_handle))
end
GO
