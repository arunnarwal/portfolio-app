

-- =============================================

-- Author: <Author,,Name>

-- Create date: <Create Date,,>

-- Description: <Description,,>

-- =============================================

CREATE FUNCTION [dbo].[fn_GetCommissionByPeriodByHeadAccount]

(

-- Add the parameters for the function here

@periodStart datetime,

@periodEnd datetime

)

RETURNS TABLE

AS

RETURN

(

--Declare @PeriodStart as datetime

--Declare @PeriodEnd as datetime

----

--set @PeriodStart='01 Aug 2009'

--set @PeriodEnd='31 Aug 2009'

SELECT BASE.HeadClAccountId as claccountid,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.TPCCharge END) as WRAPCASHTPCCharge,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.TPCCharge END) as PPTPCCharge,

sum(CASE WHEN BASE.SubAccountType='ISA' THEN Base.TPCCharge END) as ISATPCCharge,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.TPCCharge END) as SIPPTPCCharge,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.Ic END) as WRAPCASHIC,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.Ic END) as PPIC,

sum(CASE WHEN BASE.SubAccountType='ISA' THEN Base.Ic END) as ISAIC,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.Ic END) as SIPPIC,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.Wic END) as WRAPCASHWIC,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.Wic END) as PPWIC,

sum(CASE WHEN BASE.SubAccountType='ISA' THEN Base.Wic END) as ISAWIC,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.Wic END) as SIPPWIC,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.AdvisorFBRCCharge END) as WRAPCASHAdvisorFBRCCharge,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.AdvisorFBRCCharge END) as PPAdvisorFBRCCharge,

sum(CASE WHEN BASE.SubAccountType='ISA' THEN Base.AdvisorFBRCCharge END) as ISAAdvisorFBRCCharge,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.AdvisorFBRCCharge END) as SIPPAdvisorFBRCCharge,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.FBRCCharge END) as WRAPCASHFBRCCharge,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.FBRCCharge END) as PPFBRCCharge,

sum(CASE WHEN BASE.SubAccountType='ISA' THEN Base.FBRCCharge END) as ISAFBRCCharge,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.FBRCCharge END) as SIPPFBRCCharge,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.AdHocCommission END) as WRAPCASHAdHocCommission,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.AdHocCommission END) as PPAdHocCommission,

sum(CASE WHEN BASE.SubAccountType='ISA' THEN Base.AdHocCommission END) as ISAAdHocCommission,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.AdHocCommission END) as SIPPAdHocCommission,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.Bceic END) as BCEIC,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.Popc END) as WRAPCASHPOPC,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.Popc END) as PPPOPC,

sum(CASE WHEN BASE.SubAccountType='ISA' THEN Base.Popc END) as ISAPOPC,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.Popc END) as SIPPPOPC,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.Dopc END) as SIPPDOPC,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.Donc END) as SIPPDONC,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.Ponc END) as WRAPCASHPONC,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.Ponc END) as PPPONC,

sum(CASE WHEN BASE.SubAccountType='ISA' THEN Base.Ponc END) as ISAPONC,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.Ponc END) as SIPPPONC,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.Sic END) as WRAPCASHSIC,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.Sic END) as PPSIC,

sum(CASE WHEN BASE.SubAccountType='ISA' THEN Base.Sic END) as ISASIC,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.Sic END) as SIPPSIC,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.Switch END) as WRAPCASHSWITCH,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.Switch END) as PPSWITCH,

sum(CASE WHEN BASE.SubAccountType='ISA' THEN Base.Switch END) as ISASWITCH,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.Switch END) as SIPPSWITCH,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.NewCash END) as WRAPCASHNewCash,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.NewCash END) as PPNewCash,

sum(CASE WHEN BASE.SubAccountType='ISA' THEN Base.NewCash END) as ISANewCash,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.NewCash END) as SIPPNewCash,



sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.ReregAmount END) as WRAPCASHReregAmount,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.ReregAmount END) as PPReregAmount,

sum(CASE WHEN BASE.SubAccountType='ISA' THEN Base.ReregAmount END) as ISAReregAmount,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.ReregAmount END) as SIPPReregAmount,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.AverageFundsUnderManagement END) as WRAPCASHAverageFundsUnderManagement,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.AverageFundsUnderManagement END) as PPAverageFundsUnderManagement,

sum(CASE WHEN BASE.SubAccountType='ISA' THEN Base.AverageFundsUnderManagement END) as ISAAverageFundsUnderManagement,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.AverageFundsUnderManagement END) as SIPPAverageFundsUnderManagement,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.TotalDailyFundsUnderManagement END) as WRAPCASHTotalDailyFundsUnderManagement,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.TotalDailyFundsUnderManagement END) as PPTotalDailyFundsUnderManagement,

sum(CASE WHEN BASE.SubAccountType='ISA' THEN Base.TotalDailyFundsUnderManagement END) as ISATotalDailyFundsUnderManagement,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.TotalDailyFundsUnderManagement END) as SIPPTotalDailyFundsUnderManagement,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.SwitchAmounts END) as WRAPCASHSwitchAmounts,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.SwitchAmounts END) as PPSwitchAmounts,

sum(CASE WHEN BASE.SubAccountType='ISA' THEN Base.SwitchAmounts END) as ISASwitchAmounts,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.SwitchAmounts END) as SIPPSwitchAmounts,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.CrystalisedAmount END) as SIPPCrystalisedAmount,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.DFMFixedCharge END) as WRAPCASHDFMFixedCharge,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.DFMFixedCharge END) as PPDFMFixedCharge,

sum(CASE WHEN BASE.SubAccountType='ISA' THEN Base.DFMFixedCharge END) as ISADFMFixedCharge,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.DFMFixedCharge END) as SIPPDFMFixedCharge,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.Dfmic END) as WRAPCASHDFMIC,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.Dfmic END) as PPDFMIC,

sum(CASE WHEN BASE.SubAccountType='ISA' THEN Base.Dfmic END) as ISADFMIC,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.Dfmic END) as SIPPDFMIC,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.DFMTieredCharge END) as WRAPCASHDFMTieredCharge,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.DFMTieredCharge END) as PPDFMTieredCharge,

sum(CASE WHEN BASE.SubAccountType='ISA' THEN Base.DFMTieredCharge END) as ISADFMTieredCharge,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.DFMTieredCharge END) as SIPPDFMTieredCharge

FROM dbo.fn_GetCommissionByPeriodByHeadAccountBySubAccountType(@PeriodStart,@PeriodEnd) BASE

GROUP BY BASE.HeadClAccountId

)
GO
