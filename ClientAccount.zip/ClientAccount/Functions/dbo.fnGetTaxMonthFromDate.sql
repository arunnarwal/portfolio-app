SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[fnGetTaxMonthFromDate]
              (@TaxDate DateTime)
RETURNS tinyint
AS
  BEGIN
    DECLARE  @offset int,
             @taxmonth INT,
			 @month INT
                          
	/*if it's before 6th, it counts as previous month*/
	IF day(@TaxDate)<6
		BEGIN		
		SET @offset = 1		
		END
	ELSE
		BEGIN
		SET @offset = 0
		END
	
	SET @month = month(@Taxdate)

	/*calculate the tax month number, starting at 1 from 6th of April*/
	IF (@month - 3 - @offset) < 1
		BEGIN
		SET @taxmonth = 12 + (@month - 3 - @offset)
		END
	ELSE
		BEGIN
		SET @taxmonth = @month - 3 - @offset
		END	
      
    RETURN @taxmonth
  END
GO
