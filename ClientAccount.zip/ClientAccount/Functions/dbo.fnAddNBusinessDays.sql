SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
-- =============================================
-- Author:		Martin Habr
-- Create date: 24/10/2012
-- Description:	Adds N working days
-- =============================================
CREATE FUNCTION [dbo].[fnAddNBusinessDays](@date as datetime, @numberOfDays as int)
RETURNS datetime 
WITH RETURNS NULL ON NULL INPUT
AS
BEGIN
	DECLARE @addOrDeduct int
	SET @addOrDeduct = 1
	IF (@numberOfDays < 0)
	BEGIN
		SET @addOrDeduct = -1
		SET @numberOfDays = -@numberOfDays
	END

	DECLARE @counter int
	SET @counter = @numberOfDays
	SET @date = convert(datetime, convert(char, @date, 106))
 
	WHILE @counter > 0 and @date is not null
	BEGIN
		SET @date = DATEADD(DAY,@addOrDeduct,@date)
		IF NOT EXISTS(select * from LiveDB.dbo.Holidays where HolidayDate = @date) AND datepart(dw,@date)<>7 AND datepart(dw,@date)<>1
		BEGIN
			SET @counter = @counter -1
		END	
	END

	RETURN @date
END
GO