CREATE FUNCTION [dbo].[fnHeadAccountsWithIds]() RETURNS TABLE AS

RETURN

SELECT	CON.SubClAccountID AS ClAccountID,
        SECA1.Id AS AccountId,
		CON.CLAccountID AS HeadClAccountID, 
		SECA2.Id AS HeadAccountId,
		CASE WHEN CD.InvestorType = 'Consolidated' THEN 1 ELSE 0 END AS [Consolidated]
FROM	dbo.Consolidate CON
JOIN    Discovery.dbo.ClientAccount CA ON CA.ClAccountID = CON.ClAccountID
JOIN    dbo.ClientDetails CD ON CD.ClAccountID = CON.ClAccountID
JOIN    dbo.SEClientAccount SECA1 ON SECA1.ClAccountID = CON.SubClAccountID
JOIN    dbo.SEClientAccount SECA2 ON SECA2.ClAccountID = CON.ClAccountID
WHERE	CA.DPSAccountType != 'Sub-Account'

GO