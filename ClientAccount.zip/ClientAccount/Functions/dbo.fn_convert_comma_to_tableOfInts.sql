SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[fn_convert_comma_to_tableOfInts]
              (@ListValues VARCHAR(max))
RETURNS @valTable TABLE(TabValue INT)
AS
  BEGIN
	/*
	DECLARE @ListValues VARCHAR(max)
	DECLARE @valTable TABLE(tabvalue INT)
	SET @ListValues = '2583771,2583767 ,2583749,,, ,2583747 ,2583745,1'
	*/

    DECLARE  @ListValueID VARCHAR(150),
             @Pos         INT,
			 @StartIndex INT
                          
    SELECT @StartIndex = 1, @ListValues = @ListValues + ','
	SET @Pos = CHARINDEX(',',@ListValues,@StartIndex)

	WHILE @Pos > 0
	BEGIN
		SET @ListValueID = SUBSTRING(@ListValues, @StartIndex, @Pos-@StartIndex)

		IF @Pos - @StartIndex > 0 AND ISNUMERIC(LTRIM(RTRIM(@ListValueID)) + 'e0') = 1
		BEGIN
			INSERT INTO @valTable (TabValue)
			VALUES (CAST(@ListValueID AS INT))			
		END
		SET @StartIndex = @Pos + 1
		SET @Pos = CHARINDEX(',',@ListValues,@StartIndex)		
	END   

    RETURN
  END

GO
