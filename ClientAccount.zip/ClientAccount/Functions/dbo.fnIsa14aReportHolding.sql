/*
<Function>
    <Description>Returns data of ISA 14a report. This is base function not used on the report directly.</Description>
    <Parameters>
        <Parameter Name="@AsAt">
            <Description>Date as at we want to return data.</Description>
        </Parameter>
        <Parameter Name="@IncludeIsa">
            <Description>Flag to include ISA sub-account holdings.</Description>
        </Parameter>
        <Parameter Name="@IncludeJisa">
            <Description>Flag to include JISA sub-account holdings.</Description>
        </Parameter>
    </Parameters>
</Function>
*/

CREATE FUNCTION [dbo].[fnIsa14aReportHolding] (@AsAt DATETIME, @IncludeIsa BIT, @IncludeJisa BIT)
RETURNS TABLE 
AS
RETURN	

/*
DECLARE @AsAt as DATETIME;
SET @AsAt = '06-Apr-2017';
*/

-- Get primary holder number for account
WITH PrimaryAccountHolder
(
	ClAccountID,
	HolderNumber
) AS (
	SELECT
		ClAccountID,
		MIN(HolderNumber)
	FROM
		dbo.AccountHolders
	GROUP BY
		ClAccountID
)
SELECT
	CA.ClAccountID AS ClAccountID,
	H.Quantity AS Quantity,
	H.Price AS Price,
	H.[Value] AS [Value],
	I.[Security] AS InstrumentCode,
	I.ISINCode AS ISIN,
	I.Descript AS Description,
	I.SecurityType AS SecurityType,
	I.SecuritySubType AS SecuritySubType,
	I.Sec_country AS Country,
	AH.Given AS Name,
	AH.Surname AS Surname
FROM
	Cache.dbo.fnHoldingValueByAccount(Cache.dbo.fnDateToBin(@AsAt), 27) AS H
	INNER JOIN res_db.dbo.Instruments AS I ON I.Id = H.InstrumentId
    LEFT JOIN Discovery.dbo.ClientAccount AS CA ON CA.ClAccountID = Cache.dbo.fnSECAIdToClAccountId(H.SECAId)
	LEFT JOIN dbo.fnHeadAccounts() AS HA ON HA.ClAccountID = CA.ClAccountID
	LEFT JOIN PrimaryAccountHolder AS PAH ON PAH.ClAccountID = HA.HeadClAccountID
	LEFT JOIN dbo.AccountHolders AS AH ON AH.ClAccountID = PAH.ClAccountID AND AH.HolderNumber = PAH.HolderNumber
	LEFT JOIN dbo.ClientDetails CD ON CD.ClAccountId = HA.HeadClAccountID
WHERE
	H.Quantity > 0 AND
	H.LocationGroupId = 1 AND
	CA.SubAccountType = 'ISA' AND
	((@IncludeIsa = 1 AND CD.IsJuniorAccount = 0) OR (@IncludeJisa = 1 AND CD.IsJuniorAccount = 1)) AND
	CA.Status NOT IN ('Deleted', 'Inactive')
