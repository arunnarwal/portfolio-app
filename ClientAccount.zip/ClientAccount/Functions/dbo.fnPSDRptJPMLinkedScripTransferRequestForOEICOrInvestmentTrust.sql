SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE FUNCTION [dbo].[fnPSDRptJPMLinkedScripTransferRequestForOEICOrInvestmentTrust](@ArrangementType as VarChar(20), @InstrumentType as varchar(20)) RETURNS TABLE AS

RETURN 

 --declare @ArrangementType as varchar(20)
 --declare @InstrumentType as varchar(20)
 --set @ArrangementType = 'Accumulation'
-- set @ArrangementType = 'Crystallised'
 --set @ArrangementType = ''
 --set @InstrumentType = 'Invest Trust'
 --set @InstrumentType = 'OEIC'


SELECT MF.UnitTrustOEIC, INS.SecuritySubType, STRQL.LinkedRequestID, SUM(Amount) As Amount 
	FROM Discovery..ScripTransferRequestLink STRQL
	INNER JOIN Discovery..ScripTransferRequest STRQ
		ON STRQ.RequestID = STRQL.LinkedRequestID And ( @ArrangementType  = '' Or (ArrangementType = @ArrangementType ))
	LEFT OUTER JOIN Res_Db..ManagedFunds MF
		ON STRQ.InstrumentCode = MF.InstrumentCode 
	LEFT OUTER JOIN Res_Db..Instruments INS
		ON STRQ.Instrumentcode = INS.Security 

	WHERE ( @InstrumentType = '' 
		  OR ( @InstrumentType = 'Invest Trust' AND INS.SecuritySubType = 'Invest Trust' )
		  OR ( @InstrumentType = 'OEIC' AND MF.UnitTrustOEIC = 'OEIC' )
			)
	GROUP BY STRQL.LinkedRequestID, MF.UnitTrustOEIC, INS.SecuritySubType
GO
