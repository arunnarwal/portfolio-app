SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
--drop function ClientAccount.dbo.fn_GetMinSubAccountActivationDate

CREATE FUNCTION [dbo].[fn_GetMinSubAccountActivationDate] (@ClAccountID as varchar(20), @SubAccountType as varchar(20) = '%', @Origin as varchar(50) = '%', @ArrangementType as varchar(50) = '%', @IncludeFullyWithdrawn as int = 1)
RETURNS DateTime 
AS
BEGIN
	RETURN
	(
--		DECLARE @ClAccountID as varchar(20)
--		DECLARE  @SubAccountType as varchar(20) 
--	    DECLARE @Origin as varchar(50) 
--		DECLARE @ArrangementType as varchar(50)
--		DECLARE  @IncludeFullyWithdrawn as int
--
--		SET @SubAccountType  = '%'
--		SET @ClAccountID  = 'CL1039230-001'
--		SET @Origin  = '%'
--		SET @ArrangementType  = '%'
--		SET @IncludeFullyWithdrawn  = 1

		SELECT	
				min(CD.ActivationDate) as MinimumActivationDate
		FROM
				ClientAccount..ClientDetails CD 
				INNER JOIN Discovery..ClientAccount CA ON CA.ClAccountID = CD.ClAccountID
				INNER JOIN Discovery..ProductDetails PD ON PD.ClAccountID = CD.ClAccountID
		WHERE
				CA.SubAccountType LIKE @SubAccountType AND CD.ClAccountID LIKE @ClAccountID
				AND (PD.Origin LIKE @Origin OR PD.Origin is NULL)
				AND (PD.ArrangementType LIKE @ArrangementType  OR PD.ArrangementType is NULL)
				AND (
						(COALESCE(PD.FullyWithdrawn,0) = 0 AND @IncludeFullyWithdrawn = 0)
							OR
						(@IncludeFullyWithdrawn = 1)
					)
	)
END
GO
