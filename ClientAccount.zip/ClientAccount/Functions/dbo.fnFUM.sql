SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE Function [dbo].[fnFUM](@AsAt datetime) RETURNS TABLE AS

RETURN

-- non cash assets

select 
	CDIH.ClAccountID, 
	CDIH.InstrumentCode, 
	convert(Numeric(18,2),CDIH.MarketValue + COALESCE(UnsettledInvestmentCash.Quantity * Price, 0)) as MarketValue, 
	CDIH.Price, 
	cast(CDIH.Quantity + COALESCE(UnsettledInvestmentCash.Quantity, 0) as money) as Quantity
from ClientAccount.dbo.ClientDailyInstrumentHoldings CDIH
left join 
(
	select sctr.claccountid, sctr.instrumentcode, sum(sctr.quantity) as Quantity
	from Discovery..scriptransferrequest sctr
	where sctr.status NOT IN ('Completed', 'Cancelled', 'Deleted') 
	group by sctr.claccountid, sctr.instrumentcode
) UnsettledInvestmentCash on UnsettledInvestmentCash.claccountid=CDIH.claccountid and UnsettledInvestmentCash.instrumentcode=CDIH.InstrumentCode
where CDIH.asat = @AsAt

UNION ALL

-- cash assets
(
	SELECT CLIENTSANDCCY.claccountid,'GBPCash',
	--Removed by SteveH 29/01/2011 fix PR5 defects SP361,SP364,SP383
	--coalesce(convert(Numeric(18,2),CLT.CLTbalance),0)+ coalesce(convert(Numeric(18,2),CMT.CMTbalance),0) + coalesce(convert(Numeric(18,2),CLA.CLAbalance),0) - coalesce(convert(Numeric(18,2),WD.Withdrawals),0)- coalesce(convert(Numeric(18,2),ORD.BuyOrders),0)+ coalesce(convert(Numeric(18,2),ORD.SellOrders),0) as AvailableBalance
	coalesce(convert(Numeric(18,4),CLT.CLTbalance),0)+ coalesce(convert(Numeric(18,4),CMT.CMTbalance),0) + coalesce(convert(Numeric(18,2),CLA.CLAbalance),0) + coalesce(convert(Numeric(18,4),ORD.SellOrders),0) as AvailableBalance
	,1 
	--,coalesce(convert(Numeric(18,4),CLT.CLTbalance),0)+ coalesce(convert(Numeric(18,4),CMT.CMTbalance),0) + coalesce(convert(Numeric(18,2),CLA.CLAbalance),0)- coalesce(convert(Numeric(18,4),ORD.BuyOrders),0)+ coalesce(convert(Numeric(18,4),ORD.SellOrders),0) as Quantity
	,coalesce(convert(Numeric(18,4),CLT.CLTbalance),0)+ coalesce(convert(Numeric(18,4),CMT.CMTbalance),0) + coalesce(convert(Numeric(18,2),CLA.CLAbalance),0) + coalesce(convert(Numeric(18,4),ORD.SellOrders),0) as Quantity	
	FROM 
	( 
		select Q1.claccountid,Q2.ccycode from 
		(
			select claccountid from clientaccount..clientdetails
		) Q1
		cross join 
		( --select ISOCode from res_db..currencyFormat where wrapenabled=1
			select distinct ccycode as ccycode from clientaccount..gladbankaccounts
		)Q2

	) CLIENTSANDCCY
	left Join 
	(
		Select ClAccountID, CCYCode, -Sum(Amount) as CLTBalance
		From ClientAccount.dbo.CashLedgerTransactions
		Where LedgerDate < @AsAt
		Group By ClAccountID, CCYCode
	) CLT on CLIENTSANDCCY.claccountid=CLT.claccountid and CLIENTSANDCCY.ccycode=CLT.ccycode 
	Left Join 
	(
		Select CLAccountID, Currency, Sum(Amount) as CMTBalance
		From ClientAccount.dbo.CMTTrans 
		Where TranDate < @AsAt
		Group By CLAccountID, Currency
	) CMT On CMT.CLAccountID = CLIENTSANDCCY.CLAccountID And CMT.Currency = CLIENTSANDCCY.CCYCODE 
	Left Join 
	(
		Select ClAccountID, CcyCode, -Sum(case when AdjustmentType <> 'UNCLEARED_CHEQUE' then Amount else 0.0 end) as CLABalance,-Sum(case when AdjustmentType = 'UNCLEARED_CHEQUE' then Amount else 0.0 end) as UnclearedCheques
		From ClientAccount.dbo.CashLedgerAdjustments
		Where LedgerDate < @AsAt AND AdjustmentType NOT IN ('PHASED_UNLOCK','REMAINING_PHASED_UNLOCK','TOTAL_PHASED_LOCK')
		Group By ClAccountID, CcyCode
	) CLA On CLA.ClAccountID = CLIENTSANDCCY.ClAccountID And CLA.CcyCode = CLIENTSANDCCY.CCYCODE 
	/*
	--Removed by SteveH 29/01/2011 fix PR5 defects SP361,SP364,SP383 - Unused join so no point using it
	Left Join 
	(
		Select CE.ClAccountID, CE.Currency, sum(CE.Amount) as Withdrawals
		From Discovery.dbo.CashEntry CE
		inner join Discovery.dbo.Batch B on B.BatchID = CE.BatchID
		inner join Discovery.dbo.CashEntryStatus S on S.Status = CE.Status
		Where Type = 'Withdrawal' and B.BatchType IN ('Auto','One-Off') and S.[Open] = 1 and 
			((B.StandingNextCashDate < @AsAt) or B.StandingNextCashDate Is Null) 
		Group By CE.ClAccountID, CE.Currency
	) WD on WD.ClAccountID = CLIENTSANDCCY.ClAccountID And WD.Currency = CLIENTSANDCCY.CCYCode 
	*/
	Left Join 
	(
		Select OC.ClAccountID, OC.OrderSettCurrency, sum(abs(case when OC.OrderBuySell='Sell' and S.[Open] = 1 then OC.DisplayValue else 0.0 end)) as SellOrders, 
		sum(case when S.[InProgress] = 1 or (OC.Status = 'Authorised' and OC.PoolOrderID is not null) then OC.DisplayValue else 0.0 end) as DealsinProgress,
		sum(abs(case when OC.OrderBuySell='Buy' and S.[Open] = 1 and CE.batchID is null then OC.DisplayValue else 0.0 end)) as BuyOrders
		From Discovery.dbo.OrderCurrent OC		
		inner join Discovery.dbo.Batch B on B.BatchID = OC.BatchID
		inner join Discovery.dbo.OrderStatus S on S.Status = OC.Status
		left join res_db.dbo.ManagedFunds M on M.Instrumentcode = OC.InstrumentCode
		left join Discovery..CashEntry CE ON OC.BatchID=CE.batchID
		Where B.BatchType IN ('Auto','One-Off') 
		and ( S.[Open] = 1 or (S.[InProgress] = 1 or (OC.Status = 'Authorised' and OC.PoolOrderID is not null)))
		-- but ignore switches, conversionsa and insured fund
		and coalesce(M.insuredfund,0) <> 1 and OC.SwitchID Is Null and OC.ConversionID Is Null
		Group By OC.ClAccountID, OC.OrderSettCurrency
		Having round(sum(OC.DisplayValue),2) <> 0
	) ORD on ORD.ClAccountID = CLIENTSANDCCY.ClAccountID And ORD.OrderSettCurrency = CLIENTSANDCCY.CCYCODE 
	Left Join 
	(
		Select ARL.ClAccountID, 'GBP' as CcyCode, Sum(ARL.NetAmount) as FeeExpectations
		From Discovery.dbo.AdvisorRevenueLedger ARL INNER JOIN
		ClientDetails CD ON ARL.ClAccountID = CD.ClAccountID INNER JOIN
		Company CO ON CD.Company = CO.Company LEFT JOIN
		FeeTranTypes FTT ON ARL.TranType = FTT.TranType AND FTT.WrapProvider = CO.WrapProvider
		Where coalesce(ARL.Reversed,0)<>1 and 
			ARL.AsAt <= @AsAt AND ARL.GLPosted = 'NO' and 
			(ARL.PendingAdvisorPost = 'YES' OR FTT.IncludeUnauthorisedFeesInAvailCash = 1)
		Group By ARL.ClAccountID
	) FEE On FEE.ClAccountID = CLIENTSANDCCY.ClAccountID
)
GO
