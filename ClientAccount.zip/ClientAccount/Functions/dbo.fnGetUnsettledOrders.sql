CREATE FUNCTION [dbo].[fnGetUnsettledOrders]
(
	@OrderBuySell VARCHAR(10),
	@AsAt DATETIME,
	@WrapProvider varchar(20),
	@Company VarChar(20) = 'ALL'
)
RETURNS TABLE
AS

--DECLARE @OrderBuySell VARCHAR(10)
--DECLARE @AsAt DATETIME
--DECLARE @WrapProvider varchar(20)
--DECLARE @Company VarChar(20)
--
--SET @OrderBuySell = 'BUY'
--SET @AsAt = GetDate()
--SET @WrapProvider = 'CUS'
--SET @Company = 'CUSCPQ'

RETURN

SELECT
	SEC.Id AS SecClAccountId,
	SUM(OC.FilledQuantity) AS UnsettledQuantity,
	COM.Id AS CompanyId,
	INS.Id AS InstrumentId
FROM
	Discovery..OrderCurrent OC
	INNER JOIN Discovery..ClientAccount CLA ON OC.ClAccountId = CLA.ClAccountId
	INNER JOIN ClientAccount..SEClientAccount SEC ON OC.ClAccountId = SEC.ClAccountID
	INNER JOIN ClientAccount..Advisor ADV ON SEC.PrimaryAdviser = ADV.AdvCode
	INNER JOIN ClientAccount..Company COM ON ADV.Company = COM.Company
	INNER JOIN Res_db..Instruments INS ON INS.Security = OC.InstrumentCode
WHERE
	COM.WrapProvider = @WrapProvider
	AND (COM.Company = @Company OR @Company = 'ALL')
	AND OC.OrderBuySell = @OrderBuySell
	AND OC.Status = 'Completed'
	AND OC.SettlementDate > @AsAt
	AND cast(convert(char(11), OC.DatePriced, 113) as datetime)  <= @AsAt
GROUP BY SEC.Id, INS.Id, COM.Id

GO