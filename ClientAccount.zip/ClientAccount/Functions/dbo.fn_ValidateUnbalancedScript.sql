

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[fn_ValidateUnbalancedScript]()
RETURNS @valTable TABLE
([Type] varchar(10),[Message] varchar(100),DBName varchar(100),DBTable varchar(100), [Owner] varchar(100), SiteOwner varchar(100))
AS
BEGIN
	
IF (
SELECT COUNT(*) FROM (
SELECT CLAccountId
FROM dbo.ScripTransactions
WHERE Transstatus = 'Settled' AND Cutover = 1
AND (claccountid like 'ax%' OR claccountid like 'el%')
AND Location = 'Custody'
GROUP BY CLAccountId, InstrumentCode
having abs(sum(quantity * cost * COALESCE(fxcost,1))) > 0) x) > 0
BEGIN
	BEGIN
		INSERT INTO @valTable(type, message, DBName, DBTable, owner, SiteOwner)
		VALUES ('Error', 'There is unbalanced hidden scrip','Clientaccount', 'Scriptransactions','Chris Doyle', 'All')
	END
 END

return 

END
GO
