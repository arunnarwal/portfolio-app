CREATE FUNCTION [dbo].[fnGetInterestRatePackageMappingAsAt]
(
	@InterestRatePackageID AS INT,
	@AsAt AS DATETIME = null
)
RETURNS @Table TABLE
( 
	AsAt DATETIME,
	InterestRatePackageId INT, 
	InterestRatePackageScheduleId INT, 
	Currency VARCHAR(3), 
	AmountFrom MONEY
) 
AS
BEGIN

IF @AsAt is null
BEGIN
	SET @AsAt = CAST(CONVERT(VARCHAR(13), getDate(), 106) AS DATETIME)
END
ELSE
BEGIN
	SET @AsAt = CAST(CONVERT(VARCHAR(13), @AsAt, 106) AS DATETIME)
END

;WITH BeyondInterestRatePackageMapping AS 
(
SELECT 
	AsAt,
	InterestRatePackageID,
	InterestRatePackageScheduleID,
	Currency,
	AmountFrom,
	Rank() OVER (Partition by InterestRatePackageId, Currency, AmountFrom ORDER BY AsAt ASC) Ranking
FROM
	(SELECT
		CAST(CONVERT(VARCHAR(13), getDate(), 106) AS DATETIME)+1 AS AsAt,
		InterestRatePackageId,
		InterestRatePackageScheduleId,
		Currency,
		AmountFrom
	FROM
		dbo.InterestRatePackageMapping
	WHERE 
		InterestRatePackageID = @InterestRatePackageId
	UNION
	SELECT
		CAST(CONVERT(VARCHAR(13), AsAt, 106) AS DATETIME) AS AsAt,
		InterestRatePackageID,
		InterestRatePackageScheduleID,
		Currency,
		AmountFrom
	FROM 
		dbo.InterestRatePackageMappingChange
	WHERE 
		CAST(CONVERT(VARCHAR(13), AsAt, 106) AS DATETIME) > @AsAt and InterestRatePackageID = @InterestRatePackageID
	) BeyondInterestRatePackageMapping
)

INSERT INTO @Table
SELECT 
	AsAt,
	InterestRatePackageId,
	InterestRatePackageScheduleId,
	Currency,
	AmountFrom
FROM
	BeyondInterestRatePackageMapping
WHERE
	Ranking =1
RETURN

END

GO
