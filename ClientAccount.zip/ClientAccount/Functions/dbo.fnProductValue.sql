SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE FUNCTION [dbo].[fnProductValue](@AsAt datetime, @Location varchar(10), @Currency char(3), @PriceAsAt datetime) RETURNS TABLE AS
RETURN

SELECT CLAccountID,ProductValue,ProductValueOfUnclearedCheques from clientaccount..fnProductValueBase (@AsAt, @Location, @Currency, @PriceAsAt, default, default)
GO
