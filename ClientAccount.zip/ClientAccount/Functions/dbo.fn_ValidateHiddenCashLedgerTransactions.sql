

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[fn_ValidateHiddenCashLedgerTransactions]()
RETURNS @valTable TABLE
([Type] varchar(10),[Message] varchar(100),DBName varchar(100),DBTable varchar(100), [Owner] varchar(100), SiteOwner varchar(100))
AS
BEGIN
	
IF COALESCE((SELECT SUM(Amount) FROM dbo.CashLedgerTransactions
WHERE DisplayToClient = 0),0) <> 0 
BEGIN 
	BEGIN
		INSERT INTO @valTable(type, message, DBName, DBTable, owner, SiteOwner)
		VALUES ('Warning', 'Hidden Cash Ledger Transactions do not sum to zero.','ClientAccount', 'CashLedgerTransactions','Chris Doyle', 'All')
	END
END

return 

END
GO
