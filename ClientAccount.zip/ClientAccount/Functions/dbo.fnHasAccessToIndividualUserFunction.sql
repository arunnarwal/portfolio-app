SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[fnHasAccessToIndividualUserFunction]
               (@FunctionName VARCHAR(100), @UserId INT)
RETURNS BIT
AS
  BEGIN
	RETURN (
			SELECT TOP 1 
					CASE	WHEN UIF.ClientId IS NOT NULL THEN 1 
							ELSE 0 
					END
			FROM WebDB.dbo.UsersToIndividualFunctions AS UIF 
					INNER JOIN WebDB.dbo.IndividualUserFunctions AS IUF ON UIF.IndividualUserFunctionId = IUF.IndividualUserFunctionID 
					INNER JOIN Clientdb3.dbo.tblClients AS CL ON UIF.ClientID = CL.ClientID
			WHERE UIF.ClientID = @UserId AND IUF.FunctionName= @FunctionName )	
  END
GO
