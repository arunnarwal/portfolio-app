CREATE FUNCTION [dbo].[fnGetAccountModelViolations]
( 
@priceDate datetime, 
@portfolioIDs varchar(max)
)

RETURNS @outputTable TABLE (
	   PortfolioId int,
	   claccountid varchar(50),
       instrumentcode varchar(50),
	   valuation numeric(18,2),
       target numeric(18,2),
       weighting numeric(18,2),
       tolerance numeric(18,2),
       violation numeric(18,2)
	
)
AS
BEGIN

/*


declare @portfolioIds as varchar(max)
declare @priceDate as datetime;
set @priceDate = '5 jun 2013'
set @portfolioIds = '16713,16714'

*/

declare @PortfolioIdTable as table(portfolioid int primary key clustered)
insert into @PortfolioIdTable
select * from ClientAccount.dbo.fn_convert_comma_to_tableOfInts(@portfolioIds)


declare @Target as table (portfolioid int, instrumentCode varchar(50),Weighting numeric(18,15) not null, Tolerance numeric(5,2))
insert into @Target(portfolioid,instrumentcode,weighting,tolerance)
select portfolioid,instrumentcode,weighting,tolerance from discovery..vwMpassetClassBreakdown where portfolioid in (select portfolioid from @PortfolioIdTable)

declare @accounts as table(claccountid varchar(50),portfolioid int)
insert into @accounts(claccountid,portfolioid) select claccountid,portfolioid from discovery..clientaccount where portfolioid in (select portfolioid from @PortfolioIdTable)

declare @Holdings as table(claccountid varchar(50), InstrumentCode varchar(50), Quantity numeric(23,8), valuation numeric(18,2), portfolioid int)

/* Scrip holdings */
insert into @Holdings(claccountid,instrumentcode,quantity,portfolioid)
select st.claccountid,st.instrumentcode,sum(st.Quantity) Quantity, acc.portfolioid from clientaccount..scriptransactions st
inner join @accounts acc on st.claccountid = acc.claccountid
and location in ('custody','registry') and transstatus = 'Settled'
group by st.ClAccountID,st.InstrumentCode,acc.portfolioid

/* Cash holdings */
insert into @Holdings(claccountid,instrumentcode,quantity,valuation,PortfolioID)
select claccountid,instrumentcode,sum(quantity) quantity,sum(valuation) valuation,PortfolioID from (
select clt.claccountid,clt.CCYCode + 'Cash' instrumentcode,-1*sum(clt.Amount) Quantity,-1*sum(clt.Amount) valuation,acc.PortfolioID from clientaccount..cashledgertransactions clt
inner join @accounts acc on clt.claccountid = acc.claccountid
group by clt.ClAccountID,clt.CCYCode,acc.PortfolioID

union all

select cmt.claccountid,cmt.Currency + 'Cash' instrumentcode,sum(cmt.Amount) Quantity,sum(cmt.Amount) valuation,acc.PortfolioID from clientaccount..cmtTrans cmt
inner join @accounts acc on cmt.claccountid = acc.claccountid
group by cmt.ClAccountID,cmt.Currency,acc.PortfolioID) Csh
group by claccountid, instrumentcode, PortfolioID

declare @Prices as table(instrumentcode varchar(50), Price numeric(18,8))
insert into @Prices(instrumentcode,price)
select security,o from res_db..securities where date = @PriceDate
and security in (select instrumentcode from @Target)

update @Holdings set valuation = Quantity * Price
from @Holdings h inner join @Prices p
on h.instrumentcode = p.InstrumentCode

declare @accountTotals as table(claccountid varchar(50), portfolioid int, total numeric(18,2))
insert into @accountTotals(claccountid,portfolioid,total)
select claccountid,portfolioid,sum(valuation) from @Holdings
group by claccountid,portfolioid
having sum(valuation) <> 0

insert into @outputTable(PortfolioId,claccountid,instrumentcode, target,weighting,tolerance,valuation)
select h.portfolioid,h.claccountid,h.instrumentcode,coalesce(t.weighting,0) Target, (h.Valuation/val.Total)*100 actual,coalesce(t.tolerance,0) Tolerance,h.Valuation
from @Holdings h 
inner join @accountTotals val on val.claccountid = h.claccountid and val.portfolioid = h.portfolioid
left outer join @Target t on h.instrumentcode = t.instrumentcode
and t.portfolioid = h.portfolioid

update @outputTable set violation = abs(weighting-target)
update @outputTable set violation = 0 where violation < 0


return
end



GO



