 /***
<Function>
    <Description>Get List of orders for cib accounts, which generates the ptc charge</Description>
    <Parameters>
		<Parameter Name="@FromDate">
            <Description>from time</Description>
        </Parameter>
		<Parameter Name="@ToDate">
            <Description>to time</Description>
        </Parameter>
    </Parameters>
</Function>
***/
CREATE FUNCTION dbo.fnGetOrderPtcGainsBreakDown
(
@FromDate AS DATETIME, @ToDate AS DATETIME
)
RETURNS TABLE
AS

RETURN
--DECLARE @FromDate AS DATETIME = '01-Jan-2019'
--DECLARE @ToDate AS DATETIME = '10-Aug-2019'

WITH OrderGains AS
(
  SELECT
      ogb.Gain AS SellGain,
	  oc.OrderID AS OrderId,
	  oc.ClAccountId AS SubClAccountId,
	  ogb.Quantity,
      ogb.CostPerUnit,
      ogb.BookCostPerUnit,
	  ogb.InstrumentId,
	  COALESCE(xhubT.DateCompleted,oc.DateCompleted) AS OrderDateCompleted,
	  ogb.IsXhubOrder
  FROM  Discovery.dbo.OrderGainsBreakdown ogb
  INNER JOIN Discovery.dbo.OrderCurrent oc
    ON oc.OrderID = ogb.OrderId
	AND ogb.IsXhubOrder = 0
  LEFT JOIN Discovery.dbo.XHubConfirmedTrades xhubT
     ON xhubT.ModelOrderId = ogb.OrderId
      AND ogb.IsXhubOrder = 0
	  AND xhubT.ProductId = ogb.InstrumentId 
UNION ALL
   SELECT
      ogb.Gain AS SellGain,
	  xhubT.OrderId AS OrderId,
	  SECA.ClAccountId AS SubClAccountId,
	  ogb.Quantity,
      ogb.CostPerUnit,
      ogb.BookCostPerUnit,
	  ogb.InstrumentId,
	  xhubT.DateCompleted AS OrderDateCompleted,
	  ogb.IsXhubOrder
  FROM  Discovery.dbo.OrderGainsBreakdown ogb
  INNER JOIN Discovery.dbo.XHubConfirmedTrades xhubT
     ON xhubT.OrderId = ogb.OrderId
      AND ogb.IsXhubOrder = 1
  INNER JOIN dbo.HierarchyEntities  HE 
     ON CONVERT(VARCHAR(20),HE.HierarchyEntityId) = xhubT.AccountId
 INNER JOIN dbo.SEClientAccount SECA 
     ON SECA.ID = HE.EntityId
)

SELECT DISTINCT
  b.SubAccountId,
  og.OrderID,
  og.SellGain,
  COALESCE(pOrderGainBreakdown.PtcAmount, 0) AS PtcAmount,
   CASE WHEN pOrderGainBreakdown.IsBondInstrument = 1 THEN 'Bond'
     ELSE 'Equity'
  END  AS InstrumentType,
  COALESCE(og.OrderDateCompleted,pOrderGain.AsAt) AS GainCalcAsAt,
  ins.Id AS InstrumentId,
  og.Quantity,
  og.CostPerUnit,
  og.BookCostPerUnit,
  og.IsXhubOrder,
  og.OrderDateCompleted,
  pOrderGain.BondPtcChargeOrderGainId,
  pOrderGainBreakdown.CarriedForwardLossesBeforeTransaction,
  pOrderGainBreakdown.CarriedForwardLossesAfterTransaction,
  pOrderGainBreakdown.MemoLossesUtilised,
  pOrderGainBreakdown.IsBondInstrument
FROM  OrderGains og
INNER JOIN Res_db.dbo.Instruments ins
    ON ins.Id = og.InstrumentId 
INNER JOIN dbo.SEClientAccount se
    ON se.ClAccountID = og.SubClAccountID
INNER JOIN dbo.Bonds b
    ON se.Id = b.SubAccountId
LEFT JOIN dbo.BondPtcChargeOrderGainsBreakdown pOrderGainBreakdown
   ON og.OrderID = pOrderGainBreakdown.OrderId
     AND pOrderGainBreakdown.InstrumentId = ins.Id
LEFT JOIN dbo.BondPtcChargeOrderGains pOrderGain 
   ON pOrderGainBreakdown.BondPtcChargeOrderGainId = pOrderGain.BondPtcChargeOrderGainId
WHERE  COALESCE(og.OrderDateCompleted,pOrderGain.AsAt)  >= @FromDate AND  COALESCE(og.OrderDateCompleted,pOrderGain.AsAt) <  DATEADD(DAY,1, @ToDate)