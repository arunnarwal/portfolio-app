SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[fnHistoricalAllowedAccounts](@ClientID int, @AsAt datetime) 
RETURNS @Table Table (ClAccountID varchar(20) not null) AS

begin
INSERT INTO @Table
SELECT	ClAccountID
FROM	ClientAccount.dbo.vwBaseAllowedClAccountID Per
			left join ClientAccount.dbo.NetworkSuperUsers N on N.ClientID = Per.ClientID
			left join ClientAccount.dbo.Advisor A on A.AdvCode = Per.AdvisorCodes
			left join ClientAccount.dbo.HierarchyMappings HM on
					HM.MappingItemName = A.Company and HM.MappingItemType = 'Company' and 
					HM.MappingType = 'Network' and HM.MapTo = N.Network
WHERE	Per.clientid = @ClientID and
		(N.ID is null or 
			(convert(datetime,convert(varchar,HM.DateAdded,106)) < @AsAt 
				and convert(datetime,convert(varchar,dateadd(d,1,coalesce(HM.DateRemoved,@AsAt)),106)) > @AsAt)
		)
RETURN
end
GO
