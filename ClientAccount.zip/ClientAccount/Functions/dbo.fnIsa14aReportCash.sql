/*
<Function>
    <Description>Returns data for sheets V12 and V16 of ISA 14a Report.</Description>
    <Parameters>
        <Parameter Name="@AsAt">
            <Description>Date as at we want to return data.</Description>
        </Parameter>
        <Parameter Name="@IncludeIsa">
            <Description>Flag to include ISA sub-account holdings.</Description>
        </Parameter>
        <Parameter Name="@IncludeJisa">
            <Description>Flag to include JISA sub-account holdings.</Description>
        </Parameter>
        <Parameter Name="@ProductType">
            <Description>ProductType of which we want to retrieve data. Should be "Stocks/Shares" or "Cash".</Description>
        </Parameter>
    </Parameters>
</Function>
*/

CREATE FUNCTION [dbo].[fnIsa14aReportCash] (@AsAt DATETIME, @IncludeIsa BIT, @IncludeJisa BIT, @ProductType VARCHAR(20))
RETURNS TABLE 
AS
RETURN	

/*
USE ClientAccount

DECLARE @AsAt as DATETIME;
SET @AsAt = '05-Apr-2020';
DECLARE @IncludeIsa BIT
SET @IncludeIsa = 1
DECLARE @IncludeJisa BIT
SET @IncludeJisa = 1
DECLARE @ProductType VARCHAR(20)
SET @ProductType = 'Stocks/Shares'
;
*/

WITH Balance
(
	SECAId,
	CCYId,
	CMTBalance,
	CLTBalance,
	CLABalance,
	HoldingsValue
) AS (
	SELECT
		CMT.SECAId,
		CMT.CCYId,
		CMT.Balance AS CMTBalance,
		0 AS CLTBalance,
		0 AS CLABalance,
		0 AS HoldingsValue
	FROM
		Cache.dbo.Trans_CMTTrans_ByAccount CMT
	WHERE
		CMT.FromDate <= Cache.dbo.fnDateToBin(@AsAt)
		AND CMT.ToDate >= Cache.dbo.fnDateToBin(@AsAt)
UNION ALL
	SELECT
		CLT.SECAId,
		CLT.CCYId ,
		0 ,
		CLT.Balance AS CLTBalance ,
		0 AS CLABalance ,
		0 AS HoldingsValue
	FROM
		Cache.dbo.Trans_CashLedgerTransactions_ByAccount CLT
	WHERE
		CLT.FromDate <= Cache.dbo.fnDateToBin(@AsAt)
		AND CLT.ToDate >= Cache.dbo.fnDateToBin(@AsAt)
UNION ALL
	SELECT
		CLA.SECAId ,
		CLA.CCYId ,
		0 AS CMTBalance ,
		0 AS CLTBalance ,
		CLA.Balance AS CLABalance ,
		0 AS HoldingsValue
	FROM
		Cache.dbo.Trans_CashLedgerAdjustments_ByAccount CLA
	WHERE
		CLA.FromDate <= Cache.dbo.fnDateToBin(@AsAt)
		AND CLA.ToDate >= Cache.dbo.fnDateToBin(@AsAt)
),
Cash
(
	ClAccountId,
	Value
) AS (
	SELECT
		Cache.dbo.fnSECAIdToClAccountId(Balance.SECAId) AS ClAccountId,
		SUM(CMTBalance) - SUM(CLTBalance) - SUM(CLABalance) AS Value
	FROM
		Balance
	GROUP BY
		SECAId
),
PrimaryAccountHolder
(
	ClAccountID,
	HolderNumber
) AS (
	SELECT
		ClAccountID,
		MIN(HolderNumber)
	FROM
		dbo.AccountHolders
	GROUP BY
		ClAccountID
),

AccountsTransferredOut AS 
(
	SELECT ClAccountId, MIN(TransferCompleted) AS TransferCompleted
	FROM Discovery.dbo.ScripTransferRequest
	WHERE TransferDirection = 'FromFNZC' 
		AND Status = 'Completed' 
		AND FullOrPartialTransfer = 'Full'
		AND TransferCompleted >= DATEADD(YEAR, -1, @AsAt)
		AND TransferCompleted <= @AsAt
	GROUP BY ClAccountId
)

SELECT
	C.ClAccountID AS ClAccountID,
	CASE 
		WHEN C.Value < 0 AND @ProductType = 'Stocks/Shares' THEN 0
		ELSE C.Value
	END AS Value,
	AH.Given AS Name,
	AH.Surname AS Surname
FROM
	Cash AS C
	LEFT JOIN Discovery.dbo.ProductDetails PD ON PD.ClAccountId = C.ClAccountId
	LEFT JOIN Discovery.dbo.ClientAccount AS CA ON CA.ClAccountID = C.ClAccountId
	LEFT JOIN dbo.fnHeadAccounts() AS HA ON HA.ClAccountID = CA.ClAccountID
	LEFT JOIN PrimaryAccountHolder AS PAH ON PAH.ClAccountID = HA.HeadClAccountID
	LEFT JOIN dbo.AccountHolders AS AH ON AH.ClAccountID = PAH.ClAccountID AND AH.HolderNumber = PAH.HolderNumber
	LEFT JOIN dbo.ClientDetails CD ON CD.ClAccountId = HA.HeadClAccountID
	LEFT JOIN AccountsTransferredOut ATO ON ATO.ClAccountId = pd.ClAccountId
WHERE
	CA.SubAccountType = 'ISA' 
	AND	((@IncludeIsa = 1 AND CD.IsJuniorAccount = 0) OR (@IncludeJisa = 1 AND CD.IsJuniorAccount = 1)) 
	AND	PD.ProductType = @ProductType
	AND ATO.ClAccountId IS NULL
	AND PD.DateCreated <= @AsAt
	AND NOT (CA.Status = 'Closed' AND DATEDIFF(day,PD.DateCreated,CA.CloseDate) < 31)
		