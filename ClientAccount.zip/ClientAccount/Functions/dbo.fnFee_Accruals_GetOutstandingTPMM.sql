CREATE FUNCTION [dbo].[fnFee_Accruals_GetOutstandingTPMM](@ChargeDate datetime, @WrapProvider varchar(20))

RETURNS @result 
TABLE(ClAccountId VARCHAR(20),
DestinationClAccountID VARCHAR(20),
PrimaryAdviser VARCHAR(20),
Company VARCHAR(20), 
WrapProvider VARCHAR(20), 
SubAccountType VARCHAR(20), 
[Type] VARCHAR(20),
Category VARCHAR(20), 
ChargeDate DATETIME,
FromDate DATETIME,
ToDate DATETIME,
ProductType VARCHAR(20),
TotalAmount NUMERIC(18,4),
VATAmount NUMERIC(18,4),
ClientAmount NUMERIC(18,4), 
AdvisorAmount NUMERIC(18,4), 
CorporateAmount NUMERIC(18,4),
CurrencyId INT)

AS

BEGIN

WITH FADTOTALS AS (
	SELECT	Accruals.SecaId,
			Seca.CLAccountID,
			Seca.PrimaryAdviser,
			Accruals.ChargeDate,
			Company.Company,
			Company.WrapProvider,
			MIN(Accruals.AsAt) AS FromDate, 
			MAX(Accruals.AsAt) As ToDate,
			SUM(Accruals.Amount) AS TotalAmount,
			Accruals.CurrencyId
	FROM dbo.Fee_Accrual_TPMM AS Accruals
	INNER JOIN ClientAccount..SEClientAccount AS Seca 
		ON SECA.Id = Accruals.SecaId
	INNER JOIN dbo.ClientDetails AS ClientDetails
		ON Seca.ClAccountId = ClientDetails.ClAccountId
	INNER JOIN dbo.Company AS Company
		ON ClientDetails.Company = Company.Company
	WHERE Accruals.ChargeDate <= @ChargeDate 
			AND Accruals.ISProcessed = 0
			AND Company.WrapProvider = @WrapProvider 
	GROUP BY Accruals.SecaId,
			Seca.CLAccountID,
			Seca.PrimaryAdviser,
			Accruals.ChargeDate,
			Company.WrapProvider,
			Company.Company,
			Accruals.CurrencyId
	HAVING sum(Accruals.Amount) <> 0
)

INSERT @result
SELECT	FADTOTALS.ClAccountId,
		FADTOTALS.ClAccountId As DestinationClAccountID,
		FADTOTALS.PrimaryAdviser,
		FADTOTALS.Company, 
		FADTOTALS.WrapProvider, 
		ClientAccount.SubAccountType, 
		'TPMM' AS [Type],
		'TPMM' AS Category, 
		FADTOTALS.ChargeDate,
		FADTOTALS.FromDate,
		FADTOTALS.ToDate,
		ProductDetails.ProductType,
		FADTOTALS.TotalAmount,
		0 As VATAmount,
		0 AS ClientAmount, 
		0 AS AdvisorAmount, 
		FADTOTALS.TotalAmount AS CorporateAmount,
		FADTOTALS.CurrencyId
FROM FADTOTALS 
	INNER JOIN Discovery..ProductDetails AS ProductDetails 
		ON FADTOTALS.ClAccountId = ProductDetails.ClAccountId 
	INNER JOIN Discovery..ClientAccount AS ClientAccount
		ON FADTOTALS.ClAccountId = ClientAccount.ClAccountId

RETURN
END