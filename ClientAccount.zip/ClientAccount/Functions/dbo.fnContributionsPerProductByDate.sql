

-- =============================================
-- Author:		Rizwan Khalid
-- Create date: 20/07/2011
-- Description:	Returns list of contributions per member on the passed in date
-- =============================================
CREATE FUNCTION [dbo].[fnContributionsPerProductByDate]
(
	@AsAt datetime
)
RETURNS TABLE
AS
RETURN
(
	--declare @AsAt datetime;

	--set @AsAt = '2012-02-28';

	SELECT seca.AccountName AS MemberName,csd.Name AS SchemeName,fHA.HeadClAccountId, CA.ClAccountId,
	CA.SubAccountType as ProductType, ce.Amount as ContributionAmountToProduct, ce.InstructionType As ContributionType, 
	COALESCE(ce.DateCompleted,ce.NextPayDate,ce.DateCreated) as ContributionDate, ce.Frequency,
	ce.TransactionId AS UniqueID, ce.Method AS ContributionMethod, COALESCE(dba.HolderName, cba.AccountName) as AccountName,
	COALESCE(dba.AccountNumber, cba.AccountNumber) as AccountNumber, COALESCE(dba.SortCode, cba.SortCode) as SortCode,
	cmsd.EmployerEarnings, ce.Source,
	(CASE 
	WHEN pce.PayrollId IS NULL THEN 0
	ELSE pce.IsRegular
	END) AS IsRegularPayroll,
	(CASE
	WHEN pce.PayrollId IS NULL THEN 0
	ELSE pce.IsSingle
	END) AS IsSinglePayroll
	FROM Discovery.dbo.ClientAccount CA
	INNER JOIN dbo.fnHeadAccounts() fHA
		ON fHA.ClAccountId = ca.ClaccountId
	INNER JOIN dbo.SEClientAccount seca
		ON ca.ClaccountId = seca.ClaccountId
	INNER JOIN Discovery.dbo.CashEntry ce
		ON ca.ClaccountId = ce.ClaccountId
	INNER JOIN dbo.CorporateSchemeDetails as csd
		ON seca.Primaryadviser = csd.Advisorcode
	INNER JOIN dbo.CorporateMemberSchemeDetails cmsd
		ON cmsd.AccountId = fHA.HeadClAccountId
	LEFT JOIN Discovery.dbo.BankAccount as dba
		ON dba.ClaccountId = fHA.ClAccountId AND ce.Accountnumber = dba.Accountnumber AND ce.Sortcode = dba.Sortcode
	LEFT JOIN dbo.vwCorporateMemberPaycentreDetails cmp
		ON cmp.AccountId = fHA.HeadClAccountId
	LEFT JOIN dbo.CorporatePaycenters cp
		ON cp.Id = cmp.PaycentreId
	LEFT JOIN dbo.BankAccount as cba
		ON cba.Id = cp.Schemebankaccountnumber
	LEFT JOIN Discovery.dbo.PayrollCashEntry pce
		ON ce.Id = pce.CashentryId
	WHERE CA.Status = 'Active'
	AND COALESCE(ce.DateCompleted,ce.NextPayDate,ce.DateCreated) < DateAdd(day, 1, @AsAt)
	AND COALESCE(ce.DateCompleted,ce.NextPayDate,ce.DateCreated) > DateAdd(day, -1, @AsAt)
	AND ce.Status IN ('Completed', 'Authorised', 'Confirmed')
)
GO
