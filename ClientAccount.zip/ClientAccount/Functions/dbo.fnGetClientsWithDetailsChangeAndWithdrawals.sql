CREATE FUNCTION [dbo].[fnGetClientsWithDetailsChangeAndWithdrawals] (@DateModified As DateTime, @DateCreated As DateTime)
RETURNS TABLE AS
RETURN
(
/*
Declare @DateModified As DateTime
Declare @DateCreated As DateTime

set @DateModified = DateAdd(dd, -30, getdate())
set @DateCreated = DateAdd(dd, -1, getdate())
*/
SELECT DISTINCT
	HA.HeadClAccountId,
	HA.ClAccountId,
	CO.WrapProvider

FROM 
	dbo.vwHeadAccounts AS HA 
	INNER JOIN dbo.ClientChangeLog AS CCL ON HA.HeadClAccountId = CCL.ClAccountId 
	INNER JOIN Discovery.dbo.CashEntry AS CE ON HA.ClAccountId = CE.ClAccountId
	INNER JOIN dbo.ClientDetails CD ON HA.HeadClAccountId = CD.ClAccountId
	INNER JOIN dbo.Company CO ON CD.Company = CO.Company

WHERE
	CCL.TableConstant IN ('dpsAddress','dpsBankAccount','claAccountHolders')
	AND CCL.FieldName IN ('Address1','Address2','Address3','Address4','Address5','PostCode','BankName','AccountNumber','Given','Surname','DateOfBirth','EmailAddress','Gender','Given','IRDNo','MaritalStatus','Nationality','Salutation','Surname','Title','Country','SortCode','HolderName') /* HolderName = bank account name */
	AND CE.Type = 'Withdrawal'
	AND CE.InstructionType IN ('One-Off','Standing')
	AND CE.Status <> 'Cancelled'
	AND CCL.DateModified > @DateModified
	AND CE.DateCreated > @DateCreated
	AND (CE.PaymentSubType IS NULL OR CE.PaymentSubType <> 'NaturalIncome')
	AND CE.ClientId <> 8245

UNION

SELECT DISTINCT
	HA.HeadClAccountId,
	HA.ClAccountId,
	CO.WrapProvider

FROM 
	dbo.vwHeadAccounts AS HA 
	INNER JOIN dbo.ClientChangeLog AS CCL ON HA.HeadClAccountId = CCL.ClAccountId 
	INNER JOIN Discovery.dbo.OrderCurrent AS OC ON OC.ClAccountId = HA.ClAccountId
	INNER JOIN dbo.ClientDetails CD ON HA.HeadClAccountId = CD.ClAccountId
	INNER JOIN dbo.Company CO ON CD.Company = CO.Company

WHERE
	CCL.TableConstant IN ('dpsAddress','dpsBankAccount','claAccountHolders')
	AND CCL.FieldName IN ('Address1','Address2','Address3','Address4','Address5','PostCode','BankName','AccountNumber','Given','Surname','DateOfBirth','EmailAddress','Gender','Given','IRDNo','MaritalStatus','Nationality','Salutation','Surname','Title','Country','SortCode','HolderName') /* HolderName = bank account name */
	AND OC.OrderBuySell = 'Sell'
	AND OC.Status <> 'Cancelled'
	AND CCL.DateModified > @DateModified
	AND OC.DateCreated > @DateCreated
	AND OC.UserId <> 8245

UNION

SELECT DISTINCT
	HA.HeadClAccountId,
	HA.ClAccountId,
	CO.WrapProvider

FROM 
	dbo.vwHeadAccounts AS HA 
	INNER JOIN dbo.ClientChangeLog AS CCL ON HA.HeadClAccountId = CCL.ClAccountId 
	INNER JOIN Discovery.dbo.RegularWithdrawals AS RW ON RW.ClAccountId = HA.ClAccountId
	INNER JOIN dbo.ClientDetails CD ON HA.HeadClAccountId = CD.ClAccountId
	INNER JOIN dbo.Company CO ON CD.Company = CO.Company

WHERE
	CCL.TableConstant IN ('dpsAddress','dpsBankAccount','claAccountHolders')
	AND CCL.FieldName IN ('Address1','Address2','Address3','Address4','Address5','PostCode','BankName','AccountNumber','Given','Surname','DateOfBirth','EmailAddress','Gender','Given','IRDNo','MaritalStatus','Nationality','Salutation','Surname','Title','Country','SortCode','HolderName') /* HolderName = bank account name */
	AND RW.Status <> 'Cancelled'
	AND CCL.DateModified > @DateModified
	AND RW.DateCreated > @DateCreated
	AND RW.ClientId <> 8245
)
/*
exec CSFBMaster..spUpdateMetaDB @DBName='ClientAccount', @TableName='fnGetClientsWithDetailsChangeAndWithdrawals', @TableConstant='clafnGetClientsWithDetailsChangeAndWithdrawals'
*/
GO
