SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[fnIsLastDayOfMonth] 
(
	@Date DATETIME
)
RETURNS BIT
AS
BEGIN
Declare @IsLastDayofMonth as BIT
Declare @LastDayOfMonth DATETIME

SET @LastDayOfMonth = dbo.fnGetLastDayOfMonth(@Date)

IF @Date  =  @LastDayOfMonth 
	SET @IsLastDayofMonth = 1
ELSE 
	SET @IsLastDayofMonth = 0	
	
RETURN @IsLastDayofMonth

END
GO
