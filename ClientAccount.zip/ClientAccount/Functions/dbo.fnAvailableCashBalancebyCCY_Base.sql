/*** 
<Function>
    <Description>Provides figures which can be used to construct various available cash figures

        If you're making changes to this funciton please consider your reviewer - DB Arch/Application Perf teams
        have invested considerable effort to ensuring this is as fast as it can be.  Please make sure someone from
        either of those teams is included on the review.

    </Description>
    <Parameters>
        <Parameter Name="@AsAt">
            <Description>
                The effective date to get available cash balance figures for.
            </Description>
        </Parameter>
        <Parameter Name="@BatchId">
            <Description>
                If provIded, excludes orders, etc for this @BatchId in the calcs.
                Use when you want an available cash value for processing this @BatchId as opposed to adding something new.
            </Description>
        </Parameter>
        <Parameter Name="@CashEntryId">
            <Description>
                If provIded, excludes this withdrawals @CashEntryId in the calcs.
                Use when you want an available cash value for processing this @CashEntryId as opposed to adding something new.
            </Description>
        </Parameter>
        <Parameter Name="@ExcludePlatformFundSwitch">
            <Description>
                Excludes platform fund switches from the BuyOrders figures if set to 1.
            </Description>
        </Parameter>
    </Parameters>
</Function>
***/
CREATE FUNCTION [dbo].[fnAvailableCashBalancebyCCY_Base]
(
	@AsAt DATETIME,
	@BatchId INT = 0,
	@CashEntryId INT = NULL,
	@ExcludePlatformFundSwitch INT = NULL
)
RETURNS TABLE AS

RETURN

    SELECT  CLIENTSANDCCY.ClAccountId,
            CLIENTSANDCCY.CCYCode,
            CLIENTSANDCCY.WrapProvider,
            ISNULL(CLT.CLTBalance, 0) AS CLTBalance,
            ISNULL(CMT.CMTBalance, 0) AS CMTBalance,
            ISNULL(CLA.CLABalance, 0) AS CLABalance,
            ISNULL(CLA.CLAAvailableAdjustBalance, 0) AS CLAAvailableAdjustBalance,
            ISNULL(CLA.CLAPortfolioAdjustBalance, 0) AS CLAPortfolioAdjustBalance,
            ISNULL(CLA.CLAFeeAdjustBalance, 0) AS CLAFeeAdjustBalance,
            ISNULL(WD.Withdrawals, 0) + ISNULL(OSW.Oversettlement,0) AS Withdrawals,
            ISNULL(ORD.BuyOrders, 0) AS BuyOrders,
			ISNULL(ORD.BuyOrdersWithSettledCash, 0) AS BuyOrdersWithSettledCash,
            ISNULL(ORD.BuyOrdersExComm, 0) AS BuyOrdersExComm,
            ISNULL(ORD.SellOrders, 0) AS SellOrders,
            ISNULL(SELLORDSAMEBATCH.SellOrdersSameBatch, 0) AS SellOrdersSameBatch,
            ISNULL(CLT.CLTBalance, 0)
                + ISNULL(CMT.CMTBalance, 0)
                + ISNULL(CLA.CLABalance, 0)
                - ISNULL(WD.Withdrawals, 0)
                - ISNULL(DEAL.BuyDealsInProgress, 0)
                + ISNULL(ORD.SellOrders, 0) 
				+ ISNULL(ET.ETBalance, 0)	AS AvailableBalance,
            ISNULL(UDP.UnclearedCheques, 0) AS UnclearedCheques,
            ISNULL(DEAL.DealsInProgress, 0) AS DealsInProgress,
            ISNULL(DEAL.SellDealsInProgress, 0) AS SellDealsInProgress,
            ISNULL(DEAL.BuyDealsInProgress, 0) AS BuyDealsInProgress,
            ISNULL(DEAL.BuyDealsInProgressExcludingSwitches, 0) AS BuyDealsInProgressExcludingSwitches,
            ISNULL(FEE.FeeExpectations, 0) + ISNULL(PROJECTEDFEE.FeeExpectations, 0) AS FeeExpectations,
            ISNULL(FEE.FutureDatedFeeExpectations, 0) AS FutureDatedFeeExpectations,
            ISNULL(UNSETTLEDCASH.UnsettledCash, 0) AS UnsettledCash,
            ISNULL(FEE.UnsettledCashPostedFees, 0) AS UnsettledCashPostedFees,
            ISNULL(UDP.UnclearedDeposits, 0) AS UnclearedDeposits,
            ISNULL(SettlingToday.SettlingToday, 0) AS SettlingToday,
            ISNULL(ORD.SwitchSellOrders, 0) AS SwitchSellOrders,
            ISNULL(IFBUYORD.InsuredFundsBuyOrders, 0) AS InsuredFundsBuyOrders,
            ISNULL(CLT.UnsettledCashDebits, 0) AS UnsettledCashDebits,
			ISNULL(SWITCH.SwitchSellsWithUnsettledBuys, 0) AS SwitchSellsWithUnsettledBuys,
			CASE 
				WHEN ISNULL(WD.Withdrawals, 0) + ISNULL(OSW.Oversettlement,0) < ISNULL(WITHDRAWALSELLS.SellOrdersFundingWithdrawals, 0) THEN ISNULL(WD.Withdrawals, 0) + ISNULL(OSW.Oversettlement,0)
				ELSE ISNULL(WITHDRAWALSELLS.SellOrdersFundingWithdrawals, 0)
			END + ISNULL(WITHDRAWALSELLS.SellOrdersFundingBedAndIsaDisinvestment,0) AS SellOrdersFundingWithdrawals,
			ISNULL(ET.ETBalance, 0) AS ETBalance
    FROM (
            SELECT     CD.ClAccountId,
                       SCA.Id AS AccountId,
                       GC.CurrencyId,
                       GC.CurrencyCode AS CCYCode,
                       C.WrapProvider
            FROM       dbo.ClientDetails CD
            INNER JOIN dbo.SEClientAccount SCA ON CD.CLAccountId = SCA.ClAccountId
            LEFT JOIN  dbo.Company C ON CD.Company = C.Company
            CROSS JOIN CashLedger.Currencies GC
        )
        CLIENTSANDCCY

            /* CLT
                ISNULL(CLT.CLTBalance, 0) AS CLTBalance ,
                AvailableBalance

                Added: UnsettledCash
                Added: UnsettledCashDebits
            */
            LEFT JOIN
            (
               SELECT   GT.AccountId,
                        GT.CurrencyId,
                        -SUM(GT.Amount) AS CLTBalance,
                        SUM(CASE WHEN GT.RestrictSweepUntil > @AsAt AND GT.LedgerDate <= @AsAt AND GT.Amount > 0 THEN Amount ELSE 0 END) AS UnsettledCashDebits
               FROM     CashLedger.GladTransactions GT
               WHERE    GT.LedgerDate <= @AsAt
               GROUP BY GT.AccountId, GT.CurrencyId
            )
            CLT ON CLIENTSANDCCY.AccountId = CLT.AccountId AND CLIENTSANDCCY.CurrencyId = CLT.CurrencyId

			/* ET
                ISNULL(ET.ETBalance, 0) AS ETBalance 
            */
            LEFT JOIN
            (
               SELECT   ET.AccountId,
                        ET.CurrencyId,
                        -SUM(ET.Amount) AS ETBalance
               FROM     CashLedger.ExternalTransactions ET
               WHERE    ET.LedgerDate <= @AsAt
               GROUP BY ET.AccountId, ET.CurrencyId
            )
            ET ON CLIENTSANDCCY.AccountId = ET.AccountId AND CLIENTSANDCCY.CurrencyId = ET.CurrencyId

            /*
                CLT - merging this with the lookup above results in more reads of CLT if you don't need UnclearedDeposits
                    since it's only required on a rare number of lookups we're better of not merging the two.
                    ISNULL(UDP.UnclearedCheques, 0) AS UnclearedCheques,
                    ISNULL(UDP.UnclearedDeposits, 0) AS UnclearedDeposits ,

                Moved here so that the CLT looks were all near each other in the query.
            */
            LEFT JOIN
            (
                SELECT     GT.AccountId,
                           GT.CurrencyId,
                           -SUM(GT.Amount) AS UnsettledCash
                FROM       CashLedger.GladTransactions GT
                INNER JOIN CashLedger.OrderTransactions OT ON GT.TransactionId = OT.TransactionId
                INNER JOIN CashLedger.MovementTypes MT ON GT.MovementTypeId = MT.MovementTypeId
				INNER JOIN Discovery.dbo.OrderCurrent OC ON OC.OrderID = OT.OrderId
                WHERE      GT.LedgerDate <= @AsAt
                AND        GT.RestrictSweepUntil > @AsAt
                AND        MT.MovementType IN ('FUND_REDEMPTION', 'SELL_TRADE')
				AND        OC.SwitchID IS NULL

                AND NOT EXISTS
                (
                    SELECT     1
                    FROM       Discovery.dbo.CashEntry CE
                    INNER JOIN Discovery.dbo.OrderCurrent OC ON CE.BatchId = OC.BatchId
                    INNER JOIN Discovery.dbo.Batch B ON B.BatchId = CE.BatchId
                    WHERE      CE.Type = 'Withdrawal'
                    AND        B.BatchType IN ( 'Auto', 'One-Off' )
                    AND        CE.Status IN ('Authorised','Confirmed','Placed','Processing')

                    AND        (B.StandingNextCashDate <= @AsAt OR B.StandingNextCashDate IS NULL)
                    AND        (@CashEntryId IS NULL OR CE.ID <> @CashEntryId)
                    AND        OC.OrderID = OT.OrderId

                    /* This part is to exclude the Next Tax Year ISA from displaying in front office until matched */
                    /* changed this from NOT IN to NOT EXISTS */
                    AND NOT EXISTS (
                        SELECT 1
                        FROM   Discovery.dbo.LinkedCashEntryMappings LCEM
                        WHERE  CE.[Status] = 'Confirmed'
                        AND    CE.[Type] = 'Withdrawal'
                        AND    CE.Method = 'Internal Transfer'
                        AND    CE.Id = LCEM.LinkedCashEntryId
                    )
                )
				AND NOT EXISTS
				(
					SELECT 1
					FROM Discovery.dbo.CashEntry CE
					INNER JOIN Discovery.dbo.BatchLink BL ON CE.BatchID = BL.BatchID
					INNER JOIN Discovery.dbo.OrderCurrent OC2 ON BL.LinkedBatchId = OC2.BatchID
					WHERE OC2.OrderID = OT.OrderId
						AND	CE.[Status] <> 'Cancelled'
                        AND CE.Type = 'Withdrawal'
                        AND CE.Method = 'Internal Transfer'
				)
                GROUP BY GT.AccountId, GT.CurrencyId
            )
            UNSETTLEDCASH ON CLIENTSANDCCY.AccountId = UNSETTLEDCASH.AccountId AND CLIENTSANDCCY.CurrencyId = UNSETTLEDCASH.CurrencyId
            LEFT JOIN
            (
                SELECT     GT.AccountId,
                           GT.CurrencyId,
                           -SUM(CASE WHEN CE.Method NOT IN ('Cheque','Internal Transfer') THEN GT.Amount ELSE 0 END) AS UnclearedDeposits,
                            SUM(CASE WHEN CE.Method = 'Cheque' THEN GT.Amount ELSE 0 END) AS UnclearedCheques
                FROM       CashLedger.GladTransactions GT
                INNER JOIN CashLedger.CashEntryTransactions CET ON GT.TransactionId = CET.TransactionId
                INNER JOIN Discovery.dbo.CashEntry CE ON CET.CashEntryId = CE.ID
                WHERE      GT.RestrictSweepUntil > @AsAt
                AND        CE.Type = 'Deposit'
                GROUP BY   GT.AccountId, GT.CurrencyId
            )
            UDP ON UDP.AccountId = CLIENTSANDCCY.AccountId AND UDP.CurrencyId = CLIENTSANDCCY.CurrencyId

            /* CMT
                ISNULL(CMT.CMTBalance, 0) AS CMTBalance ,
                AvailableBalance
            */
            LEFT JOIN ( SELECT  CMT.ClAccountID ,
                                CMT.Currency ,
                                SUM(CMT.Amount) AS CMTBalance
                        FROM    dbo.CMTTrans CMT
                        WHERE   CMT.TranDate <= @AsAt
                        GROUP BY CMT.ClAccountID ,
                                CMT.Currency
                      ) CMT ON CMT.CLAccountID = CLIENTSANDCCY.CLAccountID
                               AND CMT.Currency = CLIENTSANDCCY.CCYCode

            /* CLA
                    ISNULL(CLA.CLABalance, 0) AS CLABalance ,
                    ISNULL(CLA.CLAAvailableAdjustBalance, 0) AS CLAAvailableAdjustBalance ,
                    ISNULL(CLA.CLAPortfolioAdjustBalance, 0) AS CLAPortfolioAdjustBalance ,
					ISNULL(CLA.CLAFeeAdjustBalance, 0) AS CLAFeeAdjustBalance,
                    ISNULL(CLA.SettlingToday, 0) AS SettlingToday
                    AvailableBalance
            */
            LEFT JOIN ( SELECT  cla.ClAccountID ,
                                cla.CCYCode ,
                                -SUM(CASE WHEN cla.AdjustmentType <> 'UNCLEARED_CHEQUE' THEN cla.Amount ELSE 0 END) AS CLABalance ,
                                -SUM(CASE WHEN cla.AvailableAdjust = 1 OR cla.PortfolioAdjust = 1 THEN cla.Amount ELSE 0 END) AS CLAAvailableAdjustBalance ,
                                -SUM(CASE WHEN cla.PortfolioAdjust = 1 THEN cla.Amount ELSE 0 END) AS CLAPortfolioAdjustBalance ,
                                -SUM(CASE WHEN cla.AdjustmentType <> 'UNCLEARED_CHEQUE' AND cla.FeeAdjust = 1 THEN cla.Amount ELSE 0 END) AS CLAFeeAdjustBalance

                        FROM    dbo.CashLedgerAdjustments cla			
                        WHERE   cla.LedgerDate <= @AsAt
                        GROUP BY cla.ClAccountID ,
                                cla.CCYCode
                      ) CLA ON CLA.ClAccountID = CLIENTSANDCCY.CLAccountID
                               AND CLA.CCYCode = CLIENTSANDCCY.CCYCode
			LEFT JOIN 
					  (	SELECT 	cla.ClAccountID ,
                                cla.CCYCode ,
                                -SUM(CASE WHEN oc.SettlementDate > @AsAt
                                               AND oc.OrderBuySell = 'Sell'
                                          THEN cla.Amount
                                          ELSE 0
                                     END) AS SettlingToday
						FROM	dbo.CashLedgerAdjustments cla
								LEFT JOIN Discovery.dbo.OrderCurrent oc
								ON oc.OrderID = cla.AWOrderID AND oc.OrderBuySell = 'Sell'
						WHERE	CLA.AdjustmentType IN ('WITHDRAWAL', 'SELL_TRADE')
						GROUP BY cla.ClAccountID ,
                                cla.CCYCode
				)SettlingToday  ON SettlingToday.ClAccountID = CLIENTSANDCCY.CLAccountID
                               AND SettlingToday.CCYCode = CLIENTSANDCCY.CCYCode
            /*
                CE
                  ISNULL(WD.Withdrawals, 0) AS Withdrawals ,
                  AvailableBalance
            */
            LEFT JOIN ( SELECT  CE.ClAccountID ,
                                CE.Currency ,
                                SUM(CE.Amount) AS Withdrawals
                        FROM    Discovery.dbo.CashEntry CE
                                INNER JOIN Discovery.dbo.Batch B ON B.BatchID = CE.BatchID
                        WHERE   CE.Type = 'Withdrawal'
                                AND B.BatchType IN ( 'Auto', 'One-Off' )
                                AND   CE.Status IN ('Authorised','Confirmed','Placed','Processing')

                                AND ( B.StandingNextCashDate <= @AsAt OR B.StandingNextCashDate IS NULL )
                                AND ( @CashEntryId IS NULL OR CE.ID <> @CashEntryId )								

                        /* This part is to exclude the Next Tax Year ISA from displaying in front office until matched */
                        /* changed this from NOT IN to NOT EXISTS */
                                AND NOT EXISTS (
                                    SELECT  CE.ID
                                    FROM     Discovery.dbo.LinkedCashEntryMappings LCEM
                                    WHERE   CE.[Status] = 'Confirmed'
                                            AND CE.[Type] = 'Withdrawal'
                                            AND CE.Method = 'Internal Transfer'
                                            AND CE.ID = LCEM.LinkedCashEntryId
                                        )
                        GROUP BY CE.ClAccountID ,
                                CE.Currency
                      ) WD
                    ON WD.ClAccountID = CLIENTSANDCCY.CLAccountID
                    AND WD.Currency = CLIENTSANDCCY.CCYCode

            /*
                OC
                    ISNULL(BUYORD.BuyOrders, 0) AS BuyOrders ,
                    ISNULL(BUYORD.BuyOrdersExComm, 0) AS BuyOrdersExComm ,
                    AvailableBalance

                    This used to just be BuyOrders but merged buy/sells together since I don't want to scan that portion of data twice
                    Moved these in:
                        ISNULL(SELLORD.SellOrders, 0) AS SellOrders ,
                        ISNULL(SELLORD.SwitchSellOrders, 0) AS SwitchSellOrders
                        AvailableBalance

            */
            LEFT JOIN ( SELECT  OC.ClAccountID ,
                                OC.OrderSettCurrency ,
                                SUM(CASE WHEN OC.OrderBuySell = 'Buy' AND OC.SwitchID IS NULL THEN COALESCE(OC.AvailableCashValue,OC.DisplayValue) ELSE 0 END) AS BuyOrders ,
                                SUM(CASE WHEN OC.OrderBuySell = 'Buy' AND OC.SwitchID IS NULL THEN OC.DisplayValueExComm ELSE 0 END) AS BuyOrdersExComm,

                                SUM(ABS(CASE WHEN OC.OrderBuySell = 'Sell' AND OC.SwitchID IS NULL THEN OC.DisplayValue ELSE 0 END)) AS SellOrders ,
                                SUM(ABS(CASE WHEN  OC.OrderBuySell = 'Sell' AND OC.SwitchID IS NOT NULL THEN OC.DisplayValue END)) AS SwitchSellOrders,

                                SUM(CASE WHEN OC.OrderBuySell = 'Buy' AND OC.SwitchID IS NULL
                                    AND ((COALESCE(GT.RestrictSweepUntil, GT.LedgerDate, ET.LedgerDate) <= @AsAt)
								       OR CE.ID IS NULL)
                                THEN OC.DisplayValue 
                                ELSE 0 
                                END) AS BuyOrdersWithSettledCash

                        FROM    Discovery.dbo.OrderCurrent OC
                                INNER JOIN Discovery.dbo.Batch B ON B.BatchID = OC.BatchID
                                INNER JOIN res_db.dbo.Instruments Inst ON Inst.Security = OC.InstrumentCode
                                LEFT JOIN Discovery.dbo.CashEntry CE ON CE.BatchID = OC.BatchID AND OC.OrderBuySell = 'Buy'
                                LEFT JOIN dbo.SEClientAccount SECA ON SECA.ClAccountId = CE.ClAccountId
                                LEFT JOIN CashLedger.CashEntryTransactions CET ON CET.CashEntryId = CE.Id
                                LEFT JOIN CashLedger.GladTransactions GT ON CET.TransactionId = GT.TransactionId
								LEFT JOIN CashLedger.ExternalTransactions ET ON CET.TransactionId = ET.TransactionId
                                LEFT JOIN CashLedger.MovementTypes MT ON GT.MovementTypeId = MT.MovementTypeId OR ET.MovementTypeId = MT.MovementTypeId
                        WHERE
                                B.BatchType IN ( 'Auto', 'One-Off' )
                                AND B.BatchID != @BatchId

                                /* just like adding the extra line since it clearly shows everything factored into this query */
                                AND OC.Status IN ('Authorised','AuthorisedSwitch','Confirmed','Placed','Pooled','Processing', 'Completed' )
                                AND ( --S.[Open] = 1
                                      OC.Status IN ('Authorised','AuthorisedSwitch','Confirmed','Placed','Pooled','Processing' )

                                      /*  This is why the OrderCurrent ClAccountID index was modified to include these columns 1000-4000 logical IO difference from this */
                                      OR ( OC.[Status] = 'Completed'
                                           AND OC.SettlementStatus NOT IN ( 'Completed', 'NotRequired' )
                                         )
                                    )

                                -- but ignore conversions
                                AND OC.ConversionID IS NULL

                                AND (CE.Id IS NULL OR (CE.Status = 'Completed' AND MT.MovementType <> 'TAX_RELIEF' AND SECA.Id = COALESCE(GT.AccountId, ET.AccountId)))
	                            AND NOT EXISTS(  SELECT 1 FROM
                                                 dbo.BedAndProductCompletionInvestments  BPCI
                                                 INNER JOIN dbo.BedAndProductCompletionCashEntries BPCE
                                                 ON BPCI.BedAndProductCompletionId = BPCE.BedAndProductCompletionId
                                                 INNER JOIN Discovery.dbo.CashEntry CEBI ON CEBI.Id  = BPCE.CashEntryId
                                                 WHERE CEBI.Status IN ('Authorised','Confirmed','Placed','Processing') AND BPCI.OrderId = OC.OrderID
                                                 AND BPCI.ClaccountId = OC.ClAccountId AND OC.OrderBuySell = 'Buy')
                                /* not a fan of this, but tried restructuring as a NOT EXISTS
                                    and had detrimental affects to performance.

                                    This bit should only apply to Buys
                                */
                                AND (
                                      OC.OrderBuySell = 'Sell'
                                      /* The compare against 0 was never in here, so meant if you explicitly stated no override
                                        they got excluded.  Written this way to avoid the test since i'm ok with it in this case
                                        BUT don't want the whole file excluded from the test.
                                      */

                                      OR NULLIF(@ExcludePlatformFundSwitch, 0) IS NULL
                                      OR ( @ExcludePlatformFundSwitch = 1
                                           AND ( Inst.SecurityType <> 'Platform fund'
                                                 OR ( Inst.SecurityType = 'Platform fund'
                                                      AND Inst.SecuritySubType = 'Platform fund'
                                                      AND OC.SwitchID IS NULL
                                                    )
                                               )
                                         )
                                    )
                        GROUP BY OC.ClAccountID ,
                                OC.OrderSettCurrency
                      ) ORD
                    ON ORD.ClAccountID = CLIENTSANDCCY.CLAccountID
                    AND ORD.OrderSettCurrency = CLIENTSANDCCY.CCYCode

            /*
                OC
                    ISNULL(SELLORDSAMEBATCH.SellOrdersSameBatch, 0) AS SellOrdersSameBatch ,
            */
            LEFT JOIN ( SELECT  OC.ClAccountID ,
                                OC.OrderSettCurrency ,
                                SUM(ABS(OC.DisplayValue)) AS SellOrdersSameBatch
                        FROM    Discovery.dbo.OrderCurrent OC
                                INNER JOIN Discovery.dbo.Batch B ON B.BatchID = OC.BatchID
                        WHERE   OC.OrderBuySell = 'Sell'
                                AND B.BatchType IN ( 'Auto', 'One-Off' )
                                AND OC.Status IN ( 'Created', 'Confirmed', 'Authorised', 'Pooled', 'Placed' )
                                AND B.BatchID = @BatchId
                                /* attempts to avoid this lookup entirely */
                                AND @BatchId <> 0

                        GROUP BY OC.ClAccountID ,
                                OC.OrderSettCurrency
                        HAVING  ROUND(SUM(OC.DisplayValue), 2) <> 0
                      ) SELLORDSAMEBATCH

                ON SELLORDSAMEBATCH.ClAccountID = CLIENTSANDCCY.CLAccountID
                AND SELLORDSAMEBATCH.OrderSettCurrency = CLIENTSANDCCY.CCYCode


            /*
                OC
                    ISNULL(DEAL.DealsInProgress, 0) AS DealsInProgress ,
                    ISNULL(DEAL.SellDealsInProgress, 0) AS SellDealsInProgress ,
                    ISNULL(DEAL.BuyDealsInProgress, 0) AS BuyDealsInProgress ,

                    Can't merge these back into Ords
                    It has
                        AND NOT EXISTS (
                                    SELECT 1 FROM Discovery.dbo.CashEntry CE WHERE OC.BatchID = CE.BatchID
                                )
                    Which complicates doing that.
            */
            LEFT JOIN ( SELECT  OC.ClAccountID ,
                                OC.OrderSettCurrency ,
                                SUM(CASE WHEN OC.OrderBuySell = 'Buy'
                                         THEN OC.DisplayValue
                                         ELSE 0
                                    END) AS BuyDealsInProgress ,
                                SUM(CASE WHEN OC.OrderBuySell = 'Buy' 
                                    AND OC.SwitchId IS NULL
                                         THEN OC.DisplayValue
                                         ELSE 0
                                    END) AS BuyDealsInProgressExcludingSwitches ,
                                SUM(CASE WHEN OC.OrderBuySell = 'Sell'
                                         THEN OC.DisplayValue
                                         ELSE 0
                                    END) AS SellDealsInProgress ,
                                SUM(CASE WHEN NOT ( OC.SecuritySubType = 'Term Deposit'
                                                    AND OC.Sec_type = 'Fixed Interest'
                                                    AND OC.Status = 'Placed'
                                                  ) THEN OC.DisplayValue
                                         ELSE 0
                                    END) AS DealsInProgress

                        FROM (

                            /* both sides of the union all are similar - the only differences are:
                                    Top one deals with
                                    AND OC.Status IN ( 'Placed', 'Pooled', 'Authorised')--, 'Completed' )

                                    the bottom with
                                    AND OC.Status = 'Completed'


                                    The work the optimizer was doing made this split necessary since it was looking up
                                    data based on status a bit differently (considerably more Completed than other status'
                                    so the statistiscal difference there made an impact.
                            */
                            SELECT
                                OC.ClAccountID ,
                                OC.OrderSettCurrency ,
                                OC.OrderBuySell,
                                OC.Status,
                                OC.DisplayValue,
                                OC.SwitchId,
                                Inst.SecuritySubType,
                                Inst.Sec_type
                            FROM    Discovery.dbo.OrderCurrent OC
                                    INNER JOIN Discovery.dbo.Batch B ON B.BatchID = OC.BatchID
                                    INNER JOIN res_db.dbo.Instruments Inst ON Inst.Security = OC.InstrumentCode
                            WHERE   B.BatchType IN ( 'Auto', 'One-Off' )
                                    AND B.BatchID <> @BatchId
                                    AND OC.Status IN ( 'Placed', 'Pooled', 'Authorised')
                                    AND ( ( 
                                            OC.Status IN ( 'Placed', 'Pooled' )
                                            OR ( OC.Status = 'Authorised'
                                                 AND ( OC.PoolOrderID IS NOT NULL OR Inst.SecuritySubType IN ('Easy Access', 'Notice', 'Term')))
                                          )
                                    )
                                -- but ignore conversions
                                    AND OC.ConversionID IS NULL
				    AND NOT (OC.Status = ('Authorised') AND Inst.SecuritySubType IN ('InsuredFund', 'Commercial Property'))

                            UNION ALL

                            SELECT
                                OC.ClAccountID ,
                                OC.OrderSettCurrency ,
                                OC.OrderBuySell,
                                OC.Status,
                                OC.DisplayValue,
                                OC.SwitchId,
                                Inst.SecuritySubType,
                                Inst.Sec_type
                            FROM    Discovery.dbo.OrderCurrent OC 
                                    INNER JOIN Discovery.dbo.Batch B ON B.BatchID = OC.BatchID
                                    INNER JOIN res_db.dbo.Instruments Inst ON Inst.Security = OC.InstrumentCode
                                    left outer join Discovery.dbo.CashEntry CE on CE.BatchID = B.BatchID and CE.Status <> 'Completed' AND OC.OrderBuySell = 'Buy'
                            WHERE   B.BatchType IN ( 'Auto', 'One-Off' )
                                    AND B.BatchID <> @BatchId
                                    AND OC.Status = ('Authorised')
                                    AND Inst.SecuritySubType IN ('InsuredFund', 'Commercial Property')
                                    and CE.ID is NULL
									-- but ignore conversions
                                    AND OC.ConversionID IS NULL

                            UNION ALL


                            SELECT
                                OC.ClAccountID ,
                                OC.OrderSettCurrency ,
                                OC.OrderBuySell,
                                OC.Status,
                                OC.DisplayValue,
                                OC.SwitchId,
                                Inst.SecuritySubType,
                                Inst.Sec_type
                            FROM    Discovery.dbo.OrderCurrent OC
                                    INNER JOIN Discovery.dbo.Batch B ON B.BatchID = OC.BatchID
                                    INNER JOIN Res_db.dbo.Instruments Inst ON Inst.Security = OC.InstrumentCode
                            WHERE   B.BatchType IN ( 'Auto', 'One-Off' )
                                    AND B.BatchID <> @BatchId
                                    AND (  ( OC.Status = 'Completed'
                                               AND OC.SettlementStatus NOT IN ( 'Completed', 'NotRequired' )
                                             )
                                        )
                                    -- but ignore conversions
                                    AND OC.ConversionID IS NULL
                            ) OC

                        GROUP BY OC.ClAccountID ,
                                OC.OrderSettCurrency
                      ) DEAL ON DEAL.ClAccountID = CLIENTSANDCCY.CLAccountID
                                AND DEAL.OrderSettCurrency = CLIENTSANDCCY.CCYCode


            /*
                ARL
                    ISNULL(FEE.FeeExpectations, 0) AS FeeExpectations ,
                    ISNULL(FEE.FutureDatedFeeExpectations, 0) AS FutureDatedFeeExpectations ,
                    ISNULL(FEE.UnsettledCashPostedFees, 0) AS UnsettledCashPostedFees ,
            */
            LEFT JOIN ( SELECT
                               T.ClAccountID ,
                               T.CCYCode AS CCYCode ,
                               SUM(T.UnsettledCashPostedFees) AS UnsettledCashPostedFees,
                               SUM(T.FeeExpectations) AS FeeExpectations,
                               SUM(T.FutureDatedFeeExpectations) AS FutureDatedFeeExpectations
                        FROM (	SELECT
                                        ARL.ClAccountID ,
                                        CF.ISOCode AS CCYCode ,
                                        OC.OrderID ,
                                        CASE
                                            WHEN ARL.AsAt <= @AsAt
                                                    AND OC.OrderBuySell = 'SELL'
                                                    AND EXISTS(SELECT 1
                                                            FROM dbo.Trades TR
                                                            WHERE TR.OrderID = OC.OrderID
                                                                AND TR.Status = 'Booked')
                                            THEN ARL.TotalAmount
                                            ELSE 0
                                        END AS UnsettledCashPostedFees,
                                        CASE
                                            WHEN ARL.AsAt <= @AsAt
                                                    AND ARL.GLPosted = 'NO' 
													AND ARL.[Status] <> 50 --HeldPendingNprCrystallisation status - held/hidden from available cash pending crystalisation completion
                                            THEN ARL.TotalAmount
                                            ELSE 0
                                        END AS FeeExpectations ,
                                        CASE
                                            WHEN ARL.AsAt > @AsAt
                                                    AND FTT.IncludeFutureDatedFeesInAvailableCash = 1
                                                    AND ARL.GLPosted = 'NO'
                                            THEN ARL.TotalAmount
                                            ELSE 0
                                        END AS FutureDatedFeeExpectations
                                FROM Discovery.dbo.AdvisorRevenueLedger ARL
                                     LEFT JOIN dbo.ClientDetails CD ON ARL.ClAccountID = CD.ClAccountID
                                     LEFT JOIN dbo.Company CO ON CD.Company = CO.Company
                                     LEFT JOIN dbo.FeeTranTypes FTT ON ARL.TranType = FTT.TranType AND FTT.WrapProvider = CO.WrapProvider
                                     LEFT JOIN Discovery.dbo.OrderCurrent OC ON OC.OrderID = ARL.OrderID
                                     INNER JOIN res_db.dbo.CurrencyFormat CF ON CF.ID = ARL.CurrencyId
                                WHERE
                                     ISNULL(ARL.Reversed, 0) <> 1
                                     AND ( ARL.PendingAdvisorPost = 'YES'
                                          OR FTT.IncludeUnauthorisedFeesInAvailCash = 1
                                     )
                                     AND ARL.AdvisorPostMethod <> 'DLT'
                                     AND FTT.IsRebate = 0
                                     AND FTT.ExcludeAuthorisedFeesInAvailableCash <> 1

                                     /* next three statements replaced with not exists */
                                     AND ( OC.OrderID IS NULL
                                          OR OC.[Status] = 'Completed'
                                     )
                                     /* doing these this way prevent a multiplication of stats 1:m OC, 1:M CashEntry 1:M2 (really big number) */
                                     AND NOT EXISTS (
                                                      SELECT 1
                                                       FROM   Discovery.dbo.Batch B
                                                      WHERE  B.BatchID = ARL.BatchID
                                                             AND B.BatchType = 'Standing'
                                                    )
                                     AND NOT EXISTS (
                                                      SELECT 1
                                                      FROM   Discovery.dbo.CashEntry CE
                                                      WHERE  CE.BatchID = ARL.BatchID
                                                             AND CE.InstructionType = 'Standing'
                                                    )

                                     AND ARL.ClAccountID IS NOT NULL
                                )T
                                GROUP BY T.ClAccountID, T.CCYCode

                      ) FEE ON FEE.ClAccountID = CLIENTSANDCCY.CLAccountID
                      /* this was missing which meant i didn't get a match up of 1:1 and ALWAYS looked this up; even if I didn't need it */
                      AND FEE.CCYCode = CLIENTSANDCCY.CCYCode

            LEFT JOIN
            (
                SELECT     PARL.ClAccountID,
                           CF.ISOCode AS CCYCode,
                           SUM(PARL.TotalAmount) AS FeeExpectations
                FROM       Discovery.Charges.ProjectedAdvisorRevenueLedger PARL
                INNER JOIN Res_DB.dbo.CurrencyFormat CF ON CF.ID = PARL.CurrencyId
                WHERE      PARL.ChargeDate > @AsAt
                AND        PARL.AsAt <= @AsAt
                GROUP BY   PARL.ClAccountID, CF.ISOCode
            )
            PROJECTEDFEE ON PROJECTEDFEE.ClAccountID = CLIENTSANDCCY.ClAccountID AND PROJECTEDFEE.Ccycode = CLIENTSANDCCY.Ccycode

            LEFT JOIN (
                SELECT     OC.ClAccountId,
                           OC.OrderSettCurrency,
                           SUM(OC.DisplayValue) AS InsuredFundsBuyOrders
                FROM       Discovery.dbo.OrderCurrent OC
                INNER JOIN Discovery.dbo.Batch B ON B.BatchId = OC.BatchId
                LEFT JOIN  Discovery.dbo.CashEntry CE ON OC.BatchId = CE.BatchId
                LEFT JOIN  res_db.dbo.ManagedFunds M ON M.InstrumentCode = OC.InstrumentCode
                WHERE      OC.OrderBuySell = 'Buy'
                AND        B.BatchType IN ('Auto', 'One-Off')
                AND        OC.[Status] IN ('Authorised', 'AuthorisedSwitch', 'Confirmed', 'Placed', 'Pooled', 'Processing') -- OrderStatus.Open = 1
                AND        OC.PoolOrderID IS NULL
                AND        B.BatchID <> @BatchId
                AND        COALESCE(M.InsuredFund, 0) = 1 -- Include only insured funds
                AND        OC.ConversionID IS NULL        -- But ignore conversions
                AND        CE.BatchId IS NULL
                GROUP BY   OC.ClAccountId,
                           OC.OrderSettCurrency
                HAVING     ROUND(SUM(OC.DisplayValue), 2) <> 0
            )
            IFBUYORD on IFBUYORD.ClAccountID = CLIENTSANDCCY.ClAccountID And IFBUYORD.OrderSettCurrency = CLIENTSANDCCY.CCYCODE
			/* Oversettled sell for withdrawals */
			LEFT JOIN (SELECT
					SUM(t.FilledValue - t.OrderValue) Oversettlement,
					t.OrderSettCurrency Currency,
					t.ClAccountID
				FROM (
					SELECT SUM(OC.FilledValue) FilledValue, SUM(OC.OrderValue) OrderValue,OC.OrderSettCurrency,OC.ClAccountID from Discovery.dbo.OrderCurrent OC
					INNER JOIN Discovery.dbo.CashEntry CE
						ON CE.BatchId = OC.BatchId
					INNER JOIN Discovery.dbo.Batch B WITH (INDEX(PK_Batch))
						ON B.BatchId = OC.BatchId
					WHERE OC.Status = 'Completed'
					AND OC.OrderBuySell = 'Sell'
					AND CE.Status in ('Authorised','Confirmed')
					AND B.OrderValueRecalc in ('Required','Processing')
					GROUP BY OC.BatchId, OC.OrderSettCurrency, OC.ClAccountId
					HAVING SUM(OC.FilledValue) > SUM(OC.OrderValue) ) t
				GROUP BY t.OrderSettCurrency, t.ClAccountID
			) OSW ON OSW.ClAccountID = CLIENTSANDCCY.ClAccountID AND OSW.Currency = CLIENTSANDCCY.CCYCode

            LEFT JOIN (
                SELECT     OC.ClAccountID,
                           OC.OrderSettCurrency,
                           -SUM(OC.DisplayValue) AS SwitchSellsWithUnsettledBuys
                FROM       Discovery.dbo.OrderCurrent OC

				/* had to switch this to a cross apply - had attempted to wrap OC.Switch ID in a convert to avoid joins in that direction
					But that didn't work under all circumstances, was getting inconsitent results 
					The cross apply is like an exists, but forces the plans selection.

					This may not be great if you're doing available cash for a large number of accounts at one (disinvestments would be one of the bigger places at 500()
					*/
				CROSS APPLY ( SELECT TOP 1 oc2.SwitchID 
							FROM Discovery.dbo.OrderCurrent oc2
                           WHERE     oc2.OrderBuySell = 'Buy'
                              
                           AND       (oc2.Status IN ('Authorised','AuthorisedSwitch','Confirmed','Placed','Pooled','Processing')
                                     OR (oc2.Status = 'Completed' AND oc2.SettlementStatus NOT IN ('Completed', 'NotRequired')))

						   AND oc2.SwitchID = OC.SwitchID
						) OC2


                WHERE      OC.SwitchID IS NOT NULL
                AND        OC.Status = 'Completed'
                AND        OC.SettlementStatus IN ('Completed', 'NotRequired')
     
                GROUP BY OC.ClAccountID, OC.OrderSettCurrency
            )
            SWITCH on SWITCH.ClAccountID = CLIENTSANDCCY.ClAccountID AND SWITCH.OrderSettCurrency = CLIENTSANDCCY.CCYCODE


			LEFT JOIN (
			 
			 SELECT 
			         t.ClAccountID ,
                     t.OrderSettCurrency ,
				     SUM(t.SellOrdersFundingWithdrawals) AS SellOrdersFundingWithdrawals,
					 SUM(t.SellOrdersFundingBedAndIsaDisinvestment) AS SellOrdersFundingBedAndIsaDisinvestment
			           
					   FROM(
			                SELECT  OC.ClAccountID ,
                                OC.OrderSettCurrency ,                                
								CASE WHEN EXISTS(
								SELECT 1 FROM Discovery.dbo.CashEntry CE 
									WHERE CE.BatchID = OC.BatchId 
									AND OC.ClAccountID =  CE.ClAccountID
									AND CE.Type = 'Withdrawal' 
									AND CE.Status IN ('Authorised','Confirmed','Placed','Processing') 
									AND ( B.StandingNextCashDate <= @AsAt OR B.StandingNextCashDate IS NULL )
									AND ( @CashEntryId IS NULL OR CE.ID <> @CashEntryId )) THEN ABS(OC.DisplayValue) ELSE 0 END  AS SellOrdersFundingWithdrawals,
								CASE WHEN  EXISTS(SELECT 1 FROM dbo.BedAndProductCompletionDisinvestments BAI
									WHERE BAI.OrderID = OC.OrderID
									   AND BAI.ClAccountid = OC.ClAccountid) THEN ABS(OC.DisplayValue) ELSE 0 END AS SellOrdersFundingBedAndIsaDisinvestment

                        FROM    Discovery.dbo.OrderCurrent OC
                                INNER JOIN Discovery.dbo.Batch B ON B.BatchID = OC.BatchID
                                
                        WHERE								
								OC.OrderBuySell = 'Sell'
                                AND B.BatchType IN ( 'Auto', 'One-Off' )
								AND B.BatchID <> @BatchId
                                /* just like adding the extra line since it clearly shows everything factored into this query */
                                AND OC.Status IN ('Authorised','AuthorisedSwitch','Confirmed','Placed','Pooled','Processing', 'Completed' )
                                AND ( --S.[Open] = 1
                                      OC.Status IN ('Authorised','AuthorisedSwitch','Confirmed','Placed','Pooled','Processing' )

                                      /*  This is why the OrderCurrent ClAccountID index was modified to include these columns 1000-4000 logical IO difference from this */
                                      OR ( OC.Status = 'Completed'
                                           AND OC.SettlementStatus NOT IN ( 'Completed', 'NotRequired' )
                                         )
                                    )
                 
                                -- but ignore conversions
                                AND OC.ConversionID IS NULL) t
                        GROUP BY t.ClAccountID ,
                                t.OrderSettCurrency
			)
			WITHDRAWALSELLS ON WITHDRAWALSELLS.ClAccountId = CLIENTSANDCCY.ClAccountID AND WITHDRAWALSELLS.OrderSettCurrency = CLIENTSANDCCY.CCYCode