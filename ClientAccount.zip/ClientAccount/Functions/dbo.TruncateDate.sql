SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- =============================================
-- Author:		Ben Arnold
-- Create date: 2007-01-16
-- Description:	Returns midnight immediately
--              prior to the date passed in
-- =============================================
CREATE FUNCTION [dbo].[TruncateDate] 
(
	@Date DATETIME
)
RETURNS DATETIME
AS
BEGIN
	DECLARE @Result DATETIME
	SELECT @Result = Convert(DATETIME, Convert(VARCHAR(10), @Date, 112), 112)
	RETURN @Result
END
GO
