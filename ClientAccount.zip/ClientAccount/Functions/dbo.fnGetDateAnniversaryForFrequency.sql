/***
<Function>
    <Description>Function to provide frequency-anniversary of SeedDate on or after AsAt together and initial period start. Simplified version of Platform.ChargeProcessing.fnGetDateAnniversaryForFrequency from Charges package.</Description>
    <Parameters>
        <Parameter Name="@AsAt">
            <Description>Date on or after the frequency-anniversary we are looking for</Description>
        </Parameter>
		<Parameter Name="@SeedDate">
            <Description>Initial date</Description>
        </Parameter>
        <Parameter Name="@Frequency">
            <Description>Frequency name</Description>
        </Parameter>
    </Parameters>
</Function>
**/

CREATE FUNCTION [dbo].[fnGetDateAnniversaryForFrequency] (
	  @AsAt DATE 
	, @SeedDate DATE
	, @Frequency VARCHAR(20)
	)
RETURNS DATE
AS

--DECLARE @AsAt AS DATE
--DECLARE @SeedDate AS DATE
--DECLARE @Frequency Varchar(20)
--SET @AsAt = '2021-02-15'
--SET @SeedDate = '2012-02-29'
--SET @Frequency = 'Quarterly'

BEGIN

DECLARE @AnniversaryDate AS DATE

; WITH [FrqAndSeedDate] AS (
	SELECT
		  @Frequency Frequency
		, CASE
			WHEN @Frequency = 'Daily' THEN 1.0
			WHEN @Frequency = 'Weekly' THEN 7.0
			WHEN @Frequency = 'Fortnightly' THEN 14.0
			WHEN @Frequency = 'Monthly' THEN 1.0
			WHEN @Frequency = 'Quarterly' THEN 3.0
			WHEN @Frequency = 'HalfYearly' THEN 6.0
			WHEN @Frequency IN ('Annual', 'Yearly') THEN 12.0
		END As Multiplier
		, @SeedDate SeedDate
		, CASE 
			WHEN @Frequency IN ('Daily','Weekly','Fortnightly') THEN 'D'
			WHEN @Frequency IN ('Monthly','Quarterly','HalfYearly' ,'Annual', 'Yearly') THEN 'M'
		END As [Period]
),

[Periods] AS (
	SELECT
		  Frequency
		, SeedDate
		, Multiplier
		, [Period]
		, CASE 
			WHEN Frequency = 'Daily'
				THEN DATEDIFF(D, SeedDate, @AsAt)
			ELSE
				CASE
					WHEN [Period] = 'D' THEN
						CASE 
							WHEN DATEADD(D, CEILING(DATEDIFF(D, SeedDate, @AsAt) / Multiplier) * Multiplier, SeedDate) < @AsAt
								THEN CEILING(DATEDIFF(D, SeedDate, @AsAt) / Multiplier) + 1
							ELSE CEILING(DATEDIFF(D, SeedDate, @AsAt) / Multiplier)
						END
					WHEN [Period] = 'M' THEN
						CASE
							WHEN DATEADD(M, CEILING(DATEDIFF(M, SeedDate, @AsAt) / Multiplier) * Multiplier, SeedDate) < @AsAt
								THEN CEILING(DATEDIFF(M, SeedDate, @AsAt) / Multiplier) + 1
							ELSE CEILING(DATEDIFF(M, SeedDate, @AsAt) / Multiplier)
						END				
				END
		END As [PeriodCount]
	FROM FrqAndSeedDate
)

SELECT @AnniversaryDate = (
	SELECT TOP 1 
		CASE
			WHEN [Period] = 'D' THEN DATEADD(D, [PeriodCount] * Multiplier, SeedDate)		
			WHEN [Period] = 'M' THEN DATEADD(M, [PeriodCount] * Multiplier, SeedDate)
		END		
	FROM [Periods]
	WHERE PeriodCount > 0
	)

RETURN @AnniversaryDate

END