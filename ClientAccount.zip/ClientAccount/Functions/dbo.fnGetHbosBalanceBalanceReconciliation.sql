create function dbo.fnGetHbosBalanceBalanceReconciliation(@balanceDate datetime, @clientId int) 
returns table
AS


/*
declare @balancedate as datetime; set @balancedate = '13 jun 2014'
declare @clientId as int; set @clientId = 8245
*/

return
select 
	HBS.ID,
	HBS.CurrentBalance, 
	HBS.AvailableBalance,
	HBS.ClearedBalance,
	HBS.Date,
	GBA.ClAccountID,
	GBA.Currency,
	HBS.ReconciledDateTime,
	CD.Company,
	A.CmtBalance,
	HBS.SortCode,
	HBS.AccountNumber as BankAccountNumber,
	BAC.ClientID
from dbo.HbosBalanceSummary HBS
inner join dbo.GladClientBankAccount GBA
	on GBA.SortCOde = HBS.SortCOde
	and GBA.AccountNumber = HBS.AccountNumber
inner join dbo.ClientDetails CD
	on CD.CLAccountID = GBA.CLAccountID
inner join dbo.vwCashLedgerTransValue A
	on GBA.ClAccountId = A.ClAccountID
inner join dbo.vwBaseAllowedClAccountID BAC
	on BAC.ClAccountID = GBA.CLAccountID
	and BAC.ClientID = @clientId
where hbs.Date = @balancedate
	go
