/***
<Function>
    <Description>Calculate corporate action reinvestment buy order value</Description>
    <Parameters>
        <Parameter Name="@TargetNewAmount">
            <Description>Target New Amount</Description>
        </Parameter>
		<Parameter Name="@PtcTotal">
            <Description>Ptc Total</Description>
        </Parameter>
        <Parameter Name="@TaxRecoverTotal">
            <Description>Tax Recover Total</Description>
        </Parameter>
    </Parameters>
</Function>
***/
CREATE FUNCTION [dbo].[fnCalculateCorporateActionBuyOrder]
  ( 
  @TargetNewAmount DECIMAL(18, 2),
  @PtcTotal DECIMAL(18,2),
  @TaxRecoverTotal DECIMAL(18,2)
   )
RETURNS DECIMAL(18, 2)
AS
BEGIN
  RETURN @TargetNewAmount - Coalesce(@PtcTotal,0) + Coalesce(@TaxRecoverTotal,0)
END
GO
