

CREATE FUNCTION [dbo].[fn_GetCommissionReportDetails]

(

-- Add the parameters for the function here

@periodStart datetime,

@periodEnd datetime,

@WrapProvider varchar(20)

)

RETURNS TABLE

AS

RETURN

(

--Declare @PeriodStart as datetime

--Declare @PeriodEnd as datetime

--Declare @WrapProvider varchar(20)

--set @PeriodStart='01 Aug 2009'

--set @PeriodEnd='31 Aug 2009'

--Set @wrapprovider ='AXA'

SELECT CPH.ClaccountId as claccountid,

CASE WHEN SECA.InvestorType = 'INDIVIDUAL'

THEN 'Individual'

WHEN SECA.InvestorType = 'INDIVID'

THEN 'Individual'

WHEN SECA.InvestorType = 'JOINT'

THEN 'Joint'

WHEN SECA.InvestorType = 'JOINT_INDIVIDUAL'

THEN 'Joint'

WHEN SECA.InvestorType = 'Trust'

THEN 'Trust'

WHEN SECA.InvestorType = 'Consolidated'

THEN 'Consolidated'

ELSE 'Third Party'

END

as accounttype,

AH.IRDNo as NINO,

HBA.Company as CompanyCode,

HBA.CompanyName as CompanyName,

HBA.Advcode as AdvisorCode,

HBA.AdviserName as AdvisorName,

HBA.BranchId as BranchCode,

HBA.Branch as BranchName,

HBA.Network as NetworkCode,

HBA.NetworkName as NetworkName,

HBA.SubCompanyName as Region,

CASE 

WHEN CD.FeeStructure = 'Bundled' THEN 'Composite'

WHEN CD.FeeStructure = 'UnBundled' THEN 'Explicit'

ELSE CD.FeeStructure

END as feestructure,

--PersonalPortfolio (GIA)

COALESCE(CPH.Ppic,0) AS GIAInitialCommission,

COALESCE(CPH.PPFBRCCharge,0)AS GIAAdvisorRegularRemuneration,

COALESCE(CPH.PPAdvisorFBRCCharge,0)AS GIAAdvisorStandardRegularRemuneration,

COALESCE(CPH.PPAdHocCommission,0)AS GIAAdhocCommission,

COALESCE(CPH.Ppsic,0)AS GIASwitchCommission,

COALESCE(CPH.Ppdfmic,0) AS GIAInitialCommission_DFM,

(COALESCE(CPH.PPDFMFixedCharge,0) + COALESCE(CPH.PPDFMTieredCharge,0)) AS GIAOngoingCommission_DFM,

--ISA

COALESCE(CPH.Isaic,0)AS ISAInitialCommission,

COALESCE(CPH.ISAFBRCCharge,0)AS ISAAdvisorRegularRemuneration,

COALESCE(CPH.ISAAdvisorFBRCCharge,0)AS ISAAdvisorStandardRegularRemuneration,

COALESCE(CPH.ISAAdHocCommission,0)AS ISAAdhocCommission,

COALESCE(CPH.Isasic,0)AS ISASwitchCommission,

COALESCE(CPH.Isadfmic,0)AS ISAInitialCommission_DFM,

(COALESCE(CPH.ISADFMFixedCharge,0) + COALESCE(CPH.ISADFMTieredCharge,0)) AS ISAOngoingCommission_DFM,

--SIPP (PIA)

COALESCE(CPH.Sippic,0)AS PIAInitialCommission,

COALESCE(CPH.SIPPFBRCCharge,0)AS PIAAdvisorRegularRemuneration,

COALESCE(CPH.SIPPAdvisorFBRCCharge,0)AS PIAAdvisorStandardRegularRemuneration,

COALESCE(CPH.SIPPAdHocCommission,0)AS PIAAdhocCommission,

COALESCE(CPH.Sippsic,0)AS PIASwitchCommission,

COALESCE(CPH.Bceic,0)AS BenefitEventCrystalisationCommission,

COALESCE(CPH.Sippdfmic,0)AS PIAInitialCommission_DFM,

(COALESCE(CPH.SIPPDFMFixedCharge,0)+ COALESCE(CPH.SIPPDFMTieredCharge,0)) AS PIAOngoingCommission_DFM,

--Total

COALESCE(CPH.Ppic,0) + COALESCE(CPH.Isaic,0) + COALESCE(CPH.Sippic,0) as TOTALInitialCommission,

COALESCE(CPH.PPFBRCCharge,0) + COALESCE(CPH.ISAFBRCCharge,0) + COALESCE(CPH.SIPPFBRCCharge,0) as TOTALAdvisorRegularRemuneration,

COALESCE(CPH.PPAdvisorFBRCCharge,0) + COALESCE(CPH.ISAAdvisorFBRCCharge ,0) + COALESCE(CPH.SIPPAdvisorFBRCCharge,0) as TOTALAdvisorStandardRegularRemuneration,

COALESCE(CPH.PPAdHocCommission,0) + COALESCE(CPH.ISAAdHocCommission,0) + COALESCE(CPH.SIPPAdHocCommission,0) as TOTALAdhocCommission,

COALESCE(CPH.Ppsic,0) + COALESCE(CPH.Isasic,0) + COALESCE(CPH.Sippsic,0) as TOTALSwitchCommission,

COALESCE(CPH.Ppdfmic,0) + COALESCE(CPH.Isadfmic,0) + COALESCE(CPH.Sippdfmic,0) as TOTALInitialCommission_DFM,

COALESCE(CPH.PPDFMFixedCharge,0) + 

COALESCE(CPH.PPDFMTieredCharge,0) + 

COALESCE(CPH.ISADFMFixedCharge,0) + 

COALESCE(CPH.ISADFMTieredCharge,0) + 

COALESCE(CPH.SIPPDFMFixedCharge,0) + 

COALESCE(CPH.SIPPDFMTieredCharge,0) as TOTALOngoingCommission_DFM,

--PP Volumes

COALESCE(CPH.PPNewCash,0) as GIANewCash,

COALESCE(CPH.PPReregAmount,0) as GIAReReg,

COALESCE(CPH.PPAverageFundsUnderManagement,0) as GIAAveregeFUM,

COALESCE(CPH.PPTotalDailyFundsUnderManagement,0) as GIATotalDailyFUM,

COALESCE(CPH.PPSwitchAmounts,0) as GIASwitchedFunds,

COALESCE(CPH.ISANewCash,0) as ISANewCash,

COALESCE(CPH.ISAReregAmount,0) as ISAReReg,

COALESCE(CPH.ISAAverageFundsUnderManagement,0) as ISAAveregeFUM,

COALESCE(CPH.ISATotalDailyFundsUnderManagement,0) as ISATotalDailyFUM,

COALESCE(CPH.ISASwitchAmounts,0) as ISASwitchedFunds,

COALESCE(CPH.SIPPNewCash,0) as PIANewCash,

COALESCE(CPH.SIPPReregAmount,0) as PIAReReg,

COALESCE(CPH.SIPPAverageFundsUnderManagement,0) as PIAAveregeFUM,

COALESCE(CPH.SIPPTotalDailyFundsUnderManagement,0) as PIATotalDailyFUM,

COALESCE(CPH.SIPPSwitchAmounts,0) as PIASwitchedFunds,

COALESCE(CPH.SIPPCrystalisedAmount,0) as PIAcrystalised,

COALESCE(CPH.WRAPCASHNewCash,0) as NewWrapCash,

COALESCE(CPH.WRAPCASHAverageFundsUnderManagement,0) as AverageWrapCashFUM,

COALESCE(CPH.WRAPCASHTotalDailyFundsUnderManagement,0) as WrapCashTotalDailyFUM,

CASE WHEN CD.InvestorType NOT IN ('Individ', 'Joint', 'Consolidated', 'Trust')

THEN 'Third Party'

ELSE CD.InvestorType

END as InvestorType

FROM dbo.fn_GetCommissionByPeriodByHeadAccount(@PeriodStart,@PeriodEnd) CPH

INNER JOIN dbo.SEClientAccount as SECA

ON CPH.ClaccountId=SECA.ClaccountId

INNER JOIN dbo.AccountHolders as AH

ON CPH.ClaccountId = AH.ClaccountId AND AH.Holdernumber = 1

INNER JOIN dbo.[vwHierarchyByAdvisor] as HBA

ON HBA.AdvCode=SECA.PrimaryAdviser

INNER JOIN dbo.ClientDetails as CD 

ON CD.ClaccountId=CPH.ClaccountId 

WHERE HBA.WrapProvider=@wrapprovider

)
GO
