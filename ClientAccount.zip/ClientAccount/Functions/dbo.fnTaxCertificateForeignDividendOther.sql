CREATE FUNCTION [dbo].[fnTaxCertificateForeignDividendOther](@FromDate DATETIME, @ToDate DATETIME, @SubAccounts VARCHAR(MAX))
RETURNS TABLE
AS
RETURN

/*
USE ClientAccount

DECLARE @FromDate DATETIME;
DECLARE @ToDate DATETIME;
DECLARE @SubAccounts VARCHAR(MAX);

SET @FromDate = '2016-04-06 00:00:00';
SET @ToDate = '2017-04-05 00:00:00';
SET @SubAccounts = 'ID1005150-001,ID1005177-001';
*/

SELECT
	ID,
	CorpActId,
	LedgerDate,
	DisplayName,
	Domicile,
	QualifyingHolding,
	Gross,
	WT,
	AmtPaid
FROM
	dbo.fnTaxCertificateForeignDividend(@FromDate, @ToDate, @SubAccounts)
WHERE
	SecuritySubType <> 'ManagedFund';
