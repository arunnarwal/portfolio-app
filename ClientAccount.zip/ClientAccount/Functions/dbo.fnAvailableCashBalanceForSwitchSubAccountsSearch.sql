/***
<Function>
    <Description>Provides the available cash for subaccounts

    </Description>
    <Parameters>
        <Parameter Name="@AsAt">
            <Description>
                The effective date to get available cash balance figures for.
            </Description>
        </Parameter>
    </Parameters>
</Function>
***/
CREATE FUNCTION [dbo].[fnAvailableCashBalanceForSwitchSubAccountsSearch]
(
	@AsAt DATETIME
)
RETURNS TABLE AS

RETURN
    
    SELECT  CLIENTSANDCCY.ClAccountId, CLIENTSANDCCY.AccountId AS SubAccountId,

            ISNULL(CLT.CLTbalance, 0)
                + ISNULL(CMT.CMTBalance, 0)
                + ISNULL(CLA.CLAbalance, 0)
                - ISNULL(WD.Withdrawals, 0)
                - ISNULL(DEAL.BuyDealsInProgress, 0)
                + ISNULL(ORD.SellOrders, 0) AS AvailableBalance
    FROM (
            SELECT     CD.ClAccountId,
                       SCA.Id AS AccountId,
                       GC.CurrencyId,
                       GC.CurrencyCode AS CCYCode,
                       C.WrapProvider
            FROM       dbo.ClientDetails CD
            INNER JOIN dbo.SEClientAccount SCA ON CD.CLAccountId = SCA.ClAccountId			
            LEFT JOIN  dbo.Company C ON CD.Company = C.Company
            CROSS JOIN CashLedger.Currencies GC
        )
        CLIENTSANDCCY

            LEFT JOIN
            (
               SELECT   GT.AccountId,
                        GT.CurrencyId,
                        -SUM(GT.Amount) AS CLTBalance,
                        SUM(CASE WHEN GT.RestrictSweepUntil > @AsAt AND GT.LedgerDate <= @AsAt AND GT.Amount > 0 THEN Amount ELSE 0 END) AS UnsettledCashDebits
               FROM     CashLedger.GladTransactions GT
               WHERE    GT.LedgerDate <= @AsAt
               GROUP BY GT.AccountId, GT.CurrencyId
            )
            CLT ON CLIENTSANDCCY.AccountId = CLT.AccountId AND CLIENTSANDCCY.CurrencyId = CLT.CurrencyId

            LEFT JOIN ( SELECT  CMT.ClAccountID ,
                                CMT.Currency ,
                                SUM(CMT.Amount) AS CMTBalance
                        FROM    dbo.CMTTrans CMT
                        WHERE   CMT.TranDate <= @AsAt
                        GROUP BY CMT.ClAccountID ,
                                CMT.Currency
                      ) CMT ON CMT.CLAccountID = CLIENTSANDCCY.CLAccountID
                               AND CMT.Currency = CLIENTSANDCCY.CCYCode

            LEFT JOIN ( SELECT  cla.ClAccountID ,
                                cla.CCYCode ,
                                -SUM(CASE WHEN cla.AdjustmentType <> 'UNCLEARED_CHEQUE' THEN cla.Amount ELSE 0 END) AS CLABalance ,
                                -SUM(CASE WHEN cla.AvailableAdjust = 1 THEN cla.Amount ELSE 0 END) AS CLAAvailableAdjustBalance ,
                                -SUM(CASE WHEN cla.PortfolioAdjust = 1 THEN cla.Amount ELSE 0 END) AS CLAPortfolioAdjustBalance ,
                                -SUM(CASE WHEN oc.SettlementDate > @AsAt
                                               AND oc.OrderBuySell = 'Sell'
                                          THEN cla.Amount
                                          ELSE 0
                                     END) AS SettlingToday
                        FROM    dbo.CashLedgerAdjustments cla

                        LEFT JOIN Discovery.dbo.OrderCurrent oc
                            ON oc.OrderID = cla.AWOrderID
                            AND oc.OrderBuySell = 'Sell'
                            AND cla.AWOrderID <> 0

                        WHERE   cla.LedgerDate <= @AsAt
                        GROUP BY cla.ClAccountID ,
                                cla.CCYCode
                      ) CLA ON CLA.ClAccountID = CLIENTSANDCCY.CLAccountID
                               AND CLA.CCYCode = CLIENTSANDCCY.CCYCode


            LEFT JOIN ( SELECT  CE.ClAccountID ,
                                CE.Currency ,
                                SUM(CE.Amount) AS Withdrawals
                        FROM    Discovery.dbo.CashEntry CE
                                INNER JOIN Discovery.dbo.Batch B ON B.BatchID = CE.BatchID

                                /*  This table doesn't seem to introduce the same problems OrderStatus does
                                    But is worth long term consideration.
                                 */
                                INNER JOIN Discovery.dbo.CashEntryStatus S ON S.[Status] = CE.[Status]
                        WHERE   CE.[Type] = 'Withdrawal'
                                AND B.BatchType IN ( 'Auto', 'One-Off' )
                                AND S.[Open] = 1

                                AND ( B.StandingNextCashDate <= @AsAt OR B.StandingNextCashDate IS NULL )
                                
                                AND NOT EXISTS (
                                    SELECT  CE.ID
                                    FROM     Discovery.dbo.LinkedCashEntryMappings LCEM
                                    WHERE   CE.[Status] = 'Confirmed'
                                            AND CE.[Type] = 'Withdrawal'
                                            AND CE.Method = 'Internal Transfer'
                                            AND CE.ID = LCEM.LinkedCashEntryId
                                        )
                        GROUP BY CE.ClAccountID ,
                                CE.Currency
                      ) WD
                    ON WD.ClAccountID = CLIENTSANDCCY.CLAccountID
                    AND WD.Currency = CLIENTSANDCCY.CCYCode

            LEFT JOIN ( SELECT  OC.ClAccountID ,
                                OC.OrderSettCurrency ,
                                SUM(CASE WHEN OC.OrderBuySell = 'Buy' THEN COALESCE(OC.AvailableCashValue,OC.DisplayValue) ELSE 0 END) AS BuyOrders ,
                                SUM(CASE WHEN OC.OrderBuySell = 'Buy' THEN OC.DisplayValueExComm ELSE 0 END) AS BuyOrdersExComm,

                                SUM(ABS(CASE WHEN OC.OrderBuySell = 'Sell' AND OC.SwitchID IS NULL THEN OC.DisplayValue ELSE 0 END)) AS SellOrders ,
                                SUM(ABS(CASE WHEN  OC.OrderBuySell = 'Sell' AND OC.SwitchID IS NOT NULL THEN OC.DisplayValue END)) AS SwitchSellOrders

                        FROM    Discovery.dbo.OrderCurrent OC
                                INNER JOIN Discovery.dbo.Batch B ON B.BatchID = OC.BatchID

                                INNER JOIN res_db.dbo.Instruments Inst ON Inst.[Security] = OC.InstrumentCode
                        WHERE
                                B.BatchType IN ( 'Auto', 'One-Off' )
                                

                                /* just like adding the extra line since it clearly shows everything factored into this query */
                                AND OC.Status IN ('Authorised','AuthorisedSwitch','Confirmed','Placed','Pooled','Processing', 'Completed' )
                                AND ( --S.[Open] = 1
                                      OC.Status IN ('Authorised','AuthorisedSwitch','Confirmed','Placed','Pooled','Processing' )

                                      /*  This is why the OrderCurrent ClAccountID index was modified to include these columns 1000-4000 logical IO difference from this */
                                      OR ( OC.[Status] = 'Completed'
                                           AND OC.SettlementStatus NOT IN ( 'Completed', 'NotRequired' )
                                         )
                                    )

                                --AND CE.BatchID IS NULL
                                -- the cashEntry check doesn't apply to Sells
                                AND NOT EXISTS ( SELECT 1 FROM Discovery.dbo.CashEntry CE WHERE OC.BatchID = CE.BatchID AND OC.OrderBuySell = 'Buy' AND CE.Status != 'Completed')

                                -- but ignore conversions
                                AND OC.OrderBuySell = 'Sell'
                                AND OC.ConversionID IS NULL


                                /* not a fan of this, but tried restructuring as a NOT EXISTS
                                    and had detrimental affects to performance.

                                    This bit should only apply to Buys
                                */
                                AND (
                                      OC.OrderBuySell = 'Sell'
                                      /* The compare against 0 was never in here, so meant if you explicitly stated no override
                                        they got excluded.  Written this way to avoid the test since i'm ok with it in this case
                                        BUT don't want the whole file excluded from the test.
                                      */
                                    )
                        GROUP BY OC.ClAccountID ,
                                OC.OrderSettCurrency
                      ) ORD
                    ON ORD.ClAccountID = CLIENTSANDCCY.CLAccountID
                    AND ORD.OrderSettCurrency = CLIENTSANDCCY.CCYCode


            LEFT JOIN ( SELECT  OC.ClAccountID ,
                                OC.OrderSettCurrency ,
                                SUM(CASE WHEN OC.OrderBuySell = 'Buy'
                                         THEN OC.DisplayValue
                                         ELSE 0
                                    END) AS BuyDealsInProgress ,
                                SUM(CASE WHEN OC.OrderBuySell = 'Sell'
                                         THEN OC.DisplayValue
                                         ELSE 0
                                    END) AS SellDealsInProgress ,
                                SUM(CASE WHEN NOT ( OC.SecuritySubType = 'Term Deposit'
                                                    AND OC.Sec_Type = 'Fixed Interest'
                                                    AND OC.[Status] = 'Placed'
                                                  ) THEN OC.DisplayValue
                                         ELSE 0
                                    END) AS DealsInProgress

                        FROM (
                            SELECT
                                OC.ClAccountID ,
                                OC.OrderSettCurrency ,
                                OC.OrderBuySell,
                                OC.Status,
                                OC.DisplayValue,
                                Inst.SecuritySubType,
                                Inst.Sec_Type
                            FROM    Discovery.dbo.OrderCurrent OC
                                    INNER JOIN Discovery.dbo.Batch B ON B.BatchID = OC.BatchID
                                    INNER JOIN res_db.dbo.Instruments Inst ON Inst.[Security] = OC.InstrumentCode
                            WHERE   B.BatchType IN ( 'Auto', 'One-Off' )
                                    AND OC.Status IN ( 'Placed', 'Pooled', 'Authorised')
                                    AND ( ( --S.[InProgress] = 1
                                            OC.Status IN ( 'Placed', 'Pooled' )
                                            OR ( OC.Status = 'Authorised'
                                                 AND OC.PoolOrderID IS NOT NULL
                                               )
                                          )
                                    )
                                    AND OC.ConversionID IS NULL
				    AND NOT (OC.Status = ('Authorised') AND Inst.SecuritySubType IN ('InsuredFund', 'Commercial Property'))

                            UNION ALL

                            SELECT
                                OC.ClAccountID ,
                                OC.OrderSettCurrency ,
                                OC.OrderBuySell,
                                OC.Status,
                                OC.DisplayValue,
                                Inst.SecuritySubType,
                                Inst.Sec_Type
                            FROM    Discovery.dbo.OrderCurrent OC
                                    INNER JOIN Discovery.dbo.Batch B ON B.BatchID = OC.BatchID
                                    INNER JOIN res_db.dbo.Instruments Inst ON Inst.[Security] = OC.InstrumentCode
                                    left outer join Discovery.dbo.CashEntry CE on CE.BatchID = B.BatchID and CE.Status <> 'Completed' AND OC.OrderBuySell = 'Buy'
                            WHERE   B.BatchType IN ( 'Auto', 'One-Off' )
                                    AND OC.Status = ('Authorised')
                                    AND Inst.SecuritySubType IN ('InsuredFund', 'Commercial Property')
                                    and CE.ID is null
                                    AND OC.ConversionID IS NULL

                            UNION ALL


                            SELECT
                                OC.ClAccountID ,
                                OC.OrderSettCurrency ,
                                OC.OrderBuySell,
                                OC.Status,
                                OC.DisplayValue,
                                Inst.SecuritySubType,
                                Inst.Sec_Type
                            FROM    Discovery.dbo.OrderCurrent OC
                                    INNER JOIN Discovery.dbo.Batch B ON B.BatchID = OC.BatchID
                                    INNER JOIN Res_db.dbo.Instruments Inst ON Inst.[Security] = OC.InstrumentCode
                            WHERE   B.BatchType IN ( 'Auto', 'One-Off' )
                                    
                                    AND (  ( OC.Status = 'Completed'
                                               AND OC.SettlementStatus NOT IN ( 'Completed', 'NotRequired' )
                                             )
                                        )
                                    AND OC.ConversionID IS NULL
                            ) OC

                        GROUP BY OC.ClAccountID ,
                                OC.OrderSettCurrency
                      ) DEAL ON DEAL.ClAccountID = CLIENTSANDCCY.CLAccountID
                                AND DEAL.OrderSettCurrency = CLIENTSANDCCY.CCYCode