/*
	Gets the charge processing frequency for the frequency char
*/
CREATE FUNCTION [Charges].[fnConvertFrequencyCharToChargeFrequency] (@FrequencyChar as CHAR(1)) RETURNS VARCHAR(20)
AS
BEGIN
	RETURN CASE 
		    WHEN @FrequencyChar = 'W' THEN 'Weekly'
			WHEN @FrequencyChar = 'M' THEN 'Monthly'
			WHEN @FrequencyChar = 'Q' THEN 'Quarterly'
			WHEN @FrequencyChar = 'A' THEN 'Yearly'
			WHEN @FrequencyChar = 'S' THEN 'HalfYearly'
			ELSE 'Unsupported'
		END
END
GO