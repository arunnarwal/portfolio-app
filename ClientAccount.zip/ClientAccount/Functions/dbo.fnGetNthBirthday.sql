SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE function [dbo].[fnGetNthBirthday]
(@DOB AS datetime,@N as tinyint)

returns datetime

as

begin
	DECLARE @temp datetime
	set @temp = dateadd(year,@N,@DOB)

	IF (datepart(month,@DOB)=2 and datepart(day,@DOB)=29 and @N % 4 <> 0)
		set @temp = dateadd(day,1,@temp)

	RETURN @temp
end
GO
