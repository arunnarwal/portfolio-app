CREATE FUNCTION [dbo].[fnProductValueBaseForDim]
    (
      @AsAt DATETIME,
      @Location VARCHAR(10),
      @Currency CHAR(3),
      @PriceAsAt DATETIME,
      @PortfolioAdjust AS BIT = 0,
      @IncludeRegistry AS BIT = 0
    )
RETURNS TABLE
AS
RETURN

--Declare @AsAt datetime
--Declare @Location varchar(10)
--Declare @Currency char(3)
--Declare @PriceAsAt datetime
--Declare @PortfolioAdjust as bit
--Declare @IncludeRegistry as bit

--SET @AsAt = '2012-07-12'
--SET @Location = 'Custody'
--SET @Currency = 'GBP'
--SET @PriceAsAt = '2012-07-12'
--SET @PortfolioAdjust = 0
--SET @IncludeRegistry = 1


SELECT  Amounts.CLAccountID,
        SUM(Amounts.Amount * COALESCE(fx2.a, 1) / COALESCE(fx1.a, 1)) AS ProductValue,
        SUM(Amounts.AmountChecksUncleared * COALESCE(fx2.a, 1) / COALESCE(fx1.a, 1)) AS ProductValueOfUnclearedCheques
FROM    ( 
		  SELECT    ST.ClAccountID,
                    I.InstrumentCCY AS CCYCode,
                    SUM(ST.Quantity * S.O) AS Amount,
                    0 AS AmountChecksUncleared
          FROM      dbo.ScripTransactions ST
                    INNER JOIN Res_DB.dbo.Instruments I ON ST.InstrumentCode = I.security
                    INNER JOIN Res_DB.dbo.Securities S ON I.security = S.security AND S.Date = @PriceAsAt
          WHERE     ST.AsAt < DATEADD(d, 1, @AsAt)
                    AND ST.TransStatus = 'Settled'
                    AND ( REPLACE(ST.Location, 'BTA', 'Custody') = @Location
                          OR @Location = 'ALL'
                          OR ( @IncludeRegistry = 1 AND ST.Location = 'Registry')
                          OR ( ST.Location = 'Registry'
                               AND I.SecurityType = 'Model'
                               AND I.SecuritySubType = 'Platform Fund'
                             )
                        )
          GROUP BY  ST.ClAccountID, I.InstrumentCCY
          HAVING    SUM(ST.Quantity) <> 0

          UNION ALL
          SELECT    CLT.CLAccountID,
                    RTRIM(CLT.CCYcode) CCYCode,
                    -ROUND(SUM(CLT.Amount), 2) Amount,
                    0 AS AmountChecksUncleared
          FROM      dbo.CashLedgerTransactions CLT
          WHERE     CLT.LedgerDate < DATEADD(d, 1, @AsAt)
          GROUP BY  CLT.CLAccountID, CLT.CCYCode

          UNION ALL
          SELECT    CLA.ClAccountID,
                    RTRIM(CLA.CCYcode) CCYCode,
                    -ROUND(SUM(CLA.Amount), 2) Amount,
                    0 AS AmountChecksUncleared
          FROM      dbo.CashLedgerAdjustments CLA
          WHERE     CLA.LedgerDate < DATEADD(d, 1, @AsAt)
                    AND CLA.PortfolioAdjust = CASE WHEN @PortfolioAdjust = 1
                                               THEN 1
                                               ELSE 0
                                          END
          GROUP BY  CLA.ClAccountID, CLA.CCYCode
          UNION ALL
          SELECT    CLA.ClAccountID,
                    RTRIM(CLA.CCYcode) CCYCode,
                    0 AS Amount,
                    -ROUND(SUM(CLA.Amount), 2) AS AmountChecksUncleared
          FROM      dbo.CashLedgerAdjustments CLA
          WHERE     CLA.LedgerDate > @AsAt
                    AND CLA.AdjustmentType = 'UNCLEARED_CHEQUE'
                    AND CLA.PortfolioAdjust = CASE WHEN @PortfolioAdjust = 1
                                               THEN 1
                                               ELSE 0
                                          END
          GROUP BY  CLA.ClAccountID, CLA.CCYCode
          UNION ALL
          SELECT    CMT.ClAccountID,
                    RTRIM(CMT.currency) CCYCode,
                    ROUND(SUM(CMT.amount), 2) Amount,
                    0 AS AmountChecksUncleared
          FROM      dbo.CMTTrans CMT
          WHERE     CMT.TranDate < DATEADD(d, 1, @AsAt)
          GROUP BY  CMT.ClAccountID, CMT.Currency
          UNION ALL
          SELECT    CT.ClAccountID,
                    RTRIM(CT.CncyCode) CCYCode,
                    ROUND(SUM(CT.amount), 2) Amount,
                    0 AS AmountChecksUncleared
          FROM      dbo.CashTransactions CT
          WHERE     CT.AsAt < DATEADD(d, 1, @AsAt)
                    AND CT.TransStatus <> 'cancelled'
                    AND CT.Location = 'external'
                    AND @Location IN ( 'External', 'All' )
          GROUP BY  CT.ClAccountID, CT.CncyCode
        ) Amounts
        LEFT JOIN Res_DB.dbo.Securities Fx1 ON Fx1.Security = Amounts.CCYCode + 'USD' AND Fx1.date = @PriceAsAt
        LEFT JOIN Res_DB.dbo.Securities Fx2 ON Fx2.Security = @Currency + 'USD' AND Fx2.date = @PriceAsAt
GROUP BY ClAccountID
GO
