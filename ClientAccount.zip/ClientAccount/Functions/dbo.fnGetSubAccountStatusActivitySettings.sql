
CREATE FUNCTION dbo.fnGetSubAccountStatusActivitySettings(@SubAccountId INT, @AccountHierarchyLevelId TINYINT, @Status VarChar(20)) RETURNS TABLE AS RETURN  

    --SET STATISTICS IO ON
    --SET STATISTICS TIME ON
    
    --DECLARE @SubAccountId AS INT
    --DECLARE @AccountHierarchyLevelId AS TINYINT
    --DECLARE @Status AS VarChar(20)

    --SET @SubAccountId = 897549
    --SELECT @AccountHierarchyLevelId = HierarchyLevelId FROM dbo.HierarchyLevels WHERE HierarchyLevelName = 'ClientAccount'
    --SET @Status = 'Active';

    --get head-account status flags
    with AccountStatusActivitySettings AS (

	   SELECT     he.ParentHierarchyEntityId, 
			    he.HierarchyEntityId, 
			    he.HierarchyLevelId, 
			    he.EntityId, 
			    @Status [Status], 
			    asas.[IsAllowedRebates], 
			    asas.[IsAllowedInterestAccrues],
			    asas.[IsAllowedInterestPayments], 
			    asas.[IsAllowedFees], 
			    asas.[IsAllowedFeePayments], 
			    asas.[IsAllowedDeposits], 
			    asas.[IsAllowedWithdrawals], 
			    asas.[IsAllowedBuyOrders], 
			    asas.[IsAllowedSellOrders], 
			    asas.[IsAllowedTransfersIn], 
			    asas.[IsAllowedTransfersOut], 
			    asas.[IsAllowedInterIntraAccountTransfers], 
			    asas.[IsAllowedSippProcessing]
	   FROM dbo.HierarchyEntities he
		  LEFT JOIN dbo.SubAccountStatusActivitySettings asas ON asas.EntityId = he.EntityId AND asas.HierarchyLevelId = he.HierarchyLevelId AND asas.[Status] = @Status
    )
    , hierarchy AS (
		    --first part of the, select the starting point (probably the accounts hierarchy level and entity id)
		    --this code is run once, and the result is passed to the lower part of the union
		  SELECT 
			    asas.HierarchyEntityId, 
			    asas.ParentHierarchyEntityId, 
			    asas.HierarchyLevelId, 
			    asas.EntityId, 
			    asas.[Status], 
			    asas.[IsAllowedRebates], 
			    asas.[IsAllowedInterestAccrues],
			    asas.[IsAllowedInterestPayments], 
			    asas.[IsAllowedFees], 
			    asas.[IsAllowedFeePayments], 
			    asas.[IsAllowedDeposits], 
			    asas.[IsAllowedWithdrawals], 
			    asas.[IsAllowedBuyOrders], 
			    asas.[IsAllowedSellOrders], 
			    asas.[IsAllowedTransfersIn], 
			    asas.[IsAllowedTransfersOut], 
			    asas.[IsAllowedInterIntraAccountTransfers], 
			    asas.[IsAllowedSippProcessing]
		  FROM AccountStatusActivitySettings asas
		  WHERE	asas.EntityId = @SubAccountId 
			 AND asas.HierarchyLevelId = @AccountHierarchyLevelId
     
		  UNION ALL
   
		  SELECT 	he.HierarchyEntityId, 
				he.ParentHierarchyEntityId, 
				he.HierarchyLevelId, 
				he.EntityId, 
				he.[Status], 
				ISNULL(x.[IsAllowedRebates], he.[IsAllowedRebates]) [IsAllowedRebates],
				ISNULL(x.[IsAllowedInterestAccrues], he.[IsAllowedInterestAccrues]) [IsAllowedInterestAccrues],
				ISNULL(x.[IsAllowedInterestPayments], he.[IsAllowedInterestPayments]) [IsAllowedInterestPayments],
				ISNULL(x.[IsAllowedFees], he.[IsAllowedFees]) [IsAllowedFees],
				ISNULL(x.[IsAllowedFeePayments], he.[IsAllowedFeePayments]) [IsAllowedFeePayments],
				ISNULL(x.[IsAllowedDeposits], he.[IsAllowedDeposits]) [IsAllowedDeposits],
				ISNULL(x.[IsAllowedWithdrawals], he.[IsAllowedWithdrawals]) [IsAllowedWithdrawals],
				ISNULL(x.[IsAllowedBuyOrders], he.[IsAllowedBuyOrders]) [IsAllowedBuyOrders],
				ISNULL(x.[IsAllowedSellOrders], he.[IsAllowedSellOrders]) [IsAllowedSellOrders],
				ISNULL(x.[IsAllowedTransfersIn], he.[IsAllowedTransfersIn]) [IsAllowedTransfersIn],
				ISNULL(x.[IsAllowedTransfersOut], he.[IsAllowedTransfersOut]) [IsAllowedTransfersOut],
				ISNULL(x.[IsAllowedInterIntraAccountTransfers], he.[IsAllowedInterIntraAccountTransfers]) [IsAllowedInterIntraAccountTransfers],
				ISNULL(x.[IsAllowedSippProcessing], he.[IsAllowedSippProcessing]) [IsAllowedSippProcessing]
		  FROM AccountStatusActivitySettings he
			 INNER JOIN hierarchy x ON x.ParentHierarchyEntityId = he.HierarchyEntityId AND x.[Status] = he.[Status]
    ) 

    SELECT IsAllowedRebates, IsAllowedInterestAccrues, IsAllowedInterestPayments, IsAllowedFees, IsAllowedFeePayments, IsAllowedDeposits, IsAllowedWithdrawals, IsAllowedBuyOrders, IsAllowedSellOrders, IsAllowedTransfersIn, IsAllowedTransfersOut, IsAllowedInterIntraAccountTransfers, IsAllowedSippProcessing
    FROM hierarchy
    WHERE ParentHierarchyEntityId IS NULL

GO


