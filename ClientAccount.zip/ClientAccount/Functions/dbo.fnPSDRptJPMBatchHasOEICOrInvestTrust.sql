SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE FUNCTION [dbo].[fnPSDRptJPMBatchHasOEICOrInvestTrust]() RETURNS TABLE AS

RETURN 

SELECT 

OC.BatchID, 1 AS HasOEICOrInvestTrust, SUM(COALESCE(DisplayValueExComm, DisplayValue)) AS OEICAndInvestTrustBatchTotal  

FROM Discovery..OrderCurrent OC

INNER JOIN Res_Db..ManagedFunds MF

ON OC.InstrumentCode = MF.InstrumentCode 

INNER JOIN Res_Db..Instruments INS

ON OC.Instrumentcode = INS.Security 

WHERE (INS.SecuritySubType = 'Invest Trust' OR MF.UnitTrustOEIC = 'OEIC')

GROUP BY OC.BatchID
GO
