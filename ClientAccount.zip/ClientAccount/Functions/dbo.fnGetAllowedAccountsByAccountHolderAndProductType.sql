CREATE FUNCTION [dbo].[fnGetAllowedAccountsByAccountHolderAndProductType]
    (
      @userID INTEGER,
      @firstName VARCHAR(50),
      @surname VARCHAR(50),
      @DateOfBirth Date,
      @productType VARCHAR(10) = NULL
    )
RETURNS @Result TABLE
    (
      AccountType VARCHAR(50),
      ClAccountId VARCHAR(50),
      AdvCode VARCHAR(20),
      AdvisorName VARCHAR(100),
      Company VARCHAR(50),
      SearchKey VARCHAR(100),
      AccountName VARCHAR(100),
      DPSAccountType VARCHAR(50),
      Status VARCHAR(50),
      ClientType VARCHAR(50),
      WrapProvider VARCHAR(50),
      SubAccountType VARCHAR(50),
      InvestorType VARCHAR(50),
      ProductType VARCHAR(50),
      IsPlatformFund TINYINT,
      PortfolioId INT,
      ProductDisplayName VARCHAR(100),
      CompanyName VARCHAR(250),
      [ReadWrite] INT,
      StopProcessing INT
    )
AS BEGIN

    IF @firstName IS NULL 
        BEGIN 
            SET @firstName = '%'
        END 

    IF @surname IS NULL 
        BEGIN
            SET @surname = '%'
        END 

    DECLARE @Accounts TABLE
        (
          accountid VARCHAR(50) PRIMARY KEY CLUSTERED,
          [ReadWrite] INT
        )

    INSERT  INTO @Accounts ( accountId, ReadWrite )
            SELECT DISTINCT
                    aa.claccountid,
                    ReadWrite
            FROM    clientaccount..vwAllowedAccounts AA
                    INNER JOIN clientaccount..accountholders AH ON AH.ClAccountID = AA.ClAccountID
                                                                   AND ah.given LIKE '%' + @firstName + '%'
                                                                   AND ah.Surname LIKE '%' + @surname + '%'
                                                                   AND ( ah.dateofbirth = @dateOfBirth
                                                                         OR @dateOfBirth = '1 jan 1900'
                                                                       )
                    INNER JOIN [ClientAccount].dbo.[vwSubAccount] SA ON SA.ClAccountID = AA.ClAccountID
                                                                        AND (@productType IS NULL  OR SA.ProductType = @productType)
            WHERE   AA.CLIENTID = @UserID 

    INSERT  INTO @Result
            (
              AccountType,
              ClAccountId,
              AdvCode,
              AdvisorName,
              Company,
              SearchKey,
              AccountName,
              DPSAccountType,
              [Status],
              ClientType,
              WrapProvider,
              SubAccountType,
              InvestorType,
              ProductType,
              IsPlatformFund,
              PortfolioId,
              ProductDisplayName,
              CompanyName,
              ReadWrite,
              StopProcessing
            )
            SELECT  seca.accountType,
                    SECA.ClAccountId,
                    SECA.PrimaryAdviser AS AdvCode,
                    Adv.Name AS AdvisorName,
                    CD.Company,
                    SECA.SearchKey,
                    SECA.AccountName,
                    CA.DPSAccountType,
                    CA.Status,
                    CD.InvestorType AS ClientType,
                    CO.WrapProvider,
                    CA.SubAccountType,
                    CD.InvestorType,
                    PD.ProductType,
                    PD.IsPlatformFund,
                    CA.PortfolioId,
                    PD.ProductDisplayName,
                    CO.CompanyName,
                    AA.ReadWrite,
                    CASP.StopProcessing
            FROM    @Accounts AA
                    INNER JOIN clientaccount.dbo.SeClientAccount SECA ON SECA.claccountId = AA.AccountId
                    INNER JOIN clientaccount.dbo.ClientDetails CD ON CD.claccountId = AA.AccountId
                    INNER JOIN Discovery.dbo.ClientAccount CA ON CA.claccountId = AA.AccountId
                    INNER JOIN Discovery.dbo.ProductDetails PD ON PD.claccountId = AA.AccountId
                    INNER JOIN clientaccount.dbo.advisor ADV ON ADV.AdvCode = SECA.PrimaryAdviser
                    INNER JOIN clientaccount.dbo.Company CO ON CO.Company = ADV.Company
                    LEFT JOIN ClientAccount.dbo.vwClientAccountsWithStopProcessing CASP ON CASP.claccountid = AA.accountid
    RETURN
   END
GO