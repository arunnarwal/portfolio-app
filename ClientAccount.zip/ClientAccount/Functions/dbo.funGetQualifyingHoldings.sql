SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE FUNCTION [dbo].[funGetQualifyingHoldings]()
RETURNS TABLE
AS
RETURN


SELECT CorpActID,ST.InstrumentCode,WraPProvider,count(st.claccountid) as TotalClients,Sum(Quantity) as TotalQuantity
FROM ClientAccount.dbo.ScripTransactions ST
inner join clientaccount..clientdetails CA
ON St.ClAccountid = ca.claccountid
inner join clientaccount..company CO
ON CA.Company = CO.Company
inner join corporateactions..corporateaction COR
ON ST.InstrumentCode = COR.InstrumentCode
WHERE (TransStatus = 'Settled') 
and location = 'custody' 
and ST.AsAt <= COR.ExDate
GROUP BY St.instrumentcode,wrapprovider,CorpActID
HAVING Sum(Quantity) <> 0
GO
