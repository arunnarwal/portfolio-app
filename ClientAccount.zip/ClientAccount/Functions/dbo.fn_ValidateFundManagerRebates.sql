

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[fn_ValidateFundManagerRebates]()
RETURNS @valTable TABLE
([Type] varchar(10),[Message] varchar(100),DBName varchar(100),DBTable varchar(100), [Owner] varchar(100), SiteOwner varchar(100))
AS
BEGIN
	
IF (
SELECT COUNT(*) FROM (
SELECT -1 * SUM(Amount) as Sum,ABS(Amount) as Amount,ClAccountId,LedgerDate as Asat
FROM dbo.CashLedgerTransactions 
WHERE  Narrative like '%Fund Management Rebate%'
GROUP BY LedgerDate,ClAccountId,ABS(Amount)) a
INNER JOIN 
(SELECT ClAccountId, AsAt,SUM(Amount) as Sum,ABS(Amount) as Amount 
FROM Discovery.dbo.Rebate 
WHERE  Narration like '%Fund Management Rebate%'
GROUP BY ClAccountId,AsAt,ABS(Amount)) b
ON a.ClaccountId = b.ClaccountId 
AND a.Asat = b.Asat
AND a.Amount = b.Amount
AND a.Sum <> b.Sum
AND (a.ClaccountId like 'el%' OR a.ClaccountId like 'ax%'))  > 0
BEGIN 
	BEGIN
		INSERT INTO @valTable(type, message, DBName, DBTable, owner, SiteOwner)
		VALUES ('Error', 'There is Mismatch fundmanager rebates','clientaccount', 'cashledgertransactions','Chris Doyle', 'AXA')
	END
END

return 

END
GO
