

CREATE FUNCTION [dbo].[fn_GetCommissionReportDetailsWithSplitIsas]
(
-- Add the parameters for the function here
@periodStart datetime,
@periodEnd datetime,
@WrapProvider varchar(20)
)
RETURNS TABLE
AS
RETURN
(
--Declare @PeriodStart as datetime
--Declare @PeriodEnd as datetime
--Declare @WrapProvider varchar(20)
--set @PeriodStart='01 Oct 2011'
--set @PeriodEnd='01 Oct 2012'
--Set @wrapprovider ='AXA'
select CPH.ClAccountId as ClAccountId,

CASE WHEN SECA.InvestorType = 'INDIVIDUAL'
		THEN 'Individual'
	WHEN SECA.InvestorType = 'INDIVID'
		THEN 'Individual'
	WHEN SECA.InvestorType = 'JOINT'
		THEN 'Joint'
	WHEN SECA.InvestorType = 'JOINT_INDIVIDUAL'
		THEN 'Joint'
	WHEN SECA.InvestorType = 'Trust'
		THEN 'Trust'
	WHEN SECA.InvestorType = 'Consolidated'
		THEN 'Consolidated'
	ELSE 'Third Party'
END
			as accounttype,
AH.IRDNo as NINO,
HBA.Company as CompanyCode,
HBA.CompanyName as CompanyName,
HBA.Advcode as AdvisorCode,
HBA.AdviserName as AdvisorName,
HBA.BranchId as BranchCode,
HBA.Branch as BranchName,
HBA.Network as NetworkCode,
HBA.NetworkName as NetworkName,
HBA.SubCompanyName as Region,
CASE 
WHEN CD.FeeStructure = 'Bundled' THEN 'Composite'
WHEN CD.FeeStructure = 'UnBundled' THEN 'Explicit'
ELSE CD.FeeStructure
END as feestructure,
--PersonalPortfolio (GIA)
COALESCE(CPH.Ppic,0) AS GIAInitialCommission,
COALESCE(CPH.PPFBRCCharge,0)AS GIAAdvisorRegularRemuneration,
COALESCE(CPH.PPAdvisorFBRCCharge,0)AS GIAAdvisorStandardRegularRemuneration,
COALESCE(CPH.PPAdHocCommission,0)AS GIAAdhocCommission,
COALESCE(CPH.Ppsic,0)AS GIASwitchCommission,
COALESCE(CPH.Ppdfmic,0) AS GIAInitialCommission_DFM,
(COALESCE(CPH.PPDFMFixedCharge,0) + COALESCE(CPH.PPDFMTieredCharge,0)) AS GIAOngoingCommission_DFM,
COALESCE(CPH.PPRegularInitialAdvisorCharge,0) as GIARegularInitialAdvisorCharge,

--ISA
COALESCE(CPH.CashISAIC,0)AS CashISAInitialCommission,
COALESCE(CPH.CashISAFBRCCharge,0)AS CashISAAdvisorRegularRemuneration,
COALESCE(CPH.CashISAAdvisorFBRCCharge,0)AS CashISAAdvisorStandardRegularRemuneration,
COALESCE(CPH.CashISAAdHocCommission,0)AS CashISAAdhocCommission,
COALESCE(CPH.CashISASIC,0)AS CashISASwitchCommission,
COALESCE(CPH.CashISADFMIC,0)AS CashISAInitialCommission_DFM,
(COALESCE(CPH.CashISADFMFixedCharge,0) + COALESCE(CPH.CashISADFMTieredCharge,0)) AS CashISAOngoingCommission_DFM,
COALESCE(CPH.CashISARegularInitialAdvisorCharge,0) as CashISARegularInitialAdvisorCharge,

--Stocks Shares Isa
COALESCE(CPH.Ssisaic,0)AS SSISAInitialCommission,
COALESCE(CPH.SSISAFBRCCharge,0)AS SSISAAdvisorRegularRemuneration,
COALESCE(CPH.SSISAAdvisorFBRCCharge,0)AS SSISAAdvisorStandardRegularRemuneration,
COALESCE(CPH.SSISAAdHocCommission,0)AS SSISAAdhocCommission,
COALESCE(CPH.Ssisasic,0)AS SSISASwitchCommission,
COALESCE(CPH.Ssisadfmic,0)AS SSISAInitialCommission_DFM,
(COALESCE(CPH.SSISADFMFixedCharge,0) + COALESCE(CPH.SSISADFMTieredCharge,0)) AS SSISAOngoingCommission_DFM,
COALESCE(CPH.SSISARegularInitialAdvisorCharge,0) as SSISARegularInitialAdvisorCharge,

--SIPP (PIA)
COALESCE(CPH.Sippic,0)AS PIAInitialCommission,
COALESCE(CPH.SIPPFBRCCharge,0)AS PIAAdvisorRegularRemuneration,
COALESCE(CPH.SIPPAdvisorFBRCCharge,0)AS PIAAdvisorStandardRegularRemuneration,
COALESCE(CPH.SIPPAdHocCommission,0)AS PIAAdhocCommission,
COALESCE(CPH.Sippsic,0)AS PIASwitchCommission,
COALESCE(CPH.Bceic,0)AS BenefitEventCrystalisationCommission,
COALESCE(CPH.Sippdfmic,0)AS PIAInitialCommission_DFM,
(COALESCE(CPH.SIPPDFMFixedCharge,0)+ COALESCE(CPH.SIPPDFMTieredCharge,0)) AS PIAOngoingCommission_DFM,
COALESCE(CPH.SIPPRegularInitialAdvisorCharge,0) as PIARegularInitialAdvisorCharge,

--Total
COALESCE(CPH.WRAPCASHAdHocCommission,0)as WrapCashAdhocCommission,

COALESCE(CPH.Ppic,0) + COALESCE(CPH.Ssisaic,0) + COALESCE(CPH.CashISAIC,0) + COALESCE(CPH.Sippic,0) as TOTALInitialCommission,
COALESCE(CPH.PPFBRCCharge,0) + COALESCE(CPH.SSISAFBRCCharge,0) + COALESCE(CPH.CashISAFBRCCharge,0) + COALESCE(CPH.SIPPFBRCCharge,0) as TOTALAdvisorRegularRemuneration,
COALESCE(CPH.PPAdvisorFBRCCharge,0) + COALESCE(CPH.SSISAAdvisorFBRCCharge ,0) + COALESCE(CPH.CashISAAdvisorFBRCCharge ,0) + COALESCE(CPH.SIPPAdvisorFBRCCharge,0) as TOTALAdvisorStandardRegularRemuneration,
COALESCE(CPH.PPAdHocCommission,0) + COALESCE(CPH.SSISAAdHocCommission,0) + COALESCE(CPH.CashISAAdHocCommission,0) + COALESCE(CPH.SIPPAdHocCommission,0) + COALESCE(CPH.WRAPCASHAdHocCommission,0) as TOTALAdhocCommission,
COALESCE(CPH.Ppsic,0) + COALESCE(CPH.Ssisasic,0) + COALESCE(CPH.CashISASIC,0) + COALESCE(CPH.Sippsic,0) as TOTALSwitchCommission,
COALESCE(CPH.Ppdfmic,0) + COALESCE(CPH.Ssisadfmic,0) + COALESCE(CPH.CashISADFMIC,0) + COALESCE(CPH.Sippdfmic,0) as TOTALInitialCommission_DFM,
COALESCE(CPH.PPRegularInitialAdvisorCharge,0) + COALESCE(CPH.SSISARegularInitialAdvisorCharge,0) + COALESCE(CPH.CashISARegularInitialAdvisorCharge,0) + COALESCE(CPH.SIPPRegularInitialAdvisorCharge,0) as TOTALRegularInitialAdvisorCharge,

COALESCE(CPH.PPDFMFixedCharge,0) + 
COALESCE(CPH.PPDFMTieredCharge,0) + 
COALESCE(CPH.SSISADFMFixedCharge,0) + 
COALESCE(CPH.CashISADFMFixedCharge,0) + 
COALESCE(CPH.SSISADFMTieredCharge,0) + 
COALESCE(CPH.CashISADFMTieredCharge,0) +
COALESCE(CPH.SIPPDFMFixedCharge,0) + 
COALESCE(CPH.SIPPDFMTieredCharge,0) as TOTALOngoingCommission_DFM,
--PP Volumes
COALESCE(CPH.PPNewCash,0) as GIANewCash,
COALESCE(CPH.PPReregAmount,0) as GIAReReg,
COALESCE(CPH.PPAverageFundsUnderManagement,0) as GIAAveregeFUM,
COALESCE(CPH.PPTotalDailyFundsUnderManagement,0) as GIATotalDailyFUM,
COALESCE(CPH.PPSwitchAmounts,0) as GIASwitchedFunds,
COALESCE(CPH.PPRegularPaymentsIn,0) as GIATotalRegularPremiums,
COALESCE(CPH.CashISANewCash,0) as CashISANewCash,
COALESCE(CPH.CashISAReregAmount,0) as CashISAReReg,
COALESCE(CPH.CashISAAverageFundsUnderManagement,0) as CashISAAveregeFUM,
COALESCE(CPH.CashISATotalDailyFundsUnderManagement,0) as CashISATotalDailyFUM,
COALESCE(CPH.CashISASwitchAmounts,0) as CashISASwitchedFunds,
COALESCE(CPH.CashISARegularPaymentsIn,0) as CashISATotalRegularPremiums,
COALESCE(CPH.SSISANewCash,0) as SSISANewCash,
COALESCE(CPH.SSISAReregAmount,0) as SSISAReReg,
COALESCE(CPH.SSISAAverageFundsUnderManagement,0) as SSISAAveregeFUM,
COALESCE(CPH.SSISATotalDailyFundsUnderManagement,0) as SSISATotalDailyFUM,
COALESCE(CPH.SSISASwitchAmounts,0) as SSISASwitchedFunds,
COALESCE(CPH.SSISARegularPaymentsIn,0) as SSISATotalRegularPremiums,
COALESCE(CPH.SIPPNewCash,0) as PIANewCash,
COALESCE(CPH.SIPPReregAmount,0) as PIAReReg,
COALESCE(CPH.SIPPAverageFundsUnderManagement,0) as PIAAveregeFUM,
COALESCE(CPH.SIPPTotalDailyFundsUnderManagement,0) as PIATotalDailyFUM,
COALESCE(CPH.SIPPSwitchAmounts,0) as PIASwitchedFunds,
COALESCE(CPH.SIPPCrystalisedAmount,0) as PIAcrystalised,
COALESCE(CPH.SIPPRegularPaymentsIn,0) as PIATotalRegularPremiums,
COALESCE(CPH.WRAPCASHNewCash,0) as NewWrapCash,
COALESCE(CPH.WRAPCASHAverageFundsUnderManagement,0) as AverageWrapCashFUM,
COALESCE(CPH.WRAPCASHTotalDailyFundsUnderManagement,0) as WrapCashTotalDailyFUM,
COALESCE(CPH.WRAPCASHRegularPaymentsIn,0) as WrapCashTotalRegularPremiums,

(SELECT PD.AdviceType FROM Discovery.dbo.ProductDetails PD WHERE PD.ClAccountId = CPH.SIPPSubClAccountId) as PIAAdviceType,
(SELECT PD.AdviceType FROM Discovery.dbo.ProductDetails PD WHERE PD.ClAccountId = CPH.CashISASubClAccountId) as CASHAdviceType,
(SELECT PD.AdviceType FROM Discovery.dbo.ProductDetails PD WHERE PD.ClAccountId = CPH.SSISASubClAccountId) as SSISAAdviceType,
(SELECT PD.AdviceType FROM Discovery.dbo.ProductDetails PD WHERE PD.ClAccountId = CPH.PPSubClAccountId) as GIAAdviceType,
(SELECT FS.Frequency FROM dbo.FeeStanding FS WHERE FS.ClaccountId = CPH.SIPPSubClAccountId AND Id IN (SELECT MAX(Id) FROM dbo.FeeStanding WHERE TranType = 'RIAC' GROUP BY ClaccountId)) as PIARIACFrequency,
(SELECT FS.Frequency FROM dbo.FeeStanding FS WHERE FS.ClaccountId = CPH.CashISASubClAccountId AND Id IN (SELECT MAX(Id) FROM dbo.FeeStanding WHERE TranType = 'RIAC' GROUP BY ClaccountId)) as CashISARIACFrequency,
(SELECT FS.Frequency FROM dbo.FeeStanding FS WHERE FS.ClaccountId = CPH.SSISASubClAccountId AND Id IN (SELECT MAX(Id) FROM dbo.FeeStanding WHERE TranType = 'RIAC' GROUP BY ClaccountId)) as SSISARIACFrequency,
(SELECT FS.Frequency FROM dbo.FeeStanding FS WHERE FS.ClaccountId = CPH.PPSubClAccountId AND Id IN (SELECT MAX(Id) FROM dbo.FeeStanding WHERE TranType = 'RIAC' GROUP BY ClaccountId)) as GIARIACFrequency,
(SELECT (IsNull(Cast(FS.MaxPayOutCount as Integer),0) - IsNull(Cast(FS.PayOutCount as Integer),0) - IsNull(Cast(FS.FailedPayOutCount as Integer),0)) FROM dbo.FeeStanding FS WHERE FS.ClaccountId = CPH.PPSubClAccountId AND Id IN (SELECT MAX(FE.Id) FROM dbo.FeeStanding FE WHERE FE.TranType = 'RIAC' GROUP BY FE.ClaccountId)) as GIARIACOutStandingDeductions,
(SELECT (IsNull(Cast(FS.MaxPayOutCount as Integer),0) - IsNull(Cast(FS.PayOutCount as Integer),0) - IsNull(Cast(FS.FailedPayOutCount as Integer),0)) FROM dbo.FeeStanding FS WHERE FS.ClaccountId = CPH.CashISASubClAccountId AND Id IN (SELECT MAX(FE.Id) FROM dbo.FeeStanding FE WHERE FE.TranType = 'RIAC' GROUP BY FE.ClaccountId)) as CashISARIAOutStandingDeductions,
(SELECT (IsNull(Cast(FS.MaxPayOutCount as Integer),0) - IsNull(Cast(FS.PayOutCount as Integer),0) - IsNull(Cast(FS.FailedPayOutCount as Integer),0)) FROM dbo.FeeStanding FS WHERE FS.ClaccountId = CPH.SSISASubClAccountId AND Id IN (SELECT MAX(FE.Id) FROM dbo.FeeStanding FE WHERE FE.TranType = 'RIAC' GROUP BY FE.ClaccountId)) as SSISARIAROutStandingDeductions,
(SELECT (IsNull(Cast(FS.MaxPayOutCount as Integer),0) - IsNull(Cast(FS.PayOutCount as Integer),0) - IsNull(Cast(FS.FailedPayOutCount as Integer),0)) FROM dbo.FeeStanding FS WHERE FS.ClaccountId = CPH.SIPPSubClAccountId AND Id IN (SELECT MAX(FE.Id) FROM dbo.FeeStanding FE WHERE FE.TranType = 'RIAC' GROUP BY FE.ClaccountId)) as SIPPRiaROutStandingDeductions,

CASE WHEN CD.InvestorType NOT IN ('Individ', 'Joint', 'Consolidated', 'Trust')
THEN 'Third Party'
ELSE CD.InvestorType
END as InvestorType
FROM dbo.fn_GetCommissionByPeriodByHeadAccountWithSplitIsas(@PeriodStart,@PeriodEnd) CPH
INNER JOIN dbo.SEClientAccount as SECA
ON CPH.ClaccountId=SECA.ClaccountId
INNER JOIN dbo.AccountHolders as AH
ON CPH.ClaccountId = AH.ClaccountId AND AH.Holdernumber = 1
INNER JOIN dbo.[vwHierarchyByAdvisor] as HBA
ON HBA.AdvCode=SECA.PrimaryAdviser
INNER JOIN dbo.ClientDetails as CD 
ON CD.ClaccountId=CPH.ClaccountId 
WHERE HBA.WrapProvider=@wrapprovider
)
GO
