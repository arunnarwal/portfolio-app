SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE FUNCTION [dbo].[fnPSDRptJPMFirstMatchedCashEntry]( @FromDate datetime, @ToDate datetime ) RETURNS TABLE AS

RETURN 

SELECT CE.ID, CE.ClAccountID, CE.BatchID, FirstCE.DateCompleted as FirstCEDateCompleted FROM Discovery..CashEntry CE

INNER JOIN 

(

SELECT CE.ClAccountID,MIN(CE.DateCompleted) AS DateCompleted 

FROM Discovery..CashEntry CE 

WHERE CE.Status = 'Completed' AND [TYPE] = 'Deposit'

GROUP BY CE.ClAccountID 

) FirstCE

ON CE.ClAccountID = FirstCE.ClAccountID AND CE.DateCompleted = FirstCE.DateCompleted AND FirstCE.DateCompleted >= @FromDate AND FirstCE.DateCompleted <= @ToDate
GO
