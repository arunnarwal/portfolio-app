SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO

CREATE FUNCTION [dbo].[fnLatestNonInsuredFundFixedFee](@asAt as DateTime) RETURNS TABLE AS

RETURN

WITH LatestNIFFF AS
(
	SELECT WrapProvider, ProductType, MAX(AsAt) AS AsAt FROM ClientAccount..NonInsuredFundFixedFee
	WHERE AsAt <= @asAt
	GROUP BY WrapProvider, ProductType
)

SELECT 
	NIFFF.ID,
	NIFFF.WrapProvider,
	NIFFF.ProductType,
	NIFFF.Amount,
	NIFFF.UserCreated,
	NIFFF.DateCreated,
	NIFFF.AsAt
FROM ClientAccount..NonInsuredFundFixedFee AS NIFFF
INNER JOIN LatestNIFFF
	ON NIFFF.WrapProvider = LatestNIFFF.WrapProvider 
	AND NIFFF.ProductType = LatestNIFFF.ProductType
	AND NIFFF.AsAt = LatestNIFFF.AsAt

GO
