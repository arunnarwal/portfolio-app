/*
<Function>
    <Description>Returns data for "Subscription details SnS ISA" and "Subscription details Cash ISA" sheets of ISA 14a Report.</Description>
    <Parameters>
        <Parameter Name="@TaxYear">
            <Description>Tax year in which we want to return data.</Description>
        </Parameter>
        <Parameter Name="@IncludeIsa">
            <Description>Flag to include ISA sub-account holdings.</Description>
        </Parameter>
        <Parameter Name="@IncludeJisa">
            <Description>Flag to include JISA sub-account holdings.</Description>
        </Parameter>
        <Parameter Name="@ProductType">
            <Description>ProductType of which we want to retrieve data. Should be "Stocks/Shares" or "Cash".</Description>
        </Parameter>
    </Parameters>
</Function>
*/

CREATE FUNCTION [dbo].[fnIsa14aReportSubscription] (@TaxYear INT, @IncludeIsa BIT, @IncludeJisa BIT, @ProductType VARCHAR(20))
RETURNS TABLE 
AS
RETURN	

/*
DECLARE @TaxYear AS INT;
DECLARE @IncludeIsa as BIT;
DECLARE @IncludeJisa as BIT;
DECLARE @ProductType AS VARCHAR(20)
SET @IncludeIsa = 1;
SET @IncludeJisa = 1;
SET @TaxYear = 2017
SET @ProductType = 'Stocks/Shares'
*/

WITH PrimaryAccountHolder
(
	ClAccountID,
	HolderNumber
) AS (
	SELECT
		ClAccountID,
		MIN(HolderNumber)
	FROM
		dbo.AccountHolders
	GROUP BY
		ClAccountID
),

IsaDeposits
(
ClAccountId,
Amount
) AS (
	SELECT 
		ClAccountId,
		SUM(Amount) AS Amount
	FROM
		Discovery.dbo.vwISASubscriptions
	WHERE
		Type = 'Deposit' AND
		TaxYear = @TaxYear - 1 AND
		ProductType = @ProductType
	GROUP BY
		ClAccountID
),

IsaWithdrawals
(
	ClAccountId,
	Amount
) AS (
	SELECT 
		ClAccountId,
		SUM(Amount) AS Amount
	FROM
		Discovery.dbo.vwISASubscriptions
	WHERE
		Type = 'Withdrawal' AND
		TaxYear = @TaxYear - 1 AND
		ProductType = @ProductType
	GROUP BY
		ClAccountID
),

Subscription
(
	ClAccountID,
	Value
) AS (
	SELECT
		COALESCE(ID.ClAccountId, IW.ClAccountId),
		CASE
			WHEN COALESCE(IRA.IsFlexiIsaAllowed, 0) = 1 THEN
				ISNULL(ID.Amount, 0) - ISNULL(IW.Amount, 0)
			ELSE ID.Amount
		END AS Value
	FROM
		IsaDeposits ID
		LEFT JOIN IsaWithdrawals IW
		ON ID.ClAccountId = IW.ClAccountId
		LEFT JOIN ProductWrapper.vwIsaReportableAccounts IRA
		ON ID.ClAccountId = IRA.ClAccountId
)

SELECT
	CONVERT(VARCHAR(20), S.ClAccountID) AS ClAccountID,
	CASE
		WHEN CONVERT(NUMERIC(28, 8), S.Value) < 0 THEN 0
		ELSE CONVERT(NUMERIC(28, 8), S.Value)
	END AS Value,
	AH.Given AS Name,
	AH.Surname AS Surname
FROM
	Subscription S
	LEFT JOIN Discovery.dbo.ClientAccount AS CA ON CA.ClAccountID = S.ClAccountId
	LEFT JOIN dbo.fnHeadAccounts() AS HA ON HA.ClAccountID = CA.ClAccountID
    INNER JOIN dbo.ClientDetails AS CD ON CD.ClAccountId = HA.HeadClAccountID
	LEFT JOIN PrimaryAccountHolder AS PAH ON PAH.ClAccountID = HA.HeadClAccountID
	LEFT JOIN dbo.AccountHolders AS AH ON AH.ClAccountID = PAH.ClAccountID AND AH.HolderNumber = PAH.HolderNumber
WHERE
	((@IncludeIsa = 1 AND CD.IsJuniorAccount = 0) OR (@IncludeJisa = 1 AND CD.IsJuniorAccount = 1)) AND
	CA.SubAccountType = 'ISA'
