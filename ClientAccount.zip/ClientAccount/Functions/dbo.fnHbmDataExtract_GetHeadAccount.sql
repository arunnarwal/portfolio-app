


CREATE FUNCTION [dbo].[fnHbmDataExtract_GetHeadAccount] ()
Returns @outputTable Table (
	Claccountid varchar(20),
	Accountname varchar(100),
	DateCreated datetime,
	[Status]  varchar(30),
	ActivationDate datetime,
	AmlStatus  varchar(30),
	SanctionStatus  varchar(30),
	PepStatus  varchar(30),
	AdviserName  varchar(100),
	AdviserFcaNumber  varchar(30),
	CompanyName  varchar(100),
	CompanyFcaNumber  varchar(30),
	NetworkName  varchar(100),
	NetworkFcaNumber  varchar(30),
	ProviderName  varchar(100),
	AdviserInitialAmt decimal(18,2),
	AdviserInitialPercent decimal(18,2),
	AdviserOngoingAmt decimal(18,2),
	AdviserOngoingPercent decimal(18,2),
	AdviserOngoingFrequency varchar(1),
	AdviserOngoingNextPaymentDate datetime,
	ProviderAnnualFeePercent  decimal(18,2),
	ProviderAnnualFeeAmount  decimal(18,2),
	DateOfBirth datetime,
	RetirementDate datetime,
	CrystallisationStatus  varchar(30),
	IrdNo varchar(20),
	MigrationReference varchar(50),
	AdviserFCAAuthStatus varchar(50),
	CompanyFCAAuthStatus varchar(50),
	NetworkFCAAuthStatus varchar(50),
	AnnualStatementDate datetime) 
AS
begin


DECLARE @accounts TABLE (Claccountid VARCHAR(20))
DECLARE @WrapProvider as VarChar(20)
SET @wrapProvider = 'HBM' 
INSERT INTO @accounts(claccountid) SELECT Claccountid FROM dbo.vwClAccountID WHERE WrapProvider = @wrapProvider and DpsAccountType = 'Account'

DECLARE @crystallisedaccounts TABLE (Claccountid VARCHAR(20))
INSERT INTO @crystallisedaccounts(Claccountid) 
SELECT C.ClAccountID from dbo.vwClAccountID A 
	INNER JOIN Discovery.dbo.ProductDetails B on A.ClAccountiD = B.ClAccountiD
	INNER JOIN dbo.Consolidate C on C.SubClAccountID = A.ClAccountID
 where A.WrapProvider = @wrapProvider and A.DpsAccountType = 'Sub-Account' and B.ArrangementType = 'Crystallised'
 and C.ClAccountiD <> C.SubClAccountID

declare @chargeTerms table (Company VARCHAR(20),InitialAdvisorCharge decimal(18,2),AdvisorOngoingCharge decimal(18,2),ProviderCharge decimal(18,2))

INSERT INTO @chargeTerms(Company,InitialAdvisorCharge,AdvisorOngoingCharge,ProviderCharge)
SELECT Company,max(InitialAdvisorCharge) InitialAdvisorCharge,max(AdvisorOngoingCharge) AdvisorOngoingCharge,max(ProviderCharge) ProviderCharge FROM (
SELECT Company, [Default] as InitialAdvisorCharge,0 as AdvisorOngoingCharge,0  as ProviderCharge
FROM dbo.vwProductTermByCompany T WHERE Termtype in ('Initial Advisor Charge') 
and Product = 'SIPP' and [Status] = 'Current' and Feestructure = 'Unbundled' and T.WrapProvider = @wrapProvider
UNION
SELECT Company, 0 as InitialAdvisorCharge,[Default] as AdvisorOngoingCharge,0  as ProviderCharge
from dbo.vwProductTermByCompany T WHERE Termtype in ('Advisor Ongoing Charge') 
and Product = 'SIPP' and [Status] = 'Current' and Feestructure = 'Unbundled' and T.WrapProvider = @wrapProvider
UNION
SELECT Company, 0 as InitialAdvisorCharge,0 as AdvisorOngoingCharge,[Default]  as ProviderCharge
FROM dbo.vwProductTermByCompany T WHERE Termtype in ('Ongoing Provider Charge') 
and Product = 'SIPP' and [Status] = 'Current' and Feestructure = 'Unbundled' and T.WrapProvider = @wrapProvider) x
GROUP BY x.Company


INSERT INTO @outputTable(
	Claccountid,
	Accountname,
	DateCreated,
	[Status],
	ActivationDate,
	AmlStatus,
	SanctionStatus,
	PepStatus,
	AdviserName,
	AdviserFcaNumber,
	CompanyName,
	CompanyFcaNumber,
	NetworkName,
	NetworkFcaNumber,
	ProviderName,
	AdviserInitialAmt,
	AdviserInitialPercent,
	AdviserOngoingAmt,
	AdviserOngoingPercent,
	AdviserOngoingFrequency,
	AdviserOngoingNextPaymentDate,
	ProviderAnnualFeePercent,
	ProviderAnnualFeeAmount,
	DateOfBirth,
	RetirementDate,
	CrystallisationStatus,
	IrdNo,
	MigrationReference,
	AdviserFCAAuthStatus,
	CompanyFCAAuthStatus,
	NetworkFCAAuthStatus,
	AnnualStatementDate)
SELECT 
	Seca.Claccountid,
	Seca.Accountname,
	Seca.DateCreated,
	CA.[Status],
	CD.ActivationDate,
	AH.AmlStatus,
	AH.HMTStatus,
	AH.PepStatus,
	adv.Name ,
	adv.FSAAuthorisationNumber,
	Co.CompanyName,
	CO.FSAAuthorisationNumber,
	Net.NetworkName,
	Net.FSAAuthorisationNumber,
	WP.ProviderName,
	0,
	CT.InitialAdvisorCharge,
	0,
	CT.AdvisorOngoingCharge,
	CD.FeeInvoicingFrequency,
	Com.NextPayDate,
	0,
	CT.ProviderCharge,
	AH.DateOfBirth,
	CD.RetirementDate,
	case
		when Crys.ClAccountId is null
			then 'Accumulation'
		else
			'Crystallised'
	end as CrystallisationStatus,
	AH.IrdNo,
	CA.ExternalSystemIdentifier1,
	'Authorised',
	Co.FSAAuthorisationStatus ,
	Net.FSAAuthorisationStatus,
	CD.ActivationDate+365

FROM @accounts A
INNER JOIN dbo.Seclientaccount Seca on Seca.ClAccountiD = A.ClAccountID
INNER JOIN dbo.ClientDetails CD on CD.ClAccountID = Seca.ClAccountID
INNER JOIN Discovery.dbo.ClientAccount CA on CA.ClAccountID = Seca.ClAccountID
INNER JOIN dbo.Advisor adv on adv.advCode = Seca.PrimaryAdviser
INNER JOIN dbo.Company Co on Co.Company = CD.Company
INNER JOIN dbo.WrapProvider WP on WP.WrapProvider = Co.WrapProvider
INNER JOIN dbo.AccountHolders AH on AH.ClAccountId = Seca.ClAccountID and AH.HolderNumber = 1
LEFT OUTER JOIN dbo.Network Net  on CO.Network = Net.Network
LEFT OUTER JOIN @chargeTerms CT on CT.COmpany = CD.Company
LEFT OUTER JOIN @crystallisedaccounts Crys on Crys.ClAccountID = A.ClAccountID
LEFT OUTER JOIN dbo.vwAcornCommissionSettingsByAdvisor Com on Com.AdvCode = Seca.PrimaryAdviser

return
end

