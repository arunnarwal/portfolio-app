
CREATE FUNCTION [dbo].[fnGetJuniorAccounts]()

RETURNS TABLE AS 

RETURN 
SELECT 
	I.DateOfBirth,
	CR.DateCreated,
	CR.AccountId,
	CR.CustomerId,
	SEC.ClAccountId
FROM Platform.DBACustomer.Individuals I
	INNER JOIN Platform.DBAAccount.CustomerRoles CR ON I.CustomerId = CR.CustomerID
	INNER JOIN Platform.DBAAccount.CustomerRoleTypes CRT ON CR.CustomerRoleTypeId = CRT.CustomerRoleTypeId AND CRT.CustomerRoleType='IndividualAccountHolder'
	INNER JOIN dbo.SEClientAccount SEC ON SEC.ID = CR.AccountID
	INNER JOIN dbo.ClientDetails CD ON CD.ClAccountId = SEC.ClAccountId AND CD.IsJuniorAccount = 1
