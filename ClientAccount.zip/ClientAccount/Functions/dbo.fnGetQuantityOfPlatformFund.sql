SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE FUNCTION [dbo].[fnGetQuantityOfPlatformFund](@ClAccountid varchar(20),@InstrumentCode varchar(20)) RETURNS TABLE AS

RETURN

SELECT sum(quantity) As Quantity from clientaccount..scriptransactions where instrumentcode = @InstrumentCode and claccountid = @ClAccountid and transstatus = 'Settled' and location = 'Registry' group by instrumentcode
GO
