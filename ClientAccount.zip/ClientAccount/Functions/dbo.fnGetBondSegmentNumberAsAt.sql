CREATE FUNCTION [dbo].[fnGetBondSegmentNumberAsAt](@AsAt DATETIME) Returns TABLE AS
RETURN

--DECLARE @AsAt AS DATETIME
--SET @AsAt ='3-Sep-2019'

SELECT
  seg.SubAccountId,
  COALESCE(segH.NumberOfActiveSegments, seg.NumberOfActiveSegments) AS NumberOfActiveSegments
FROM dbo.BondActiveSegments seg
  LEFT JOIN dbo.BondActiveSegmentsHistory segH
    ON seg.SubAccountId =  segH.SubAccountId
	  AND segH.FromDateTime < @AsAt AND segH.ToDateTime >= @AsAt
WHERE COALESCE(segH.FromDateTime, seg.FromDateTime)  <= @AsAt
GO
