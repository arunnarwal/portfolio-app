SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[fnGetTaxMonthLabelFromDate]
              (@TaxDate DateTime)
RETURNS varchar(12)
AS
  BEGIN
    DECLARE  @offset int,
             @taxmonth INT,
			 @month INT,
			 @desc varchar(12)
                          
	/*if it's before 6th, it counts as previous month*/
	IF day(@TaxDate)<6
		BEGIN		
		SET @offset = 1		
		END
	ELSE
		BEGIN
		SET @offset = 0
		END
	
	SET @month = month(@Taxdate)

	/*calculate the tax month number, starting at 1 from 6th of April*/
	IF (@month - 3 - @offset) < 1
		BEGIN
		SET @taxmonth = 12 + (@month - 3 - @offset)
		END
	ELSE
		BEGIN
		SET @taxmonth = @month - 3 - @offset
		END

	/*display label of that month*/
	SET @desc = 
	CASE
		WHEN @taxmonth = 1 THEN '6/4-5/5'
		WHEN @taxmonth = 2 THEN '6/5-5/6'
		WHEN @taxmonth = 3 THEN '6/6-5/7'
		WHEN @taxmonth = 4 THEN '6/7-5/8'
		WHEN @taxmonth = 5 THEN '6/8-5/9'
		WHEN @taxmonth = 6 THEN '6/9-5/10'
		WHEN @taxmonth = 7 THEN '6/10-5/11'
		WHEN @taxmonth = 8 THEN '6/11-5/12'
		WHEN @taxmonth = 9 THEN '6/12-5/1'
		WHEN @taxmonth = 10 THEN '6/1-5/2'
		WHEN @taxmonth = 11 THEN '6/2-5/3'
		WHEN @taxmonth = 12 THEN '6/3-5/4'
	END
	
	RETURN @desc
  END
GO
