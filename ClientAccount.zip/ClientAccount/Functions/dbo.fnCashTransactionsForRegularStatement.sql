/***
<Function>
    <Description>Cash Ledger transactions that is used by services to display on UI, all transaction types are included</Description>
    <Parameters>
         <Parameter Name="@SubAccountIdsCsv">
         <Description>List of accounts that should be returned</Description>
      </Parameter>
      <Parameter Name="@ExcludeManualCashAdjustments">
         <Description>Flag to indicate whether to include manual cash adjustments or not</Description>
      </Parameter>
      <Parameter Name="@IsForValuationStatement">
         <Description>Flag to indicate whether this is generated for valuation statement</Description>
      </Parameter>
    </Parameters>
</Function>
***/
CREATE FUNCTION dbo.fnCashTransactionsForRegularStatement
(
    @SubAccountIdsCsv VARCHAR(MAX),
    @ExcludeManualCashAdjustments BIT,
    @IsForValuationStatement BIT
) RETURNS TABLE
AS
RETURN

    WITH SubAccountIds AS
    (
        SELECT Csv.TabValue AS SubAccountId, SECA.ClAccountId
        FROM CSFBMAster.dbo.Fn_convert_comma_to_table_char(@SubAccountIdsCsv) Csv
        INNER JOIN dbo.SEClientAccount SECA ON SECA.Id = Csv.TabValue
    ),
    Trans AS
    (
        SELECT
            GT.AccountId,
            GT.TransactionId,
            GT.LedgerDate,
            GT.MovementTypeId,
            GT.CurrencyId,
            GT.Amount,
            GT.MovementSourceId,
            GT.RestrictSweepUntil,
            GT.IsCapital,
            GT.IsProductCapital
        FROM
            CashLedger.GladTransactions AS GT
            LEFT JOIN CashLedger.ManualCashAdjustmentTransactions MCAT ON MCAT.TransactionId = GT.TransactionId
            LEFT JOIN dbo.ManualCashAdjustmentRequests MCAR ON MCAR.Id = MCAT.ManualCashAdjustmentId
        WHERE
            GT.DisplayToClient = 1
            AND GT.Amount <> 0
            AND ((@ExcludeManualCashAdjustments = 0 AND MCAR.OriginalContributionTransId IS NULL) OR MCAT.TransactionId IS NULL)

        UNION ALL

        SELECT
            GT.AccountId,
            GT.TransactionId,
            GT.LedgerDate,
            GT.MovementTypeId,
            GT.CurrencyId,
            GT.Amount,
            GT.MovementSourceId,
            CONVERT(SMALLDATETIME, NULL) RestrictSweepUntil,
            GT.IsCapital,
            GT.IsProductCapital
        FROM
            CashLedger.ExternalTransactions AS GT
        WHERE
            GT.DisplayToClient = 1
            AND GT.Amount <> 0
            AND GT.AccountId IN (select S.SubAccountId FROM SubAccountIds S)
    ),
    Clt AS
    (
        SELECT
            Acc.ClAccountID AS SubClAccountID,
            GT.TransactionId,
            GT.LedgerDate,
            MT.MovementType,
            C.CurrencyCode AS CcyCode,
            -GT.Amount           AS Amount,
            tn.Narrative,
            T.CreatedDateTime AS DateCreated,
            TOD.OrderID,
            TCED.CashEntryId AS OriginatingCashEntryID,
            TCD.ArlId,
            GT.RestrictSweepUntil,
            TCAD.CorporateActionId AS CorpActId,
            MS.MovementSource,
            GT.IsCapital,
            GT.IsProductCapital
        FROM
            Trans AS GT
            INNER JOIN CashLedger.Transactions AS T ON GT.TransactionId = T.TransactionId
            INNER JOIN SubAccountIds AS Acc ON Acc.SubAccountId = GT.AccountId
            INNER JOIN CashLedger.MovementTypes AS MT ON MT.MovementTypeId = GT.MovementTypeId
            INNER JOIN CashLedger.Currencies AS C ON C.CurrencyId = GT.CurrencyId
            INNER JOIN CashLedger.MovementSources AS MS ON MS.MovementSourceId = GT.MovementSourceId
            LEFT JOIN CashLedger.TransactionNarratives AS TN ON TN.TransactionId = GT.TransactionId
            LEFT JOIN CashLedger.OrderTransactions AS TOD ON TOD.TransactionId = T.TransactionId
            LEFT JOIN CashLedger.ChargeTransactions AS TCD ON TCD.TransactionId = T.TransactionId
            LEFT JOIN CashLedger.CashEntryTransactions AS TCED ON TCED.TransactionId = T.TransactionId
            LEFT JOIN CashLedger.CorporateActionTransactions AS TCAD ON TCAD.TransactionId = t.TransactionId
        WHERE
            MT.MovementType <> 'CALL_TRANSACTION'
    ),
    ReversingManualCashAdjustments AS
    (
        SELECT OriginalContributionTransId, SUM(Amount) AS Amount
        FROM dbo.ManualCashAdjustmentRequests
        WHERE OriginalContributionTransId IS NOT NULL
        AND Status = 'Completed'
        AND @ExcludeManualCashAdjustments = 0
        GROUP BY OriginalContributionTransId
    ),
    Transactions AS
    (
        SELECT DISTINCT
            CLT.TransactionId,
            Sub.SubAccountId AS SubAccountId,
            CLT.DateCreated AS TransactionDate,
            COALESCE(CLT.RestrictSweepUntil, CLT.LedgerDate) AS SettlementDate,
            CLT.Amount + ISNULL(MCAT.Amount, 0) AS Amount,
            CLT.CCYCode AS Currency,
            PD.ProductType,
            CLT.Narrative,
            CLT.DateCreated,
            CLT.MovementType,
            ARL.Trantype AS ChargeType,
            CE.AWScripTransferID AS TransferId,
            COALESCE(CLT.OrderId, CLT.OriginatingCashEntryId, CLT.CorpActId, CLT.ArlId) AS SourceActionId,
            CLT.MovementSource,
            CE.ID AS CashEntryId,
            CLT.IsCapital,
            CLT.IsProductCapital
        FROM
            SubAccountIds Sub
            INNER JOIN Clt AS CLT ON CLT.SubClAccountId = Sub.ClAccountId
            INNER JOIN Discovery.dbo.ProductDetails AS PD ON CLT.SubClAccountId = PD.ClAccountId
            LEFT JOIN Discovery.dbo.AdvisorRevenueLedger ARL ON ARL.Id = CLT.ArlId
            LEFT JOIN Discovery.dbo.CashEntry CE ON CE.Id = CLT.OriginatingCashEntryId
            LEFT JOIN ReversingManualCashAdjustments MCAT ON MCAT.OriginalContributionTransId = CLT.TransactionId
        WHERE
            CLT.Amount + ISNULL(MCAT.Amount, 0) <> 0

        UNION ALL

        SELECT DISTINCT
            R.TransID AS TransactionId,
            Sub.SubAccountId,
            R.LedgerDate AS TransactionDate,
            R.LedgerDate AS SettlementDate,
            R.Amount,
            R.CCYCode AS Currency,
            PD.ProductType,
            R.Narrative,
            R.DateCreated,
            R.MovementType,
            ARL.Trantype AS ChargeType,
            CE.AWScripTransferID AS TransferId,
            COALESCE(R.OrderId, R.OriginatingCashEntryId, R.CorpActId, R.ArlId) AS SourceActionId,
            R.MovementSource,
            CE.ID AS CashEntryId,
            R.Capital,
            R.ProductCapital
        FROM
            SubAccountIds Sub
            INNER JOIN dbo.RegistryCashLedgerTransactions R ON R.ClAccountId = Sub.ClAccountId
            INNER JOIN Discovery.dbo.ProductDetails AS PD ON R.ClAccountId = PD.ClAccountId
            LEFT JOIN Discovery.dbo.AdvisorRevenueLedger ARL ON ARL.Id = R.ArlId
            LEFT JOIN Discovery.dbo.CashEntry CE ON CE.Id = R.OriginatingCashEntryId

        UNION ALL

        SELECT DISTINCT
            CMT.Id AS TransactionId,
            Sub.SubAccountId,
            CMT.TransactionDate,
            CMT.TransactionDate AS SettlementDate,
            CMT.Amount,
            CMT.Currency,
            PD.ProductType,
            CMT.TransType AS Narrative,
            CMT.TransactionDate AS DateCreated,
            CMT.TransType AS MovementType,
            NULL AS ChargeType,
            NULL AS TransferId,
            NULL AS SourceActionId,
            NULL As MovemenSource,
            NULL AS CashEntryId,
            1,
            1
        FROM
            SubAccountIds Sub
            INNER JOIN dbo.CmtTrans CMT ON CMT.ClAccountId = Sub.ClAccountId
            LEFT OUTER JOIN Discovery.dbo.ProductDetails PD ON PD.ClAccountID = CMT.ClAccountId
        WHERE
            CMT.TransType IN ('Interest', 'AIL', 'RWT', 'NRWT')
            AND CMT.DisplayToClient = 1
            AND CMT.Amount <> 0
            AND CMT.ClAccountId IN (SELECT S.ClAccountId FROM SubAccountIds S) -- In addition to the join to force a seek on CMTTrans		
    ),
    CashEntryIdsToExclude AS
    (
        SELECT T.CashEntryId FROM Transactions T
        INNER JOIN Discovery.dbo.CashEntry CE ON CE.Id = T.CashEntryId AND CE.AccountNumber IS NOT NULL
        INNER JOIN dbo.SEClientAccount SECA ON  SECA.ClAccountID = CE.AccountNumber
        WHERE SECA.InvestorType = 'TRADING'
    )

    SELECT
        T.TransactionId,
        T.SubAccountId,
        T.TransactionDate,
        T.SettlementDate,
        T.Amount,
        T.Currency,
        T.ProductType,
        T.Narrative,
        T.DateCreated,
        T.MovementType,
        T.ChargeType,
        T.TransferId,
        T.SourceActionId,
        SUM(T.Amount) OVER (PARTITION BY T.SubAccountId ORDER BY T.TransactionDate ROWS UNBOUNDED PRECEDING) AS Balance,
        T.MovementSource,
        T.IsCapital,
        T.IsProductCapital
    FROM
        Transactions T
        WHERE @IsForValuationStatement = 0 OR NOT EXISTS (SELECT 1 FROM  CashEntryIdsToExclude CEI WHERE CEI.CashEntryId = T.CashEntryId)
