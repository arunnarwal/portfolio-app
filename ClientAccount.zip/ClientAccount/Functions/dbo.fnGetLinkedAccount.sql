SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[fnGetLinkedAccount](@claccountid varchar(20)) RETURNS TABLE AS  
  
RETURN  
  
SELECT   
 SubClAccountID as ClAccountID,C.CLAccountID as LinkAccount
FROM   
 ClientAccount.dbo.Consolidate c  
  INNER JOIN  
 (SELECT headClAccountID,claccountid FROM ClientAccount.dbo.fnheadaccounts() WHERE claccountid = @claccountid and consolidated = 1) AS linked   
 ON c.ClAccountID = linked.headClAccountID  
 AND  
 c.SubClAccountID not like '%-%' and SubClAccountID = @claccountid
 AND c.Status = 'Authorised'
INNER JOIN discovery..clientaccount CA   
   ON CA.claccountid = C.claccountid   
    AND CA.islinkedaccountforfees = 1 
GO