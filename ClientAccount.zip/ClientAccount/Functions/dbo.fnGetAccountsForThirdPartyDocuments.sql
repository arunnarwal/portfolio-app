SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[fnGetAccountsForThirdPartyDocuments](@FromDate datetime, @ToDate datetime) RETURNS TABLE AS

RETURN

/*

 DECLARE @FromDate datetime 

 DECLARE @ToDate datetime 

 select @FromDate = '16 Jan 2012 7:00PM', @ToDate = '17 Jan 2012 7:00PM'

*/

SELECT 

 Distinct(CE.ClAccountID) As ClAccountID

FROM 

 Discovery..CashEntry AS CE

 Inner Join ClientAccount..vwSubAccount AS SA

 On CE.ClAccountId = SA.SubClAccountId

WHERE SA.SubAccountType = 'JISA' And Source = 'Third Party' 

 and (

  (Method = 'Cheque' and [Type] = 'Deposit' and DateCompleted between @FromDate and @ToDate)

  OR (Method = 'Direct Debit' and [Type] = 'Deposit' and Firstdate Between @FromDate And @ToDate and InstructionType = 'Standing')

 )
GO
