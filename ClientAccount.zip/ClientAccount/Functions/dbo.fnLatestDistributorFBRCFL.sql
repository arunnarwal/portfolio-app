SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO

CREATE FUNCTION [dbo].[fnLatestDistributorFBRCFL](@asAt as DateTime) RETURNS TABLE AS 

RETURN 

WITH LatestDistributorFBRC AS
(
	SELECT SchemeID, MAX(StartDate) AS StartDate FROM ClientAccount..SchemeDistributorFBRC 
	WHERE StartDate <= @asAt 
		  AND ( EndDate IS NULL OR EndDate >= @asAt )
		  And Status = 'Active'	
	GROUP BY SchemeID
)

SELECT 
DFBRC.SchemeID,
[Percent],
ContinueUntil,
DFBRC.StartDate,
EndDate,
ApplyToGIA, 
ApplyToSISA, 
ApplyToSIPP,
CreatedDate,
CreatedUserId, 
LastUpdatedDate,
LastUpdatedUserId
FROM ClientAccount..SchemeDistributorFBRC AS DFBRC
INNER JOIN LatestDistributorFBRC AS LFBRC
	ON DFBRC.SchemeID = LFBRC.SchemeID 
	AND DFBRC.StartDate = LFBRC.StartDate
	AND ( DFBRC.EndDate IS NULL OR DFBRC.EndDate >= @asAt )
	And Status = 'Active'	

GO
