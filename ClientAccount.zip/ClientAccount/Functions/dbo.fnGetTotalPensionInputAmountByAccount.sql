/***
<Function>
    <Description>Function to get total pension input amout by headAccountId in specific date range</Description>
</Function>
***/

SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[fnGetTotalPensionInputAmountByAccount] ( @FromDate DATETIME, @ToDate DATETIME )
RETURNS @AmountTab TABLE
	(
		ClAccountID		VARCHAR (20),
		Amount			MONEY,
		TaxYear			INT
	)
AS
BEGIN
	--DECLARE @FromDate DATETIME
	--DECLARE @ToDate DATETIME
	--SET @FromDate = '2015-10-06 00:00:00.000'
	--SET @ToDate = '2016-01-06 00:00:00.000'

	DECLARE @EdgeDate DATETIME
	SET @EdgeDate = '2000-04-06 00:00:00.000'

	INSERT @AmountTab
		SELECT
			HA.HeadClAccountID AS ClAccountID,
			SUM(CE.Amount) AS Amount,
			CASE 
				WHEN DATEPART(DAYOFYEAR, CE.DateCompleted) < DATEPART(DAYOFYEAR, DATEADD(YEAR, YEAR(CE.DateCompleted)-YEAR(@EdgeDate),@EdgeDate)) 
					THEN YEAR(DATEADD(YEAR, -1, CE.DateCompleted))
				ELSE YEAR(CE.DateCompleted)
			END AS TaxYear
		FROM Discovery.dbo.ProductDetails PD
			INNER JOIN Discovery.dbo.CashEntry CE 
				ON CE.ClAccountID = PD.ClAccountID
			LEFT JOIN dbo.fnHeadAccounts() HA 
				ON HA.ClAccountID = PD.ClAccountID
		WHERE
			PD.ArrangementType = 'Accumulation'
			AND CE.Status = 'Completed'
			AND CE.Type = 'Deposit'
			AND CONVERT(DATE, CE.DateCompleted) BETWEEN @FromDate AND @ToDate
		GROUP BY
			HA.HeadClAccountID, 
			CASE 
				WHEN DATEPART(DAYOFYEAR, CE.DateCompleted) < DATEPART(DAYOFYEAR, DATEADD(YEAR, YEAR(CE.DateCompleted)-YEAR(@EdgeDate),@EdgeDate)) 
					THEN YEAR(DATEADD(YEAR, -1, CE.DateCompleted))
				ELSE YEAR(CE.DateCompleted)
			END
	RETURN
END

GO