CREATE FUNCTION [dbo].[fnProductValueForDim](@AsAt datetime, @Location varchar(10), @Currency char(3), @PriceAsAt datetime) RETURNS TABLE AS
RETURN

	SELECT	CLAccountID, 
			ProductValue,
			ProductValueOfUnclearedCheques 
	FROM dbo.fnProductValueBaseForDim (@AsAt, @Location, @Currency, @PriceAsAt, default, default)

GO
