CREATE FUNCTION [dbo].[FnGetInterestRatePackageSettingsAsAt]
(
	@ClAccountID AS VARCHAR(max),
	@AsAt AS DATETIME = null
)
RETURNS @Table TABLE
( 
	ClaccountId VARCHAR(50),
	InterestRatePackageID INT, 
	StartDate DATETIME, 
	EndDate DATETIME,
	Source VARCHAR(20)
) 
AS
BEGIN

IF @AsAt IS NULL
BEGIN
	SET @AsAt = CAST(CONVERT(VARCHAR(13), getDate(), 106) AS DATETIME)
END
ELSE
BEGIN
	SET @AsAt = CAST(CONVERT(VARCHAR(13), @AsAt, 106) AS DATETIME)
END

;WITH BeyondInterestRatePackageSettings AS 
(
SELECT 
	ClaccountID,
	InterestRatePackageId,
	StartDate,
	EndDate,
	Source,
	Rank() over (Partition by ClAccountId order by AsAt asc) Ranking
FROM
	(SELECT
		CAST(CONVERT(VARCHAR(13), getDate(), 106) AS DATETIME)+1 AS AsAt,
		sec.ClaccountID,
		settings.InterestRatePackageID,
		settings.StartDate,
		settings.EndDate,
		settings.Source
	FROM 
		dbo.InterestRatePackageSetting settings
		INNER JOIN dbo.SeClientAccount sec on sec.Id = settings.SeClientAccountId
	WHERE 
		sec.ClaccountID = @ClaccountID
	UNION
	SELECT
		CAST(CONVERT(VARCHAR(13), settings.AsAt, 106) AS DATETIME) AS AsAt,
		sec.ClaccountID,
		settings.InterestRatePackageID,
		settings.StartDate,
		settings.EndDate,
		settings.Source
	FROM 
		dbo.InterestRatePackageSettingChange settings
		INNER JOIN dbo.SeClientAccount sec on sec.Id = settings.SeClientAccountId
	WHERE 
		CAST(CONVERT(VARCHAR(13), AsAt, 106) as DATETIME) > @AsAt and sec.ClaccountID = @ClaccountID
	) BeyondInterestRatePackageSettings
)

INSERT INTO @Table
SELECT
	ClaccountId,
	InterestRatePackageId,
	StartDate,
	EndDate,
	Source
FROM 
	BeyondInterestRatePackageSettings 
WHERE 
	Ranking = 1
RETURN
END

GO


