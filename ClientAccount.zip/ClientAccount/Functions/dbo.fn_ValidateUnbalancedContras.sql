

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- ============================================
CREATE FUNCTION [dbo].[fn_ValidateUnbalancedContras]()
RETURNS @valTable TABLE
([Type] varchar(10),[Message] varchar(100),DBName varchar(100),DBTable varchar(100), [Owner] varchar(100), SiteOwner varchar(100))
AS
BEGIN
DECLARE @Result integer
SET @Result = 0
IF(	SELECT COUNT(*) FROM (SELECT ClAccountId
FROM dbo.CashLedgerTransactions
WHERE contraid IS NOT NULL
GROUP BY ClAccountId, ContraId
having abs(sum(amount)) > 0.01) x) > 0
BEGIN
	BEGIN
		INSERT INTO @valTable(type, message, DBName, DBTable, owner, SiteOwner)
		VALUES ('Error','Unbalanced Contras Found','ClientAccount', 'CashLedgerTransactions','Fyfester', 'ALL')
	END
END 

return
END
GO
