

-- =============================================

-- Author: <Author,,Name>

-- Create date: <Create Date,,>

-- Description: <Description,,>

-- =============================================

CREATE FUNCTION [dbo].[fn_GetCommissionByPeriodByHeadAccountWithSplitIsas]

(

-- Add the parameters for the function here

@periodStart datetime,

@periodEnd datetime

)

RETURNS TABLE

AS

RETURN

(

--

--Declare @PeriodStart as datetime

--

--Declare @PeriodEnd as datetime

--

----

--

--set @PeriodStart='01 Oct 2011'

--

--set @PeriodEnd='01 Oct 2012'

SELECT BASE.HeadClAccountId as claccountid,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.TPCCharge END) as WRAPCASHTPCCharge,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.TPCCharge END) as PPTPCCharge,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Cash' THEN Base.TPCCharge END) as CashISATPCCharge,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Stocks/Shares' THEN Base.TPCCharge END) as SSISATPCCharge,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.TPCCharge END) as SIPPTPCCharge,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.Ic END) as WRAPCASHIC,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.Ic END) as PPIC,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Cash' THEN Base.Ic END) as CashISAIC,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Stocks/Shares' THEN Base.Ic END) as SSISAIC,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.Ic END) as SIPPIC,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.Wic END) as WRAPCASHWIC,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.Wic END) as PPWIC,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Cash' THEN Base.Wic END) as CashISAWIC,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Stocks/Shares' THEN Base.Wic END) as SSISAWIC,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.Wic END) as SIPPWIC,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.AdvisorFBRCCharge END) as WRAPCASHAdvisorFBRCCharge,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.AdvisorFBRCCharge END) as PPAdvisorFBRCCharge,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Cash' THEN Base.AdvisorFBRCCharge END) as CashISAAdvisorFBRCCharge,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Stocks/Shares' THEN Base.AdvisorFBRCCharge END) as SSISAAdvisorFBRCCharge,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.AdvisorFBRCCharge END) as SIPPAdvisorFBRCCharge,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.FBRCCharge END) as WRAPCASHFBRCCharge,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.FBRCCharge END) as PPFBRCCharge,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Cash' THEN Base.FBRCCharge END) as CashISAFBRCCharge,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Stocks/Shares' THEN Base.FBRCCharge END) as SSISAFBRCCharge,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.FBRCCharge END) as SIPPFBRCCharge,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.AdHocCommission END) as WRAPCASHAdHocCommission,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.AdHocCommission END) as PPAdHocCommission,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Cash' THEN Base.AdHocCommission END) as CashISAAdHocCommission,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Stocks/Shares' THEN Base.AdHocCommission END) as SSISAAdHocCommission,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.AdHocCommission END) as SIPPAdHocCommission,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.Bceic END) as BCEIC,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.Popc END) as WRAPCASHPOPC,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.Popc END) as PPPOPC,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Cash' THEN Base.Popc END) as CashISAPOPC,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Stocks/Shares' THEN Base.Popc END) as SSISAPOPC,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.Popc END) as SIPPPOPC,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.Dopc END) as SIPPDOPC,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.Donc END) as SIPPDONC,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.Ponc END) as WRAPCASHPONC,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.Ponc END) as PPPONC,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Cash' THEN Base.Ponc END) as CashISAPONC,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Stocks/Shares' THEN Base.Ponc END) as SSISAPONC,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.Ponc END) as SIPPPONC,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.Sic END) as WRAPCASHSIC,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.Sic END) as PPSIC,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Cash' THEN Base.Sic END) as CashISASIC,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Stocks/Shares' THEN Base.Sic END) as SSISASIC,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.Sic END) as SIPPSIC,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.Switch END) as WRAPCASHSWITCH,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.Switch END) as PPSWITCH,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Cash' THEN Base.Switch END) as CashISASWITCH,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Stocks/Shares' THEN Base.Switch END) as SSISASWITCH,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.Switch END) as SIPPSWITCH,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.NewCash END) as WRAPCASHNewCash,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.NewCash END) as PPNewCash,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Cash' THEN Base.NewCash END) as CashISANewCash,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Stocks/Shares' THEN Base.NewCash END) as SSISANewCash,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.NewCash END) as SIPPNewCash, 

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.ReregAmount END) as WRAPCASHReregAmount,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.ReregAmount END) as PPReregAmount,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Cash' THEN Base.ReregAmount END) as CashISAReregAmount,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Stocks/Shares' THEN Base.ReregAmount END) as SSISAReregAmount,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.ReregAmount END) as SIPPReregAmount,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.AverageFundsUnderManagement END) as WRAPCASHAverageFundsUnderManagement,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.AverageFundsUnderManagement END) as PPAverageFundsUnderManagement,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Cash' THEN Base.AverageFundsUnderManagement END) as CashISAAverageFundsUnderManagement,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Stocks/Shares' THEN Base.AverageFundsUnderManagement END) as SSISAAverageFundsUnderManagement,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.AverageFundsUnderManagement END) as SIPPAverageFundsUnderManagement,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.TotalDailyFundsUnderManagement END) as WRAPCASHTotalDailyFundsUnderManagement,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.TotalDailyFundsUnderManagement END) as PPTotalDailyFundsUnderManagement,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Cash' THEN Base.TotalDailyFundsUnderManagement END) as CashISATotalDailyFundsUnderManagement,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Stocks/Shares' THEN Base.TotalDailyFundsUnderManagement END) as SSISATotalDailyFundsUnderManagement,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.TotalDailyFundsUnderManagement END) as SIPPTotalDailyFundsUnderManagement,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.SwitchAmounts END) as WRAPCASHSwitchAmounts,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.SwitchAmounts END) as PPSwitchAmounts,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Cash' THEN Base.SwitchAmounts END) as CashISASwitchAmounts,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Stocks/Shares' THEN Base.SwitchAmounts END) as SSISASwitchAmounts,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.SwitchAmounts END) as SIPPSwitchAmounts,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.CrystalisedAmount END) as SIPPCrystalisedAmount,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.DFMFixedCharge END) as WRAPCASHDFMFixedCharge,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.DFMFixedCharge END) as PPDFMFixedCharge,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Cash' THEN Base.DFMFixedCharge END) as CashISADFMFixedCharge,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Stocks/Shares' THEN Base.DFMFixedCharge END) as SSISADFMFixedCharge,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.DFMFixedCharge END) as SIPPDFMFixedCharge,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.Dfmic END) as WRAPCASHDFMIC,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.Dfmic END) as PPDFMIC,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Cash' THEN Base.Dfmic END) as CashISADFMIC,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Stocks/Shares' THEN Base.Dfmic END) as SSISADFMIC,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.Dfmic END) as SIPPDFMIC,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.DFMTieredCharge END) as WRAPCASHDFMTieredCharge,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.DFMTieredCharge END) as PPDFMTieredCharge,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Cash' THEN Base.DFMTieredCharge END) as CashISADFMTieredCharge,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Stocks/Shares' THEN Base.DFMTieredCharge END) as SSISADFMTieredCharge,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.DFMTieredCharge END) as SIPPDFMTieredCharge,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.RegularInitialAdvisorCharge END) as PPRegularInitialAdvisorCharge,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Cash' THEN Base.RegularInitialAdvisorCharge END) as CashISARegularInitialAdvisorCharge,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Stocks/Shares' THEN Base.RegularInitialAdvisorCharge END) as SSISARegularInitialAdvisorCharge,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.RegularInitialAdvisorCharge END) as SIPPRegularInitialAdvisorCharge,

--sum(CASE WHEN BASE.Subaccounttype='Personal Portfolio' THEN (IsNull(Cast(fs.MaxPayOutCount as Integer),0) - IsNull(Cast(fs.PayOutCount as Integer),0) - IsNull(Cast(fs.FailedPayOutCount as Integer),0)) END) as PPRIAROutStandingDeductions,

--

--sum(CASE WHEN BASE.Subaccounttype='ISA' and Base.ProductType = 'Cash' THEN (IsNull(Cast(fs.MaxPayOutCount as Integer),0) - IsNull(Cast(fs.PayOutCount as Integer),0) - IsNull(Cast(fs.FailedPayOutCount as Integer),0)) END) as CashISARIAOutStandingDeductions,

--

--sum(CASE WHEN BASE.Subaccounttype='ISA' and Base.ProductType = 'Stocks/Shares' THEN (IsNull(Cast(fs.MaxPayOutCount as Integer),0) - IsNull(Cast(fs.PayOutCount as Integer),0) - IsNull(Cast(fs.FailedPayOutCount as Integer),0)) END) as SSISARIAROutStandingDeductions,

--

--sum(CASE WHEN BASE.Subaccounttype='SIPP') THEN (IsNull(Cast(fs.MaxPayOutCount as Integer),0) - IsNull(Cast(fs.PayOutCount as Integer),0) - IsNull(Cast(fs.FailedPayOutCount as Integer),0)) END) as SIPPRiaROutStandingDeductions,

sum(CASE WHEN BASE.SubAccountType='Wrap Cash' THEN Base.RegularPaymentsIn END) as WRAPCASHRegularPaymentsIn,

sum(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.RegularPaymentsIn END) as PPRegularPaymentsIn,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Cash' THEN Base.RegularPaymentsIn END) as CashISARegularPaymentsIn,

sum(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Stocks/Shares' THEN Base.RegularPaymentsIn END) as SSISARegularPaymentsIn,

sum(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.RegularPaymentsIn END) as SIPPRegularPaymentsIn,

Max(CASE WHEN BASE.SubAccountType='Personal Portfolio' THEN Base.SubClAccountId END) as PPSubClAccountID,

Max(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Cash' THEN Base.SubClAccountId END) as CashISASubClAccountID,

Max(CASE WHEN BASE.SubAccountType='ISA' AND Base.ProductType = 'Stocks/Shares' THEN Base.SubClAccountId END) as SSISASubClAccountID,

Max(CASE WHEN BASE.SubAccountType='SIPP' THEN Base.SubClAccountId END) as SIPPSubClAccountID

FROM dbo.fn_GetCommissionByPeriodByHeadAccountByProductType(@PeriodStart,@PeriodEnd) BASE

GROUP BY BASE.HeadClAccountId

)
GO
