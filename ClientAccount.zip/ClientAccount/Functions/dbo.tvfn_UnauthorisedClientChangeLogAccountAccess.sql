CREATE FUNCTION dbo.tvfn_UnauthorisedClientChangeLogAccountAccess(@clientID int)
RETURNS TABLE AS
RETURN
SELECT
	CCL.id,
	CCL.ClAccountID,
	CL.investortype,
	CCL.Identifier,
	CCL.TableConstant,
	CCL.TableName,
	CCL.OriginalValue,
	CCL.NewValue,
	CCL.ModifiedBy,
	CCL.ChangeStatus,
	CCL.IdentifierField,
	CCL.DateModified,
	CCL.FieldName as FieldName,
	IsNull(fieldMappings.DisplayField,CCL.FieldName) as DisplayFieldName,
	CCL.AttemptCount,
	CCL.TaskRequestID,
	CCL.Type,
	CCL.Authorised,
	CCL.TransactionID,
	ACA.ClientID,
	ACA.ReadWrite,
	TC.FirstName + ' ' + TC.Surname AS ModifiedByName,
	CL.WrapProvider,
	CL.Company,
	UG.UserGroupID,
	CL.AccountName,
	Coalesce(AH.HolderNumber, ADR.HolderNumber) As HolderNumber,
	AH.HolderType,
	ba.DDIrec,
	ba.verificationrec
FROM dbo.ClientChangeLog AS CCL
	cross apply tvfn_BaseAllowedClientClAccountID(CCL.ClAccountid,@clientid) AS ACA
	INNER JOIN dbo.vwClAccountID CL on CL.ClAccountID = CCL.ClAccountID
	INNER JOIN ClientDB3.dbo.tblClients AS TC ON CCL.ModifiedBy = TC.ClientID
	INNER JOIN webdb..userstogroups AS UG ON UG.clientID = TC.ClientID
	LEFT JOIN csfbmaster..DisplayFieldsMappedToDBColumns as fieldMappings on fieldMappings.TableConstant = CCL.TableConstant AND fieldmappings.DatabaseField = CCL.FieldName
	left outer join accountholders AH on CCL.Tableconstant = 'claAccountHolders' and isnumeric(CCL.identifier)=1 and CCL.identifier = CAST(AH.ID AS varchar(20))
	left outer join Discovery..Address ADR on CCL.Tableconstant = 'dpsAddress' and isnumeric(CCL.identifier)=1 and CCL.identifier = CAST(ADR.ID AS varchar(20))
	inner join Discovery..BankAccount as ba on ccl.claccountid = ba.claccountid
WHERE CCL.[Authorised] = 0 and ba.id = (select max(id) from discovery..bankaccount where claccountid= ccl.claccountid)
GO