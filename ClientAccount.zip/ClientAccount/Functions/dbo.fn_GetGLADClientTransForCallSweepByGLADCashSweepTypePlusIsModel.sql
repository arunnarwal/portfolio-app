SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION  [dbo].[fn_GetGLADClientTransForCallSweepByGLADCashSweepTypePlusIsModel](@WrapProvider varchar(20), @GLADCashSweepType varchar(20),@batchGroupID as Integer)
Returns TABLE 
as
/*
*	Author:imcghee
*	Date created: 19 Nov 2009
*   Intended Purpouse:  
*/
--
--declare @WrapProvider varchar(20)
--declare @GLADCashSweepType varchar(20)
--declare @BatchGroupID integer
--
--set @WrapProvider ='All'
--set @GLADCashSweepType ='toPIACall'
--set @BatchGroupID ='0'
return
select 
	case When TOACCOUNT.PortfolioID > 0 Then 1
	Else 0
	End as ToAccountIsModel ,
	case When FROMACCOUNT.PortfolioID > 0 Then 1
	Else 0
	End as FromAccountIsModel ,
	BASEREPORT.Datecreated,
	BASEREPORT.claccountid,
	BASEREPORT.FromClaccountid,
	BASEREPORT.ToClaccountid,
	BASEREPORT.CCYCode,
	BASEREPORT.Amount,
	BASEREPORT.Wrapprovider,
	BASEREPORT.Company,
	BASEREPORT.CMTOverDraftAllowed,
	BASEREPORT.Narrative,
	BASEREPORT.NarrativeDetail,
	BASEREPORT.reference,
	BASEREPORT.MovementType,
	BASEREPORT.MovementSource
from clientaccount.dbo.fn_GetGLADClientTransactionsForCallSweepByGLADCashSweepType(@WrapProvider,@GLADCashSweepType,@batchGroupID) as BASEREPORT
Left Join  Discovery..clientAccount TOACCOUNT on BASEREPORT.ToClaccountid=TOACCOUNT.claccountid
Left Join  Discovery..clientAccount FROMACCOUNT on BASEREPORT.FromClaccountid=FROMACCOUNT.claccountid
GO
