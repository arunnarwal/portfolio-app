CREATE FUNCTION  [dbo].[fn_GetCmtBalanceWithSubsequentIndividualSwept](@BalanceDate datetime)
Returns TABLE 
as

/*
declare @BalanceDate datetime

set @BalanceDate ='13 jun 2014'
*/

return
Select ClAccountId,Sum(CMTBalance) CMTBalance
from (

select fHA.HeadClAccountId as ClAccountID,Sum(Amount) CmtBalance 
from dbo.CmtTrans CT 
inner Join dbo.FnHeadAccounts() fHA
on FHA.ClAccountID = CT.ClAccountID
where CT.TranDate <= @balancedate
group by fHA.HeadClAccountId

union all

select fHA.HeadClAccountId as ClAccountID,Sum(Amount) CmtBalance 
from dbo.CmtTrans CT 
inner Join dbo.FnHeadAccounts() fHA
on FHA.ClAccountID = CT.ClAccountID
where CT.TranDate > @balancedate
and DlInkBatch = 0
group by fHA.HeadClAccountId

) CMT
Group by CMT.ClAccountID


GO

