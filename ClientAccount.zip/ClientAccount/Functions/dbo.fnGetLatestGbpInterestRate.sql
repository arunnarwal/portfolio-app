CREATE FUNCTION [dbo].[fnGetLatestGbpInterestRate]
(
	@ToDate DATETIME
)
RETURNS DECIMAL(18,8)
AS
BEGIN
	--DECLARE @ToDate DATETIME
	--SET @ToDate = '2013-05-25 23:59:59.0'
	--SELECT TOP 1 GBP, Date FROM [ClientAccount].[dbo].[CMTInterestRate] WHERE Date <= @ToDate ORDER BY Date DESC

    RETURN (SELECT TOP 1 GBP FROM [ClientAccount].[dbo].[CMTInterestRate] WHERE Date <= @ToDate ORDER BY Date DESC)
END