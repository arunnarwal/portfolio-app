

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[fn_ValidateJournalAliasGLDivisionCodes]()
RETURNS @valTable TABLE
([Type] varchar(10),[Message] varchar(100),DBName varchar(100),DBTable varchar(100), [Owner] varchar(100), SiteOwner varchar(100))
AS
BEGIN
	
IF (SELECT COUNT(*) FROM dbo.GladJournalActionAlias
WHERE GLDivisionCode NOT IN (SELECT GLDivisionCode FROM dbo.GladGLDivision)) > 0 
BEGIN 
	BEGIN
		INSERT INTO @valTable(type, message, DBName, DBTable, owner, SiteOwner)
		VALUES ('Warning', 'Journal Alias GL Division Codes not set up.','ClientAccount', 'GladJournalActionAlias','Audrey Wan', 'All')
	END
END

return 

END
GO
