CREATE FUNCTION [dbo].[fnGetAllowedAccountsByAccountHolderV2] (@UserID INTEGER, @FirstName VARCHAR(50), @Surname VARCHAR(50), @DateOfBirth Date)
RETURNS @Result table
(	AccountType VARCHAR(50),
	ClAccountId  VARCHAR(50),
	AdvCode  VARCHAR(20),
	AdvisorName  VARCHAR(250),
	Company  VARCHAR(50),
	SearchKey  VARCHAR(100),
	AccountName  VARCHAR(100),  
	DPSAccountType  VARCHAR(50),
	Status  VARCHAR(50),  
	ClientType  VARCHAR(50),
	WrapProvider  VARCHAR(50),  
	SubAccountType  VARCHAR(50), 
	InvestorType  VARCHAR(50),
	ProductType  VARCHAR(50),  
	IsPlatformFund tinyint, 
	PortfolioId int,
	ProductDisplayName  VARCHAR(100),
	CompanyName  VARCHAR(250),
	Sanctioned BIT,
	CustomerId INT)
AS
BEGIN

DECLARE @UserType VARCHAR(10);
SELECT @UserType = GroupType FROM ClientDB3.dbo.vwUsers WHERE ClientId = @Userid

IF @FirstName IS NULL
BEGIN 
	SET @FirstName = '%'
END
ELSE
BEGIN
	SET @FirstName = @FirstName + '%'
END

IF @Surname  IS NULL
BEGIN
	SET @Surname = '%'
END
ELSE
BEGIN
	SET @Surname = @Surname + '%'
END

DECLARE @Accounts TABLE(
	AccountID VARCHAR(50) PRIMARY KEY CLUSTERED,
	CustomerId INT,
	AccountName VARCHAR(50)
)

IF @UserType = 'Internal'
BEGIN
	INSERT INTO @Accounts (AccountID, CustomerId, AccountName)
	SELECT DISTINCT SECA.ClAccountID AS AccountId, 
		CR.CustomerId, 
		COALESCE(Ind.GivenName + ' ' + Ind.FamilyName, Org.OrganisationName) AS AccountName 
	FROM dbo.SEClientAccount AS SECA 
		INNER JOIN Platform.DBAAccount.CustomerRoles AS CR ON SECA.ID = CR.AccountId AND CR.IsPrimaryRole = 1
		LEFT JOIN Platform.DBACustomer.Individuals AS Ind ON Ind.CustomerId = CR.CustomerId
		LEFT JOIN Platform.DBACustomer.Organisations AS Org ON Org.CustomerId = CR.CustomerId
	WHERE (Ind.GivenName LIKE @FirstName OR Org.OrganisationName LIKE @FirstName)
	AND Ind.FamilyName LIKE @Surname
	AND (Ind.DateOfBirth = @DateOfBirth OR @DateOfBirth = '1 jan 1900')
	OPTION(RECOMPILE)
END
ELSE
BEGIN
	INSERT INTO @Accounts(AccountID, CustomerId, AccountName)
	SELECT DISTINCT AA.CLAccountId,
		CR.CustomerId,
		COALESCE(Ind.GivenName + ' ' + Ind.FamilyName, Org.OrganisationName) AS AccountName 
	FROM dbo.vwAllowedAccounts AA
	INNER JOIN dbo.SEClientAccount AS HSECA ON HSECA.ClAccountId = AA.CLAccountId
	INNER JOIN Platform.DBAAccount.CustomerRoles AS CR ON HSECA.ID = CR.AccountId AND CR.IsPrimaryRole = 1
	LEFT JOIN Platform.DBACustomer.Individuals AS Ind ON Ind.CustomerId = CR.CustomerId
	LEFT JOIN Platform.DBACustomer.Organisations AS Org ON Org.CustomerId = CR.CustomerId
WHERE AA.CLIENTID = @UserID
	AND (Ind.GivenName LIKE @FirstName OR Org.OrganisationName LIKE @FirstName)
	AND Ind.FamilyName LIKE @Surname
	AND (Ind.DateOfBirth = @DateOfBirth OR @DateOfBirth = '1 jan 1900')
end


INSERT INTO @Result(AccountType, ClAccountId, AdvCode, AdvisorName, Company, SearchKey, AccountName, DPSAccountType, [Status], ClientType, WrapProvider, SubAccountType, InvestorType, ProductType, IsPlatformFund, PortfolioId, ProductDisplayName, CompanyName, Sanctioned, CustomerId)
SELECT 
	seca.accountType,
	SECA.ClAccountId,
	SECA.PrimaryAdviser AS AdvCode,
	Adv.Name AS AdvisorName,
	CD.Company,
	SECA.SearchKey,
	SECA.AccountName, 
	CA.DPSAccountType,
	CA.Status, 
	CD.InvestorType AS ClientType,
	CO.WrapProvider, 
	CA.SubAccountType, 
	CD.InvestorType,
	PD.ProductType, 
	PD.IsPlatformFund, 
	CA.PortfolioId,
	PD.ProductDisplayName,
	CO.CompanyName,
	CD.Sanctioned,
	AA.customerid
FROM @Accounts AA
INNER JOIN dbo.SEClientAccount AS SECA ON SECA.claccountId = AA.AccountId
INNER JOIN dbo.ClientDetails AS CD ON CD.ClaccountId = AA.AccountId
INNER JOIN Discovery.dbo.ClientAccount AS CA ON CA.ClAccountID = AA.AccountId
INNER JOIN Discovery.dbo.ProductDetails AS PD ON PD.ClAccountid = AA.AccountId
INNER JOIN dbo.Advisor AS ADV ON ADV.AdvCode = SECA.PrimaryAdviser
INNER JOIN dbo.Company AS CO ON CO.Company = ADV.Company
RETURN
END
GO
