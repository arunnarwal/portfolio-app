SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[fnGetPulseHoldingUnitPriceInEUR](@sedol varchar(30),@date datetime)

RETURNS decimal(15,7)

AS

BEGIN

Declare @return decimal(15,7)

if Exists (Select 1 from ClientAccount..PulsePrices price where price.sedol = @sedol and price.valuedate <= @date) 

begin

Select Top 1 @return = priceInEUR from ClientAccount..PulsePrices price where price.sedol = @sedol and price.valuedate <= @date order by price.valuedate desc, id desc

end

else 

begin

if Exists (Select 1 from ClientAccount..PulsePrices price where price.sedol = @sedol)

begin

Select Top 1 @return = priceInEUR from ClientAccount..PulsePrices price where price.sedol = @sedol order by price.valuedate asc, id desc

end

else

begin

Select @return = 1

end

end

RETURN @return

END
GO
