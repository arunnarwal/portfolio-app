CREATE FUNCTION [dbo].[fnTaxCertificateUkRebateSummary](@FromDate datetime, @ToDate datetime)
RETURNS TABLE
AS
RETURN

/*
USE ClientAccount

DECLARE @FromDate DATETIME;
DECLARE @ToDate DATETIME;

SET @FromDate = '2016-04-06 00:00:00';
SET @ToDate = '2017-04-05 00:00:00';
*/

SELECT
	ClAccountID,
	SUM(R.Amount + R.TaxAmount) As Net, /* tax amount is stored as negative, so adding it */
	-SUM(R.TaxAmount) As Tax,
	SUM(R.Amount) As Gross
FROM
	Discovery.dbo.Rebate AS R
WHERE
	R.TaxAmount IS NOT NULL
	AND R.AsAt <= @ToDate
	AND R.AsAt >= @FromDate
GROUP BY
	ClAccountID;
