CREATE FUNCTION [dbo].[fnFee_Accruals_GetOutsandingMFR](@ChargeDate datetime, @WrapProvider varchar(20), @TaxRate Numeric(10, 4), @BondPolicyTax Numeric(10, 4)) Returns TABLE AS

--declare @ChargeDate datetime
--declare @WrapProvider varchar(20)
--declare @TaxRate NUMERIC(10,4)
--declare @BondPolicyTax NUMERIC(10,4)

--SET @WrapProvider = 'OM'
--SET @ChargeDate = '01 june 2018'
--SET @TaxRate = 20.0
--SET @BondPolicyTax = 10.0
--;
RETURN

WITH FADTOTALS AS (
	SELECT	FAD.SECAId,
			SECA.CLAccountID,
			CB.ChargeBasisName,
			RS.RebateScheduleName,
			SECA.PrimaryAdviser,
			FAD.ChargeDate,
			C.Company,
			C.WrapProvider,
			PD.ProductType,
			ROUND(SUM(FAD.TotalAmount), 2) AS TotalAmount,
			ROUND(SUM(FAD.TrailAmount), 2) as TrailAmount,
			0 AS VATAmount, --SUM(FAD.VATAmount) AS VATAmount, --no - just set to zero.			
			
			--OMW logic to apply:
			--only GIAS - check if Third party somehow (product sub type)
			--only CB3 rebates
			--company - third party firm is taxExempt
			--customer tax exempt (possibly existing field possibly missing build)
			-- tax amount logic repeated in ProcessMigratedAccountsRebatesCommandHandler.CalculateTaxAmount (ChargeBasis3 only)
			ROUND((
			CASE
				WHEN PD.ProductType <> 'Personal Portfolio' AND PD.ProductType <> 'CIB' THEN 0
				WHEN PD.ProductType = 'Personal Portfolio' AND C.CompanyType = 'thirdparty' AND C.IsTaxExempt = 1 THEN 0
				WHEN TEA.CLAccountId IS NOT NULL THEN 0
				ELSE --apply tax based on total or trail amount depending if account is CB3 or CB2 --round the total before calculating tax on it
					CASE
						WHEN CB.ChargeBasisName = 'ChargeBasis3' THEN round(sum(FAD.TotalAmount), 2)
						WHEN CB.ChargeBasisName = 'ChargeBasis2' THEN round(sum(FAD.TrailAmount), 2)
						ELSE 0
					END
			END
			) 
			* (
			CASE WHEN PD.ProductType ='CIB' THEN
			  @BondPolicyTax
			ELSE
			  @TaxRate
			END)  / 100, 2) As TaxAmount,			
			DATEADD(MONTH, DATEDIFF(MONTH, 0, FAD.ChargeDate)-1, 0) AS FromDate, --First day of previous month based on ChargeDate
			DATEADD(MONTH, DATEDIFF(MONTH, -1, FAD.ChargeDate)-1, -1) As ToDate, --Last Day of previous month based on ChargeDate
			I.[Security],
			AVG(FAD.Valuation) as Valuation,
			AVG(FAD.Rate) as Rate,
			FAD.CurrencyId,
			ROUND(SUM (CASE WHEN NT.Id IS NULL THEN 0 ELSE FAD.TrailAmount END), 2) NominatedTrailApplicable,
			AVG (CASE WHEN NT.Id IS NULL THEN 0 ELSE NT.Valuation END) NominatedTrailValuation
	FROM ClientAccount.dbo.Fee_Accrual_MFR AS FAD
	INNER JOIN ClientAccount.dbo.SEClientAccount AS SECA 
		ON SECA.Id = FAD.SECAId
	INNER JOIN ClientAccount.dbo.ClientDetails AS CD 
		ON SECA.ClAccountId = CD.ClAccountId
	INNER JOIN ClientAccount.dbo.Company AS C 
		ON C.Company = CD.Company
	INNER JOIN Res_db.dbo.Instruments AS I
		ON I.ID = FAD.InstrumentID
	INNER JOIN One.Charges.ChargeBases AS CB
		ON CB.ChargeBasisId = FAD.ChargeBasisId
	INNER JOIN One.Charges.RebateSchedules RS
		ON CB.RebateScheduleId = RS.RebateScheduleId
	INNER JOIN Discovery.dbo.ProductDetails AS PD 
		ON PD.ClAccountid = SECA.ClAccountID
	LEFT JOIN dbo.fnGetTaxExemptAccountsForMFR() AS TEA 
		ON TEA.ClAccountid = SECA.ClAccountID
	LEFT JOIN dbo.Fee_Accrual_NominatedTrail NT 
		ON NT.SubAccountId = FAD.SECAId
		AND NT.AsAt = FAD.AsAt
	WHERE FAD.ChargeDate <= @ChargeDate 
			AND FAD.ISProcessed = 0
			AND C.WrapProvider = @WrapProvider 
	GROUP BY FAD.SECAId,
			SECA.CLAccountID,
			CB.ChargeBasisName,
			RS.RebateScheduleName,
			SECA.PrimaryAdviser,
			FAD.ChargeDate,
			C.WrapProvider,
			PD.ProductType,
			C.Company,
			C.CompanyType,
			C.IsTaxExempt,
			I.[Security],
			FAD.CurrencyId,
			TEA.ClAccountID
	HAVING ROUND(SUM(FAD.TotalAmount), 2) <> 0
)

SELECT	FADTOTALS.ClAccountId,
		FADTOTALS.ClAccountId As DestinationClAccountID,
		FADTOTALS.ChargeBasisName,
		FADTOTALS.RebateScheduleName,
		FADTOTALS.PrimaryAdviser,
		FADTOTALS.Company, 
		FADTOTALS.WrapProvider, 
		CA.SubAccountType, 
		'MFR' AS [Type],
		'MFR' AS Category, 
		FADTOTALS.ChargeDate,
		FADTOTALS.FromDate,
		FADTOTALS.ToDate,
		FADTOTALS.ProductType,
		FADTOTALS.TotalAmount,
		FADTOTALS.TrailAmount,
		FADTOTALS.VATAmount,
		FADTOTALS.TAXAmount,
		FADTOTALS.TotalAmount AS CorporateAmount,
		FADTOTALS.[Security] as InstrumentCode,
		FADTOTALS.Valuation,
		FADTOTALS.Rate,
		FADTOTALS.CurrencyId,
		FADTOTALS.NominatedTrailApplicable,
		FADTOTALS.NominatedTrailValuation,
		CA.Status SubAccountStatus
FROM FADTOTALS 
	INNER JOIN Discovery..ClientAccount AS CA 
		ON FADTOTALS.ClAccountId = CA.ClAccountId
GO
