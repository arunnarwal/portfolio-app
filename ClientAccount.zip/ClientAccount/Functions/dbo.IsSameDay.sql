SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- =============================================
-- Author:		Ben Arnold
-- Create date: 2007-01-16
-- Description:	Returns 1 if both dates are
--              within the same calendar day,
--              otherwise returns 0.
-- =============================================
CREATE FUNCTION [dbo].[IsSameDay] 
(
	@Date1 DATETIME,
	@Date2 DATETIME
)
RETURNS TINYINT
AS
BEGIN
	DECLARE @Result TINYINT
	SELECT @Result = 
		CASE WHEN dbo.TruncateDate(@Date1) = dbo.TruncateDate(@Date2)
		THEN 1
		ELSE 0
		END
	RETURN @Result
END
GO
