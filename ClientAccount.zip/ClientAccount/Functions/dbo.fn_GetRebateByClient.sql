CREATE FUNCTION [dbo].[fn_GetRebateByClient](@AsAt as datetime)
RETURNS TABLE AS
return (

SELECT 
	SP.Id as SystemProviderID
	,SP.SystemProvider
	,WP.Id as WrapProviderID
	,WP.WrapProvider
	,NT.Id as NetworkID
	,NT.Network
	,CC.Id as CompanyID
	,CC.Company
	,BR.Id as BranchID
	,BR.Branch
	,ADV.Id as AdvCodeID
	,ADV.AdvCode
	,SECA.Id AS SECAID
	,SECA.ClAccountId
	,I.Id AS InstrumentID
	,MF.InstrumentCode
	,COALESCE(RC.Rate, RWP.Rate, RSP.Rate) AS Rate
	,COALESCE(RC.BundledRate, RWP.BundledRate, RSP.BundledRate) AS BundledRate
	,COALESCE(RC.UnBundledRate, RWP.UnBundledRate, RSP.UnBundledRate) AS UnBundledRate
	,COALESCE(RC.TrailRate, RWP.TrailRate, RSP.TrailRate) AS TrailRate
	,COALESCE(RC.FromDate, RWP.FromDate, RSP.FromDate) AS FromDate
	,COALESCE(RC.ToDate, RWP.ToDate, RSP.ToDate) AS ToDate
	,COALESCE(RC.[Status], RWP.[Status], RSP.[Status]) AS [Status]
FROM dbo.SystemProvider AS SP
INNER JOIN dbo.WrapProvider AS WP
	ON WP.SystemProvider = SP.SystemProvider
INNER JOIN dbo.Company AS CC
	ON WP.WrapProvider = CC.WrapProvider
INNER JOIN dbo.Advisor AS ADV
	ON ADV.Company = CC.Company
LEFT OUTER JOIN dbo.Branches AS BR
	ON BR.Company = CC.Company
		AND BR.Id = ADV.BranchId
LEFT OUTER JOIN dbo.Network AS NT
	ON NT.Network = CC.Network
		AND NT.WrapProvider = WP.WrapProvider
INNER JOIN dbo.SEClientAccount AS SECA
	ON ADV.AdvCode = SECA.PrimaryAdviser
CROSS APPLY Res_DB.dbo.ManagedFunds AS MF
INNER JOIN Res_DB.dbo.Instruments AS I
	ON I.Security = MF.InstrumentCode
LEFT JOIN dbo.RebateBySystemProvider AS RSP
	ON RSP.InstrumentsId = I.Id AND RSP.ProviderId = SP.Id
	AND (@AsAt >= RSP.FromDate AND (RSP.ToDate IS NULL OR @AsAt <= RSP.ToDate))
LEFT JOIN dbo.RebateByWrapProvider AS RWP
	ON RWP.InstrumentsId = I.Id AND RWP.WrapProviderId = WP.Id
	AND (@AsAt >= RWP.FromDate AND (RWP.ToDate IS NULL OR @AsAt <= RWP.ToDate))
LEFT JOIN dbo.RebateByCompany AS RC
	ON RC.InstrumentsId = I.Id AND RC.CompanyId = CC.Id
	AND (@AsAt >= RC.FromDate AND (RC.ToDate IS NULL OR @AsAt <= RC.ToDate))
)
