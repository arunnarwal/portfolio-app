 /***
<Function>
    <Description>Get concatenated customer id(s) for account</Description>
    <Parameters>
		<Parameter Name="@ClAccountId">
            <Description>ClAccountID from ClientAccount.dbo.SEClientAccount</Description>
        </Parameter>
    </Parameters>
</Function>
***/
CREATE FUNCTION dbo.fnGetCustomerIdsForReport
(
	@ClAccountId VARCHAR(20)
)
RETURNS VARCHAR(255)
AS
BEGIN
	DECLARE @InvestorType AS VARCHAR(20)
	SELECT @InvestorType = InvestorType 
	FROM dbo.ClientDetails
	WHERE ClAccountId = @ClAccountId
	
	DECLARE @CustomerIds VARCHAR(255)

	IF (@InvestorType IN ('Individ','Trust','Company'))
	BEGIN
		SELECT @CustomerIds = CONVERT(VARCHAR(20),cr.CustomerId)
		FROM dbo.SEClientAccount seca
			INNER JOIN Platform.DBAAccount.CustomerRoles cr ON seca.ID = cr.AccountId
		WHERE seca.ClAccountId = @ClAccountId
			AND cr.IsPrimaryRole = 1
	END
	ELSE IF (@InvestorType IN ('Joint'))
	BEGIN
		SELECT @CustomerIds = COALESCE(@CustomerIds + ',', '') + CONVERT(VARCHAR(20),cr.CustomerId)
		FROM dbo.SEClientAccount seca
		INNER JOIN Platform.DBAAccount.CustomerRoles cr ON seca.ID = cr.AccountId
		WHERE seca.ClAccountId = @ClAccountId
	END
	ELSE
	BEGIN
		SELECT @CustomerIds = ''
	END	

	RETURN @CustomerIds
END
