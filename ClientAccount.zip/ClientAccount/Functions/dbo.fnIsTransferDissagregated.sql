/***
<Function>
    <Description>Check if the transfer is Disaggregated</Description>
    <Parameters>
        <Parameter Name="@BatchId">
            <Description>Specific Cash Entry batch ID to check</Description>
        </Parameter>
    </Parameters>
</Function>
***/
CREATE FUNCTION [dbo].[fnIsTransferDissagregated]
(
    @BatchId INT = 0
)
RETURNS BIT
AS BEGIN

DECLARE @IsTransferDissagregated BIT = 0

SELECT @IsTransferDissagregated = CASE WHEN ST.Disaggregated = 1 THEN 1 ELSE 0 END FROM Discovery.dbo.ScripTransferRequest ST WHERE ST.BatchID = @BatchId

RETURN @IsTransferDissagregated

END