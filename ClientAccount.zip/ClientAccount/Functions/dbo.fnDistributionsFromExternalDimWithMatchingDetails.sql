Create function dbo.fnDistributionsFromExternalDimWithMatchingDetails(@recId as integer, @tableConstant as varchar(50))
returns table
AS
return
Select
DFE.Id,
DFE.ManagerId,
DFE.ClAccountID,
DFE.PartnerRef,
DFE.Type,
DFE.Description,
DFE.Date,
DFE.Amount,
DFE.BankPaymentReference,
DFE.TaskRequestId,
RR.ID as ReconciledResultId,
RR.DateAdded as DateReconciled 
from Discovery.dbo.vwDistributionsFromExternalDim DFE
left outer join ClientAccount.dbo.Reconciledresults RR
	on RR.IdFIeldValue = DFE.Id 
	and RR.RecId = @recId
	and RR.TableConstant = @tableConstant

