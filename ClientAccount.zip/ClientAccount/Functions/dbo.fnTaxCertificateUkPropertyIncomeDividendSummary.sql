CREATE FUNCTION [dbo].[fnTaxCertificateUkPropertyIncomeDividendSummary](@FromDate datetime, @ToDate datetime)
RETURNS TABLE
AS
RETURN

/*
USE ClientAccount

DECLARE @FromDate DATETIME;
DECLARE @ToDate DATETIME;

SET @FromDate = '2016-04-06 00:00:00';
SET @ToDate = '2017-04-05 00:00:00';
*/

SELECT
	ClAccountID,
	SUM(Gross) - SUM(WT) + SUM(Equalisation) AS Net,
	SUM(WT) AS Tax,
	SUM(Gross) AS Gross
FROM
	dbo.vwTaxableIncomeDataForUK
WHERE
	LedgerDate >= @FromDate
	AND LedgerDate <= @ToDate
	AND Reversal IS NULL
	AND [Type] = 'Dividend'
	AND ((MFIncomeType = 'Dividend' And SecuritySubType = 'ManagedFund') OR SecuritySubType <> 'ManagedFund')
	AND Domicile = 'UK'
	AND SubAccountType IN ('Wrap Cash','Personal Portfolio')
	AND PID = 1
GROUP BY
	ClAccountID;
