CREATE FUNCTION [dbo].[fnGetTotalCompanyHoldersByInstrumentCode] (@AsAt datetime, @Company VarChar(20), @InstrumentCode varchar(20))
RETURNS TABLE 
AS
RETURN
/*declare @AsAt datetime, @Company varchar(20), @InstrumentCode varchar(20)
set @AsAt=getdate()
set @Company='BARCLAYSDEF'
set @InstrumentCode='00OQ.GB' */
select Count(ClAccountID) as NumberOfClients, sum(Quantity) as Quantity
from (
select CD.ClAccountID, sum(ST.Quantity) as Quantity
		from dbo.ScripTransactions ST 
			LEFT JOIN dbo.ClientDetails CD ON CD.ClAccountID = ST.ClAccountID
		where  ST.AsAt <= @AsAt AND CD.Company = @Company and ST.InstrumentCode=@InstrumentCode
		group by ST.InstrumentCode,CD.ClAccountID
		having sum(ST.Quantity) <> 0) a
