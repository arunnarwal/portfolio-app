

CREATE FUNCTION [dbo].[fnGetTrustCorrespondentsNames]() 
RETURNS TABLE AS RETURN (
	SELECT
		CA_AH.ClAccountId AS ClAccountId,
		CA_AH.Given AS CorrespondentGiven,
		CA_AH.Surname AS CorrespondentSurname
	FROM dbo.AccountHolders CA_AH
		INNER JOIN dbo.TrustParticipantDetails CA_TPD
			ON CA_AH.ClAccountId = CA_TPD.ClAccountId
			AND  CA_AH.HolderNumber = CA_TPD.HolderNumber
	WHERE CA_TPD.IsCorrespondent = 1
)
