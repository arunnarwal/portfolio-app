SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[fnIsLastDayOfQuarter] 
(
	@Date DATETIME
)
RETURNS BIT
AS
BEGIN
Declare @IsLastDayofQuarter as BIT
Declare @LastDayOfQuarter DATETIME

SET @LastDayOfQuarter = dbo.fnGetLastDayOfQuarter(@Date)


IF @Date  =  @LastDayOfQuarter 
	SET @IsLastDayofQuarter = 1
ELSE 
	SET @IsLastDayofQuarter = 0	
	
RETURN @IsLastDayOfQuarter

END
GO
