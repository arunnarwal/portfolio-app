

-- =============================================

-- Author: vjablons

-- Create date: june 2011

-- Description: Function to display manual cash adjustments for failed direct debit.

-- Breaks the info down by ClAccountId, parameters specify the timeframe.

-- =============================================

CREATE FUNCTION [dbo].[fnFailedContributionsBySubAccounts]

(

-- Add the parameters for the function here

@fromdate datetime,

@todate datetime

)

RETURNS TABLE

AS

RETURN

(

SELECT 

CLT.ClAccountId as claccountid, sum(MCAR.Amount) as amount

FROM 

dbo.CashLedgerTransactions as CLT

LEFT JOIN dbo.ManualCashAdjustmentRequests as MCAR ON replace(CLT.Reference,'ADJ','') = MCAR.Id AND LEFT(CLT.Reference,3) = 'ADJ'

WHERE

CLT.LedgerDate between @fromdate AND @todate

AND CLT.MovementType = 'CAPITAL_OUT'

AND CLT.MovementSource = 'ManualCashAdj' 

AND MCAR.AdjustmentType = 'Failed Direct Debit'

AND abs(MCAR.Amount)=abs(CLT.Amount)

GROUP BY CLT.ClAccountId

)
GO
