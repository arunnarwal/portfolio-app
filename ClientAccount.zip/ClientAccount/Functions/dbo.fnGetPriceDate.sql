SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Mark Mein
-- Create date: 2011-01-16
-- Description:	Returns the last weekday if date is a weekend
-- =============================================
CREATE FUNCTION [dbo].[fnGetPriceDate] 
(
	@Date DATETIME
)
RETURNS DATETIME
AS
BEGIN
	DECLARE @Result DATETIME
	SELECT @Result = CASE 
						WHEN DATEPART(dw, @Date) = 7 THEN DATEADD(dd, -1, @Date) --Saturday, go back to Friday
						WHEN DATEPART(dw, @Date) = 1 THEN DATEADD(dd, -2, @Date) --Sunday, go back to Friday
						ELSE @Date
					END 
	RETURN @Result
END
GO
