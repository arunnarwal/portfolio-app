

CREATE FUNCTION [dbo].[fnGetISAContributionsAtHeadAccountLevel]
              (@taxyearstartdate DATETIME,
               @taxyearenddate DATETIME)
RETURNS TABLE
AS
  RETURN
    
    /*declare @taxyearstartdate datetime, @taxyearenddate datetime
    set @taxyearstartdate = '2015-04-06 00:00:00.000' 
    set @taxyearenddate = '2016-04-04 00:00:00.000'
	*/
   
	SELECT HeadAccounts.HeadAccountId,
		   SUM(ISAContributions.CurrentTaxContribution) AS CurrentISAContribution
	FROM   (SELECT CON.ClAccountId AS HeadAccountId, 
				   CON.SubClAccountId AS SubAccountId
			FROM   dbo.Consolidate CON
				   LEFT JOIN dbo.SEClientAccount SEC ON CON.ClAccountId = SEC.ClAccountId
				   LEFT JOIN dbo.HierarchyEntities HIE ON SEC.Id = HIE.EntityId
				   LEFT JOIN dbo.HierarchyLevels HIL ON HIE.HierarchyLevelId = HIL.HierarchyLevelId
			WHERE CON.ClAccountId <> CON.SubClAccountId
				  AND HIL.HierarchyLevelName = 'ClientAccount') AS HeadAccounts

			LEFT JOIN (SELECT   ClAccountId,
								Sum(CurrentTaxContribution) AS CurrentTaxContribution
					   FROM     (SELECT   ClAccountId,
										  Sum(Amount) AS CurrentTaxContribution
								 FROM     Discovery.dbo.CashEntry
								 WHERE    MovementType IN ('Capital In','CAPITAL_IN')
										  AND Status = 'Completed'
										  AND ExcludeFromSubLimit = 0
										  AND DateCompleted >= @taxyearstartdate
										  AND DateCompleted < @taxyearenddate
										  AND ClAccountId IN (SELECT ClAccountId
															  FROM   Discovery.dbo.ProductDetails
															  WHERE  ProductType IN ('Stocks/Shares','Cash')
																	 AND COALESCE(IsDfmManaged,0) = 0
																	 AND COALESCE(IsPlatformFund,0) = 0)
								 GROUP BY ClAccountId
								 UNION ALL
								 SELECT   PD.ClAccountId,
										  Sum(CE.Amount) AS CurrentTaxContribution
								 FROM     Discovery.dbo.CashEntry CE
										  INNER JOIN Discovery.dbo.ProductDetails PD
										  ON CE.AccountNumber = PD.ClAccountId
								 WHERE    CE.MovementType IN ('Capital In','CAPITAL_IN')
										  AND CE.Status = 'Completed'
										  AND CE.Type = 'Withdrawal'
										  AND CE.ExcludeFromSubLimit = 0
										  AND CE.DateCompleted >= @taxyearstartdate
										  AND CE.DateCompleted < @taxyearenddate
										  AND CE.Method = 'Internal Transfer'
										  AND PD.ProductType IN ('Stocks/Shares','Cash')
										  AND COALESCE(PD.IsDfmManaged,0) = 0
										  AND COALESCE(PD.IsPlatformFund,0) = 0
								 GROUP BY PD.ClAccountId) ISACalculation
						  GROUP BY ISACalculation.ClAccountId) AS ISAContributions
	ON HeadAccounts.SubAccountId = ISAContributions.ClAccountId
	GROUP BY HeadAccounts.HeadAccountId
GO