CREATE FUNCTION [dbo].[fnTaxCertificateUkBondGiltInterestSummary](@FromDate datetime, @ToDate datetime)
RETURNS TABLE
AS
RETURN

/*
USE ClientAccount

DECLARE @FromDate DATETIME;
DECLARE @ToDate DATETIME;

SET @FromDate = '2016-04-06 00:00:00';
SET @ToDate = '2017-04-05 00:00:00';
*/

SELECT
	ClAccountID,
	SUM(Gross) - SUM(WT) AS Net,
	SUM(WT) AS Tax,
	SUM(Gross) AS Gross
FROM
	dbo.vwTaxableIncomeDataForUK
WHERE
	LedgerDate >= @FromDate
	AND LedgerDate <= @ToDate
	AND Reversal IS NULL
	AND [Type] = 'Interest'
	AND Domicile = 'UK'
	AND InstrumentCode <> 'GBPCash'
	AND IsBond = 1
	AND SubAccountType IN ('Wrap Cash','Personal Portfolio')
	AND SecuritySubType <> 'Term Deposit'
GROUP BY
	ClAccountID;