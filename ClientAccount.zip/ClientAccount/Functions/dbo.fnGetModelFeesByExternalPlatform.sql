/***
<Function>
  <Description>Main data source for Model Fees Report (task 20886)</Description>
</Function>
***/

CREATE FUNCTION [dbo].[fnGetModelFeesByExternalPlatform]
               (@fromDate DATETIME,
                @toDate   DATETIME)
RETURNS TABLE
AS
  RETURN
    (SELECT   ClAccountId,
              PlatformId,
              PortfolioId,
              TranType,
              Sum(NetAmount) total,
			  sum(totalamount) GrossAmount,
			  sum(VATAmount) TaxAmount
     FROM     (SELECT arl.AsAt,
                      arl.ClAccountId,
                      arl.NetAmount,
                      arl.TranType,
                      ca.PortfolioId,
                      mem.PlatformId,
					  arl.TotalAmount,
					  arl.VATAmount
               FROM   Discovery.dbo.AdvisorRevenueLedger arl
                      INNER JOIN Discovery.dbo.ClientAccount ca
                        ON ca.ClaccountId = arl.ClaccountId
                      INNER JOIN dbo.ClientDetails cd
                        ON cd.ClaccountId = arl.ClaccountId
                      INNER JOIN dbo.AccountPlatformMembership mem
                        ON mem.AccountId = cd.Id
               WHERE  arl.AsAt >= @fromDate
                      AND arl.AsAt <= @toDate
                      AND arl.GLPosted = 'Yes') iq
     GROUP BY iq.ClAccountId,
              iq.PlatformId,
              iq.PortfolioId,
              iq.TranType)
GO