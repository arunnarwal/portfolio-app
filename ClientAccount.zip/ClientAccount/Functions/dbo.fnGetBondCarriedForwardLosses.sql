CREATE FUNCTION [dbo].[fnGetBondCarriedForwardLosses](@AsAt DATETIME) Returns TABLE AS
RETURN

--DECLARE @AsAt AS DATETIME
--SET @AsAt =' 15-Aug-2019'
WITH BondCarriedForwardLosses AS(
SELECT
  cfl.SubAccountId,
  COALESCE(cflH.ValidFrom, cfl.ValidFrom) AS ValidFrom,
  COALESCE(cflH.BondInstrumentsCarriedForwardLosses, cfl.BondInstrumentsCarriedForwardLosses) AS BondInstrumentsCarriedForwardLosses,
  COALESCE(cflH.BondInstrumentsCarriedForwardLossesCurrencyId, cfl.BondInstrumentsCarriedForwardLossesCurrencyId) AS BondInstrumentsCarriedForwardLossesCurrencyId,
  COALESCE(cflH.EquityInstrumentsCarriedForwardLosses, cfl.EquityInstrumentsCarriedForwardLosses) AS EquityInstrumentsCarriedForwardLosses,
  COALESCE(cflH.EquityInstrumentsCarriedForwardLossesCurrencyId, cfl.EquityInstrumentsCarriedForwardLossesCurrencyId) AS EquityInstrumentsCarriedForwardLossesCurrencyId,
  COALESCE(cflH.PtcChargeSourceTypeId, cfl.PtcChargeSourceTypeId) AS PtcChargeSourceTypeId,
  COALESCE(cflH.PtcChargeSourceId, cfl.PtcChargeSourceId) AS PtcChargeSourceId
FROM dbo.BondCarriedForwardLosses cfl
  LEFT JOIN dbo.BondCarriedForwardLossesHistory cflH
    ON cflH.SubAccountId =  cfl.SubAccountId
	  AND cflH.ValidFrom < @AsAt AND cflH.ValidTo >= @AsAt
WHERE COALESCE(cflH.ValidFrom, cfl.ValidFrom)  <= @AsAt
)

SELECT 
  T.SubAccountId,
  T.ValidFrom,
  T.BondInstrumentsCarriedForwardLosses,
  T.BondInstrumentsCarriedForwardLossesCurrencyId,
  T.EquityInstrumentsCarriedForwardLosses,
  T.EquityInstrumentsCarriedForwardLossesCurrencyId,
  T.PtcChargeSourceTypeId,
  T.PtcChargeSourceId
 FROM
(
  SELECT *,ROW_NUMBER() OVER(PARTITION BY SubAccountId ORDER BY ValidFrom DESC) RN
  FROM BondCarriedForwardLosses
)T
WHERE T.RN = 1


GO
