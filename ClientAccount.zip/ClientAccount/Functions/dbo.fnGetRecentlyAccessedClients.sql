SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[fnGetRecentlyAccessedClients](@userId int,@excludeSubAccounts int = 0)
RETURNS TABLE AS RETURN

WITH allowedSessions AS (
	SELECT TOP 100
		WWCS.ClAccountID, 
		WWCS.AccountName,
		WWCS.Status,
		WWCS.LastUpdated
	FROM         
		dbo.vwbaseAllowedClaccountID AS CA 
	INNER HASH JOIN dbo.WorkflowWizardClientSession AS WWCS 
		ON CA.ClAccountID = WWCS.ClAccountID AND WWCS.LastUpdated > DATEADD(dd,-31,GETDATE()) AND WWCS.CLAccountID IS NOT NULL
	WHERE
		ca.ClientID = @UserID and
		(@excludeSubAccounts = 0 or (@excludeSubAccounts = 1 and ca.claccountid not like '%-%'))
	ORDER BY 
		WWCS.LastUpdated DESC
)

SELECT TOP 20 claccountid,accountname,max(lastupdated) LastUpdated,status,company FROM (
	SELECT
		allowedSessions.ClAccountID, 
		coalesce(allowedSessions.AccountName,seca.accountname) AS accountname,
		allowedSessions.Status,
		allowedSessions.LastUpdated,
		CD.Company 
	FROM allowedSessions
		INNER JOIN dbo.seclientaccount seca
			ON seca.claccountid = allowedSessions.claccountid 
		INNER JOIN dbo.clientdetails cd
			ON seca.claccountid = cd.claccountid
) t
GROUP BY claccountid,accountname,status,company
ORDER BY max(LastUpdated) DESC
GO
