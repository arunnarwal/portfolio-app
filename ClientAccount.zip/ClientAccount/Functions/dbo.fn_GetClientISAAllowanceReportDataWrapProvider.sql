SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[fn_GetClientISAAllowanceReportDataWrapProvider](@taxyearstartdate DATETIME, @tye DATETIME, @WrapProvider varchar(20))
RETURNS TABLE

AS
RETURN

--DECLARE @taxyearstartdate DATETIME, @tye DATETIME, @WrapProvider varchar(20)
--SET @taxyearstartdate = '2009-04-06 00:00:00.000' 
--SET @tye = '2012-04-06 00:00:00.000'
--SET @WrapProvider = 'AV'

SELECT 
	Account.CLAccountID,
	Account.AccountName,
	DOB.DateOfBirth,
	Account.Company,
	Account.AdvCode,
	Account.AdvName,
	Account.BaseCCY,
	COALESCE (ISAContributions.CurrentTaxContribution, 0) AS CurrentTaxContribution,
	COALESCE (DueContributions.TotalAmount, 0) AS DueTaxContribution,
	COALESCE (NextTYContribution.TotalAmount, 0) AS NextTYContributions
FROM (
	SELECT
		ClAccountID,
		Status,
		Company,
		AccountName,
		AdvCode,
		AdvName,
		TermsAndConditionsAgreed,
		HeadClAccountID,
		BaseCCY
	FROM ClientAccount..vwCombinedClientDetails
	WHERE 
		Status IN ('Active' ,'Submitted')
		AND SubAccountType = 'ISA'
		AND ClAccountID IN (
			SELECT ClAccountID 
			FROM Discovery..ProductDetails 
			WHERE 
				ProductType = 'Stocks/Shares' 
				AND IsDfmManaged = 0 
				AND IsPlatformFund = 0
			)
	) AS Account
LEFT JOIN (
	SELECT 
		DateOfBirth,
		ClAccountID 
	FROM ClientAccount..AccountHolders 
	WHERE HolderNumber = 1) DOB
	ON Account.HeadClAccountID = DOB.ClAccountID
INNER JOIN ClientAccount..Company CO
	ON CO.Company = Account.Company AND CO.WrapProvider = @WrapProvider
LEFT JOIN (
	SELECT 
		ClAccountID,
		SUM(CurrentTaxContribution) AS CurrentTaxContribution
	FROM (
		SELECT 
			ClAccountID,
			SUM(Amount) CurrentTaxContribution
		FROM Discovery..CashEntry
		WHERE 
			MovementType IN ('Capital In', 'CAPITAL_IN') --Issue 337325: unfortunately we have to have both of these variants here (and all other movementtype conditions below)
			AND Status = 'Completed'
			AND ExcludeFromSubLimit = 0 
			AND COALESCE(ISASubscriptionDate, DateCompleted) >= @taxyearstartdate 
			AND COALESCE(ISASubscriptionDate, DateCompleted) < @tye --Issue 727879: Added COALESCE to defaultly calculate with ISASubscriptionDate instead of DateCompleted
			AND ClAccountID IN (
				SELECT ClAccountID
				FROM Discovery..ProductDetails
				WHERE 
					ProductType = 'Stocks/Shares'
					AND IsDfmManaged = 0
					AND IsPlatformFund = 0
				)
		GROUP BY ClAccountID
		
		UNION ALL
		
		SELECT
			PD.ClAccountid,
			SUM(Amount) CurrentTaxContribution
		FROM Discovery..CashEntry CE
		INNER JOIN Discovery..ProductDetails PD
			ON CE.AccountNumber = PD.ClAccountid  --Issue 337325: this had join on ce.claccountid, which is incorrect for internal transfers
		WHERE
			MovementType IN ('Capital In', 'CAPITAL_IN')
			AND Status = 'Completed'
			AND Type = 'Withdrawal'
			AND ExcludeFromSubLimit = 0
			AND COALESCE(ISASubscriptionDate, DateCompleted) >= @taxyearstartdate
			AND COALESCE(ISASubscriptionDate, DateCompleted) < @tye --Issue 727879: Added COALESCE to defaultly calculate with ISASubscriptionDate instead of DateCompleted
			AND Method = 'Internal Transfer'
			AND ProductType = 'Stocks/Shares'
			AND IsDfmManaged = 0 and isplatformfund = 0
		GROUP BY PD.ClAccountID
	) X
GROUP BY X.ClAccountID
) AS ISAContributions
	ON Account.CLAccountID = ISAContributions.CLAccountID
LEFT JOIN ( 
	SELECT 
		ClAccountID,
		SUM(Value) TotalAmount
	FROM (
		SELECT 
			ClAccountID,
			SUM(
				CASE 
					WHEN COALESCE(ISASubscriptionDate, DateCompleted) >= @taxyearstartdate
						AND COALESCE(ISASubscriptionDate, DateCompleted) < @tye  --Issue 727879: Added COALESCE to defaultly calculate with ISASubscriptionDate instead of DateCompleted
						THEN 1 
						ELSE 0 
				END +
				CASE 
					WHEN Frequency = 'Monthly' 
						THEN 
							CASE 
								WHEN DATEPART(D,NextPayDate) < DATEPART(D,@tye) 
									THEN 1 
								ELSE 0 
							END +
							CASE 
								WHEN InstructionType = 'Standing' 
									THEN DATEDIFF(M, NextPayDate, DATEADD(M, DATEDIFF(M, 0, @tye), 0))
								ELSE 1 
							END
					WHEN Frequency = 'Quarterly'
						THEN 
							CASE
								WHEN DATEPART(D, NextPayDate) < DATEPART(D, @tye)
									THEN 1
								ELSE 0 
							END +
							CASE
								WHEN InstructionType = 'Standing' 
									THEN DATEDIFF(Q, NextPayDate, DATEADD(Q, DATEDIFF(Q, 0, @tye), 0)) 
								ELSE 1
							END
					WHEN Frequency = 'Yearly' 
						THEN 
							CASE 
								WHEN DATEPART(D, NextPayDate) < DATEPART(D, @tye)
									THEN 1
								ELSE 0 
							END +
							CASE 
								WHEN InstructionType = 'Standing'
									THEN DATEDIFF(YY, NextPayDate, DATEADD(M, DATEDIFF(M, 0, @tye), 0))
								ELSE 1
							END 
					ELSE 1 
				END * Amount
			) AS Value
		FROM Discovery..CashEntry 
		WHERE
			InstructionType IN ('Standing')
			AND MovementType IN ('Capital In', 'CAPITAL_IN')
			AND Status IN ('Authorised', 'Placed')
			AND ExcludeFromSubLimit = 0
			AND NextPayDate <= @tye
		GROUP BY ClAccountID
	
		UNION ALL

		SELECT
			ClAccountID,
			SUM(Amount) Value
		FROM Discovery..CashEntry
		WHERE
			InstructionType IN ('Auto', 'One-off')
			AND MovementType IN ('Capital In', 'CAPITAL_IN')
			AND Status IN ('Authorised', 'Placed')
			AND ExcludeFromSubLimit = 0 
			AND NextPayDate <= @tye
		GROUP BY ClAccountID
	) Tab1
	GROUP BY ClAccountID
) DueContributions
	ON Account.CLAccountID = DueContributions.CLAccountID
LEFT JOIN ( 
	SELECT 
		ClAccountID,
		SUM(Value) TotalAmount
	FROM (
		SELECT 
			ClAccountID, 
			SUM(Amount *
				CASE 
					WHEN Frequency = 'Monthly' 
						THEN 12 
					WHEN Frequency = 'Quarterly' 
						THEN 4 
					WHEN Frequency = 'Yearly' 
						THEN 1
					ELSE 0 
				END
			) Value
		FROM Discovery..CashEntry
		WHERE 
			InstructionType IN ('Standing')
			AND MovementType IN ('Capital In', 'CAPITAL_IN') 
			AND Status IN ('Authorised', 'Placed')
			AND ExcludeFromSubLimit = 0
		GROUP BY ClAccountID

		UNION ALL 

		SELECT 
			AccountNumber ClAccountID,
			SUM(Amount) Value
		FROM Discovery..CashEntry
		WHERE
			InstructionType IN ('Auto', 'One-off')
			AND Method = 'Internal Transfer'
			AND MovementType IN ('Capital In', 'CAPITAL_IN')
			AND Status IN ('Authorised', 'Placed')
			AND ExcludeFromSubLimit = 0
			AND FirstDate >= @tye
		GROUP BY AccountNumber
	) Tab2
	GROUP BY ClAccountID
) NextTYContribution
	ON Account.CLAccountID = NextTYContribution.CLAccountID
GO