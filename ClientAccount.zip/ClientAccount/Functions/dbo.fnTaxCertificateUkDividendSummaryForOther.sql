CREATE FUNCTION [dbo].[fnTaxCertificateUkDividendSummaryForOther](@FromDate datetime, @ToDate datetime)
RETURNS TABLE
AS
RETURN

/*
USE ClientAccount

DECLARE @FromDate DATETIME;
DECLARE @ToDate DATETIME;

SET @FromDate = '2016-04-06 00:00:00';
SET @ToDate = '2017-04-05 00:00:00';
*/

SELECT
	ClAccountID,
	SUM(AmtPaid) AS Net,
	SUM(WT) AS Tax,
	SUM(Gross) AS Gross
FROM
	dbo.fnTaxCertificateUkDividendSummary(@FromDate, @ToDate)
WHERE
	SecuritySubType <> 'ManagedFund'
GROUP BY
	ClAccountID;
