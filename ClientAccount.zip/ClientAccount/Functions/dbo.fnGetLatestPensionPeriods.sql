/***
<Function>
    <Description>Returns latest pension for periods for the supplied account number</Description>
    <Parameters>
        <Parameter Name="@ClAccountId">
            <Description>Account number to look up</Description>
        </Parameter>
    </Parameters>
</Function>
***/
CREATE FUNCTION dbo.fnGetLatestPensionPeriods
(
    @ClAccountID VARCHAR(20)
)
RETURNS TABLE AS RETURN 
(
    WITH TotalCount AS
    (
        SELECT @ClAccountId AS ClAccountId, COUNT(1) AS TotalCount
        FROM dbo.SippDetailsHistory
        WHERE ClAccountId = @ClAccountId
    )
    SELECT TOP 1
        H.ID,
        H.ClAccountID,
        H.InputPeriodStart,
        H.InputPeriodEnd,
        H.Nominated,
        C.TotalCount
    FROM dbo.SippDetailsHistory H
    INNER JOIN TotalCount C ON H.ClAccountId = C.ClAccountId
    WHERE H.ClAccountId = @ClAccountId
    ORDER BY ID DESC
)
GO
