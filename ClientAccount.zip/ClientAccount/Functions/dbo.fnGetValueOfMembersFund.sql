SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

/*
 ============================================= 
 Author:  jkrampol  
 Create date: 29 October 2012 
 Description: returns data which are used for RPSCOM100 Report for Zurich Corporate
 =============================================  
*/

CREATE function [dbo].[fnGetValueOfMembersFund](@headAccountId varchar(20), @AsAt datetime)  RETURNS TABLE AS return 

WITH CM AS (
	SELECT isnull(Sum(Amount),0) AS CMAmount, claccountid   
	FROM ClientAccount.dbo.CMTTrans
	WHERE trANDate <= @AsAt 
	AND claccountid like @headAccountId+'%'
	GROUP BY claccountid
),
ExternalCASh AS (
	SELECT isnull(Sum(Amount),0) AS ExternalAmount, claccountid 
	FROM ClientAccount.dbo.CAShTransactions
	WHERE transstatus <> 'cancelled'     
	AND location = 'external' 
	AND ASAt <= @AsAt 
	AND claccountid like @headAccountId+'%'
	GROUP BY claccountid
),
LedgerAdj AS (
	SELECT -round(isnull(Sum(Amount),0),2) AS LedgerAdjAmount, claccountid 
	FROM ClientAccount.dbo.CAShLedgerAdjustments
	WHERE ledgerDate <= @AsAt 
	AND PortfolioAdjust = 1 
	AND claccountid like @headAccountId+'%'
	GROUP BY claccountid
),
Ledger AS (
	SELECT -round(isnull(Sum(Amount),0),2) AS LedgerAmount, claccountId 
	FROM ClientAccount.dbo.CAShLedgerTransactions
	WHERE ledgerDate <= @AsAt 
	AND claccountid like @headAccountId+'%'
	GROUP BY claccountID
),
SumOfAmounts AS (
	SELECT 
		left(CM.claccountid, LEN(CM.claccountid) - 4) AS headAccountID,
		CM.claccountid, 
		isnull(CMAmount,0) AS CMAmount, 
		isnull(ExternalAmount,0) AS ExternalAmount, 
		isnull(LedgerAdjAmount,0) AS LedgerAdjAmount, 
		isnull(LedgerAmount,0) AS LedgerAmount,
		isnull(CMAmount,0) + isnull(ExternalAmount,0) + isnull(LedgerAdjAmount,0) + isnull(LedgerAmount,0) AS SumOfAmounts
	FROM CM
		LEFT JOIN ExternalCASh ON CM.claccountid = ExternalCASh.claccountid
		LEFT JOIN LedgerAdj ON CM.claccountid = LedgerAdj.claccountid
		LEFT JOIN Ledger ON CM.claccountid = Ledger.claccountid
	WHERE cm.claccountid like @headAccountId+'%'
	AND isnull(CMAmount,0) + isnull(ExternalAmount,0) + isnull(LedgerAdjAmount,0) + isnull(LedgerAmount,0) <> 0
),
SumOfAmountsTotal AS (
	SELECT 
		isnull(Sum(SumOfAmounts),0) AS SumOfAmounts, 
		headAccountID 
	FROM SumOfAmounts
	GROUP BY headAccountID
),
Quantities AS
(
	SELECT claccountid, instrumentCode, isnull(Sum(Quantity),0) QuantitySum 
	FROM clientaccount..ScripTransactions
	WHERE ASat <= @AsAt 
	GROUP BY InstrumentCode,claccountid
),
ScripTransactionsTotal AS
(
	SELECT 
		left(Q.claccountid, LEN(Q.claccountid) - 4) AS headAccountID,
		Sum(Q.QuantitySum * Sec.o) AS ScripTransactionsTotal
	FROM Quantities Q
	LEFT JOIN res_db.dbo.securities Sec
	ON Sec.security = Q.instrumentCode
	WHERE Sec.date = @AsAt
	AND claccountid like @headAccountId+'%'
	GROUP BY left(Q.claccountid, LEN(Q.claccountid) - 4)
),
ValueOfMembersFund AS 
(
	SELECT 
		stt.headaccountid,
		stt.ScripTransactionsTotal,
		soat.SumOfAmounts,
		isnull(stt.ScripTransactionsTotal, 0) + isnull(soat.SumOfAmounts, 0) AS ValueOfMembersFund 
	FROM ScripTransactionsTotal stt 
	LEFT JOIN SumOfAmountsTotal soat ON stt.headaccountid  = soat.headaccountid
)
SELECT 
	ValueOfMembersFund.*, 
	Round(ValueOfMembersFund,0) AS RoundedValueOfMembersFund 
FROM ValueOfMembersFund
GO
