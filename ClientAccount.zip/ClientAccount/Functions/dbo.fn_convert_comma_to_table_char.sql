SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[fn_convert_comma_to_table_char]
              (@ListValues VARCHAR(max))
RETURNS @valTable TABLE(tabvalue VARCHAR(150))
AS
  BEGIN
    DECLARE  @ListValueID VARCHAR(150),
             @Pos         INT
                          
    SET @ListValues = LTRIM(RTRIM(@ListValues)) + ','
                                                  
    SET @Pos = CHARINDEX(',',@ListValues,1)
               
    IF REPLACE(@ListValues,',','') <> ''
      BEGIN
        WHILE @Pos > 0
          BEGIN
            SET @ListValueID = LTRIM(RTRIM(LEFT(@ListValues,@Pos - 1)))
                               
            IF @ListValueID <> ''
              BEGIN
                INSERT INTO @valTable
                           (tabvalue)
                VALUES     (@ListValueID)
              END
              
            SET @ListValues = RIGHT(@ListValues,LEN(@ListValues) - @Pos)
                              
            SET @Pos = CHARINDEX(',',@ListValues,1)
          END
      END
      
    RETURN
  END
GO
