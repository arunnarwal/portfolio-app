CREATE FUNCTION [dbo].[fn_GetNetValueByClAccountId]
(
	@ClAccountId VARCHAR(255)
)
RETURNS DECIMAL (18,2)
AS
BEGIN
	DECLARE @TotalValue DECIMAL (18,2)
	SET @TotalValue = 0

	DECLARE @IDList TABLE (ID int)
	INSERT INTO @IDList
	SELECT id FROM dbo.SEClientAccount SA
	INNER JOIN ClientAccount..fnHeadAccounts() HA ON SA.ClAccountID = HA.ClAccountID
	where HA.HeadClAccountID = @ClAccountId And HA.ClAccountID <> HA.HeadClAccountID
	order by ID

	DECLARE @i INT
	SELECT @i = min(ID) FROM @IDList
	WHILE @i is not null
	BEGIN  
	  SELECT TOP 1 @TotalValue = @TotalValue + (CashAmount + NonCashAmount + BTAAmount) 
	  FROM Cache.dbo.Fee_FUM_ByAccount_Archive WHERE SECAId = @i ORDER BY AsAt DESC  
	  SELECT @i = min(ID) FROM @IDList WHERE ID > @i
	END
	RETURN @TotalValue
END