SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[fn_CashEntriesWhereInitialCommissionByValueExceedsMaximumPercentage](@clientid int,@fromdate as datetime, @toDate as datetime) 

Returns TABLE 

as

/*

* Author:imcghee

* Date created: 21 jan 2009

* Intended Purpouse: The Aim is to identify all Cash Entries where commission was choosen By amount ,

* That have had there amount adjusted downwards and as a result the Commission exceeds

* the Maximum Percentage defined in the product terms 

*/

return 

with OriginalCashEntry as /* Get Original cash entry value */

(Select ORIG.EditID ,ECE.CashID, ECE.Amount from 

(select min(editid) as editid,cashid from discovery..EditCashEntry Group by cashid) as ORIG

inner Join discovery..EditCashEntry ECE on ORIG.EditId=ECE.EditID 

inner join discovery..Cashentry CE on ECE.CashID=CE.ID

Where CE.Status ='Completed'and CE.type='Deposit' and CE.ICMethod='BYVALUE' 

and CE.DateCompleted IS NOT null and CE.DateCompleted Between @fromDate and @todate

),

CashEntryAccount as /* Get ClientDetails */

(

select CD.Feestructure,CE.ID as cashID,SECA.PrimaryAdviser as AdvCode ,Cd.Company,SECA.AccountName ,

coalesce(TERM.DisplayTerm,PD.ProductDisplayname) as ProductName,CA.subaccounttype as subaccounttype,

b.AdviceType,

b.AdviceGiven

from discovery..CashEntry CE

INNER JOIN discovery..batch AS b ON b.batchid = ce.batchid

inner Join discovery..clientaccount CA 

on CA.claccountid=CE.claccountid

Inner Join clientaccount..fnHeadAccounts() HEAD 

on CE.claccountid=HEAD.claccountid And consolidated=0

inner Join clientaccount..ClientDetails CD on HEAD.Headclaccountid=CD.claccountid

inner Join clientaccount..SEclientaccount SECA on CE.claccountid=SECA.claccountid

inner Join discovery..productdetails PD on CE.claccountid=PD.claccountid

/* QR5 - rename NPR & PR to Scheme 1 & Scheme 2 */

left join ClientAccount..Company COM on CD.Company = COM.Company

left join ClientAccount..vwTerminologyByWrapProviderByContext TERM on PD.ProductDisplayname = TERM.Term and TERM.WrapProvider = COM.WrapProvider and TERM.Context = 'ShortForm'

Where Feestructure='Unbundled' and CE.Status ='Completed'and CE.type='Deposit' and CE.ICMethod='BYVALUE' 

and CE.DateCompleted IS NOT null and CE.DateCompleted Between @fromDate and @todate)

/* now the main query */

select COMP.Companyname, 

ADV.Name as AdviserName,

CE.claccountid,

ACCOUNTDETAILS.AccountName,

ACCOUNTDETAILS.ProductName,

coalesce(ORIGINAL.amount,CE.Amount) as OriginalCashEntryAmount,

CE.Amount as CurrentCashEntryAmount,

CE.IcValue,

CE.IcValue/CE.Amount*100 as PercentCommissionrecieved,

CE.IcValue/coalesce(ORIGINAL.amount,CE.Amount)*100 as PercentChargeExpected,

CE.DateCompleted,

BASE.clientid, 

case

When IsNull(CE.AdviceType,b.AdviceType) = 'IndependentAdvice' Then 'Independent Advice'

When IsNull(CE.AdviceType,b.AdviceType) = 'RestrictedAdviceMultiTied' Then 'Restricted Advice (Multi-Tied)'

When IsNull(CE.AdviceType,b.AdviceType) = 'RestrictedAdviceSingleTied' Then 'Restricted Advice (Single-Tied)'

When IsNull(CE.AdviceType,b.AdviceType) = 'RestrictedAdviceWholeOfMarket' Then 'Restricted Advice (Whole of Market)'

When IsNull(CE.AdviceType,b.AdviceType) = 'SimplifiedAdvice' Then 'Simplified Advice'

When IsNull(CE.AdviceType,b.AdviceType) = 'ExecutionOnly' Then 'Execution Only'

When IsNull(CE.AdviceType,b.AdviceType) = 'NonAdvised' Then 'Non-Advised'

Else ''

END as AdviceType,

case

When IsNull(CE.AdviceGiven,b.AdviceGiven) = 1 then 'Yes'

When IsNull(CE.AdviceGiven,b.AdviceGiven) = 0 then 'No'

else ''

END as AdviceGiven

from discovery..CashEntry CE

inner Join CashEntryAccount ACCOUNTDETAILS on CE.ID= ACCOUNTDETAILS.CashID

Left Join OriginalCashEntry ORIGINAL on ORIGINAL.cashid=CE.id And CE.Amount < ORIGINAL.amount

Left join clientaccount..advisor ADV on ACCOUNTDETAILS.advcode=ADV.AdvCode

Left join clientaccount..company COMP on ACCOUNTDETAILS.Company=COMP.Company

inner join clientaccount..vwBaseAllowedClAccountID BASE on CE.claccountid=BASE.claccountid

Left Join clientaccount..vwProductTermByClient PT 

on PT.claccountid=CE.claccountid and PT.termtype='Initial Commission' and PT.Status='Current' and ACCOUNTDETAILS.FeeStructure = PT.FEEStructure and PT.Product=ACCOUNTDETAILS.subaccounttype

INNER JOIN Discovery..batch AS b ON b.batchid = ce.batchid

Where Base.clientid=@clientid and CE.Status ='Completed'and CE.type='Deposit' and CE.ICMethod='BYVALUE' and CE.IcValue>CE.Amount*(pt.max/100)

and CE.DateCompleted IS NOT null and CE.DateCompleted Between @fromDate and @todate 

--select * from fn_CashEntriesWhereInitialCommissionByValueExceedsMaximumPercentage(8245,'01 jan 2006','01 sep 2009')
GO
