SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[fn_isallowedclient] (@ClAccountId VarChar(20), @clientid int) returns int AS

begin
declare @rv int;
select @rv = 0;

SELECT @rv=ClientID
FROM dbo.ClientAccountSecurity cas
inner join dbo.SEClientAccount seca on cas.advisorcodes = seca.primaryadviser and cas.claccountid is null
where seca.claccountid = @claccountid and clientid=@clientid

if @rv=0
SELECT @rv=ClientID FROM dbo.clientaccountsecurity cas
inner join dbo.Consolidate CON on CON.ClAccountID = CAS.ClAccountID
where cas.claccountid is not null
and  CON.subclaccountid = @claccountid
and cas.clientid = @clientid

RETURN @rv
end
GO
