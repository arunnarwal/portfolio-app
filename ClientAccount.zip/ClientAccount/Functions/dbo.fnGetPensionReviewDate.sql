/**
<Function>
    <Description>Function to retrive next pension review date for given sub-account.</Description>
    <Parameters>
        <Parameter Name="@SubAccountId">
            <Description>Id of Sub Account for which the review date should be retrieved.</Description>
        </Parameter>
    </Parameters>
</Function>
**/

CREATE FUNCTION dbo.fnGetPensionReviewDate(@SubAccountId INT) RETURNS DATETIME AS
BEGIN
	DECLARE @Now DATETIME = GETDATE()
	DECLARE @ReviewDate DATETIME
	DECLARE @ReferencePeriodEndDate DATETIME
	DECLARE @SubClAcountId AS VARCHAR(20)
	DECLARE @IsFlexible BIT

	SELECT TOP 1 
		@SubClAcountId = SECA.ClAccountId,
		@ReviewDate = CASE WHEN PD.FlexibleDrawdown = 1 THEN CONVERT(DATE, PD.DateCreated) ELSE SD.PensionYearStart END,
		@ReferencePeriodEndDate = SD.ReferencePeriodEndDate,
		@IsFlexible = PD.FlexibleDrawdown
	FROM
		dbo.SEClientAccount SECA
	INNER JOIN
		Discovery.dbo.ProductDetails PD ON PD.ClAccountId = SECA.ClAccountID
	LEFT JOIN
		dbo.SippDetails SD ON SD.ClAccountId = SECA.ClAccountID AND SD.ReferencePeriodEndDate IS NOT NULL
	WHERE
		SECA.Id = @SubAccountId
		AND PD.ProductType = 'NPR'
		AND PD.ArrangementType = 'Crystallised'
	
	IF (@ReviewDate IS NOT NULL)
	BEGIN
		SET @ReviewDate = CASE
		WHEN DATEADD(YY, DATEDIFF(YY, @ReviewDate, @Now), @ReviewDate) > @Now THEN
			DATEADD(YY, DATEDIFF(YY, @ReviewDate, @Now), @ReviewDate) 
		ELSE
			DATEADD(YY, DATEDIFF(YY, @ReviewDate, @Now) + 1, @ReviewDate)
		END

		IF (@ReferencePeriodEndDate IS NOT NULL AND (@IsFlexible IS NULL OR @IsFlexible != 1))
		BEGIN
			SET @ReviewDate = CASE
			WHEN DATEADD(YY, DATEDIFF(YY, @ReviewDate, @ReferencePeriodEndDate), @ReviewDate) > @ReferencePeriodEndDate THEN
				DATEADD(YY, DATEDIFF(YY, @ReviewDate, @ReferencePeriodEndDate), @ReviewDate) 
			ELSE
				DATEADD(DAY, DATEDIFF(DAY, @ReviewDate, @ReferencePeriodEndDate) + 1, @ReviewDate)
			END
		END
	END

	RETURN @ReviewDate
END