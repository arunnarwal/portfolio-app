

CREATE FUNCTION [dbo].[fn_GetPensionSchemeClientData](@fromDate as datetime, @toDate as datetime)

RETURNS TABLE AS
return (

/*declare @fromDate as datetime
declare @toDate as datetime

select @fromDate = '04-06-2012'
select @toDate = '04-05-2013';*/

-- with topFeeAssetSummaries as
-- (
-- select clAccountId, max(AsAt) as AsAt from dbo.FeeAssetSummaries where AsAt <= @todate and AsAt >= @fromdate and Product = 'SIPP' group by clAccountId
-- )

SELECT

RecordType,

PensionSchemeTaxReference,

StructuredName,

NamingConvention,

MemberName,

Nino,

Address,

PostCode,

DateOfBirth,

Gender,

COALESCE(Status,'9')as Status,

dbo.LeftPad(sum(IndividualContribution),6,'0') as IndividualContribution,

dbo.LeftPad(sum(EmployerContribution),6,'0') as EmployerContribution,

TermAssuranceContribution as TermAssuranceContribution,

dbo.LeftPad(cast(Round((sum(CashTransfers)+ sum(InspecieTransfers)),0)as int),8,'0') as TotalAmountOfTransferPaymentReceived,

/*dbo.LeftPad(sum(TotalAmountOfTransferPaymentReceived),8,'0') as TotalAmountOfTransferPaymentReceived,*/

TotalNIRebates as TotalNIRebates,

dbo.LeftPad(sum(ValueOfMembersFund),8 , '0')

as ValueOfMembersFund,

Max(DateOfFundValuation) as DateOfFundValuation,

ProductType,

WrapProvider

FROM (

SELECT

PD.WrapProvider,

'2' AS RecordType,

CASE PD.WrapProvider WHEN 'ZRP' THEN '00000000000781648RB' ELSE '' END as PensionSchemeTaxReference,

'N' As StructuredName,

'01' As NamingConvention,

Left(dbo.RightPad( COALESCE(CD.Title, '') + ' ' + COALESCE(CD.Given, '') + ' ' + COALESCE(CD.Surname, ''),50, ' '),50) As MemberName,

dbo.RightPad(COALESCE(CD.IRDNo, ''), 9, ' ') As NINO,

Left(dbo.RightPad(COALESCE(A.Address1,''), 50, ' '),50) +

Left(dbo.RightPad(COALESCE(A.Address2,''), 50, ' '),50) +

Left(dbo.RightPad(COALESCE(A.Address3,''), 50, ' '),50) +

Left(dbo.RightPad(COALESCE(A.Address5,''), 50, ' '),50) As Address,

Left(dbo.RightPad(COALESCE(A.Address4, ''), 8, ' '),8) As PostCode,

dbo.LeftPad(Convert(varchar(2), Day(CD.DateOfBirth)),2,'0') +

dbo.LeftPad(Convert(varchar(2), Month(CD.DateOfBirth)),2,'0') +

CONVERT(varchar(4), Year(CD.DateOfBirth)) As DateOfBirth,

CASE CD.Gender

WHEN 'Male' THEN 'M'

WHEN 'Female' THEN 'F'

ELSE 'U'

END As Gender,

CASE CD.EmploymentStatus
	WHEN 'Employed' THEN 1
	WHEN 'Retired' THEN 2
	WHEN 'Self Employed' THEN 3
	WHEN 'Caregiver for person over 16' THEN 6
	WHEN 'Caregiver for person under 16' THEN 5
	WHEN 'Full Time Education' THEN 7
	WHEN 'Unemployed' THEN 8
	ELSE 9 END As Status
,

COALESCE(Round(

Cast((SELECT sum(Amount)

FROM (SELECT 

CASE WHEN Contributions.SubType IS NULL AND PD.SubAccountType = 'SIPP' AND PD.ProductType = 'NPR' AND Contributions.SIPPType='Net' THEN Contributions.Amount/0.8

ELSE Contributions.SettledAmount END as Amount

from Discovery.dbo.CashEntry Contributions

where Contributions.ClAccountid=PD.ClAccountid and

Contributions.DateCompleted >= @fromDate and

Contributions.DateCompleted <= @toDate and

Contributions.SubType IS NULL AND

Contributions.[Type]='Deposit' AND

Contributions.[Status]='Completed' AND

((Contributions.AccountNumber like '%-001' and Method='Internal Transfer' )or (Method<>'Internal Transfer' )) and

(COALESCE(Contributions.Source, '') <> 'Employer')

) as Unaggregated) as int),0),0) As IndividualContribution,

COALESCE(Round(

Cast((SELECT sum(Amount)

from (select

CASE WHEN Contributions.SubType IS NULL AND PD.SubAccountType = 'SIPP' AND PD.ProductType = 'NPR' AND Contributions.SIPPType='Net' THEN Contributions.Amount/0.8

ELSE Contributions.SettledAmount END as Amount

from Discovery.dbo.CashEntry Contributions

where Contributions.ClAccountid=PD.ClAccountid and

Contributions.DateCompleted >= @fromDate and

Contributions.DateCompleted <= @toDate and

Contributions.SubType IS NULL AND

Contributions.[Type]='Deposit' AND

Contributions.[Status]='Completed' AND

Contributions.Source = 'Employer'

) as Unaggregated) as int)

,0),0) As EmployerContribution,

dbo.LeftPad(0,6,'0') As TermAssuranceContribution,

COALESCE(

(SELECT sum(Transfers.SettledAmount)

from Discovery.dbo.CashEntry Transfers

where Transfers.ClAccountid=PD.ClAccountid and

Transfers.DateCompleted >= @fromDate AND

Transfers.DateCompleted <= @toDate and

Transfers.SubType='Transfer' AND

Transfers.[Type]='Deposit' AND

Transfers.[Status]='Completed')

,0) As CashTransfers,



COALESCE(

(SELECT sum( Transfers.Quantity * prices.O )as TransferValue

from Discovery.dbo.ScripTransferRequest Transfers

inner Join Res_DB.dbo.Securities Prices on prices.Security=Transfers.Instrumentcode and Prices.Date=Res_DB.dbo.fn_DateWithPrices(Transfers.TransferCompleted)

where Transfers.ClAccountid=PD.ClAccountid and

Transfers.TransferCompleted >= @fromDate AND

Transfers.TransferCompleted <= @toDate and

Transfers.Status='Completed' and COALESCE(Transfers.TransferMode,'') <> 'CASH' )

,0) As InspecieTransfers, /*wasn't including script transfers*/

dbo.LeftPad(0,6,'0') As TotalNIRebates,

-- Cast(COALESCE(Round(FAS.TotalHolding + FAS.TotalCash,0),0)as int) As ValueOfMembersFund, /*changed from totalholding totalcash nov 2011*/

Cast(COALESCE(Round(FAS.CashValue + FAS.NonCashValue,0),0)as int) As ValueOfMembersFund, /*changed from totalholding totalcash nov 2011*/


case
	when fas.AsAt is not null then
		REPLACE(CONVERT(CHAR(10), FAS.AsAt, 103), '/', '')
	WHEN @todate < GetDate() THEN
		REPLACE(CONVERT(CHAR(10), @todate, 103), '/', '')
	ELSE
		REPLACE(CONVERT(CHAR(10), GetDate(), 103), '/', '')
END As DateOfFundValuation,

PD.ProductType

From Discovery.dbo.vwProductDetails PD

Inner Join dbo.AccountHolders CD ON CD.Claccountid = PD.HeadClAccountId and cd.HolderNumber = 1

INNER JOIN

(SELECT Address1, Address2, Address3, Address4, Address5, ClAccountID,HolderNumber FROM Discovery.dbo.Address WHERE [Type] = 'Residential') A

ON A.CLaccountid = PD.HeadClAccountId and (a.HolderNumber is null or a.HolderNumber = cd.HolderNumber)

-- left join dbo.FeeAssetSummaries FAS ON FAS.ClAccountid=PD.ClAccountid and FAS.AsAt=DATEADD(dd, 0, DATEDIFF(dd, 0, @toDate-1)) and FAS.Product='SIPP'
left join Cache.dbo.FumByAccByDate FAS ON FAS.ClAccountid=PD.ClAccountid and FAS.AsAt=DATEADD(dd, 0, DATEDIFF(dd, 0, @toDate-1)) and FAS.SubAccountType='SIPP'
-- Changed back for ZRetail this function was created for us hope nobody else uses it

-- left join (select summary.claccountId, summary.AsAt, summary.TotalHolding, summary.TotalCash from dbo.FeeAssetSummaries summary inner join topFeeAssetSummaries topfas ON summary.ClAccountid=topfas.ClAccountid and summary.AsAt = topfas.AsAt and summary.Product='SIPP') Fas on fas.clAccountId = pd.claccountId changed as part of ZR-2994
left join

(select min(coalesce(Activationdate,Inceptiondate)) as MinDateCreated, HeadClAccountId, SubAccountType from Discovery.dbo.vwProductDetails group by HeadClAccountID, SubAccountType) PD2

on PD.HeadClAccountId = PD2.HeadClAccountId and PD.SubAccountType = PD2.SubAccountType

WHERE

PD.SubAccountType = 'SIPP' and PD2.MinDateCreated <= @toDate

) as RAWDATA

WHERE (RAWDATA.IndividualContribution<>0 OR RAWDATA.EmployerContribution<>0 OR RAWDATA.TermAssuranceContribution<>0 OR RAWDATA.CashTransfers<>0 OR RAWDATA.InspecieTransfers<>0 OR RAWDATA.TotalNIRebates<>0 OR RAWDATA.ValueOfMembersFund<>0)

group by

RecordType,

PensionSchemeTaxReference,

StructuredName,

NamingConvention,

MemberName,

Nino,

Address,

PostCode,

DateOfBirth,

Gender,

Status,

TermAssuranceContribution,

TotalNIRebates,

ProductType,

WrapProvider

)
GO
