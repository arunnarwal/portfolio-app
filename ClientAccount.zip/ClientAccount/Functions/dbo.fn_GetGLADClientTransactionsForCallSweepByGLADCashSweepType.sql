SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION  [dbo].[fn_GetGLADClientTransactionsForCallSweepByGLADCashSweepType](@WrapProvider varchar(20), @GLADCashSweepType varchar(20),@batchGroupID as Integer)
Returns TABLE 
as
/*
*	Author:imcghee
*	Date created: 19 Nov 2009
*   Intended Purpouse:  
*/
--
--USE [ClientAccount]
--GO
--declare @WrapProvider varchar(20)
--declare @GLADCashSweepType varchar(20)
--declare @BatchGroupID integer
--
--set @WrapProvider ='All'
--set @GLADCashSweepType ='All'
--set @BatchGroupID =3706;
return
with PeriodCashLedgerTransactions as -- Get Original cash entry value
(
	Select	
			CLT.datecreated,
			CLT.CLAccountID,
			CLT.Amount, 
			CLT.CCYCode,
			CLT.Narrative,
			COALESCE(CLT.NarrativeDetail,CLT.Narrative) as NarrativeDetail,
			CLT.Reference,
			CLT.MovementType,
			CLT.MovementSource,
			CLT.LedgerSource,
			CLT.RestrictSweepUntil,
			CLT.originatingcashentryid
	FROM 	dbo.CashLedgerTransactions clt
				Inner Join dbo.GladInternalCashSweepContent C on C.TransId = CLT.TransID
	WHERE	C.BatchGroupID = @BatchGroupID
 )
	Select	CLT.datecreated,
			CLT.CLAccountID,
			case 
				when CLT.MovementType ='PRODUCT_TRANSFER' and CLT.AMOUNT >0 and CE.Type='Withdrawal' then 
					CE.CLAccountID 
				when CLT.MovementType ='PRODUCT_TRANSFER' and CLT.AMOUNT >0 and CE.Type='Deposit' then 
					 CE.AccountNumber 
				when CLT.MovementType ='PRODUCT_TRANSFER' and CLT.AMOUNT <0 and CE.Type='Withdrawal' then 
					CE.CLAccountID 
				when CLT.MovementType ='PRODUCT_TRANSFER' and CLT.AMOUNT <0 and CE.Type='Deposit' then 
					CE.AccountNumber  
				when CLT.MovementType <>'PRODUCT_TRANSFER' and CLT.AMOUNT >0 	then
					CLT.CLAccountID	
			else
				''
			end as FromClAccountID ,
			case 
				when CLT.MovementType ='PRODUCT_TRANSFER' and CLT.AMOUNT >0 and CE.Type='Withdrawal' then 
					 CE.AccountNumber
				when CLT.MovementType ='PRODUCT_TRANSFER' and CLT.AMOUNT >0 and CE.Type='Deposit' then 
					  CE.CLAccountID  
				when CLT.MovementType ='PRODUCT_TRANSFER' and CLT.AMOUNT <0 and CE.Type='Withdrawal' then 
					CE.AccountNumber
				when CLT.MovementType ='PRODUCT_TRANSFER' and CLT.AMOUNT <0 and CE.Type='Deposit' then 
					CE.CLAccountID    
				when CLT.MovementType <>'PRODUCT_TRANSFER' and CLT.AMOUNT <0 then
					CLT.CLAccountID
			else
				''
			end as ToClAccountID ,
			CLT.CCYCode,
			Round(CLT.Amount,2) AS Amount , 
			CO.WrapProvider, 
			CD.Company, 
			WP.CMTOverdraftAllowed,
			case
				when ce2.PaymentSubType='LifetimeAllowanceTaxCharge' and clt.MovementType='TAX' then 'Excess Benefits Tax Charge'
				else CLT.Narrative
			end as Narrative,
			case
				when ce2.PaymentSubType='LifetimeAllowanceTaxCharge' and clt.MovementType='TAX' then 'Excess Benefits Tax Charge'
				else COALESCE(CLT.NarrativeDetail,CLT.Narrative)
			end as NarrativeDetail,
			CLT.Reference,
			CLT.MovementType,
			CLT.MovementSource			
	From PeriodCashLedgerTransactions CLT
		Inner Join dbo.ClientDetails CD ON CD.ClAccountID = CLT.ClAccountID 
		Inner Join dbo.Company CO ON CD.Company = CO.Company 
		Inner Join dbo.WrapProvider WP ON CO.WrapProvider = WP.WrapProvider
		Left Join discovery.dbo.cashentry CE on CLT.MovementType='PRODUCT_TRANSFER' and 'TFR'+ Cast(CE.ID as Varchar(10))=CLT.Reference  
		Left Join discovery.dbo.cashentry CE2 on CLT.originatingcashentryid=CE2.ID  
		
	Where	(@GLADCashSweepType ='All' or CD.GLADCashSweepType = @GLADCashSweepType) And 
			(@WrapProvider='All' or CO.WrapProvider = @WrapProvider)
GO
