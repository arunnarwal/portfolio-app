

CREATE FUNCTION [dbo].[fn_ValidateJournalAliasGLDepartmentCodes]()
RETURNS @valTable TABLE
([Type] varchar(10),[Message] varchar(100),DBName varchar(100),DBTable varchar(100), [Owner] varchar(100), SiteOwner varchar(100))
AS
BEGIN
	
IF (SELECT COUNT(*) FROM dbo.GladJournalActionAlias
WHERE GLDepartmentCode NOT IN (SELECT GLDepartmentCode FROM dbo.GladGLDepartment)) > 0 
BEGIN 
	BEGIN
		INSERT INTO @valTable(type, message, DBName, DBTable, owner, SiteOwner)
		VALUES ('Warning', 'Journal Alias GL Department Codes not set up.','ClientAccount', 'GladJournalActionAlias','Audrey Wan', 'All')
	END
END

return 

END
GO
