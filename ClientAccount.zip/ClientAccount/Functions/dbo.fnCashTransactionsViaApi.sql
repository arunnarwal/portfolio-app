/***
<Function>
    <Description>Cash Ledger transactions that is used by services to display on UI, all transaction types are included</Description>
</Function>
***/
CREATE FUNCTION dbo.fnCashTransactionsViaApi(@SubAccountIdsCsv AS VARCHAR(MAX), @ExcludeManualCashAdjustments AS BIT) RETURNS TABLE
AS
RETURN
    WITH SubAccountIds AS
    (
        SELECT Csv.TabValue AS SubAccountId, SECA.ClAccountID
        FROM CSFBMAster.dbo.Fn_convert_comma_to_table_char(@SubAccountIdsCsv) Csv
        INNER JOIN dbo.SEClientAccount AS SECA ON SECA.Id = Csv.TabValue
    ),
    Trans AS
    (
        SELECT
            GT.AccountId,
            GT.TransactionId,
            GT.LedgerDate,
            GT.MovementTypeId,
            GT.CurrencyId,
            GT.Amount,
            GT.MovementSourceId,
            GT.RestrictSweepUntil
        FROM CashLedger.GladTransactions AS GT
        WHERE
            GT.DisplayToClient = 1
            AND GT.Amount <> 0
            AND GT.AccountId IN (select S.SubAccountId FROM SubAccountIds S)
            AND (@ExcludeManualCashAdjustments = 0 OR NOT EXISTS (SELECT 1 FROM CashLedger.ManualCashAdjustmentTransactions MCAT WHERE MCAT.TransactionId = GT.TransactionId))

        UNION ALL

        SELECT
            GT.AccountId,
            GT.TransactionId,
            GT.LedgerDate,
            GT.MovementTypeId,
            GT.CurrencyId,
            GT.Amount,
            GT.MovementSourceId,
            CONVERT(SMALLDATETIME, NULL) RestrictSweepUntil
        FROM CashLedger.ExternalTransactions AS GT
        WHERE
            GT.DisplayToClient = 1
            AND GT.Amount <> 0
            AND GT.AccountId IN (select S.SubAccountId FROM SubAccountIds S)
    ),
    Clt AS
    (
        SELECT
            Acc.ClAccountID AS SubClAccountID,
            GT.TransactionId,
            GT.LedgerDate,
            MT.MovementType,
            C.CurrencyCode AS CcyCode,
            -GT.Amount           AS Amount,
            tn.Narrative,
            T.CreatedDateTime AS DateCreated,
            TOD.OrderID,
            TCED.CashEntryId AS OriginatingCashEntryID,
            TCD.ArlId,
            GT.RestrictSweepUntil,
            TCAD.CorporateActionId AS CorpActId,
            MS.MovementSource
        FROM  Trans AS GT
            INNER JOIN CashLedger.Transactions AS T ON GT.TransactionId = T.TransactionId
            INNER JOIN SubAccountIds AS Acc ON Acc.SubAccountId = GT.AccountId
            INNER JOIN CashLedger.MovementTypes AS MT ON MT.MovementTypeId = GT.MovementTypeId
            INNER JOIN CashLedger.Currencies AS C ON C.CurrencyId = GT.CurrencyId
            INNER JOIN CashLedger.MovementSources AS MS ON MS.MovementSourceId = GT.MovementSourceId
            LEFT JOIN CashLedger.TransactionNarratives AS TN ON TN.TransactionId = GT.TransactionId
            LEFT JOIN CashLedger.OrderTransactions AS TOD ON TOD.TransactionId = T.TransactionId
            LEFT JOIN CashLedger.ChargeTransactions AS TCD ON TCD.TransactionId = T.TransactionId
            LEFT JOIN CashLedger.CashEntryTransactions AS TCED ON TCED.TransactionId = T.TransactionId
            LEFT JOIN CashLedger.CorporateActionTransactions AS TCAD ON TCAD.TransactionId = t.TransactionId
        WHERE MT.MovementType <> 'CALL_TRANSACTION'
    ),
	ReversedTransactions AS (
        SELECT CLT.TransactionId FROM Clt
        INNER JOIN dbo.ManualCashAdjustmentRequests MCAR ON CLT.TransactionId = MCAR.OriginalContributionTransId AND MCAR.Status = 'Completed'
        GROUP BY CLT.TransactionId, CLT.Amount
        HAVING SUM(MCAR.Amount) = -CLT.Amount
    ),
    Transactions AS
    (
        SELECT  DISTINCT
                CLT.TransactionId,
                Sub.SubAccountId AS SubAccountId,
                CLT.DateCreated AS TransactionDate,
                COALESCE(CLT.RestrictSweepUntil, CLT.LedgerDate) AS SettlementDate,
                CLT.Amount,
                CLT.CCYCode AS Currency,
                PD.ProductType,
                CLT.Narrative,
                CLT.DateCreated,
                CLT.MovementType,
                ARL.Trantype AS ChargeType,
                CE.AWScripTransferID AS TransferId,
                COALESCE(CLT.OrderId, CLT.OriginatingCashEntryId, CLT.CorpActId, CLT.ArlId) AS SourceActionId,
                CLT.MovementSource
        FROM SubAccountIds Sub
        INNER JOIN Clt AS CLT ON CLT.SubClAccountId = Sub.ClAccountId
        INNER JOIN Discovery.dbo.ProductDetails AS PD ON CLT.SubClAccountId = PD.ClAccountId
        LEFT JOIN Discovery.dbo.AdvisorRevenueLedger ARL ON ARL.Id = CLT.ArlId
        LEFT JOIN Discovery.dbo.CashEntry CE ON CE.Id = CLT.OriginatingCashEntryId
        WHERE (@ExcludeManualCashAdjustments = 0 OR CE.Id IS NULL OR NOT EXISTS(SELECT 1 FROM ReversedTransactions RT WHERE RT.TransactionId = CLT.TransactionId))

        UNION ALL

        SELECT 	DISTINCT
                CMT.Id AS TransactionId,
                Sub.SubAccountId,
                CMT.TransactionDate,
                CMT.TransactionDate AS SettlementDate,
                CMT.Amount,
                CMT.Currency,
                PD.ProductType,
                NULL AS Narrative,
                CMT.TransactionDate AS DateCreated,
                CMT.TransType AS MovementType,
                NULL AS ChargeType,
                NULL AS TransferId,
                NULL AS SourceActionId,
                NULL As MovemenSource
        FROM
            SubAccountIds Sub
            INNER JOIN dbo.CmtTrans CMT ON CMT.ClAccountId = Sub.ClAccountId
            LEFT JOIN Discovery.dbo.ProductDetails PD ON PD.ClAccountID = CMT.ClAccountId
        WHERE
            CMT.TransType IN ('Interest','AIL','RWT','NRWT')
            AND CMT.DisplayToClient = 1
            AND CMT.Amount <> 0
            AND CMT.ClAccountId IN (SELECT S.ClAccountId FROM SubAccountIds S) -- In addition to the join to force a seek on CMTTrans
    )

    SELECT
        TransactionId,
        SubAccountId,
        TransactionDate,
        SettlementDate,
        Amount,
        Currency,
        ProductType,
        Narrative,
        DateCreated,
        MovementType,
        ChargeType,
        TransferId,
        SourceActionId,
        SUM(Amount) OVER (PARTITION BY SubAccountId ORDER BY TransactionDate, TransactionId ROWS UNBOUNDED PRECEDING) AS Balance,
        MovementSource
    FROM
        Transactions
