UPDATE
	dbo.AssetProvider
SET
	Name = 'Anon Name',
	AddressLine1 = 'Anon AddressLine1',
	AddressLine2 = 'Anon AddressLine2',
	AddressLine3 = 'Anon AddressLine3',
	PostCode = 'Anon',
	PhoneNumber = 'Anon PhoneNumber',
	FaxNumber = 'Anon FaxNumber',
	Email = 'Anon Email',
	ContactPerson = 'Anon ContactPerson',
	FSAAuthorisationNumber = FSAAuthorisationNumber;

UPDATE 
	C 
SET 
	C.CompanyName = N.Network
FROM dbo.Company C 
INNER JOIN dbo.Network N ON N.Network = C.Network 
WHERE C.CompanyName = N.NetworkName 


UPDATE 
	dbo.Network
SET	
	NetworkName = Network,
	FSAAuthorisationNumber = NULL,
	Email = 'anon@email.com',
	ExternalReferenceCode = NULL,
	Phone = '01179000001',
	Fax = '01179000001';

UPDATE dbo.BulkIllustrationScratchTable SET Surname = 'Anon Surname';

;WITH BankAccountUpdateData As
(
SELECT Id,
ROW_NUMBER() OVER (ORDER BY Id DESC) AS RN
FROM dbo.BankAccount
)

UPDATE 
	dbo.BankAccount
SET
	AccountNumber = CONVERT(VARCHAR,1234000 + RN),
	SortCode = '112233',
	Address1 = 'Address line 1',
	Address2 = 'Address line 2',
	Address3 = 'Address line 3',
	Address4 = 'Address line 4',
	BankName = 'Anon Bank' + CONVERT(VARCHAR, RN),
	AccountName = 'Bank Acc' + CONVERT(VARCHAR, RN),
	AccountReference = 'Bank Ref' + CONVERT(VARCHAR, RN)
FROM ClientAccount.dbo.BankAccount BA
INNER JOIN BankAccountUpdateData ON BA.Id = BankAccountUpdateData.Id

UPDATE
	Banking.SwiftInterimTransactions
SET
	AccountReference = 'Anon AccountRef',
	SupplementaryDetails = 'Anon Details';

UPDATE
	dbo.AccountNoteAttachments
SET
	Filename = 'Anon Filename',
	EditedBy = EditedBy;

UPDATE
	dbo.AccountNotes
SET
	Note = 'Anon Note';

UPDATE
	dbo.BankAccountHistory
SET
	OwnerType = 'Anon OwnerType',
	Owner = 'Anon Owner',
	AccountNumber = 'Anon AccountNumber',
	SortCode = 'An SC',
	AccountName = 'Anon AccountName';

UPDATE
	dbo.ClientAccountDetailsAudit
SET
	RetirementDate = GETDATE(),
	BeneficiaryTitle = 'Title',
	BeneficiaryFirstName = 'AnonName',
	BeneficiarySurname = 'AnonSurname',
	BeneficiaryDob = GETDATE(),
	BeneficiaryRelationship = 'Anon',
	DeathBeneficiaryTitle = 'Title',
	DeathBeneficiaryFirstName = 'AnonName2',
	DeathBeneficiarySurname = 'AnonSurname2',
	DeathBeneficiaryDob = GETDATE(),
	DeathBeneficiaryGender = 'Anon';

UPDATE
	dbo.ClientDetailsMarketingPreferences
SET
	Email = Email;

UPDATE
	dbo.ClientNotes
SET
	Notes = 'Anon Notes';

UPDATE
	dbo.Contact
SET
	contactName = 'Anon contactName',
	officeTelephone = 'Anon officeTelephone',
	mobileTelephone = 'Anon mobileTelephone',
	notes = 'Anon notes',
	emailaddress = 'Anon emailaddress';

UPDATE
	dbo.CorporateAccountManager
SET
	Email = 'Anon Email';

UPDATE
	dbo.CorporateClientAnnuityQuote
SET
	IllHealth = IllHealth,
	IsMarried = IsMarried,
	PartnerName = 'Anon PartnerName',
	PartnerDateOfBirth = GETDATE(),
	Gender = 'Anon Gender';

UPDATE
	dbo.CorporateEmployeeAssessmentOptOutAuditLog
SET
	IpAddress = 'Anon IpAddress',
	FullName = 'Anon  FullName',
	DateOfBirth = GETDATE();

UPDATE
	dbo.CorporateEmployeeAssessmentResults
SET
	EmployerName = 'Anon EmployerName',
	Title = 'Anon',
	FirstName = 'Anon FirstName',
	Surname = 'Anon Surname',
	NationalInsuranceNumber = 'Anon NIN',
	PermanentResidentialAddressLine1 = 'Anon Address1',
	PermanentResidentialAddressLine2 = 'Anon Address2',
	PermanentResidentialAddressLine3 = 'Anon Address3',
	PermanentResidentialAddressLine4 = 'Anon Address4',
	PermanentResidentialAddressPostcode = 'Anon AddressPostcode',
	TelephoneNumberHomeMobile = 'Anon TelephoneNumberHomeMobile',
	TelephoneNumberWork = 'Anon TelephoneNumberWork',
	EmailAddressWork = 'Anon EmailAddressWork',
	EmailAddressPersonal = 'Anon EmailAddressPersonal',
	DateOfBirth = GETDATE(),
	Gender = 'Other';

UPDATE
	dbo.CustomerOwnership
SET
	Active = Active,
	DateCreated = GETDATE(),
	UserIdCreated = UserIdCreated,
	DateModified = GETDATE(),
	UserIDModified = UserIDModified;

UPDATE
	dbo.CustomerRole
SET
	PrimaryCustomer = PrimaryCustomer,
	EffectiveDate = GETDATE(),
	DateCreated = GETDATE(),
	Status = 'Anon Status',
	DateModified = GETDATE(),
	UserIdCreated = UserIdCreated,
	Other = 'Anon Other',
	UserIDModified = UserIDModified;

UPDATE
	dbo.DebitCardPaymentsLog
SET
	decision = 'Anon decision',
	billTo_city = 'Anon billTo_city',
	billTo_country = 'CTR',
	billTo_firstname = 'Anon billTo_firstname',
	billTo_postalCode = 'Anon billTo_postalCode',
	billTo_street1 = 'Anon billTo_street1',
	billTo_street2 = 'Anon billTo_street2',
	ccAuthReply_amount = 'Anon ccAuthReply_amount',
	ccAuthReply_authorizedDateTime = 'Anon ccAuthReply_authorizedDateTime',
	ccAuthReply_avsCode = 'Anon ccAuthReply_avsCode',
	ccAuthReply_avsCodeRaw = 'Anon ccAuthReply_avsCodeRaw',
	ccAuthReply_cvCode = 'Anon ccAuthReply_cvCode',
	ccAuthReply_processorResponse = 'Anon ccAuthReply_processorResponse',
	ccAuthReply_reasonCode = 'Anon ccAuthReply_reasonCode',
	decision_publicSignature = 'Anon decision_publicSignature',
	billTo_email = 'Anon billTo_email',
	billTo_lastName = 'Anon billTo_lastName';

UPDATE
	dbo.DesignatedIndividual
SET
	Email = 'Anon Email';

UPDATE
	dbo.FacebookIntegration
SET
	EmailAddress = 'Anon EmailAddress';

UPDATE
	dbo.FSAAuthorisationFirms
SET
	PrincipalAddressLine1 = 'Anon PrincipalAddressLine1',
	PrincipalAddressLine2 = 'Anon PrincipalAddressLine2',
	PrincipalAddressLine3 = 'Anon PrincipalAddressLine3',
	PrincipalAddressLine4 = 'Anon PrincipalAddressLine4',
	PrincipalAddressLine5 = 'Anon PrincipalAddressLine5',
	PrincipalAddressLine6 = 'Anon PrincipalAddressLine6',
	TelephoneNoCountryPrefix = 'TelPr',
	TelephoneNoAreaCode = 'TelAreaC',
	TelephoneNoLocalNumber = 'Anon TelephoneNoLocalNumber';

UPDATE
	dbo.InvestmentProgrammeCorporateMembersHistory
SET
	IPRetirementDate = GETDATE();
	
UPDATE
	dbo.LeaversScratchTable
SET
	FirstName = 'Anon FirstName',
	LastName = 'Anon LastName',
	NationalInsuranceNumber = 'Anon',
	DateOfBirth = GETDATE();

UPDATE
	dbo.ManualCashAdjustmentBankAccount
SET
	ownerName = 'Anon ownerName',
	accountName = 'Anon accountName',
	accountNumber = 'Anon accountNumber',
	sortCode = 'Anon';

UPDATE
	dbo.ManualCashAdjustmentRequests
SET
	PaymentReference = 'Anon PaymentReference',
	ExcessReliefReasonDetails = 'Anon ExcessReliefReasonDetails';

UPDATE
	dbo.PensionDeathBeneficiaries
SET
	Title = 'Anon Title',
	Given = 'Anon Given',
	Surname = 'Anon Surname',
	Gender = 'O',
	DateOfBirth = GETDATE(),
	IRDNo = 'Anon',
	HasNoInsuranceNumber = HasNoInsuranceNumber,
	Address1 = 'Anon Address1',
	Address2 = 'Anon Address2',
	Address3 = 'Anon Address3',
	Address4 = 'Anon Address4',
	PostCode = 'Anon PostCode',
	Country = '61';

UPDATE
	dbo.MoneyLaunderingChecksDetails
SET
	HouseNumber = 'Anon HouseNumber',
	Street = 'Anon Street',
	City = 'Anon City',
	Title = 'Anon Title',
	Region = 'Anon Region',
	Postcode = 'Anon Postcode',
	Country = 'Anon Country',
	FirstName = 'Anon FirstName',
	LastName = 'Anon LastName',
	Initials = 'Anon Initials',
	[Day of birth] = GETDATE(),
	NiNo = 'Anon NiNo',
	Level = 'Anon Level',
	Status = 'Anon Status',
	HighRiskPolicyRules = 'Anon HighRiskPolicyRules',
	ErrorMessage = 'Anon ErrorMessage';

UPDATE
	dbo.SubCompanyContactDetails
SET
	EmailAddress = 'Anon EmailAddress',
	Phone = 'Anon Phone',
	Fax = 'Anon Fax',
	Address1 = 'Anon Address1',
	Address2 = 'Anon Address2',
	Address3 = 'Anon Address3',
	Address4 = 'Anon Address4',
	PostCode = 'Anon PostCode',
	Country = 'Anon Country';

UPDATE
	dbo.MVCWizardControllersHistory
SET
	ControllerName = 'Anon ControllerName';

UPDATE
	dbo.PensionLifetimeAllowanceHistory
SET
	Note = 'Anon Note',
	Cause = 'Anon Cause';

UPDATE
	dbo.PensionProtectionInformation
SET
	individualProtection2016Amount = individualProtection2016Amount,
	individualProtection2014Amount = individualProtection2014Amount,
	SevereIllHealthDeclarationDate = GETDATE();

UPDATE
	dbo.PeriodicStatementRunSettings
SET
	Notes = 'Anon Notes';

UPDATE
	dbo.PensionLifetimeAllowanceHistory
SET
	Note = 'Anon Note',
	Cause = 'Anon Cause';

UPDATE
	dbo.MembersScratchTable
SET
	NiNo = 'Anon NiNo';


UPDATE
	dbo.JuniorAccountInfo
SET
	NINO = 'Anon',
	RegisteredContactToChildRelation = 'Anon';


UPDATE
	dbo.AccountNoteComments
SET
	Comment = 'Anon Comment';


UPDATE
	Banking.SwiftStatementTransactions
SET
	AccountReference = 'Anon AccountRef',
	SupplementaryDetails = 'Anon Details';

UPDATE
	Banking.SwiftStatementMessages
SET
	AccountNumber = 'Anon AccountNumber';



UPDATE 
    AH
SET 
    Given = 'Anon Given', 
    Surname = 'Anon Surname',
    EmailAddress ='Anon EmailAddress',
    HomePhone = 'Anon HomePhone', 
    WorkPhone = 'Anon WorkPhone', 
    MobilePhone = 'Anon MobilePhone',
    MoneyLaunderingData = NULL,
    DateOfBirth = '01/01/' + Convert(varchar(10), YEAR(DateOfBirth)),
    Salutation = 'Anon Salutation',
    Employer = 'A Company',
    JobTitle = NULL,
	Title = 'Anon Title', 
	Initials = 'Anon', 
	Gender = NULL, 
	MaritalStatus = NULL, 
	OtherPassword = NULL, 
	Nationality = NULL, 
	Fax = 'Anon Fax', 
	AlternateEmail = NULL, 
	Relationship = NULL, 
	MoneyLaundering = NULL, 
	CompanyNumber = NULL,  
	TaxReference = NULL,  
	LivingWithPartner = NULL, 
	OtherType = NULL, 
	OtherName = NULL, 
	UKResident = 'Yes', 
	CivilPartner = NULL, 
	JointTenants = NULL, 
	UKTaxResident = 'Yes', 
	PreferredPhoneNo = NULL, 
	IRDNo = 0,
	DependentOfDeceasedMember = 0, 
	RelationShipToSettlor1 = NULL, 
	RelationShipToSettlor2 = NULL, 
	CompanyType = NULL, 
	DateAppointed = NULL, 
	DateRemoved = NULL, 
	smoker = NULL, 
	TrusteeStatus = NULL, 
	SettlorStatus = NULL, 
	BeneficiaryStatus = NULL, 
	DateOfDeath = NULL, 
	DateOfDeathNotified = NULL, 
	Deceased = NULL, 
	TaxResidency = 'GBR', 
	PEPStatus = NULL, 
	OFACStatus = NULL, 
	HMTStatus = NULL, 
	EUSDStatus = NULL, 
	EUSDStatusComment = NULL, 
	EUSDTaxIDNumber = NULL, 
	EUSDCountryofBirth = NULL, 
	EUSDTownofBirth = NULL, 
	EUSDReporting = NULL, 
	ExperianCode = NULL, 
	Suffix = NULL, 
	Occupation = NULL, 
	Industry = NULL, 
	countryofcitizenship = 'UK', 
	RiskRating = NULL, 
	OtherTitle = NULL, 
	PreferredEmailMethod = NULL, 
	PreferredContactMethod = 'Email', 
	DeathNotified = NULL,
	DependentOnDeceasedBelow75AtDeath = NULL,
	DependentCommencedAfterTY2015 = NULL,
	TargetCapitalAge = NULL,
	RetirementAge = NULL,
	SensitivePerson = NULL,
	CrownEmployeeOverseas = NULL,
	ArmedForcesMember = NULL,
	EmploymentStatus = NULL,
	Domicile = NULL,
	ExperianMessage = NULL,
	ExperianHRPolicyRule = NULL,
	ExperianScore = NULL,
	ProbateDate = GETDATE(),
	AMLTimestamp = NULL,
	TaxIdentificationNumber = NULL,
	CountryOfBirth = NULL,
	TownOfBirth = NULL,
	FinancialCrimeWarning = FinancialCrimeWarning,
	GoneAway = NULL,
	Dependents = NULL,
	sourceofwealth = NULL,
	sourceofwealthdetails = NULL,
	Bankrupt = NULL,
	DocumentsHardCopyRequired = DocumentsHardCopyRequired,
	BCE5cEventDate = NULL,
	IsTaxExempt = IsTaxExempt
FROM ClientAccount.dbo.AccountHolders AH

UPDATE a
SET
Name = AdvCode,
Title = NULL,
Address1 = 'Add Line 1', Address2 = 'Add Line 2', Address3 = 'Add Line 3', Address4 = 'Add Line 4',
PostCode ='AA1 1AA',
Phone = '01179000001' , 
FaxNumber = '01179000001',
EmailAddress = 'anon@anon.com', 
BankAccountCCYCode = 'GBP', 
BankAccountNo = NULL, 
TaxId = NULL, 
FSAAuthorisationNumber = 'Anon', 
Notes = null,
JobTitle = 'Anon JobTitle'
FROM dbo.Advisor a

UPDATE 
	ClientAccount.dbo.AccountAccessAttempts
SET 
	Email = 'anonymous.client@test.co.uk',
	DOB = '1980-10-01',
	NINO = 'NA123456A'

UPDATE ClientAccount.dbo.Address
SET 
	Context = 'Default', --current state
	OwnerType = OwnerType,	--no way to anonymize - can be Company, Branch or Advisor
	OwnerName = OwnerName,
	Country = 'GBR', 
	Type = 'Postal',
	address1 = 'Add Line 1', 
	address2 = 'Add Line 2', 
	address3 = 'Add Line 3', 
	address4 = 'Add Line 4', 
	PostCode = 'AA1 1AA'--, EmailAddress = ownerName + '@test.com'
WHERE address1 <> 'Add Line 1' AND address2 <> 'Add Line 2'

UPDATE 
    ClientAccount.dbo.Branches
SET 
    Email = NULL
WHERE 
    Email IS NOT NULL   

UPDATE dbo.CashLedgerAdjustments SET Narrative = ClACcountId + ' adjustment'
UPDATE dbo.CashLedgerAdjustmentsHistory SET Narrative = ClACcountId + ' adjustment'

UPDATE dbo.CashTransactions SET Note = CASE 
	WHEN Note = 'Cancelled for disaggregation' THEN 'Cancelled for disaggregation'
	ELSE NULL
END

UPDATE 
    dbo.ClientDetails
SET 
    IRDNo = 'Anon IRDno',
	ClientDisplayName = NULL, 
	ExecutorEmail = NULL, 
	Gender = NULL, 
	MaritalStatus = NULL, 
	MoneyLaunderingData = NULL, 
	OtherDetails = NULL, 
	POAEmail = NULL, 
	ReferredBy = NULL, 
	WHTDomicile = 'UK'
FROM 
    dbo.ClientDetails CD
WHERE 
    IRDNo IS NOT NULL 
    AND IRDNo <> ''

UPDATE 
	dbo.Company
SET 
	ParentCompany = NULL, 
	Email = CASE WHEN Email IS NOT NULL THEN Company + '@test.com' END, 
	phonenumber = '01179000001', 
	fax = '01179000001',
	FSAAuthorisationNumber = NULL, 
	NetworkFSAAuthorisationNumber = NULL, 
	PSD_FSAAuthorisationNumber = NULL, 
	PSD_NetworkFSAAuthorisationNumber = NULL,
	BankAccountNo = NULL, --All values expected to be NULL already
	CountryCode = 'GBR', 
	BankAccountCcyCode = 'GBP',
	ValuationReportEmailAddress = 'Anon ReportEmailAddress',
	PrimaryContactName = 'Anon PrimaryContactName',
	LeiCode = 'Anon LeiCode';

UPDATE 
	dbo.CorporateContactDetails 
SET 
	Email = 'anonymous@test.com',
	Phone = '0123456789', 
	Fax = '0123456789',
	ContactNotes = 'anon ContractNotes',
	ExtensionPhone = 'anon ExtensionPhone';


UPDATE dbo.CounterpartyReceipts SET Narrative = 'Receipt'
UPDATE dbo.CustodianAccounts SET Notes = '' WHERE Notes <> ''

SELECT AccountName OldAccountName, 
	WrapProvider + ' ' + BankAlias NewAccountName, 
	WrapProvider, 
	RIGHT('00000000' + CONVERT(VARCHAR(8), ID), 8) AccountNumber,
	RIGHT('000000' + CONVERT(VARCHAR(8), ID), 6) SortCode
INTO #GladBankAccounts
FROM dbo.GladBankAccounts
WHERE 1=1

UPDATE 
	dbo.GladCashSweepLog 
SET 	
	ChapsUniqueId = NULL
FROM dbo.GladCashSweepLog gcsl 
LEFT JOIN #GladBankAccounts fromacc ON fromacc.OldAccountName = gcsl.FromBankAccountName 
LEFT JOIN #GladBankAccounts toacc ON toacc.OldAccountName = gcsl.ToBankAccountName 
WHERE gcsl.FromBankAccountName IS NOT NULL OR gcsl.ToBankAccountName IS NOT NULL

UPDATE 
	dbo.HSBCAccUploadData 
SET 
	AccName = NULL, 
	AccountNo = NULL, 
	UKSortCode = NULL 

UPDATE 
	dbo.PensionArrangementMembers
SET 
	address1 = 'Anon address1', 
	address2 = 'Anon address2',		
	address3 = 'Anon address3',
	address4 = 'Anon address4', 
	postcode = 'Anon address4', 
	[DateofBirth] = GETDATE(),
	Given = 'Anon Given', 
	Surname = 'Anon Surname', 
	Title = 'Not Specified', 
	Initials = 'Anon', 
	Gender = NULL, 
	Relationship = NULL, 
	Country = '0'

UPDATE 
	dbo.BeneficiaryAuditLog
SET 
	address1 = 'Anon address1', 
	address2 = 'Anon address2',		
	address3 = 'Anon address3',
	address4 = 'Anon address4', 
	postcode = 'Anon address4', 
	[DateofBirth] = GETDATE(),
	Given = 'Anon Given', 
	Surname = 'Anon Surname', 
	Title = 'Not Specified', 
	Initials = 'Anon', 
	Gender = NULL, 
	Relationship = NULL, 
	Country = '0'
	   	 
UPDATE dbo.ReconciliationBatch SET Notes = NULL

UPDATE		se
SET			CPName      = 'Anon CPName',
			SearchKey   = 'Anon SearchKey',
			AccountName = 'Anon AccountName',
			AccountDesc = 'PRIVATE Account'
FROM		dbo.SEClientAccount se 
WHERE		se.ClAccountId LIKE '%[0-9]%';

UPDATE dbo.TradeRebookingAuthorisations SET Narrative = '', CompletedDate = NULL

UPDATE  ClientAccount.dbo.TrustDetailsHistory
SET 
[DateofBirth] = ah.dateofbirth, Given = ah.Given, Surname = ah.surname, 
address1 = 'add line 1', address2 = 'add line 2',address3 = 'add line 3',address4 = 'add line 4', 
country ='UK', postcode = 'AA1 1AA', Title = ah.Title, Gender = ah.Gender
FROM  ClientAccount.dbo.AccountHolders ah 
INNER JOIN Clientaccount.dbo.Fnheadaccounts() fnh on fnh.headclaccountid = ah.claccountid
INNER JOIN ClientAccount.dbo.TrustDetailsHistory tdh on tdh.claccountid = fnh.claccountid
WHERE address1 <> 'add line 1' AND address2 <> 'add line 2'

UPDATE dbo.WrapProvider SET DefaultBankSortCode = '111111'

UPDATE
	ClientAccount.Srit.FileTaxRegimeCustomerInfoStaging
SET
	NINO = 'NA123456A',
	DateOfBirth = '01/01/1980',
	Surname = 'Anon ' + CONVERT(VARCHAR(10), TaxRegimeCustomerInfoStagingId),
	ResidencyTaxStatus = '0',
	CorrectedNINO = 'NA123456A'

UPDATE ClientAccount.Srit.TaxRegimeCustomerInfo SET ResidencyTaxStatusId = 1	

UPDATE noninc 
	SET Narrative = ca.Type + ' ' + ca.InstrumentCode, 
	NarrativeDetail = ca.Type + ' ' + ca.InstrumentCode
FROM dbo.CANonIncomeJnl noninc INNER JOIN CorporateActions.dbo.CorporateAction ca ON ca.ID = noninc.CorpActId


UPDATE noninchist SET Narrative = 'Narrative', NarrativeDetail = 'NarrativeDetail'
FROM dbo.CANonIncomeJnlHistory noninchist INNER JOIN CorporateActions.dbo.CorporateAction ca ON ca.ID = noninchist.CorpActId

TRUNCATE TABLE dbo.GadRates 

UPDATE 
    dbo.WorkflowWizardClientSession
SET 
    [Status] = 'DELETED', 
	Note = '',
	WizardValuesBytes = NULL,
    WizardValues = NULL
WHERE 
    [Status] IN ('InProgress', 'REJECTEDAUTHORISATION', 'New', 'COMPLETE', 'PENDINGAUTHORISATION', 'SUBMITTED')

UPDATE 
    dbo.WorkflowWizardClientSession 
SET 
    AccountName = NULL
WHERE 
    AccountName IS NOT NULL

UPDATE dbo.XHubNaturalIncomeTransfer SET Narrative = '';
UPDATE dbo.XHubNaturalIncomeTransferStaging SET Narrative = '';

UPDATE 
	dbo.AdhocPaymentManualDestinationAccounts
SET 
	AccountName = 'Anon',
	AddressLine1 = '',
	AddressLine2 = '',
	PostCode = '',
	SortCode = NULL,
	NCCType = '',
	AccountNumber = 'AnonNumber',
	BIC = NULL,
	NationalClearingCode = '',
	IBAN = '',
	FFC = '',
	BankName = '',
	BankAddress1 = '',
	BankAddress2 = '',
	BankPostCode = '',
	BankCountry = '';

UPDATE 
	dbo.GladBankAccountSweeps 
SET 
	FromBankAccountNumber = '',
	FromBankAccountSortCode = '',
	ToBankAccountNumber = '',
	ToBankAccountSortCode = '',
	Narrative = NULL;

UPDATE
	dbo.BankStatementBatch
SET
	Source = 'Anon Source',
	AccountNumber = 'Anon AccountNumber',
	DateAdded = GETDATE(),
	Filename = 'Anon Filename';

UPDATE
	dbo.PulsePortfolios
SET
	ClientName = 'Anon ClientName';

UPDATE
	dbo.SupportDiagnosticEmail
SET
	EmailAddress = 'Anon EmailAddress';

UPDATE
	dbo.WorkplaceSavings
SET
	Salary = Salary;

UPDATE HE
SET HE.DisplayName = ADV.[Name]
FROM ClientAccount.dbo.HierarchyEntities HE
INNER JOIN ClientAccount.dbo.Advisor ADV ON ADV.ID = HE.EntityId AND HierarchyLevelId = 5
WHERE HE.DisplayName <> ADV.[Name]

UPDATE HE
SET HE.DisplayName = SECA.CPName
FROM ClientAccount.dbo.HierarchyEntities HE
INNER JOIN ClientAccount.dbo.SEClientAccount SECA ON SECA.ID = HE.EntityId AND HierarchyLevelId = 6
WHERE HE.DisplayName <> SECA.CPName

UPDATE	dbo.FtpConnections
SET		Party = 'Party ' + CAST(Id AS VARCHAR),
		Host = '',
		Password = '',
		UserName = '';

TRUNCATE TABLE dbo.AccountHolderstoProductsLifeAssured
TRUNCATE TABLE dbo.AlertEmailLog
TRUNCATE TABLE dbo.AuditLog
TRUNCATE TABLE dbo.BOSSterlingAccTransactions
TRUNCATE TABLE dbo.BwaToAuthorise
TRUNCATE TABLE dbo.CashTransactionsHistory
TRUNCATE TABLE dbo.ChapsManualAccounts 
TRUNCATE TABLE dbo.ClientAccountProviderAddress 
TRUNCATE TABLE dbo.ClientChangeLog 
TRUNCATE TABLE dbo.ClientDetailsHistory
TRUNCATE TABLE dbo.ClientDetails_Pending
TRUNCATE TABLE dbo.ClientDetails_Pending
TRUNCATE TABLE dbo.ClientInsertLog
TRUNCATE TABLE dbo.CMTInterestAdjustmentPreview 
TRUNCATE TABLE dbo.CompanyAddresses
TRUNCATE TABLE dbo.CompanyContacts
TRUNCATE TABLE dbo.CorporateActionsToNotifyToClients
TRUNCATE TABLE dbo.CounterpartyScripTransactions
TRUNCATE TABLE dbo.DocumentationLog	
TRUNCATE TABLE dbo.EFTMapping
TRUNCATE TABLE dbo.EmailAddresses
TRUNCATE TABLE dbo.EmailGroups
TRUNCATE TABLE dbo.Employer						
TRUNCATE TABLE dbo.ExternalAsset	
TRUNCATE TABLE dbo.FeeFICSchedule				
TRUNCATE TABLE dbo.FeeInvoicesSharesExtract		
TRUNCATE TABLE dbo.GladBankAccountsSippExclusions 
TRUNCATE TABLE dbo.GSClientDetail
TRUNCATE TABLE dbo.GSRegistration
TRUNCATE TABLE dbo.IncomeExternalBatch	
TRUNCATE TABLE dbo.OldCustody			
TRUNCATE TABLE dbo.RBSAccUploadData	
TRUNCATE TABLE dbo.ReconciliationNotes	
TRUNCATE TABLE dbo.ScripAdjustments	
TRUNCATE TABLE dbo.ScripTransfers	
TRUNCATE TABLE dbo.TemplateClients				
TRUNCATE TABLE dbo.TrustDetails
TRUNCATE TABLE dbo.TrustParticipantDetails
TRUNCATE TABLE dbo.WizardStatus	
TRUNCATE TABLE dbo.WorkflowWizardIZCheck
TRUNCATE TABLE Srit_Audit.CorrectedNinosCustomers
TRUNCATE TABLE Srit_Audit.TaxRegimeCustomerAudit
TRUNCATE TABLE Srit_Audit.TaxRegimeUnableToMatchAudit
TRUNCATE TABLE dbo.NZXReportingGroups	
TRUNCATE TABLE dbo.Results	
TRUNCATE TABLE dbo.TableChangeLog
TRUNCATE TABLE dbo.SFTPSecrets
TRUNCATE TABLE dbo.PulseHoldings
TRUNCATE TABLE dbo.PulseHoldingsRawData
TRUNCATE TABLE dbo.PulsePortfoliosRawData
TRUNCATE TABLE dbo.PulsePortfoliosStagingTable
TRUNCATE TABLE dbo.TargetRetirementFund
TRUNCATE TABLE dbo.TaxStatementsReportsCache
TRUNCATE TABLE dbo.WithdrawalCalculation_DestinationAccounts
TRUNCATE TABLE dbo.WorkplaceSavingsDetails
TRUNCATE TABLE dbo.CorporateEmployeeAssessmentOptOutToken

DROP TABLE #GladBankAccounts

DECLARE @ChunkSize AS INTEGER = 25000000;
DECLARE @MaxTransId AS INTEGER;
SELECT @MaxTransId = MAX(Id) FROM dbo.CMTTrans;

IF @MaxTransId IS NULL OR @MaxTransId = 0 
UPDATE dbo.CMTTrans SET AccountNumber = NULL, AccountName = NULL
ELSE
DECLARE @StartLine AS INTEGER = 0;
WHILE @StartLine <= @MaxTransId
BEGIN
UPDATE 
	dbo.CMTTrans
SET 
	AccountNumber = NULL
WHERE Id BETWEEN @StartLine AND (@StartLine + @ChunkSize) 
AND AccountNumber IS NOT NULL;

UPDATE 
	dbo.CMTTrans
SET 	
	AccountName = NULL
WHERE Id BETWEEN @StartLine AND (@StartLine + @ChunkSize) 
AND AccountName IS NOT NULL;

SET @StartLine = @StartLine + @ChunkSize;
END