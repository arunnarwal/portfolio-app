/***
<Schema>
	<Description>Schema for all tables related to GLAD</Description>
	<Service>Banking</Service>
	<Feature>GeneralLedger</Feature>
</Schema>
***/
CREATE SCHEMA [Glad]
AUTHORIZATION [dbo]
GO
