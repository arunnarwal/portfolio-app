CREATE SCHEMA [OperationsReport]
AUTHORIZATION [dbo]
GO
