/***
<Schema>
	<Description>Contains custom OMW client money objects</Description>
</Schema>
***/
CREATE SCHEMA ClientMoney_Omw AUTHORIZATION dbo
GO
