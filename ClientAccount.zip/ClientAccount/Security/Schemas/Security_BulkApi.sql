/***
<Schema>
	<Description>Contains objects to facilitate the bulk client account security migration</Description>
	<Service>Migration</Service>
	<Feature>Migration</Feature>
</Schema>
***/
CREATE SCHEMA [Security_BulkApi]
AUTHORIZATION [dbo]
GO
