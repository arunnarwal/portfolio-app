/***
<Schema>
	<Description>Schema for all tables related to TRADERS</Description>
	<Service>Traders</Service>
	<Feature>Trading</Feature>
</Schema>
***/
CREATE SCHEMA [Traders]
AUTHORIZATION [dbo]
GO
