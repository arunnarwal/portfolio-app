/***
<Schema>
	<Description>Contains objects required for ChargeProcessing</Description>
	<Service>Charges</Service>
	<Feature>Charges</Feature>
</Schema>
***/
CREATE SCHEMA [ChargeProcessing] AUTHORIZATION [dbo]
GO
