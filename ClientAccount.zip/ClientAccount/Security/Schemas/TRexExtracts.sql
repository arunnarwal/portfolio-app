/***
<Schema>
	<Description>
		Contains objects used to facilitate\execute extracts to TRex for reconciliations
	</Description>
</Schema>
***/
CREATE SCHEMA [TRexExtracts] AUTHORIZATION [dbo]
GO
