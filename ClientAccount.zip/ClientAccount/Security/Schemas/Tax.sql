/***
<Schema>
	<Description>Tax schema</Description>
	<Service>Unknown</Service>
	<Feature>Unknown</Feature>
</Schema>
***/
CREATE SCHEMA [Tax]
AUTHORIZATION [dbo]
GO
