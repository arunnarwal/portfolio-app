/***
<Table>
	<Description>Primary schema for FuzzySearch objects</Description>
</Table>
***/
CREATE SCHEMA [FuzzySearch]
GO
