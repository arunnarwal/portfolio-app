CREATE SCHEMA [HierarchyEntities]
AUTHORIZATION [dbo]
GO
