/***
<Schema>
	<Description>Schema for API objects for the core "Platform" database</Description>
	<Service>Transactions</Service>
	<Feature>Transactions</Feature>
</Schema>
***/
CREATE SCHEMA [Transactions]
AUTHORIZATION [dbo]
GO
