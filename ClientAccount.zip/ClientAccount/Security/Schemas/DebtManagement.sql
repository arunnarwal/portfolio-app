/***
<Schema>
	<Description>Schema for all tables related to DebtManagement</Description>	
	<Service>Unknown</Service>
	<Feature>Unknown</Feature>	
</Schema>
***/
CREATE SCHEMA [DebtManagement]
AUTHORIZATION [dbo]
GO
