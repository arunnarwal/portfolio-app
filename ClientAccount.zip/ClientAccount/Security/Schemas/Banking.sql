/***
<Schema>
    <Description>Contains objects for banking integration</Description>
</Schema>
***/
CREATE SCHEMA [Banking] AUTHORIZATION [dbo]
GO