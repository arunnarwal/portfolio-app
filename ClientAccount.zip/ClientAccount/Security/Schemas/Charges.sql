/***
<Schema>
	<Description>Contains objects for the Charges service</Description>
	<Service>Charges</Service>
	<Feature>Charges</Feature>
</Schema>
***/
CREATE SCHEMA [Charges] AUTHORIZATION [dbo]
GO
