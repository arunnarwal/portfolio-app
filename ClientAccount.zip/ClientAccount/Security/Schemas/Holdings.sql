/***
<Table>
	<Description>Schema for API objects for the core "Platform" database</Description>
	<Service>Portfolio Analysis<Service>
	<Feature>Holdings<Feature>
</Table>
***/
CREATE SCHEMA [Holdings]
AUTHORIZATION [dbo]
GO
