/***
<Schema>
	<Description>Schema for all tables related to Reconciliations</Description>
	<Service>Cash</Service>
	<Feature>Reconciliations</Feature>
</Schema>
***/
CREATE SCHEMA [Reconciliations]
AUTHORIZATION [dbo]
GO
